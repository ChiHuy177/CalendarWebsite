CREATE FUNCTION [dbo].[TVF_AppSourceInfo_PackageFingerprint_Holdlock]
(
    @SiteId uniqueidentifier,
    @PackageFingerprint binary(64)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppSourceInfo] WITH (INDEX=AppSourceInfo_PackageFingerprint, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        PackageFingerprint = @PackageFingerprint

go

