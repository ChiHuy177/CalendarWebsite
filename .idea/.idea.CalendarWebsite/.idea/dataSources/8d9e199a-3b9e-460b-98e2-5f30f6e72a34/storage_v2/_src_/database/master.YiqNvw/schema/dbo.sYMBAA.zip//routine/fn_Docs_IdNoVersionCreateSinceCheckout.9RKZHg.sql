CREATE FUNCTION [dbo].[fn_Docs_IdNoVersionCreateSinceCheckout](
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        TVF_Docs_Id(@SiteId, @DocId)
    WHERE
        VersionCreatedSinceSTCheckout = 0

go

