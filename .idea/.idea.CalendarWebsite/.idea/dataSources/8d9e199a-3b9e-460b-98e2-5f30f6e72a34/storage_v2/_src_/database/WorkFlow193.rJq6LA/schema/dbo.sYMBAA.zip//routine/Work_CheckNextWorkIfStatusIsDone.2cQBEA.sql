-- [Work_CheckNextWorkIfStatusIsDone] '4061','node-d7b8390a-0074-48ae-bd59-180258f0a29c','342262'   
   CREATE   PROC [dbo].[Work_CheckNextWorkIfStatusIsDone]   
   @workProcessId as nvarchar(500)   
   ,@nodeIdList as nvarchar(max)  
   ,@parentWork as nvarchar(50)   
   as   
   select   
   case when b.TrangThaiCongViec=N'Hủy' or b.TrangThaiCongViec=N'Huỷ' then N'Từ chối' else b.TrangThaiCongViec end as TrangThaiCongViec,   
   a.QuyTrinhDinhKem, a.Nodeid,c.WorkflowId   
   ,NextStep,d.Title , d.CategoryWorkProcessId   
   into #a   
   from Dynamic.Data_WORK a   
   inner join Dynamic.Data_RESOURCETTFC b on a.TrangThaiCongViec= trim(str(b.UserWorkflowId))   
   inner join Dynamic.Data_WORK as e on a.CongViecCha=e.UserWorkflowId   
   inner join Dynamic.Data_TMDSQTCV c on c.UserWorkflowId=e.QuyTrinhDinhKem   
   inner join Dynamic.Data_LSQTCV d on TRIM(STR(c.UserWorkflowId))=d.CategoryWorkProcessId and a.Nodeid=d.Nodeid   
   where a.Nodeid in (select * from string_split(@nodeIdList,','))   
   and e.QuyTrinhDinhKem=@workProcessId and a.CongViecCha= @parentWork   
   select a.Title as Name,a.CategoryWorkProcessId,a.Nodeid,Step, NextStep , a.CategoryWorkProcessId as QuyTrinhDinhKem   
   ,a.Title
   into #b   
   from Dynamic.Data_LSQTCV a   
   inner join (   
   select a.CategoryWorkProcessId, b.value from #a a   
   CROSS APPLY STRING_SPLIT(ISNULL(a.NextStep,''),',') AS b   
   ) b on a.Step=b.value and a.CategoryWorkProcessId=b.CategoryWorkProcessId   
   select b.* from #a a   
   inner join #b b on b.Name=a.TrangThaiCongViec   
   drop table #a   
   drop table #b   
go

