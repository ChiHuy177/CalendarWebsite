CREATE PROCEDURE [dbo].[proc_ReturnCachedNavAcls](
    @DocSiteId   uniqueidentifier,
    @Webs_Id     uniqueidentifier,
    @Webs_NavParentWebId uniqueidentifier,
    @CachedNavDirty int = NULL,
    @HasScopeCache bit = NULL)
AS    
    SET NOCOUNT ON
    DECLARE @ret int
    IF @CachedNavDirty IS NULL
    BEGIN
        SELECT TOP 1
            @CachedNavDirty = CachedNavDirty,
            @HasScopeCache = CASE WHEN CachedNavScope IS NULL THEN 0 ELSE 1 END
        FROM
            TVF_Webs_Id(@DocSiteId, @Webs_Id) AS Webs
    END
    IF (@CachedNavDirty = 0 AND
         (@HasScopeCache = 1 OR @Webs_NavParentWebId IS NOT NULL))
    BEGIN
        EXEC @ret = proc_GetWebNavAclsForCachedScope
            @DocSiteId, @Webs_Id, @Webs_NavParentWebId
        IF (@ret <> 0)
        BEGIN
            RETURN @ret
        END
    END
    ELSE
    BEGIN
        SELECT 
            NULL
        WHERE
            1 = 0
    END
    RETURN 0

go

