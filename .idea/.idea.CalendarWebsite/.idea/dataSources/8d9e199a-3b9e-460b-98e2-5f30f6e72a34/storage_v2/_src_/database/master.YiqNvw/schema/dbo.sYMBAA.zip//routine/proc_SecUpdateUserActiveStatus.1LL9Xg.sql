CREATE PROCEDURE [dbo].[proc_SecUpdateUserActiveStatus](
    @SiteId uniqueidentifier,
    @UserId int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    IF @UserId = 1073741823 OR
        @UserId = 1073741822
    BEGIN
        SET @RET = 0
        GOTO cleanup
    END
    DECLARE @OldIsActive bit    
    DECLARE @UserInfoListId uniqueidentifier
    DECLARE @RootWebId uniqueidentifier
    DECLARE @ColName nvarchar(64)
    DECLARE @RowOrdinal tinyint    
    SELECT TOP 1
        @UserInfoListId = S.UserInfoListId,
        @RootWebId = S.RootWebId,
        @RowOrdinal = S.UserIsActiveFieldRowOrdinal,
        @ColName = S.UserIsActiveFieldColumnName
    FROM
        TVF_Sites_NoLock_Id(@SiteId) AS S
    SELECT TOP 1
        @OldIsActive = UI.tp_IsActive
    FROM
        TVF_UserInfo_PK(@SiteId, @UserId) AS UI
    WHERE
        UI.tp_Deleted = 0
    IF @OldIsActive IS NULL
    BEGIN
        SET @RET = 0
        GOTO cleanup
    END
    IF @UserInfoListId IS NOT NULL AND
        @ColName IS NOT NULL
    BEGIN
        DECLARE @QueryString nvarchar(1024)
        DECLARE @ItemParentId uniqueidentifier
        DECLARE @ItemDocId uniqueidentifier
        SELECT TOP 1
            @ItemParentId = tp_ParentId,
            @ItemDocId = tp_DocId
        FROM
            TVF_UserData_NoLock_ListItemLevelRow(@SiteId, @UserInfoListId, @UserId, 1, @RowOrdinal) AS UD
        SET @QueryString = 
        N'UPDATE 
            UD
        SET
            UD.' + @ColName + ' = 1
        FROM' +
           ' AllUserData AS UD WITH(INDEX=AllUserData_ParentId)' +
       ' WHERE
            UD.tp_SiteId = @SiteId AND
            UD.tp_DeleteTransactionId = 0x AND
            UD.tp_IsCurrentVersion = CONVERT(bit, 1) AND
            UD.tp_ParentId = @ItemParentId AND
            UD.tp_DocId = @ItemDocId AND
            UD.tp_CalculatedVersion = 0 AND
            UD.tp_Level = 1 AND
            UD.tp_RowOrdinal = @RowOrdinal'
        EXEC sp_executesql @QueryString,
            N'@SiteId uniqueidentifier, @ItemParentId uniqueidentifier, @ItemDocId uniqueidentifier, @RowOrdinal int',
            @SiteId, @ItemParentId, @ItemDocId, @RowOrdinal
        SET @RET = @@ERROR
        IF @RET <> 0
            GOTO cleanup
    END
    UPDATE
        UI
    SET
        UI.tp_IsActive = 1
    FROM
        TVF_UserInfo_PK(@SiteId, @UserId) AS UI
    IF @OldIsActive = 0
    BEGIN
        EXEC proc_LogChange @SiteId, NULL, NULL, @UserId, NULL, NULL, @UserId,
            NULL, 8192, 128, NULL
    END
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @RET

go

