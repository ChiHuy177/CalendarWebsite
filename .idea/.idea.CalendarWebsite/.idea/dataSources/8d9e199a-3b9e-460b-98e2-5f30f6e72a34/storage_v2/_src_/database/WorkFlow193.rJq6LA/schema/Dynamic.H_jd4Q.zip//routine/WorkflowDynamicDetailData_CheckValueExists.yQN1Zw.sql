CREATE     
    PROCEDURE [Dynamic].[WorkflowDynamicDetailData_CheckValueExists] 
	@WorkflowId BIGINT,
	@ColumnName nvarchar(max),
	@Value nvarchar(max),
	@IgnoreUserWorkflowId nvarchar(max) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @IgnoreUserWorkflowId IS NULL
		SET @IgnoreUserWorkflowId = '';

	DECLARE @TableName NVARCHAR(MAX), @TableCode NVARCHAR(MAX), @TableNameResult NVARCHAR(MAX);
		DECLARE @SqlScript NVARCHAR(MAX) = '';


		SET @TableName =(
			SELECT Title
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
		SET @TableCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)

		set @TableNameResult = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableCode, '^a-z0-9')
			);		

		SET @SqlScript =  'SELECT 
								d.UserWorkflowId
								FROM ' + @TableNameResult + ' d 
									INNER JOIN UserWorkflow u ON u.Id = d.UserWorkflowId
													WHERE [' + @ColumnName + '] = N''' + @Value + '''
														AND u.IsDeleted = 0
														AND u.IsDraft <> 1
														AND (
															''' + @IgnoreUserWorkflowId + ''' = ''''
															OR ''' + @IgnoreUserWorkflowId +''' <> CAST(u.Id AS VARCHAR(MAX))
															)';
		print @SqlScript
		EXEC sp_ExecuteSql @SqlScript;
END
go

