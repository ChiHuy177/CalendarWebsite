
-- =============================================
-- Author:		DuyDam
-- Create date: 16/11/2021
-- Description:	Remvoe all other un executed steps and set index of passed step into 0
-- =============================================
CREATE PROCEDURE [dbo].[RejectUserWorkflowAndReturnToStep1] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DELETE [dbo].[UserWorkflowStep]
	WHERE UserWorkflowId = @UserWorkflowId
		AND FinishTime IS NULL
		AND (
			Action IS NULL
			OR Action = ''
			);

	UPDATE [dbo].[UserWorkflowStep]
	SET [Index] = 0
	WHERE UserWorkflowId = @UserWorkflowId;
END
go

