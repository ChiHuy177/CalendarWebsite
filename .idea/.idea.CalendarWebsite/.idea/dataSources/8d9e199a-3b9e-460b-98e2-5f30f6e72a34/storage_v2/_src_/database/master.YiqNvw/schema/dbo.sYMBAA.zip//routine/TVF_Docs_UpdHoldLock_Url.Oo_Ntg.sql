CREATE FUNCTION [dbo].[TVF_Docs_UpdHoldLock_Url]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (UPDLOCK, HOLDLOCK, INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName = @DirName AND
        LeafName = @LeafName

go

