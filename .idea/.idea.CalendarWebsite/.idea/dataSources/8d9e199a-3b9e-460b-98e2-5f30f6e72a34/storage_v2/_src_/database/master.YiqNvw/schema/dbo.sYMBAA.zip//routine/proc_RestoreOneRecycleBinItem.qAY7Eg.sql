CREATE PROCEDURE [dbo].[proc_RestoreOneRecycleBinItem](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @UserId int,
    @AppPrincipalId int,
    @DeleteUserId int,
    @ItemType tinyint,
    @ListId uniqueidentifier,
    @ListItemId int,
    @DocId uniqueidentifier,
    @DocVersionId int,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @Title nvarchar(260),
    @ListDirName nvarchar(256),
    @ScopeId uniqueidentifier,
    @ThresholdRowCount int,
    @DeleteTransactionId varbinary(16),
    @ChildDeleteTransactionId varbinary(16),
    @FailedDirName nvarchar(256) OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @ContainingListBaseType int
    DECLARE @ExceptionList bit
    DECLARE @ContainingListFlags bigint
    DECLARE @ContainingListId uniqueidentifier
    DECLARE @DocClientId varbinary(16)
    DECLARE @EffectiveDeleteTransactionId varbinary(16)
    DECLARE @UpdateListItemCount bit
    SET @UpdateListItemCount = 0    
    IF (@ChildDeleteTransactionId = 0x)
        SET @EffectiveDeleteTransactionId = @DeleteTransactionId
    ELSE
        SET @EffectiveDeleteTransactionId = @ChildDeleteTransactionId
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    SELECT TOP 1
        @DocClientId = D.ClientId
    FROM
        TVF_AllDocs_NoLock_Id(@SiteId, @DocId) AS D
    IF (@ListId IS NOT NULL AND 
        (@ItemType = 4 OR
        @ItemType = 5))
    BEGIN
        SELECT TOP 1
            @ExceptionList = tp_NoThrottleListOperations
        FROM
            TVF_AllLists_CI(@SiteId, @WebId, @ListId) AS AL
        IF @ExceptionList = 1
            SET @ThresholdRowCount = 0        
    END        
    IF ((@ThresholdRowCount > 0) AND (
        @ItemType = 4 OR
        @ItemType = 5 OR
        @ItemType = 6))
    BEGIN
        DECLARE @Count int
        SET @Count = 0
        SELECT TOP (@ThresholdRowCount + 1)
            @Count = COUNT(1)
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        WHERE
            AD.Level = 1
        IF @Count > @ThresholdRowCount
        BEGIN
            SET @Ret = 36
            GOTO cleanup
        END
    END
    IF (@ItemType = 2 OR @ItemType = 8)
    BEGIN
        DECLARE @DeltaSize bigint
        SELECT
            @DeltaSize = SUM(R.Size)
        FROM
            TVF_RecycleBin_DelIdChildId(
                @SiteId,
                @DeleteTransactionId, 
                @ChildDeleteTransactionId) AS R
        WHERE
            R.SiteId = @SiteId AND
            R.WebId = @WebId AND
            R.DeleteUserId = @DeleteUserId
        EXEC proc_AddStorageMetricsChange @SiteId, @DocId, @DeltaSize, 1
    END
    IF (@ItemType = 2)
    BEGIN
        DECLARE @NewListId uniqueidentifier
        DECLARE @NewItemId int
        DECLARE @NewDocParentId uniqueidentifier
        DECLARE @NewLeafName nvarchar(128)
        SELECT TOP 1
            @NewListId = D.ListId,
            @NewItemId = D.DoclibRowId,
            @NewDocParentId = D.ParentId,
            @NewLeafName = D.LeafName
        FROM 
            TVF_Docs_Id(@SiteId, @DocId) AS D
        IF (@@ROWCOUNT = 0)
        BEGIN
            SET @Ret = 1979
            GOTO cleanup
        END
        UPDATE
            AWP
        SET
            AWP.tp_Deleted = 0
        FROM
            TVF_AllWebParts_SiteIsCurPageIdPageVer(
                @SiteId,
                CONVERT(bit, 0),
                @DocId,
                @DocVersionId) AS AWP
        WHERE
            AWP.tp_Deleted = CONVERT(bit, 1)
        UPDATE
            ADV
        SET
           DeleteTransactionId = 0x
        FROM
            TVF_AllDocVersions_SiteDocIdUIVersion(
                @SiteId, 
                @DocId, 
                @DocVersionId) AS ADV
        WHERE
            ADV.DeleteTransactionId = @EffectiveDeleteTransactionId
        UPDATE
            AUD
        SET
            AUD.tp_DeleteTransactionId = 0x,
            AUD.tp_ListId = @NewListId,
            AUD.tp_ID = @NewItemId,
            AUD.tp_ParentId = @NewDocParentId
        FROM
            TVF_AllUserData_ListDelItemCal(
                @SiteId, 
                @NewListId, 
                @EffectiveDeleteTransactionId, 
                @NewItemId, 
                @DocVersionId) AS AUD
        DELETE 
            R
        FROM
            TVF_RecycleBin_DelIdChildId(
                @SiteId, 
                @DeleteTransactionId, 
                @ChildDeleteTransactionId) AS R
        WHERE
            R.WebId = @WebId AND
            R.DeleteUserId = @DeleteUserId
        SET @Ret = 0
        GOTO cleanup
    END 
    SET @ContainingListBaseType = -1
    SET @ContainingListFlags = 0x0
    SET @ContainingListId = 0x0
    DECLARE @AttachmentSubfolderUrl nvarchar(260)
    IF (@ListId IS NOT NULL AND 
        (@ItemType = 1 OR
        @ItemType = 5) OR
        @ItemType = 3 OR
        @ItemType = 8 OR
        @ItemType = 7)
    BEGIN
        IF @ListDirName IS NULL
        BEGIN
            SET @Ret = 1359
            GOTO cleanup
        END
        DECLARE @CurrentListDirName nvarchar(256)
        SELECT TOP 1
            @CurrentListDirName = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END,
            @ContainingListBaseType = L.tp_BaseType,
            @ContainingListFlags = L.tp_Flags,
            @ContainingListId = L.tp_ID,
            @AttachmentSubfolderUrl = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END + N'/'+ N'Attachments'
        FROM
            TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
        CROSS APPLY
            TVF_Docs_Id(L.tp_SiteId, L.tp_RootFolder) AS D
        IF @CurrentListDirName IS NULL OR @ListDirName <> @CurrentListDirName
        BEGIN
            SET @Ret = 1979
            GOTO cleanup
        END
    END
    IF (@ItemType = 3 AND
        @ContainingListBaseType = 4 AND
        @ContainingListFlags & 0x800 = 0)
    BEGIN
        DECLARE @HasOtherResponses int
        DECLARE @MeetingInstanceId int
        SELECT TOP 1
            @MeetingInstanceId = UD.tp_InstanceID
        FROM
            TVF_AllUserData_ListDelVerItem(
                @SiteId, 
                @ContainingListId, 
                @EffectiveDeleteTransactionId, 
                CONVERT(bit, 1), 
                @ListItemId) AS UD
        EXEC @HasOtherResponses = proc_UserHasDataItems 
            @SiteId, 
            @ContainingListId, 
            @UserId,    
            @MeetingInstanceId,
            @RequestGuid OUTPUT
        IF @HasOtherResponses <> 0 
        BEGIN
            SET @Ret = 80
            GOTO cleanup
        END
    END
    IF (@ItemType = 4 AND 
        EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_Lists_WebId(@SiteId, @WebId) AS L
            WHERE
                L.tp_Title = @Title))
    BEGIN
        SET @Ret = 183
        GOTO cleanup
    END
    IF (@ItemType = 1 OR
        @ItemType = 5 OR
        @ItemType = 6 OR
        @ItemType = 4 OR
        @ItemType = 7)
    BEGIN
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_Docs_Url(@SiteId, @DirName, @LeafName))
        BEGIN
            SET @Ret = 80
            GOTO cleanup
        END
    END
    IF (@ItemType = 7 OR
        @ItemType = 8)
    BEGIN
        IF NOT EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_UserData_ListItem(@SiteId, @ContainingListId, @ListItemId))
        BEGIN
            SET @Ret = 1979
            GOTO cleanup
        END
    END
    IF (@ItemType = 6 AND 
        EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_AllLists_WebId(@SiteId, @WebId) AS L1
            CROSS APPLY
                TVF_AllLists_WebId(L1.tp_SiteId, L1.tp_WebId) AS L2
            WHERE
                L1.tp_DeleteTransactionId = @EffectiveDeleteTransactionId AND
                L2.tp_Title = L1.tp_Title))
    BEGIN
        SET @Ret = 80
        GOTO cleanup
    END
    DECLARE @DirDirName nvarchar(256)
    DECLARE @DirLeafName nvarchar(128)
    EXEC proc_SplitUrl
        @DirName,
        @DirDirName OUTPUT,
        @DirLeafName OUTPUT
    DECLARE @NewParentId uniqueidentifier
    DECLARE @NewScopeId uniqueidentifier
    DECLARE @NewCtoOffset int
    DECLARE @NeedChangeParent bit    
    SELECT TOP 1
        @NewParentId = D.Id,
        @NewScopeId = D.ScopeId,
        @NewCtoOffset = D.CtoOffset
    FROM
        TVF_Docs_Url(@SiteId, @DirDirName, @DirLeafName) AS D
    IF @NewParentId IS NULL
    BEGIN
        SET @Ret = 3
        SET @FailedDirName = @DirName;
        GOTO cleanup
    END
    IF @ItemType = 8
    BEGIN
        SET @NeedChangeParent = 0
    END
    ELSE
    BEGIN
        DECLARE @OldParentId uniqueidentifier    
        SET @OldParentId = NULL
        SELECT TOP 1
            @OldParentId = AD.ParentId
        FROM
            TVF_AllDocs_Id(@SiteId, @DocId) AS AD
        WHERE
            AD.DeleteTransactionId = @EffectiveDeleteTransactionId
        IF @OldParentId IS NULL AND @ItemType <> 4
        BEGIN
            SET @Ret = 1359
            GOTO cleanup
        END
        IF @OldParentId = @NewParentId
            SET @NeedChangeParent = 0
        ELSE
            SET @NeedChangeParent = 1
    END
    DECLARE @FixUpCtoOffset bit    
    SET @FixUpCtoOffset = 0   
    DECLARE @CtoOffset int
    IF @ItemType = 5
    BEGIN
        SELECT TOP 1
            @FixUpCtoOffset = 
                CASE 
                    WHEN AD.DocFlags & 8192 <> 0 THEN 0 
                    ELSE 1 
                END,
            @CtoOffset = AD.CtoOffset
        FROM
            TVF_AllDocs_DelIdUrl(
                @SiteId, 
                @EffectiveDeleteTransactionId, 
                @DirName, 
                @LeafName) AS AD
    END
    IF (@ListId IS NOT NULL AND @ListItemId IS NOT NULL)
    BEGIN
        IF (@ItemType = 3 OR @ItemType = 1)
        BEGIN    
            EXEC @Ret = proc_CheckItemForDuplicateValues
                @SiteId,
                @WebId,
                @ListId,
                @ListItemId,
                1,
                @EffectiveDeleteTransactionId
            IF @Ret <> 0
            BEGIN
                GOTO CLEANUP
            END
            EXEC @Ret = proc_CheckItemForInvalidParentLookups
                @SiteId,
                @ListId,
                @ListItemId,
                1,
                @DeleteTransactionId,
                @EffectiveDeleteTransactionId
            IF @Ret <> 0
            BEGIN
                GOTO CLEANUP
            END
        END
        ELSE IF (@ItemType = 5)
        BEGIN
            EXEC @Ret = proc_CheckFolderForDuplicateValues
                @SiteId,
                @WebId,
                @ListId,
                @ListItemId,
                @DirName,
                @LeafName,
                1,
                @EffectiveDeleteTransactionId
            IF @Ret <> 0
            BEGIN
                GOTO CLEANUP
            END
            EXEC @Ret = proc_CheckFolderForInvalidParentLookups
                @SiteId,
                @WebId,
                @ListId,
                @ListItemId,
                @DirName,
                @LeafName,
                1,
                @DeleteTransactionId,
                @EffectiveDeleteTransactionId
            IF @Ret <> 0
            BEGIN
                GOTO CLEANUP
            END
        END
    END
    IF (@ItemType = 1 OR
        @ItemType = 3 OR
        @ItemType = 8 OR
        @ItemType = 5 OR
        @ItemType = 4)
    BEGIN    
        UPDATE
            I
        SET
            I.Deleted = 0
        FROM
            TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD
        CROSS APPLY
            TVF_ImmedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, AUD.tp_ID) AS I
        OPTION (FORCE ORDER)
        UPDATE
            S
        SET
            S.Deleted = 0
        FROM
            TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD
        CROSS APPLY
            TVF_SchedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, AUD.tp_ID) AS S
        OPTION (FORCE ORDER)
        UPDATE
           ADV
        SET
           DeleteTransactionId = 0x
        FROM
           TVF_AllDocVersions_SiteDocId(@SiteId, @DocId) AS ADV
        WHERE
           ADV.DeleteTransactionId = @EffectiveDeleteTransactionId
        IF @NeedChangeParent = 1
        BEGIN
            UPDATE
                AUD
            SET
                AUD.tp_DeleteTransactionId = 0x,
                AUD.tp_ParentId = 
                    CASE
                        WHEN AUD.tp_DocId = @DocId THEN @NewParentId
                        ELSE AUD.tp_ParentId
                    END
            FROM
                TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD
        END
        ELSE
        BEGIN
            UPDATE
                AUD
            SET
                AUD.tp_DeleteTransactionId = 0x
            FROM
                TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD
        END
    END
    ELSE IF (@ItemType = 6)
    BEGIN
        DECLARE @ItemsDeleted table (
            ListId uniqueidentifier NOT NULL,
            ItemId int NOT NULL)
        INSERT INTO 
            @ItemsDeleted (ListId, ItemId)
        SELECT
            AUD.tp_ListId,
            AUD.tp_ID
        FROM
            TVF_AllLists_WebId(@SiteId, @WebId) AS AL
        CROSS APPLY
            TVF_AllUserData_ListDel(AL.tp_SiteId, AL.tp_ID, AL.tp_DeleteTransactionId) AS AUD
        WHERE
            AL.tp_DeleteTransactionId = @EffectiveDeleteTransactionId
        UPDATE
            ImmedSubscriptions
        SET
            Deleted = 0
        WHERE
            SiteId = @SiteId AND
            EXISTS(
                SELECT 
                    1 
                FROM 
                    @ItemsDeleted D
                WHERE
                    D.ListId = ImmedSubscriptions.ListId AND
                    D.ItemId = ImmedSubscriptions.ItemId)
        UPDATE
            SchedSubscriptions
        SET
            Deleted = 0
        WHERE
            SiteId = @SiteId AND
            EXISTS(
                SELECT 
                    1
                FROM 
                    @ItemsDeleted D
                WHERE
                    D.ListId = SchedSubscriptions.ListId AND
                    D.ItemId = SchedSubscriptions.ItemId)
        UPDATE
            U
        SET
            U.tp_DeleteTransactionId = 0x
        FROM
            @ItemsDeleted as D
        CROSS APPLY
            TVF_AllUserData_ListDelItem(@SiteId, D.ListId, @EffectiveDeleteTransactionId, D.ItemId) AS AUD
    END
    DECLARE @ItemCountDelta int
    SET @ItemCountDelta = 0
    IF @ItemType = 1 OR @ItemType = 7
    BEGIN
        IF @ItemType = 1
        BEGIN
            EXEC @Ret = proc_RestoreFixupImageInternal
                @SiteId,
                @WebId,
                @EffectiveDeleteTransactionId,
                @DirName,
                @LeafName
            IF (@Ret <> 0)
                GOTO cleanup
        END
        IF @ItemType = 1
        BEGIN
            SELECT
                @ItemCountDelta = COUNT(1)
            FROM
                TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
            WHERE
                AD.DoclibRowId IS NOT NULL AND
                AD.IsCurrentVersion = 1
        END
        UPDATE
            AD
        SET
            AD.ParentId = 
                CASE 
                    WHEN AD.ParentId = @OldParentId THEN @NewParentId 
                    ELSE AD.ParentId 
                END,
            AD.ScopeId =
                CASE
                    WHEN AD.ScopeId = @ScopeId THEN @NewScopeId 
                    ELSE AD.ScopeId 
                END,
            AD.CtoOffset =
                CASE
                    WHEN 
                        @FixUpCtoOffset = 1 AND 
                        (AD.CtoOffset IS NULL AND 
                        @CtoOffset IS NULL OR AD.CtoOffset = @CtoOffset) 
                        THEN @NewCtoOffset
                    ELSE AD.CtoOffset
                END,
            AD.DeleteTransactionId = 0x
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        UPDATE
            P
        SET
            P.tp_Deleted = 0
        FROM
            TVF_Personalization_SitePage(@SiteId, @DocId) AS P
        WHERE
            P.tp_Deleted = CONVERT(bit, 1)
        UPDATE
            AWP
        SET
            AWP.tp_Deleted = 0
        FROM
            TVF_AllWebParts_SitePageId(
                @SiteId,
                @DocId) AS AWP
        WHERE
            AWP.tp_Deleted = CONVERT(bit, 1)
        UPDATE
            ADV
        SET
            DeleteTransactionId = 0x
        FROM
            TVF_AllDocVersions_SiteDocId(@SiteId, @DocId) AS ADV
        WHERE
            DeleteTransactionId = @EffectiveDeleteTransactionId
    END
    ELSE
    BEGIN
        IF (@ItemType = 4 OR
            @ItemType = 5 OR
            @ItemType = 6)
        BEGIN
            UPDATE
                ADV
            SET
                ADV.DeleteTransactionId = 0x
            FROM
                TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
            CROSS APPLY
                TVF_AllDocVersions_SiteDocId(AD.SiteId, AD.Id) AS ADV
            WHERE
                ADV.DeleteTransactionId = AD.DeleteTransactionId
        END
        IF (@ItemType = 5)
        BEGIN
            SELECT
                @ItemCountDelta = COUNT(1)
            FROM
                TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
            WHERE
                AD.DoclibRowId IS NOT NULL AND
                AD.IsCurrentVersion = 1
            IF (@AttachmentSubfolderUrl IS NOT NULL)
            BEGIN
                DECLARE @AttachmentsFolderDeltaSize bigint
                SELECT
                    @AttachmentsFolderDeltaSize = SUM(SM.TotalSize)
                FROM
                    TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
                CROSS APPLY
                    TVF_AllDocs_DelIdUrl(
                        @SiteId,
                        @EffectiveDeleteTransactionId,
                        @AttachmentSubfolderUrl, 
                        CAST(AD.DoclibRowId AS nvarchar(128))) AS AttachmentFolders
                CROSS APPLY
                    TVF_StorageMetrics_DocId(AttachmentFolders.SiteId, AttachmentFolders.Id) AS SM
                WHERE
                    AD.DoclibRowId IS NOT NULL AND
                    AD.IsCurrentVersion = 1
                DECLARE @AttachmentsFolderDirName nvarchar(256)
                DECLARE @AttachmentsFolderLeafName nvarchar(128)
                EXEC proc_SplitUrl @AttachmentSubfolderUrl, 
                        @AttachmentsFolderDirName OUTPUT, @AttachmentsFolderLeafName OUTPUT
                DECLARE @AttachmentsFolderDocId uniqueidentifier
                SELECT
                    @AttachmentsFolderDocId = D.Id
                FROM
                    TVF_Docs_Url(@SiteId, @AttachmentsFolderDirName, @AttachmentsFolderLeafName) AS D
                IF (@AttachmentsFolderDocId IS NOT NULL)
                BEGIN
                    EXEC proc_AddStorageMetricsChange @SiteId, @AttachmentsFolderDocId, @AttachmentsFolderDeltaSize, 1
                END
            END
        END
        ELSE IF (@ItemType = 3)
        BEGIN
            SET @ItemCountDelta = 1
        END
        UPDATE
            P
        SET
            P.tp_Deleted = 0
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        CROSS APPLY
            TVF_Personalization_SitePage(@SiteId, AD.Id) AS P
        WHERE
            P.tp_Deleted = CONVERT(bit, 1)
        UPDATE
            AWP
        SET
            AWP.tp_Deleted = 0
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        CROSS APPLY
            TVF_AllWebParts_SitePageId(@SiteId, AD.Id) AS AWP
        WHERE
            AWP.tp_Deleted = CONVERT(bit, 1)
        IF (@ItemType = 4 OR
            @ItemType = 3 OR
            @ItemType = 5 OR
            @ItemType = 6)
        BEGIN
            SELECT TOP 1
                @OldParentId = AD.ParentId
            FROM
                TVF_AllDocs_Id(@SiteId, @DocId) AS AD
            WHERE
                AD.DeleteTransactionId = @EffectiveDeleteTransactionId
        END
        UPDATE
            AD
        SET
            AD.DeleteTransactionId = 0x,
            AD.ParentId = 
                CASE 
                    WHEN AD.ParentId = @OldParentId THEN @NewParentId 
                    ELSE AD.ParentId 
                END,
            AD.ScopeId = 
                CASE
                    WHEN AD.ScopeId = @ScopeId THEN @NewScopeId
                    ELSE AD.ScopeId
                END
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
    END
    IF @ItemType = 4
    BEGIN
        UPDATE
            I
        SET
            I.Deleted = 0
        FROM
            TVF_ImmedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, NULL) AS I
        UPDATE
            S
        SET
            S.Deleted = 0
        FROM
            TVF_SchedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, NULL) AS S
        UPDATE
            AL
        SET
            AL.tp_DeleteTransactionId = 0x,
            AL.tp_ScopeId =
                CASE
                    WHEN AL.tp_ScopeId = @ScopeId THEN @NewScopeId
                    ELSE AL.tp_ScopeId
                END
        FROM
            TVF_AllLists_CI(@SiteId, @WebId, @ListId) AS AL
    END
    ELSE IF @ItemType = 6
    BEGIN
        UPDATE
            ImmedSubscriptions
        SET
            ImmedSubscriptions.Deleted = 0
        FROM
            TVF_AllLists_WebId(@SiteId, @WebId) AS AL
        CROSS APPLY
            TVF_ImmedSubscriptions_SiteIdListIdItemId(
                AL.tp_Siteid, AL.tp_ID, NULL) AS ImmedSubscriptions
        WHERE
            AL.tp_DeleteTransactionId = @EffectiveDeleteTransactionId
        UPDATE
            SchedSubscriptions
        SET
            Deleted = 0
        WHERE
            SiteId = @SiteId AND
            ListId IN (
                SELECT
                    tp_ID
                FROM
                    AllLists
                WHERE
                    tp_WebId = @WebId AND
                    tp_DeleteTransactionId = @EffectiveDeleteTransactionId) AND
            ItemId IS NULL        
        UPDATE
            AL
        SET
            AL.tp_DeleteTransactionId = 0x,
            AL.tp_ScopeId =
                CASE
                    WHEN AL.tp_ScopeId = @ScopeId THEN @NewScopeId
                    ELSE AL.tp_ScopeId
                END
        FROM
            TVF_AllLists_WebId(@SiteId, @WebId) AS AL
        WHERE
            AL.tp_DeleteTransactionId = @EffectiveDeleteTransactionId
    END
    IF @ItemCountDelta > 0 AND
        @ListId IS NOT NULL AND
        (@ItemType = 5 OR
        @ItemType = 1 OR
        @ItemType = 3 OR
        @ItemType = 8)
    BEGIN
        EXEC proc_AppendListItemCountQuota @SiteId, @ListId, @ItemCountDelta, 0
    END
    UPDATE
        ALK
    SET
        ALK.DeleteTransactionId = 0x
    FROM
        TVF_AllLinks_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS ALK
    UPDATE
        DP
    SET
        DP.DeleteTransactionId = 0x
    FROM
        TVF_Deps_SiteDelId(@SiteId, @EffectiveDeleteTransactionId) AS DP
    IF @ScopeId IS NULL
        EXEC proc_SecFixScopeByTransactionId @SiteId, @WebId, @EffectiveDeleteTransactionId
    UPDATE
        P
    SET
        P.DelTransId = 0x
    FROM
        TVF_Perms_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS P
    UPDATE
        AUDJ        
    SET
        AUDJ.tp_DeleteTransactionId = 0x
    FROM
        TVF_AllUserDataJunctions_SiteDel(@SiteId, @EffectiveDeleteTransactionId) AS AUDJ
    DELETE 
        R
    FROM
        TVF_RecycleBin_DelIdChildId(@SiteId, @DeleteTransactionId, @ChildDeleteTransactionId) AS R
    WHERE
        R.WebId = @WebId AND
        R.DeleteUserId = @DeleteUserId
    IF (@ItemType = 1 OR
        @ItemType = 5 OR
        @ItemType = 3 OR
        @ItemType = 8 OR
        @ItemType = 6 OR
        @ItemType = 7 OR
        @ItemType = 4)
    BEGIN
        DECLARE @FullName nvarchar(260)
        IF (@ItemType = 1 OR
            @ItemType = 5 OR
            @ItemType = 6)
        BEGIN    
            SET @FullName = CASE WHEN (DATALENGTH(@DirName) = 0) THEN @LeafName WHEN (DATALENGTH(@LeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @LeafName END
        END
        DECLARE @RestoreDate datetime
        SET @RestoreDate = GETUTCDATE()
        IF (@ItemType = 7)
        BEGIN
            EXEC proc_LogChange @SiteId, @WebId, NULL, NULL, @DocId, NULL,
                NULL, NULL, 131072, 16, 
                @RestoreDate, NULL, NULL, @DocClientId
            EXEC proc_AddEventToCache @SiteId, @WebId, @ListId, @ListItemId,
                NULL, NULL, NULL, 8192, NULL, @RestoreDate, NULL, NULL, 
                @RequestGuid = @RequestGuid OUTPUT
        END
        ELSE IF (@ItemType = 4)
        BEGIN
            EXEC proc_LogChange @SiteId, @WebId, @ListId, NULL, NULL, NULL,
                NULL, NULL, 131072, 2, @RestoreDate
        END
        ELSE IF (@ListItemId IS NOT NULL)
        BEGIN
            DECLARE @RestoreEventType int
            SET @RestoreEventType = 
                CASE WHEN (@ChildDeleteTransactionId = 0x) 
                THEN
                    131081
                ELSE
                    131072
                END;
            EXEC proc_AddEventToCacheForDeleteRestore
                @SiteId, 
                @WebId, 
                @ListId,
                @ListItemId,
                @LeafName,
                @FullName,
                @DocId,
                @RestoreEventType,
                @UserId,
                @RestoreDate,
                NULL,
                NULL,
                @DocClientId,
                @RequestGuid OUTPUT
        END
        ELSE
        BEGIN
            IF (@ItemType = 1)
            BEGIN
                EXEC proc_LogChange @SiteId, @WebId, @ListId, NULL, @DocId, NULL,
                    NULL, @FullName, 131072, 16, 
                    @RestoreDate, NULL, NULL, @DocClientId
            END
            ELSE IF (@ItemType = 5 OR @ItemType = 6)
            BEGIN
                EXEC proc_LogChange @SiteId, @WebId, @ListId, NULL, @DocId, NULL,
                    NULL, @FullName, 131072, 32, 
                    @RestoreDate, NULL, NULL, @DocClientId
            END
        END
    END
    IF @ItemType = 7
    BEGIN
        EXEC proc_UpdateAttachmentsFlag @SiteId, @DirName,
            @DeleteUserId, 1
    END
    IF @ItemType = 1 OR @ItemType = 3
    BEGIN
        EXEC proc_UpdateChildCount 
            @SiteId, 
            @DirName, 
            @LeafName,
            @ListItemId, 
            0, 
            0, 
            1
    END
    ELSE IF @ItemType = 5
    BEGIN
        EXEC proc_UpdateChildCount
            @SiteId, 
            @DirName, 
            @LeafName,
            @ListItemId, 
            0, 
            1, 
            1
    END
    IF @ItemType = 5
    BEGIN
        EXEC proc_DirtyItemsForWikiLinking @SiteId, @WebId, @DirName, @LeafName, 1
    END
    ELSE
    BEGIN
        EXEC proc_DirtyItemsForWikiLinking @SiteId, @WebId, @DirName, @LeafName, 0
    END
    IF EXISTS
        (SELECT TOP 1
             1
         FROM
             TVF_Links_PId_DId(@SiteId, @NewParentId, @DocId) AS L
         WHERE
             L.FieldId IS NOT NULL)
    BEGIN
        UPDATE
            D
        SET
            D.BumpVersion = CASE WHEN (CAST(1 AS bit)) = CAST(0 AS bit) THEN D.BumpVersion WHEN CASE WHEN D.DocFlags IS NULL OR (D.DocFlags & 4) = 0 THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END = CAST(0 AS bit) THEN D.BumpVersion WHEN D.BumpVersion > 250 THEN 1 ELSE D.BumpVersion + 1 END, D.ContentVersion = CASE WHEN (CAST(1 AS bit)) = CAST(0 AS bit) THEN D.ContentVersion ELSE CASE WHEN CASE WHEN D.DocFlags IS NULL OR (D.DocFlags & 4) = 0 THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END = CAST(0 AS bit) THEN D.ContentVersion ELSE D.ContentVersion + 1 END END,            
            D.ListDataDirty = 1
        FROM
            TVF_Docs_PId_DId(@SiteId, @NewParentId, @DocId) AS D
        UPDATE
            L
        SET
            L.tp_ListDataDirty = L.tp_ListDataDirty | 1,
            L.tp_CacheParseId = NULL
        FROM
            TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
    END
cleanup:
    IF @Ret = 0 AND
       (@ItemType = 1 OR
        @ItemType = 5 OR
        @ItemType = 3 OR       
        @ItemType = 8 OR       
        @ItemType = 2 OR       
        @ItemType = 4)
    BEGIN
        DECLARE @AuditItemType tinyint
        DECLARE @AuditEventData nvarchar(4000)
        IF (@ItemType = 1 OR @ItemType = 2) 
            SET @AuditItemType = 1
        ELSE IF (@ItemType = 3 OR @ItemType = 8) 
            SET @AuditItemType = 3
        ELSE IF (@ItemType = 5) 
            SET @AuditItemType = 5
        ELSE IF (@ItemType = 4) 
            SET @AuditItemType = 4
        IF (@ItemType = 2 OR @ItemType = 8)
        BEGIN
            SET @AuditEventData = 
                STUFF(STUFF('</>', 3, 0, 'Version'), 1, 0, STUFF(STUFF(STUFF('</>', 3, 0, 'Major'), 1, 0, STUFF(@DocVersionId/512, 1, 0, STUFF('<>', 2, 0, 'Major'))) + STUFF(STUFF('</>', 3, 0, 'Minor'), 1, 0, STUFF(@DocVersionId%512, 1, 0, STUFF('<>', 2, 0, 'Minor'))), 1, 0, STUFF('<>', 2, 0, 'Version')))
        END
        ELSE
        BEGIN
            SET @AuditEventData = NULL
        END
        DECLARE @AuditUserId int
        IF @UserId = 0
            SET @AuditUserId = -1
        ELSE
            SET @AuditUserId = @UserId
        EXEC proc_AddAuditEntryFromSql 
               @SiteId, 
               @DirName, 
               @LeafName, 
               @AuditItemType, 
               @AuditUserId,
               @AppPrincipalId,
               10, 
               @AuditEventData,
               0x00000200
        SET @UpdateListItemCount = 1
    END
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    IF @UpdateListItemCount = 1
    BEGIN
    EXEC proc_UpdateListItemCount @SiteId, @ListId    
    END
    RETURN @Ret

go

