CREATE PROCEDURE [dbo].[proc_SecUpdateAcl](
    @SiteId       uniqueidentifier,
    @RoleDefWebId uniqueidentifier)
AS
    SET NOCOUNT ON
    DECLARE @RoleWebFullUrl nvarchar(256)
    DECLARE @RoleWebFullUrlLike nvarchar(1024)
    DECLARE @ScopeId uniqueidentifier
    SELECT TOP 1
        @RoleWebFullUrl = W.FullUrl
    FROM
        TVF_Webs_Id(@SiteId, @RoleDefWebId) AS W
    EXEC proc_EscapeForLike @RoleWebFullUrl, @RoleWebFullUrlLike OUTPUT
    DECLARE curScopeId CURSOR LOCAL FAST_FORWARD FOR 
    SELECT 
        P.ScopeId 
    FROM 
        TVF_Perms_ScopeUrlEqLike_Value(@SiteId, @RoleWebFullUrl, @RoleWebFullUrlLike) AS P 
    WHERE
        P.RoleDefWebId  = @RoleDefWebId
    UNION ALL
    SELECT 
        DP.ScopeId 
    FROM 
        TVF_DeletedPerms_ScopeUrlLike(@SiteId, @RoleWebFullUrlLike) AS DP 
    WHERE
        DP.RoleDefWebId  = @RoleDefWebId
    OPEN curScopeId
    FETCH NEXT FROM curScopeId INTO @ScopeId
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        EXEC proc_SecUpdateAclForScope @SiteId, @ScopeId
        FETCH NEXT FROM curScopeId INTO @scopeId
    END
    CLOSE curScopeId
    DEALLOCATE curScopeId
    RETURN 0

go

