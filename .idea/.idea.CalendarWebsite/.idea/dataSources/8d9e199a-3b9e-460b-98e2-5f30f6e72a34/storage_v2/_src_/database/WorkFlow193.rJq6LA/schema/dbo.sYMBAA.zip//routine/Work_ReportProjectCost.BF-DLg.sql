-- Work_ReportProjectCost 'P:287' ,224903                            
   CREATE   PROC Work_ReportProjectCost                 
   @UserId as nvarchar(50)            
   ,@projectId as nvarchar(50)                            
   as                            
   declare @check as int            
   set @check=( select COUNT( *) from Dynamic.Data_RESOURCEDA a where a.UserWorkflowId=@projectId and @UserId= ( select * from Split(PermissionShowReport,';') where Item=@UserId))            
   CREATE table #tb (Code nvarchar(250), Name nvarchar(250), Value float, ShortContent nvarchar(1000)                          
   , CreatedTime nvarchar(150), GroupId nvarchar(100), CouponId bigint, Status nvarchar(150), RowIndex int,GroupProject nvarchar(250))                
   update a set a.ProjectId=b.UserWorkflowId 
   from Dynamic.Data_ProjectLinkCoupon a  
   inner join Dynamic.Data_RESOURCEDA b on a.ProjectId=b.Ten 
   where b.UserWorkflowId=@projectId
   ;
   update a set a.GroupProject=b.UserWorkflowId
   from Dynamic.Data_ProjectLinkCoupon a  
   inner join Dynamic.Data_ProjectGroup b on a.GroupProject=b.Ten 
   where b.ProjectId=@projectId
   if(@check>0)            
   begin             
   select                              
   b.Id                            
   ,b.UserWorkflowId                            
   ,b.ParentId                            
   ,a.DisplayText                            
   ,b.CouponId as WorkFlowId                            
   ,b.CoulumnCoupon                            
   ,a.ProjectId                            
   ,c.WorkId                            
   ,c.CouponId                            
   , 'Dynamic.Data_'+[dbo].[Work_ReplaceInvalidChars](trim(d.Code)) as TableName                          
   ,ISNULL(a.RowIndex,0) as RowIndex                
   ,c.GroupProject      
   into #a                            
   from Dynamic.Data_WorkProjectCost a                            
   inner join Dynamic.Data_WorkProjectCost b on a.ProjectId=b.ProjectId and a.UserWorkflowId=b.ParentId                             
   inner join           
   (                            
   select a.UserWorkflowId as WorkId, a.Duan, b.CouponId, b.WorkFlowId, a.GroupProject                      
   from Dynamic.Data_WORK a                             
   inner join Dynamic.Data_ProjectLinkCoupon b on a.UserWorkflowId=b.WorkId and b.Type=4                             
   where a.Duan=@projectId  and ISNULL(a.IsActive,'True')='True' and ISNULL(b.IsDelete,'False')='False'                  
   union                        
   select a.UserWorkflowId as WorkId, a.UserWorkflowId, b.CouponId, b.WorkFlowId ,b.GroupProject                      
   from Dynamic.Data_RESOURCEDA a                             
   inner join Dynamic.Data_ProjectLinkCoupon b on a.UserWorkflowId=b.ProjectId and b.Type= 1                            
   where a.UserWorkflowId=@projectId and ISNULL(a.IsDeleted,'False')='False' and ISNULL(b.IsDelete,'False')='False'                  
   ) c on c.Duan=a.ProjectId and cast(b.CouponId as bigint)= cast(c.WorkFlowId as bigint)          
   inner join Workflow d on d.Id=c.WorkFlowId          
   where a.ProjectId=@projectId and ISNULL(b.IsDelete,'False')='False'  and ISNULL(a.IsDelete,'False')='False'                 
   Declare @Id int,@workId as bigint , @sql as nvarchar(max), @table as nvarchar(500)                            
   ,@column as nvarchar(250), @userWorkflowId as nvarchar(50), @display as nvarchar(500),@groupId as nvarchar(100), @rowIndex as nvarchar(50)                     
   ,@CouponId as nvarchar(50), @GroupProject as nvarchar(250)         
   While (Select Count(*) From #a) > 0                            
   Begin                            
   Select Top 1 @Id = Id, @workId =WorkId, @CouponId=CouponId From #a               
   --Select @Id,@workId,* from #a where id =@id  and WorkId=@workId and @CouponId=CouponId        
   set @column=(Select CoulumnCoupon from #a where id =@id  and WorkId=@workId and CouponId=@CouponId)                            
   set @table=(Select TableName from #a where id =@id  and WorkId=@workId and CouponId=@CouponId)                            
   set @userWorkflowId=(Select CouponId from #a where id =@id  and WorkId=@workId and CouponId=@CouponId)                             
   set @display=(Select DisplayText from #a where id =@id  and WorkId=@workId and CouponId=@CouponId)                            
   set @groupId=(Select ParentId from #a where id =@id  and WorkId=@workId and CouponId=@CouponId )                            
   set @rowIndex=(Select RowIndex from #a where id =@id  and WorkId=@workId and CouponId=@CouponId)                       
   set @column=( select  STUFF((SELECT ' sum(isnull(' +  a.Item+',0)) +'FROM (select * from Split(@column,';')) a FOR XML PATH('')),1, 1, ''))          
   set @GroupProject=(Select GroupProject from #a where id =@id  and WorkId=@workId and CouponId=@CouponId)                            
   set @sql=N'insert into #tb (Name,Value,Code,ShortContent,CreatedTime,GroupId,CouponId,Status,RowIndex,GroupProject)                     
   select N'''+@display+''', '+left(@column,len(@column)-1)+'       
   ,b.WorkflowCode,b.ShortContent,CONVERT(char, b.CreatedTime,103) as CreatedTime,'''+@groupId+'''                          
   ,b.Id  ,case when b.UserWorkflowStatus =0 then N'''+N'Chờ phê duyệt'+'''                          
   when b.UserWorkflowStatus =1 then N'''+N'Phê duyệt'+''' else N'''+N'Từ chối'+''' end as Status,'+@rowIndex+'           
   , '+isnull(@GroupProject,'''''')+'          
   from '+@table+' a                             
   inner join UserWorkflow b on a.UserWorkflowId=b.Id where UserWorkflowId='''+@userWorkflowId+'''                      
   and IsDeleted =0          
   group by b.WorkflowCode,b.ShortContent,b.CreatedTime,b.Id,b.UserWorkflowStatus'                            
   exec(@sql)                            
   print(@sql)                            
   --Do some PROCessing here                             
   Delete #a Where Id = @Id and WorkId=@workId    and CouponId=@CouponId                        
   End                            
   end            
   select case when ISNULL(Code,'')='' then N'[Chưa nhập mã]' else Code end as Code,Name,SUM(Value) as Value, ShortContent,CreatedTime,GroupId as GroupReportId,CouponId,b.Status ,RowIndex            
   ,ROW_NUMBER() OVER(ORDER BY name ASC) AS [Key],ISNULL(b.GroupProject,a.UserWorkflowId) as GroupProject          
   ,a.Ten as GroupProjectName                      
   ,isnull(a.GroupParent,'') as GroupParent          
   from Dynamic.Data_ProjectGroup a           
   left join #tb b on b.GroupProject=a.UserWorkflowId          
   where a.ProjectId=@projectId and ISNULL(a.IsDelete,'False')='False'          
   group by Code,Name, ShortContent,CreatedTime,GroupId,CouponId ,b.Status ,RowIndex,GroupProject ,a.Ten ,a.UserWorkflowId               
   ,a.GroupParent        
   union       
   select case when ISNULL(Code,'')='' then N'[Chưa nhập mã]' else Code end as Code,Name,SUM(Value) as Value, ShortContent,CreatedTime,GroupId as GroupReportId,CouponId,'' as Status ,RowIndex            
   ,ROW_NUMBER() OVER(ORDER BY name ASC) AS [Key],'' as GroupProject          
   ,'' as GroupProjectName                      
   ,'' as GroupParent          
   from #tb a  where GroupProject=''      
   group by Code,Name, ShortContent,CreatedTime,GroupId,CouponId ,RowIndex,GroupProject              
   --drop table #a                             
   --drop table #tb 
go

