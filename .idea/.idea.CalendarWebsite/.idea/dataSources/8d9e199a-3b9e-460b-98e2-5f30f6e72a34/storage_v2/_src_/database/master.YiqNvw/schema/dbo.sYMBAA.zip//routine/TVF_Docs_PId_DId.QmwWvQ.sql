CREATE FUNCTION [dbo].[TVF_Docs_PId_DId]
(
    @SiteId uniqueidentifier,
    @ParentId uniqueidentifier,
    @Id uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (INDEX=AllDocs_ParentId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        ParentId = @ParentId AND
        Id = @Id

go

