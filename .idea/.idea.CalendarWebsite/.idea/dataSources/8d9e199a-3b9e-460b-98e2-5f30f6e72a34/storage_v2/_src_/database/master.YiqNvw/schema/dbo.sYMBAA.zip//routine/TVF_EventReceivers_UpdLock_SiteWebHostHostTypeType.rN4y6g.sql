CREATE FUNCTION [dbo].[TVF_EventReceivers_UpdLock_SiteWebHostHostTypeType]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @HostId uniqueidentifier,
    @HostType int,
    @Type int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[EventReceivers] WITH (UPDLOCK, INDEX=EventReceivers_ByHost, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId AND
        HostId = @HostId AND
        HostType = @HostType AND
        Type = @Type

go

