CREATE FUNCTION [dbo].[TVF_Links_TargetDirNameLike]
(
    @SiteId uniqueidentifier,
    @TargetDirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllLinks] WITH (INDEX=Links_Backward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        TargetDirName LIKE @TargetDirNameLike

go

