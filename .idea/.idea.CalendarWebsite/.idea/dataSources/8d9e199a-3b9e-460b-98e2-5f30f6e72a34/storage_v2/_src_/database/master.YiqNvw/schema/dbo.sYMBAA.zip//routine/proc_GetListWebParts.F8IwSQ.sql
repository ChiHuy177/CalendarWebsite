CREATE PROCEDURE [dbo].[proc_GetListWebParts](
    @ListId uniqueidentifier,
    @ViewId uniqueidentifier,
    @UserId int,
    @DocVersion int,
    @bGetAllLevel bit,
    @bGetDeleted bit = 0,
    @bGetAllUsers bit = 0,
    @SiteId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @IsCurrent bit
    IF @DocVersion = 0
    BEGIN
        IF @ViewId IS NULL
        BEGIN
            SELECT
                WP1.tp_ListId,
                WP1.tp_Type,
                WP1.tp_ID,
                WP1.tp_Flags,
                WP1.tp_DisplayName,
                CASE WHEN (DATALENGTH(AD.DirName) = 0) THEN AD.LeafName WHEN (DATALENGTH(AD.LeafName) = 0) THEN AD.DirName ELSE AD.DirName + N'/' + AD.LeafName END AS tp_PageUrl,
                WP1.tp_BaseViewID,
                WP1.tp_View,
                WP1.tp_Level,
                WP1.tp_ContentTypeId,
                WP1.tp_PageUrlID,
                tp_AllUsersProperties = CASE WHEN @ViewId IS NULL
                THEN
                    NULL
                ELSE
                    WP1.tp_AllUsersProperties
                END,
                tp_PerUserProperties = CASE WHEN @ViewId IS NULL
                THEN
                    NULL
                ELSE
                    WP1.tp_PerUserProperties
                END,
                tp_WebPartIdProperty = CASE WHEN @ViewId IS NULL
                THEN
                    NULL
                ELSE
                    WP1.tp_WebPartIdProperty
                END,
                tp_Cache = CASE WHEN @ViewId IS NULL
                THEN 
                    NULL
                ELSE
                    WP1.tp_Cache
                END
            FROM
                TVF_WebParts_List(@SiteId, @ListId) AS WP1
            CROSS APPLY
                TVF_AllDocs_Id_Level(WP1.tp_SiteId, WP1.tp_PageUrlID, WP1.tp_Level) AS AD
            WHERE
                WP1.tp_SiteId = @SiteId AND
                (@bGetDeleted = 1 OR AD.DeleteTransactionId = 0x) AND
                (@bGetAllLevel = 1 OR 
                (AD.Level = 255 AND 
                    AD.LTCheckoutUserId = @UserId OR
                ((AD.Level = 1 AND (AD.DraftOwnerId IS NULL OR WP1.tp_UserID = @UserId AND
                    NOT EXISTS (
                        SELECT TOP 1
                            1 
                        FROM 
                            TVF_WebParts_SitePartIdLvl(WP1.tp_SiteId, WP1.tp_ID, 2))
                  ) OR
                  AD.Level = 2)  AND
                (AD.LTCheckoutUserId IS NULL OR AD.LTCheckoutUserId <> @UserId)))) AND
                (@bGetAllUsers = 1 OR WP1.tp_UserID IS NULL OR WP1.tp_UserID = @UserId)
            ORDER BY
                WP1.tp_CreationTime
            OPTION (FORCE ORDER)
        END
        ELSE 
        BEGIN
            SELECT
                WP1.tp_ListId,
                WP1.tp_Type,
                WP1.tp_ID,
                WP1.tp_Flags,
                WP1.tp_DisplayName,
                CASE WHEN (DATALENGTH(AD.DirName) = 0) THEN AD.LeafName WHEN (DATALENGTH(AD.LeafName) = 0) THEN AD.DirName ELSE AD.DirName + N'/' + AD.LeafName END AS tp_PageUrl,
                WP1.tp_BaseViewID,
                WP1.tp_View,
                WP1.tp_Level,
                WP1.tp_ContentTypeId,
                WP1.tp_PageUrlID,
                tp_AllUsersProperties = CASE WHEN @ViewId IS NULL
                THEN
                    NULL
                ELSE
                    WP1.tp_AllUsersProperties
                END,
                tp_PerUserProperties = CASE WHEN @ViewId IS NULL
                THEN
                    NULL
                ELSE
                    WP1.tp_PerUserProperties
                END,
                tp_WebPartIdProperty = CASE WHEN @ViewId IS NULL
                THEN
                    NULL
                ELSE
                    WP1.tp_WebPartIdProperty
                END,
                tp_Cache = CASE WHEN @ViewId IS NULL
                THEN 
                    NULL
                ELSE
                    WP1.tp_Cache
                END
            FROM
                TVF_WebParts_SitePartId(@SiteId, @ViewId) AS WP1
            CROSS APPLY
                TVF_AllDocs_Id_Level(WP1.tp_SiteId, WP1.tp_PageUrlID, WP1.tp_Level) AS AD
            WHERE
                WP1.tp_ListId = @ListId AND
                (@bGetDeleted = 1 OR AD.DeleteTransactionId = 0x) AND
                (@bGetAllLevel = 1 OR 
                (AD.Level = 255 AND 
                    AD.LTCheckoutUserId = @UserId OR
                ((AD.Level = 1 AND (AD.DraftOwnerId IS NULL OR WP1.tp_UserID = @UserId AND
                    NOT EXISTS (
                        SELECT TOP 1
                            1 
                        FROM 
                            TVF_WebParts_SitePartIdLvl(WP1.tp_SiteId, WP1.tp_ID, 2))
                  ) OR
                  AD.Level = 2)  AND
                (AD.LTCheckoutUserId IS NULL OR AD.LTCheckoutUserId <> @UserId)))) AND
                (@bGetAllUsers = 1 OR WP1.tp_UserID IS NULL OR WP1.tp_UserID = @UserId)
            ORDER BY
                WP1.tp_CreationTime
            OPTION (FORCE ORDER)
        END
    END
    ELSE 
    BEGIN
        SELECT
            WP1.tp_ListId,
            WP1.tp_Type,
            WP1.tp_ID,
            WP1.tp_Flags,
            WP1.tp_DisplayName,
            CASE WHEN (DATALENGTH(AD.DirName) = 0) THEN AD.LeafName WHEN (DATALENGTH(AD.LeafName) = 0) THEN AD.DirName ELSE AD.DirName + N'/' + AD.LeafName END AS tp_PageUrl,
            WP1.tp_BaseViewID,
            WP1.tp_View,
            WP1.tp_Level,
            WP1.tp_ContentTypeId,
            WP1.tp_PageUrlID,
            tp_AllUsersProperties = CASE WHEN @ViewId IS NULL
            THEN
                NULL
            ELSE
                WP1.tp_AllUsersProperties
            END,
            tp_PerUserProperties = CASE WHEN @ViewId IS NULL
            THEN
                NULL
            ELSE
                WP1.tp_PerUserProperties
            END,
            tp_WebPartIdProperty = CASE WHEN @ViewId IS NULL
            THEN
                NULL
            ELSE
                WP1.tp_WebPartIdProperty
            END,     
            tp_Cache = CASE WHEN @ViewId IS NULL
            THEN 
                NULL
            ELSE
                WP1.tp_Cache
            END
        FROM
            TVF_AllWebParts_ListIsCurPageVer(
                @SiteId,
                @ListId, 
                CONVERT(bit, 0),
                @DocVersion) AS WP1
        CROSS APPLY
            TVF_AllDocs_Id(WP1.tp_SiteId, WP1.tp_PageUrlID) AS AD
        WHERE
            WP1.tp_SiteId = @SiteId AND
            (@bGetDeleted = 1 OR AD.DeleteTransactionId = 0x) AND
            AD.IsCurrentVersion = CONVERT(bit,1) AND
            (@ViewId IS NULL OR @ViewId = WP1.tp_ID)
        UNION ALL
        SELECT
            WP1.tp_ListId,
            WP1.tp_Type,
            WP1.tp_ID,
            WP1.tp_Flags,
            WP1.tp_DisplayName,
            CASE WHEN (DATALENGTH(AD.DirName) = 0) THEN AD.LeafName WHEN (DATALENGTH(AD.LeafName) = 0) THEN AD.DirName ELSE AD.DirName + N'/' + AD.LeafName END AS tp_PageUrl,
            WP1.tp_BaseViewID,
            WP1.tp_View,
            WP1.tp_Level,
            WP1.tp_ContentTypeId,
            WP1.tp_PageUrlID,
            tp_AllUsersProperties = CASE WHEN @ViewId IS NULL
            THEN
                NULL
            ELSE
                WP1.tp_AllUsersProperties
            END,
            tp_PerUserProperties = CASE WHEN @ViewId IS NULL
            THEN
                NULL
            ELSE
                WP1.tp_PerUserProperties
            END,
            tp_WebPartIdProperty = CASE WHEN @ViewId IS NULL
            THEN
                NULL
            ELSE
                WP1.tp_WebPartIdProperty
            END,          
            tp_Cache = CASE WHEN @ViewId IS NULL
            THEN 
                NULL
            ELSE
                WP1.tp_Cache
            END            
        FROM
            TVF_WebParts_List(@SiteId, @ListId) AS WP1
        CROSS APPLY
            TVF_AllDocs_Id_Level(WP1.tp_SiteId, WP1.tp_PageUrlID, WP1.tp_Level) AS AD
        WHERE
            WP1.tp_SiteId = @SiteId AND
            AD.UIVersion = @DocVersion AND
            AD.IsCurrentVersion = CONVERT(bit,0) AND   
            (@bGetDeleted = 1 OR AD.DeleteTransactionId = 0x) AND
            (@ViewId IS NULL OR @ViewId = WP1.tp_ID) 
    END

go

