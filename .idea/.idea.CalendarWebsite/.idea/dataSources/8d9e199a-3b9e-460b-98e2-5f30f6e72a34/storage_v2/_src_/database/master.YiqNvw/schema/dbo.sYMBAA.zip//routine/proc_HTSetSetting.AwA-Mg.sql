CREATE PROCEDURE [dbo].[proc_HTSetSetting](
    @settingKey nchar(10),
    @newValue int
)
AS
    SET NOCOUNT ON
    UPDATE HT_Settings
    SET value = @newValue
    WHERE [key] = @settingKey

go

