CREATE FUNCTION [dbo].[TVF_NameValuePair_Hindi_CI_AS_ListField]
(
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NameValuePair_Hindi_CI_AS] WITH (INDEX=NameValuePair_Hindi_CI_AS_MatchUserData, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ListId = @ListId AND
        FieldId = @FieldId

go

