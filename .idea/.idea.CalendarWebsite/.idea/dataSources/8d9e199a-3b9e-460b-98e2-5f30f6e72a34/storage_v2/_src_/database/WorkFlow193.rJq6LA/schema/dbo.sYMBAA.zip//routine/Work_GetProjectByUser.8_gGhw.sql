-- Work_GetProjectByUser '','','','P:287',''                
   CREATE   PROC [dbo].[Work_GetProjectByUser]                
   @id as nvarchar(50)                
   ,@type as nvarchar(150)=''               
   ,@projectId as nvarchar(50)=''               
   ,@defaultUser as nvarchar(50)=''               
   ,@department as nvarchar(50)=''               
   ,@name as nvarchar(50)=''               
   as                
   select a.[User],b.value as DepartmentId into #tbDepartment from Dynamic.Data_RuleViewProject a               
   cross apply string_split(Department,';') b               
   where [User]=@defaultUser               
   declare @userId as nvarchar(50)=''               
   if(@id='' and @department='')               
   begin               
   set @userId=@defaultUser               
   end               
   else               
   begin               
   set @userId=@id               
   end               
   if(@projectId <>'')               
   begin                
   -- cap nhat dau , thanh ;      
   --update Dynamic.Data_WORK set Nguoixuly = REPLACE(Nguoixuly,',',';'),NguoiXuLyDauTien = REPLACE(NguoiXuLyDauTien,',',';') where               
   --(Nguoixuly like '%,%' or NguoiXuLyDauTien like '%,%') and Duan=@projectId               
   --;               
   -- cap nhat LastModified chi de hien thi trong danh sach la ngay hoan thanh           
   --select MAX(a.Date) as Date, a.WorkId           
   --into #lscn          
   --from Dynamic.Data_LSCNTTCV a           
   --inner join Dynamic.Workflow_WORK b on a.WorkId=b.UserWorkflowId          
   --inner join Dynamic.Data_WORK c on b.UserWorkflowId=c.UserWorkflowId          
   --where c.Duan=@projectId           
   --and a.Note=N'Tự động hoàn thành công việc khi công việc hoàn thành' and a.ColumnName='TrangThaiCongViec'          
   --and b.LastModified is null          
   --group by a.WorkId          
   --update a set a.LastModified=b.Date from Dynamic.Workflow_WORK a          
   --inner join #lscn b on a.UserWorkflowId=b.WorkId          
   --;          
   select               
   a.[UserWorkflowId] as ProjectId               
   ,a.[UserWorkflowId] as Id                
   ,a.[Ten] as Name                
   ,a.[MoTa] as Description                
   ,a.[ThanhPhanThamGia] as UserPartner                
   ,a.[NgayBatDau] as [Start]                
   ,a.[NgayKetThuc] as [End]                
   ,a.[TrangThai] as StatusProject                
   ,a.[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                
   ,a.[Quanly] as Manager                
   ,a.UserWorkflowId                
   ,AddAllUserWhenAddWork               
   ,RuleViewWork                
   ,b.Id as DepartmentId               
   ,b.Title as DepartmentName               
   ,a.NguoiTheoDoi               
   ,a.CouponIdInfoExtendForWork               
   ,a.FormExtendInfo             
   , a.UseNewTheme        
   ,a.ShowMenu        
   ,a.ApplySLA      
   ,ApprovedUserExcecType  
   ,ApprovedUserExcec  
   ,a.ColumnViewWhenAddWork  
   from Dynamic.Data_RESOURCEDA a               
   inner join Department b on a.Department=b.Id               
   where               
   a.UserWorkflowId=@projectId               
   and ISNULL(a.IsDeleted,'False')='False' and TrangThai = N'Đang thực hiện' and ISNULL(Ten,'') like N'%'+@name+'%'               
   order by Id desc                
   end               
   else               
   begin               
   declare @tbUser table ( UserId nvarchar(50), UserWorkflowId bigint)               
   insert into @tbUser               
   select * from                
   (               
   SELECT                
   'P:'+ trim(str(c.PersonalProfilesId)) AS userId               
   ,a.UserWorkflowId               
   -- into #da               
   FROM DYNAMIC.Data_RESOURCEDA AS a                
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b        
   inner join GroupPersonalProfile c on 'G:'+ trim(str(GroupsId))=b.value               
   where left(trim(b.value),2)='G:' and ISNULL(a.IsDeleted,'False')='False'               
   union               
   SELECT               
   b.value AS userId               
   ,a.UserWorkflowId               
   -- into #da               
   FROM DYNAMIC.Data_RESOURCEDA AS a               
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b               
   where left(trim(b.value),2)='P:' and ISNULL(a.IsDeleted,'False')='False'                
   union               
   SELECT                
   b.value AS userId               
   ,a.UserWorkflowId       
   -- into #da               
   FROM DYNAMIC.Data_RESOURCEDA AS a               
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b               
   where left(trim(b.value),2)='P:' and ISNULL(a.IsDeleted,'False')='False'               
   union               
   SELECT                
   'P:'+trim(str(d.Id)) AS userId               
   ,a.UserWorkflowId               
   FROM DYNAMIC.Data_RESOURCEDA AS a                
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b                
   inner join GroupPersonalProfile c on REPLACE(b.value,'G:','')=c.GroupsId               
   INNER JOIN PersonalProfile d ON d.Id =c.PersonalProfilesId               
   WHERE ISNULL(a.IsDeleted,'False')='False' and left(trim(b.value ),2)='G:'               
   ) a group by userId,UserWorkflowId               
   if((@id='' and @department='') )               
   begin               
   if(select COUNT(*) from #tbDepartment)>0               
   begin               
   select                
   c.[UserWorkflowId] as ProjectId               
   ,c.[UserWorkflowId] as Id                
   ,c.[Ten] as Name                
   ,c.[MoTa] as Description                
   ,c.[ThanhPhanThamGia] as UserPartner                
   ,c.[NgayBatDau] as [Start]                
   ,c.[NgayKetThuc] as [End]                
   ,c.[TrangThai] as StatusProject                
   ,c.[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                
   ,c.[Quanly] as Manager                
   ,c.UserWorkflowId                
   ,c.AddAllUserWhenAddWork                
   ,RuleViewWork               
   ,d.Id as DepartmentId               
   ,d.Title as DepartmentName               
   ,c.NguoiTheoDoi               
   ,c.CouponIdInfoExtendForWork               
   ,c.FormExtendInfo             
   , c.UseNewTheme        
   ,c.ShowMenu        
   ,c.ApplySLA     
   ,ApprovedUserExcecType  
   ,ApprovedUserExcec  
   ,c.ColumnViewWhenAddWork  
   from Dynamic.Data_RuleViewProject a               
   cross apply Split(a.Department,';' ) b               
   inner join Dynamic.Data_RESOURCEDA c on c.Department=b.Item               
   inner join Department d on c.Department=d.Id               
   where a.[User]=@defaultUser and ISNULL(Loai,'') like N'%'+ @type+'%' and ISNULL(c.IsDeleted,'False')='False' and TrangThai = N'Đang thực hiện' and ISNULL(Ten,'') like N'%'+@name+'%'               
   end               
   else               
   begin               
   select               
   a.[UserWorkflowId] as ProjectId               
   ,a.[UserWorkflowId] as Id               
   ,a.[Ten] as Name                
   ,a.[MoTa] as Description                
   ,a.[ThanhPhanThamGia] as UserPartner                
   ,a.[NgayBatDau] as [Start]                
   ,a.[NgayKetThuc] as [End]                
   ,a.[TrangThai] as StatusProject                
   ,a.[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                
   ,a.[Quanly] as Manager                
   ,a.UserWorkflowId        
   ,AddAllUserWhenAddWork               
   ,RuleViewWork               
   ,d.Id as DepartmentId               
   ,d.Title as DepartmentName               
   ,a.NguoiTheoDoi               
   ,a.CouponIdInfoExtendForWork               
   ,a.FormExtendInfo             
   , a.UseNewTheme        
   ,a.ShowMenu        
   ,a.ApplySLA      
   ,ApprovedUserExcecType  
   ,ApprovedUserExcec  
   ,a.ColumnViewWhenAddWork  
   from Dynamic.Data_RESOURCEDA a               
   inner join @tbUser b on b.UserWorkflowId=a.UserWorkflowId               
   inner join Department d on a.Department=d.Id               
   where b.UserId=@userId and ISNULL(Loai,'') like N'%'+ @type+'%' and ISNULL(a.IsDeleted,'False')='False' and TrangThai = N'Đang thực hiện' and ISNULL(Ten,'') like N'%'+@name+'%'          
   end               
   end               
   else if((@id<>'' and @department<>''))               
   begin               
   select               
   a.[UserWorkflowId] as ProjectId        
   ,a.[UserWorkflowId] as Id                
   ,a.[Ten] as Name                
   ,a.[MoTa] as Description                
   ,a.[ThanhPhanThamGia] as UserPartner               
   ,a.[NgayBatDau] as [Start]                
   ,a.[NgayKetThuc] as [End]                
   ,a.[TrangThai] as StatusProject                
   ,a.[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                
   ,a.[Quanly] as Manager               
   ,a.UserWorkflowId               
   ,AddAllUserWhenAddWork               
   ,RuleViewWork               
   ,d.Id as DepartmentId               
   ,d.Title as DepartmentName               
   ,a.NguoiTheoDoi               
   ,a.CouponIdInfoExtendForWork               
   ,a.FormExtendInfo             
   , a.UseNewTheme        
   ,a.ShowMenu        
   ,a.ApplySLA      
   ,ApprovedUserExcecType  
   ,ApprovedUserExcec  
   ,a.ColumnViewWhenAddWork  
   from Dynamic.Data_RESOURCEDA a               
   inner join @tbUser b on b.UserWorkflowId=a.UserWorkflowId               
   inner join Department d on a.Department=d.Id               
   where b.UserId=@userId and a.Department=@department and ISNULL(Loai,'') like N'%'+ @type+'%' and ISNULL(a.IsDeleted,'False')='False' and TrangThai = N'Đang thực hiện' and ISNULL(Ten,'') like N'%'+@name+'%'                
   end               
   else if(@id='' and @department<>'')               
   begin               
   select               
   c.[UserWorkflowId] as ProjectId               
   ,c.[UserWorkflowId] as Id                
   ,c.[Ten] as Name                
   ,c.[MoTa] as Description               
   ,c.[ThanhPhanThamGia] as UserPartner                
   ,c.[NgayBatDau] as [Start]               
   ,c.[NgayKetThuc] as [End]                
   ,c.[TrangThai] as StatusProject                
   ,c.[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                
   ,c.[Quanly] as Manager               
   ,c.UserWorkflowId                
   ,c.AddAllUserWhenAddWork               
   ,RuleViewWork               
   ,d.Id as DepartmentId               
   ,d.Title as DepartmentName               
   ,c.NguoiTheoDoi               
   ,c.CouponIdInfoExtendForWork               
   ,c.FormExtendInfo             
   , c.UseNewTheme        
   ,c.ShowMenu        
   ,c.ApplySLA      
   ,ApprovedUserExcecType  
   ,ApprovedUserExcec  
   ,c.ColumnViewWhenAddWork  
   from Dynamic.Data_RuleViewProject a               
   cross apply Split(a.Department,';' ) b               
   inner join Dynamic.Data_RESOURCEDA c on c.Department=b.Item               
   inner join Department d on c.Department=d.Id               
   where a.[User]=@defaultUser and c.Department =@department and ISNULL(Loai,'') like N'%'+ @type+'%' and ISNULL(c.IsDeleted,'False')='False' and TrangThai = N'Đang thực hiện' and ISNULL(Ten,'') like N'%'+@name+'%'               
   end               
   else if(@id<>'' and @department='')               
   begin               
   select               
   a.[UserWorkflowId] as ProjectId               
   ,a.[UserWorkflowId] as Id                
   ,a.[Ten] as Name                
   ,a.[MoTa] as Description     
   ,a.[ThanhPhanThamGia] as UserPartner               
   ,a.[NgayBatDau] as [Start]                
   ,a.[NgayKetThuc] as [End]                
   ,a.[TrangThai] as StatusProject                
   ,a.[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                
   ,a.[Quanly] as Manager                
   ,a.UserWorkflowId                
   ,AddAllUserWhenAddWork               
   ,RuleViewWork               
   ,d.Id as DepartmentId               
   ,d.Title as DepartmentName               
   ,a.NguoiTheoDoi               
   ,a.CouponIdInfoExtendForWork               
   ,a.FormExtendInfo             
   , a.UseNewTheme        
   ,a.ShowMenu        
   ,a.ApplySLA      
   ,ApprovedUserExcecType  
   ,ApprovedUserExcec  
   ,a.ColumnViewWhenAddWork  
   from Dynamic.Data_RESOURCEDA a            
   inner join @tbUser b on b.UserWorkflowId=a.UserWorkflowId               
   inner join Department d on a.Department=d.Id               
   where b.UserId=@userId and ISNULL(Loai,'') like N'%'+ @type+'%' and ISNULL(a.IsDeleted,'False')='False' and TrangThai = N'Đang thực hiện' and ISNULL(Ten,'') like N'%'+@name+'%'                
   end               
   end
go

