CREATE FUNCTION [dbo].[TVF_Deps_SiteDelIdUrlLike]
(
    @SiteId uniqueidentifier,
    @DeleteTransactionId varbinary(16),
    @FullUrlLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Deps] WITH (INDEX=Deps_DocToDep, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = @DeleteTransactionId AND
        FullUrl LIKE @FullUrlLike

go

