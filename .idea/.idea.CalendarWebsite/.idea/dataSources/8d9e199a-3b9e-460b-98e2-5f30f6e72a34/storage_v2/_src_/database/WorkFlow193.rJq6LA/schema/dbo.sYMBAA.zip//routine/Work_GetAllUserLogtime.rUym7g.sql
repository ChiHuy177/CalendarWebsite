CREATE   PROC [dbo].[Work_GetAllUserLogtime]     
   @date AS CHAR(50) = '2022-10-26'     
   ,@projectName AS NVARCHAR(250) = '25576'     
   ,@email AS NVARCHAR(max) = 'vuongnq@vntt.com.vn'     
   ,@department AS NVARCHAR(50) = ''     
   as     
   SELECT     
   a.Id     
   ,FullName AS title     
   --,trim(str(DATEDIFF(HOUR, a.Ngaybatdau,a.Ngayhoantat )))+'h' as description      
   ,'' AS description     
   ,a.SoGio Total     
   ,trim(CONVERT(CHAR, a.Ngay, 23)) + ' 02:00:00' AS [start]     
   ,trim(CONVERT(CHAR, a.Ngay, 23)) + ' 22:00:00' AS [end]     
   ,a.UserWorkflowId     
   ,a.Congviec     
   ,a.Email     
   ,d.Data as Data     
   ,trim(CONVERT(CHAR, a.ngay, 23)) as DateLogtime    
   INTO #a     
   FROM [Dynamic].Data_VNTTSLT AS a     
   INNER JOIN [dbo].[PersonalProfile] b ON a.Email = b.Email and ISNULL(b.IsDeleted,0)=0           
   INNER JOIN Dynamic.Data_RESOURCEDA c ON a.Duan = c.UserWorkflowId     
   inner join [Dynamic].Workflow_VNTTSLT d on d.UserWorkflowId =a .UserWorkflowId     
   inner join Department f on b.DepartmentId=f.Id and isnull(f.IsDeleted,0)=0    
   WHERE   LEFT( trim(CONVERT(CHAR, a.Ngay, 23)),7) =  LEFT( trim(CONVERT(CHAR, @date, 23)),7)     
   and ISNULL(a.IsDelete,'False')='False' 
   AND (a.Duan = @projectName or ''= @projectName)     
   and f.Id=@department  
   IF (@email = '')     
   begin     
   SELECT a.*     
   ,b.UserWorkflowId AS WorkId     
   FROM #a a     
   inner join Dynamic.Data_WORK b on a.Congviec=b.UserWorkflowId     
   end     
   ELSE     
   begin     
   SELECT a.*     
   ,a.Congviec AS WorkId     
   FROM #a a     
   WHERE a.Email IN (     
   SELECT value     
   FROM STRING_SPLIT(@email, ';')     
   )     
   end     
   DROP TABLE #a
go

