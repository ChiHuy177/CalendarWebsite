CREATE PROCEDURE [dbo].[proc_UpdateVirusInfo](
    @DocSiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @DocLevel tinyint,
    @DocVersion int,
    @NextBSNToCheck bigint,
    @BSNBump bigint,
    @StreamSchema tinyint,
    @VirusVendorID int,
    @VirusStatus tinyint,
    @VirusInfo nvarchar(255),
    @VirusInfoEx varbinary(max),
    @SendingContent bit,
    @DocSize int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocParentId uniqueidentifier
    SELECT TOP 1
        @DocParentId = Docs.ParentId
    FROM
        TVF_Docs_UpdLock_Id_Level(@DocSiteId, @DocId, @DocLevel) AS Docs
    IF @@ROWCOUNT <> 1
    BEGIN
        RETURN 3
    END
    IF @SendingContent = CAST(0 AS bit)
    BEGIN
        UPDATE
            Docs
        SET
            VirusStatus = @VirusStatus,
            VirusInfo = @VirusInfo,
            VirusVendorID = @VirusVendorID,
            VirusInfoEx = @VirusInfoEx,
            -- not sending content, @BSNBump should be 0
            NextBSN = 
                CASE 
                    WHEN NextBSN IS NOT NULL AND @BSNBump IS NOT NULL THEN NextBSN + @BSNBump 
                    ELSE NextBSN 
                END,
            StreamSchema = 
                CASE 
                    WHEN @StreamSchema IS NULL THEN StreamSchema 
                    ELSE @StreamSchema 
                END
        FROM
            TVF_Docs_CI(@DocSiteId, @DocParentId, @DocId, @DocLevel) AS Docs
        WHERE
            (@NextBSNToCheck IS NULL OR NextBSN IS NULL OR @NextBSNToCheck = NextBSN) AND
            ETagVersion = @DocVersion
        IF @@ROWCOUNT <> 1
        BEGIN
            RETURN 1150 
        END
        ELSE
        BEGIN
            UPDATE
                Docs
            SET
                Docs.NextBSN = Docs.NextBSN + @BSNBump
            FROM
                TVF_Docs_PId_DId(@DocSiteId, @DocParentId, @DocId) AS Docs
            WHERE
                Docs.Level <> @DocLevel AND
                (Docs.Level >= 0 AND Docs.Level <= 256) AND 
                Docs.NextBSN IS NOT NULL AND @BSNBump IS NOT NULL
            RETURN 0
        END
    END
    ELSE 
    BEGIN
        DECLARE @cbDelta int
        SELECT TOP 1
            @cbDelta = Size - @DocSize
        FROM
            TVF_Docs_CI(@DocSiteId, @DocParentId, @DocId, @DocLevel) AS Docs
        IF @@ROWCOUNT <> 1
        BEGIN
            RETURN 3
        END
        UPDATE
            Docs
        SET
            Size = @DocSize,
            TimeLastWritten = dbo.fn_RoundDateToNearestSecond(GETUTCDATE()),
            Docs.InternalVersion = Docs.EffectiveVersion, Docs.BumpVersion = 0,
            VirusStatus = @VirusStatus,
            VirusInfo = @VirusInfo,
            VirusVendorID = @VirusVendorID,
            VirusInfoEx = @VirusInfoEx,
            DocFlags = DocFlags | 64,
            FFMConsistent = CAST(0 AS bit), 
            ContentVersion = 
                CASE 
                    WHEN @SendingContent = CAST(1 AS bit) THEN ContentVersion+1 
                    ELSE ContentVersion
                END,
            NextBSN =
                CASE 
                    WHEN @SendingContent = CAST(1 AS bit) AND Docs.NextBSN IS NOT NULL 
                        THEN Docs.NextBSN + @BSNBump
                    ELSE NextBSN
                END,
            StreamSchema = 
                CASE 
                    WHEN @StreamSchema IS NULL THEN StreamSchema 
                    ELSE @StreamSchema 
                END
        FROM
            TVF_Docs_CI(@DocSiteId, @DocParentId, @DocId, @DocLevel) AS Docs
        WHERE
            (@NextBSNToCheck IS NULL OR NextBSN IS NULL OR @NextBSNToCheck = NextBSN) AND
            ETagVersion = @DocVersion
        IF @@ROWCOUNT <> 1
        BEGIN
            RETURN 1150
        END
        ELSE IF @SendingContent = 1
        BEGIN
            UPDATE
                Docs
            SET
                Docs.NextBSN = Docs.NextBSN + @BSNBump
            FROM
                TVF_Docs_PId_DId(@DocSiteId, @DocParentId, @DocId) AS Docs
            WHERE
                Docs.Level <> @DocLevel AND
                (Docs.Level >= 0 AND Docs.Level <= 256) AND 
                Docs.NextBSN IS NOT NULL
        END
        EXEC proc_QMChangeSiteDiskUsedAndContentTimestamp
            @DocSiteId, @cbDelta, 1, @DocId
        RETURN 0
    END

go

