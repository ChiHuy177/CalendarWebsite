-- [Work_InsertUpdateWorkProcessVersion] 32887,0 
   CREATE   PROC [dbo].[Work_InsertUpdateWorkProcessVersion] 
   @UserWorkflowId as char(150)=1405 
   as 
   update Dynamic.Data_TMDSQTCV set Version='1' where UserWorkflowId=@UserWorkflowId and ISNULL(Version,1)=1 
   SELECT a.Id 
   ,a.UserWorkflowId 
   ,a.Title 
   ,a.WorkflowId 
   ,a.FlowChartData 
   ,ISNULL(a.Version,1) as Version 	
   into #a 
   FROM Dynamic.Data_TMDSQTCV a 
   inner join Dynamic.Data_TMDSQTCV b on a.WorkflowId=b.WorkflowId and a.Version=b.Version +1 
   where b.UserWorkflowId=@UserWorkflowId 
   if(select count(*) from #a)>0
   begin 
   INSERT INTO [Dynamic].[Data_FOLLOWCHART] 
   ( 
   [Nguoixuly] 
   ,[Nguoiphoihop] 
   ,[Nguoitheodoi] 
   ,[Mota] 
   ,[Tieude] 
   ,[Loaicv] 
   ,[Douutien] 
   ,[Thoigian] 
   ,[nodeid] 
   ,[QuyTrinhDinhKem]) 
   select [Nguoixuly] 
   ,[Nguoiphoihop] 
   ,[Nguoitheodoi] 
   ,[Mota] 
   ,[Tieude] 
   ,[Loaicv] 
   ,[Douutien] 
   ,[Thoigian] 
   ,[nodeid] 
   ,(select top 1 UserWorkflowId from #a) 
   from 
   [Dynamic].[Data_FOLLOWCHART] a 
   left join #a b on a.QuyTrinhDinhKem=b.UserWorkflowId	 
   where QuyTrinhDinhKem=@UserWorkflowId and b.Id is null 
   end 
   INSERT INTO [Dynamic].[Data_LSQTCV] 
   ( 
   [Title] 
   ,[Step] 
   ,[NextStep] 
   ,[Nodeid] 
   ,[Version] 
   ,[CategoryWorkProcessId]) 
   select a.Title 
   ,Step1 
   ,NextStep1 
   ,FlowChartId 
   ,b.Version 
   ,b.UserWorkflowId 
   from WorkflowStep a 
   inner join Dynamic.Data_TMDSQTCV b on a.WorkflowId=b.WorkflowId 
   left join [Dynamic].[Data_LSQTCV] c on c.Nodeid=a.FlowChartId and c.Version=b.Version 
   where b.UserWorkflowId=@UserWorkflowId and c.Id is null 
   update c set c.Step=a.Step1,c.NextStep=a.NextStep1, c.Title=a.Title 
   from WorkflowStep a 
   inner join Dynamic.Data_TMDSQTCV b on a.WorkflowId=b.WorkflowId 
   inner join [Dynamic].[Data_LSQTCV] c on c.Nodeid=a.FlowChartId and c.Version=b.Version 
   where b.UserWorkflowId=@UserWorkflowId 
   drop table #a
go

