CREATE FUNCTION [dbo].[TVF_Sites_NoLock_ALL]
(
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllSites] WITH (NOLOCK, INDEX=Sites_Id)
    WHERE
        Deleted = CONVERT(bit, 0)

go

