CREATE FUNCTION [dbo].[TVF_Docs_XLock_DirNameEqLike_NotForDelete]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @DirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        T1.*
    FROM
    (SELECT
        *
    FROM
        AllDocs WITH (XLOCK, INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName = @DirName
    UNION ALL
    SELECT
        *
    FROM
        AllDocs WITH (XLOCK, INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName LIKE @DirNameLike) AS T2
    INNER LOOP JOIN
        AllDocs AS T1 WITH (INDEX=AllDocs_ParentId, FORCESEEK)
    ON
                    T1.SiteId = T2.SiteId AND
                    T1.DeleteTransactionId = T2.DeleteTransactionId AND
                    T1.ParentId = T2.ParentId AND
                    T1.Id = T2.Id AND
                    T1.Level = T2.Level

go

