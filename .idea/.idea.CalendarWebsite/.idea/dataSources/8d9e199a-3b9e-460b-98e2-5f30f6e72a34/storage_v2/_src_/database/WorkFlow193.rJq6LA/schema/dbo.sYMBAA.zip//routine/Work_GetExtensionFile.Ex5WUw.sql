CREATE   PROC [dbo].[Work_GetExtensionFile] 
   @UserWorkflowId as bigint =218145 
   ,@id as bigint= 1838 
   as 
   declare @code as nvarchar(250), @user as nvarchar(500),@userManagerProject as nvarchar(500) 
   set @code= (select Code from Workflow where Id in ( select WorkflowId from UserWorkflow where Id=@UserWorkflowId )) 
   if(@code='WORK') 
   begin 
   select Name, Path as Value from Dynamic.CheckList_WORK where Id=@id 
   end 
   else if( @code='RESOURCEDA')
   begin 
   select Name, Path as Value from Dynamic.CheckList_RESOURCEDA where Id=@id 
   end
go

