CREATE FUNCTION [dbo].[TVF_GroupMembership_NoLock_Member]
(
    @SiteId uniqueidentifier,
    @MemberId int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[GroupMembership] WITH (NOLOCK, INDEX=GroupMembership_MemberId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        MemberId = @MemberId

go

