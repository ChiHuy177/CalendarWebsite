CREATE   PROC [dbo].[Work_GetManager]
   @userId as nvarchar(250)
   ,@type as int=1
   as
   if(@type=1)-- lay truong phong
   begin 
   select tp.Id as tp from PersonalProfile p	
   left join Department d on d.id = p.DepartmentId
   left join PersonalProfile tp on tp.Id = d.ManagerId
   where 'P:'+ TRIM(str(p.Id))= @userId
   end
   else -- lay qltt
   begin 
   select ql.Id as QLTT from PersonalProfile p
   left join PersonalProfile ql on ql.Id = p.ManagerId	
   where 'P:'+ TRIM(str(p.Id))= @userId
   end
go

