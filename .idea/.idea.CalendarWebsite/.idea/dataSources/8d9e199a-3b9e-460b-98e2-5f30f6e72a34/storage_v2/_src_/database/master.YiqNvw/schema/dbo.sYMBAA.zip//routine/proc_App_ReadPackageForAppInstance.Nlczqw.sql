CREATE Procedure [dbo].[proc_App_ReadPackageForAppInstance] (
    @InstallationId uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
SET NOCOUNT ON
SELECT Package FROM TVF_AppInstallations_Id(@SiteId, @InstallationId) AS Installation
    CROSS APPLY TVF_AppSourceInfo_SourceInfoId(@SiteId, Installation.SourceInfoId) AS SourceInfo
    CROSS APPLY TVF_AppPackages_PackageFingerprint(@SiteId, SourceInfo.PackageFingerprint)

go

