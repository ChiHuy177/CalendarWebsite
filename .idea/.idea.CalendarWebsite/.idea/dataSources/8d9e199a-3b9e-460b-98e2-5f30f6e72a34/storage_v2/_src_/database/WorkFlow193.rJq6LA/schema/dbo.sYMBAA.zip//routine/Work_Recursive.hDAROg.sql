-- [Work_Recursive] '342635',0,0                    
   CREATE   PROC [dbo].[Work_Recursive]                    
   @workId as nvarchar(max)                   
   ,@isMyWork as bit =0                   
   ,@getAllIncludeActiveFalse as bit =0                   
   as                    
   -- tạo bảng lưu workid                   
   declare @tbId table(UserWorkflowId bigint, RowIndex int,IsMyWork int)                    
   insert into @tbId select Item,0,0 from Split(@workId,',')                   
   ;                   
   -- tao bang tam #tbWork              
   SELECT                    
   a.UserWorkflowId,a.Tieude,a.Duan, a.CongViecCha                  
   into #tbWork              
   FROM Dynamic.Data_WORK a  where Id=0              
   declare @sql as nvarchar(max) =N'', @where as nvarchar(max)=''                   
   if(@isMyWork=0 and @getAllIncludeActiveFalse =0)                   
   begin                   
   set @where= N' where ISNULL( a.IsActive,''True'')=''True'' order by a.IndexWork'                   
   end                   
   else if(@isMyWork=1)                   
   begin                   
   set @where=N' left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId                   
   where d.TrangThaiCongViec<>N''Hoàn thành'' and ISNULL( a.IsActive,''True'')=''True''                   
   order by ISNULL(DATEDIFF(DAY, Ngayketthuc, GETDATE()),999999) desc '                   
   end                   
   set @sql=N'insert into #tbWork                   
   SELECT                    
   a.UserWorkflowId,a.Tieude,a.Duan, a.CongViecCha                    
   FROM Dynamic.Data_WORK a                   
   '                   
   exec(@sql+@where)                   
   print(@sql+@where)              
   ;                   
   -- ***************** đệ quy trong sql lấy ra tất cả cha con **************************                    
   -- rowIndex thứ tự node tính từ cha xuống băt đầu là 0 (0->1->2....)                    
   WITH Managers AS                    
   (                    
   --initialization                    
   SELECT a.UserWorkflowId,a.Tieude,a.CongViecCha, a.Duan, 0 as RowIndex,1 as IsMyWork                    
   FROM [Dynamic].[Data_WORK] AS a                    
   inner join @tbId b on a.UserWorkflowId=b.UserWorkflowId            
   where  ISNULL( a.IsActive,'True')='True'           
   --where a.UserWorkflowId in (218184,218207,218930,217302,217404,218720,218722)                    
   UNION ALL                    
   --recursive execution                   
   SELECT                    
   a.UserWorkflowId,a.Tieude,a.CongViecCha,b.Duan, b.RowIndex +1 as RowIndex,0 as IsMyWork                    
   FROM #tbWork a                   
   inner join Managers b on ISNULL(b.UserWorkflowId,'') = ISNULL(a.CongViecCha,'')                   
   )                    
   -- ***************** đệ quy trong sql lấy ra tất cả cha con **************************                    
   --bảng #a thêm vào bang tạm #a workId                    
   SELECT a.UserWorkflowId,RowIndex,IsMyWork,Tieude into #a                    
   FROM Managers a                    
   --bảng #b lấy ra distinct workId để xuống dưới join không bị trùng                    
   select UserWorkflowId into #b from #a group by UserWorkflowId                   
   -- bảng #c lấy ra gốc cha (gốc cha là 0) having dùng để lấy ra node bằng 0 và là duy nhất                   
   select UserWorkflowId ,min(RowIndex) as RowIndex,Tieude into #c from #a                    
   group by UserWorkflowId,Tieude having COUNT(UserWorkflowId)=1                    
   CREATE TABLE #duan (UserWorkflowId char(50), Ten nvarchar(500), Loai nvarchar(500))                    
   insert into #duan select UserWorkflowId,Ten,Loai from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False'                    
   insert into #duan select '','',''  
   SELECT a.Duan                    
   ,a.Id                    
   ,a.UserWorkflowId                  
   ,case when ISNULL( h.RowIndex,9999)=0 then 0 else 9999 end as RowIndex                   
   ,ISNULL(a.CongViecCha,'') as CongViecCha                    
   ,a.tieude AS title                    
   ,ISNULL(a.noidung, '') AS description        
   ,a.TrangThaiCongViec AS STATUS                    
   ,a.tieude                   
   ,a.noidung                    
   ,ISNULL(a.Nguoiphoihop, '') AS Nguoiphoihop ,isnull(a.Nguoixuly, '') AS Nguoixuly                   
   ,ISNULL(a.Nguoigiao, '') AS Nguoigiao                    
   ,ISNULL(a.Nguoitheodoi, '') AS Nguoitheodoi                    
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, null), 120)) AS [start]                    
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS [end]                    
   ,trim(CONVERT(CHAR, ISNULL(e.CreatedTime, getdate()), 120)) AS CreatedTime                    
   ,ISNULL(a.Loaicv, '') AS Loaicv                    
   ,a.Tiendo as Progress                    
   ,b.Ten as projectName                   
   ,b.UserWorkflowId as ProjectId                    
   ,d.Ten as statusName                   
   ,a.Douutien Priority                   
   ,c.TenCV as CategoryName                   
   ,d.TrangThaiCongViec as StatusType                   
   ,e.Id as Id1                   
   ,e.CreatedBy                   
   ,case when ISNULL( g.UserWorkflowId,0)>0 then 1 else 0 end as IsMyWork                    
   ,d.TrangThaiCongViec as StatusType                   
   ,case when ISNULL(g.UserWorkflowId,0)>0 then 1 else 0 end as IsMyWork                    
   ,case when d.TrangThaiCongViec=N'Hoàn thành' then trim(CONVERT(CHAR, ISNULL(e.LastModified, null), 120)) else null end as DateComplete                    
   ,CONVERT(CHAR, ISNULL(e.LastModified, e.CreatedTime), 120) as LastModified                    
   --,case when exists ( select UserWorkflowId as abc from [Dynamic].[Data_WORK] where CongViecCha=a.UserWorkflowId) then 'True' else 'False' end as Haschildren                    
   ,ISNULL(a.CongViecCha,'') as Parent                    
   ,case when ISNULL( h.RowIndex,9999)=0 then 'True' else '' end as IsShowInGanttChart                   
   ,case when d.TrangThaiCongViec<>N'Hoàn thành' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) >0 then N'Trễ '+ trim(str( DATEDIFF(DAY, Ngayketthuc, GETDATE()))) +N' ngày'                   
   when d.TrangThaiCongViec<>N'Hoàn thành' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) <0 then N'Còn '+ trim(str( ABS( DATEDIFF(DAY, Ngayketthuc, GETDATE())))) +N' ngày'                   
   when d.TrangThaiCongViec<>N'Hoàn thành' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) =0 then N'Hôm nay ( '+ trim(str( DATEDIFF(HOUR, GETDATE(),Ngayketthuc )))+'h )'                   
   else '' end as RemainTime                   
   ,i.Ten as GroupProject                   
   ,case when d.TrangThaiCongViec<> N'Hoàn thành' and DATEDIFF(DAY, a.Ngayketthuc, GETDATE()) >0 then trim(str( DATEDIFF(DAY, a.Ngayketthuc, GETDATE())))                   
   when d.TrangThaiCongViec<> N'Hoàn thành' and DATEDIFF(DAY, a.Ngayketthuc, GETDATE()) <0 then trim(str(( DATEDIFF(DAY, a.Ngayketthuc, GETDATE())))) else 0 end as RemainTimeInt                   
   ,a.IndexWork                  
   ,case when ISNULL(a.WorkRepeatId,'')<> '' then N'Việc lặp'            
   when ISNULL(a.Nodeid,'')<> '' or ISNULL(a.QuyTrinhDinhKem,'')<> '' then   
   case when ISNULL(a.ProcessType,'')=N'chỉ chạy 1 quy trình' then a.ProcessType  
   when ISNULL(a.ProcessType,'')=N'đồng thời' then a.ProcessType  
   else N'Quy trình' end 
   when ISNULL(a.RequestChangeUser,0)=1 then N'Chuyển xử lý'
   else N'Công việc' end as WorkType     
   ,a.GrantChartToId,a.GrantChartType       
   FROM [Dynamic].[Data_WORK] AS a                    
   inner join #duan b on ISNULL(a.Duan,'')=b.UserWorkflowId                   
   left join DYNAMIC.Data_NHOMCV c on a.Loaicv=c.UserWorkflowId                    
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId  and a.Duan=d.Duan          
   inner join Dynamic.Workflow_WORK e on a.UserWorkflowId=e.UserWorkflowId                    
   inner join #b f on a.UserWorkflowId=f.UserWorkflowId                    
   left join @tbId g on a.UserWorkflowId=g.UserWorkflowId                    
   left join #c h on a.UserWorkflowId=h.UserWorkflowId                   
   left join Dynamic.Data_ProjectGroup i on i.UserWorkflowId=a.GroupProject and i.ProjectId=a.Duan                   
   -- order by ISNULL(DATEDIFF(DAY, a.Ngayketthuc, GETDATE()),999999) desc , d.TrangThaiCongViec,a.UserWorkflowId                   
   --select * from #a                    
   --select * from #c                    
   drop table #duan                   
   drop table #tbWork                   
   drop table #a                    
   drop table #b                    
   drop table #c                   
   -- [Work_Recursive] '257775,253595,247736,260653,256713,263300,255721,247722,263302,258503,247716,247733',0   
go

