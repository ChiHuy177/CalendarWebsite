CREATE PROCEDURE [dbo].[proc_EnableDeclarativeWorkflowAssociations] (
    @SiteId uniqueidentifier,
    @Enabled int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        WFA        
    SET
        WFA.Configuration = 
            CASE 
                WHEN (@Enabled = 1) THEN (WFA.Configuration & ~128) 
                ELSE (WFA.Configuration | 128) 
            END
    FROM
        TVF_WorkflowAssoc_Site(@SiteId) AS WFA
    WHERE        
        (WFA.Configuration & 64) <> 0

go

