CREATE FUNCTION [dbo].[TVF_Docs_Id_LevelLT]
(
    @SiteId uniqueidentifier,
    @Id uniqueidentifier,
    @LTLevel tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (INDEX=Docs_IdLevelUnique, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        Id = @Id AND
        Level < @LTLevel

go

