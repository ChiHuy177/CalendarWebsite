-- Work_CheckUploadFileFalse 217400
   CREATE   PROC [dbo].[Work_CheckUploadFileFalse] 
   @workId as nvarchar(150)
   as 
   declare @code as nvarchar(150)='',@sql as nvarchar(max)=''
   set @code=(select Code from Workflow where Id in (select WorkflowId from UserWorkflow where Id=@workId))
   set @sql='
   declare @count as int
   set @count=( select COUNT(*) from Dynamic.CheckList_'+TRIM(@code)+'
   where UserWorkflowId='+@workId+' and 
   ISNUMERIC(Path)=0)
   delete Dynamic.CheckList_'+TRIM(@code)+'
   where UserWorkflowId='+@workId+' and 
   ISNUMERIC(Path)=0
   select @count
   '
   exec(@sql)
   print(@sql)
go

