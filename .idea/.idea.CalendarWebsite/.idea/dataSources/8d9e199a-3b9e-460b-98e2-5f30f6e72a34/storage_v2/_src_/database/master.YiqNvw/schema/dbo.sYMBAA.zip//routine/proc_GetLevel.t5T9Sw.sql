CREATE PROCEDURE [dbo].[proc_GetLevel](
    @DocSiteId   uniqueidentifier,
    @DocDirName  nvarchar(256),
    @DocLeafName nvarchar(128),
    @UserId      int,
    @MaxCheckinLevel tinyint,
    @Level       tinyint OUTPUT,
    @CheckinLevel tinyint = NULL OUTPUT,
    @WebId       uniqueidentifier = NULL OUTPUT,
    @DocParentId uniqueidentifier = NULL OUTPUT,
    @DocId uniqueidentifier = NULL OUTPUT
    )
AS
    SET NOCOUNT ON 
    DECLARE @CheckoutUserId int
    DECLARE @DraftOwnerId int
    DECLARE @Lists_Flags    bigint    
    SET @Level = NULL
    SET @DocParentId = NULL
    SET @DocId = NULL
    SET @CheckinLevel = NULL
    SELECT TOP 1
        @DocParentId = ParentId,
        @DocId = Id
    FROM
        TVF_Docs_NoLock_Url(@DocSiteId, @DocDirName, @DocLeafName) AS Docs
    IF @DocId IS NULL
        RETURN
    SELECT TOP 1    
        @CheckoutUserId = Docs.LTCheckoutUserId,
        @DraftOwnerId = Docs.DraftOwnerId,
        @Level = Docs.Level,
        @Lists_Flags = L.tp_Flags,
        @WebId = Docs.WebId
    FROM 
        TVF_Docs_PIdDIdLevelLEQ(
            @DocSiteId, 
            @DocParentId, 
            @DocId, 
            @MaxCheckinLevel) AS Docs
    OUTER APPLY
        fn_Lists_SubImage(
            Docs.SiteId,
            Docs.WebId,
            Docs.ListId,
            Docs.DocFlags,
            Docs.DoclibRowId) AS L
    WHERE
        Docs.Level <> 255
    ORDER BY 
        Docs.Level DESC
    OPTION (FORCE ORDER)
    IF (@Level IS NULL  OR 
        (@DraftOwnerId IS NOT NULL AND
        (@Lists_Flags IS NULL OR
        ((@Lists_Flags & 0x100000 = 0) AND 
         (@Lists_Flags & 0x200000 = 0)) OR
         (@DraftOwnerId = @UserId)))) AND
       @MaxCheckinLevel = 1 
    BEGIN
        SELECT TOP 1
            @CheckoutUserId = LTCheckoutUserId,
            @Level = Level,
            @WebId = WebId
        FROM 
            TVF_Docs_CI(@DocSiteId, @DocParentId, @DocId, 2) AS Docs
    END
    SET @CheckinLevel = @Level
    IF (@UserId IS NOT NULL AND @UserId <> 0) AND
        (@Level IS NULL OR 
        (@CheckoutUserId IS NOT NULL AND 
        ((@CheckoutUserId = @UserId) OR (@UserId = -1))))
    BEGIN
        SELECT TOP 1
            @Level = Level,
            @WebId = WebId
        FROM
            TVF_Docs_CI(@DocSiteId, @DocParentId, @DocId, 255) AS Docs
        WHERE
            ((CheckoutUserId = @UserId) OR (@UserId = -1))
    END   

go

