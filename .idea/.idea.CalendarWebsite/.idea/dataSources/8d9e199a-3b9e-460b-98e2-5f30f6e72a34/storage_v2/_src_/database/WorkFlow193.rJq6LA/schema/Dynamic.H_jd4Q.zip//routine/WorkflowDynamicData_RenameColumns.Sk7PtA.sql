-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicData_RenameColumns] 
	-- Add the parameters for the stored procedure here
	@OldName nvarchar(max),
	@NewName nvarchar(max),
	@PropertyId bigint
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @ColumnName NVARCHAR(MAX);
	DECLARE @WorkflowId BIGINT;
	DECLARE @SqlScript NVARCHAR(4000);

	SET @WorkflowId = (
				SELECT TOP 1 WorkflowId
				FROM Property
				WHERE Id = @PropertyId
				);
	SET @ColumnName = (
				SELECT TOP 1 Name
				FROM Property
				WHERE Id = @PropertyId
				);
	SET @TableName = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @WorkflowId
				)
	SET @TableName = CONCAT (
				'Dynamic.Data_'
				,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
				);

	SET @SqlScript = 'IF OBJECT_ID(N''' + @TableName + ''', N''U'') IS NOT NULL AND COL_LENGTH(N''' + @TableName + ''', ''' + @OldName + ''') IS NOT NULL 
					BEGIN '
					+ ' EXEC sp_RENAME N'''
					+ @TableName + '.' + @OldName 
					+''', N''' +  @NewName 
					+ ''', ''COLUMN'''
					+ ' END'
		print @SqlScript;
		EXEC sp_ExecuteSql @SqlScript;
END
go

