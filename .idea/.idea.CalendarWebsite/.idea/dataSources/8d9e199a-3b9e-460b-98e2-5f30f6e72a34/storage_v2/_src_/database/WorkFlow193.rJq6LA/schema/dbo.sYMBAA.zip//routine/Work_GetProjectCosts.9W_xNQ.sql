CREATE   PROC [dbo].[Work_GetProjectCosts]             
   @isParent as bit =0           
   ,@projectId as nvarchar(50)          
   as            
   if(@isParent  = 1)            
   begin            
   select a.RowIndex, a.UserWorkflowId , a. DisplayText            
   from Dynamic.data_WorkProjectCost a             
   where ISNULL(a.IsDelete,'false') ='false' and ISNULL(a.ParentId,'') ='' and a.ProjectId =@projectId     
   order by a.UserWorkflowId   desc
   end            
   else            
   begin             
   select b.RowIndex,  a.UserWorkflowId , b. DisplayText , a.ParentId as parentId, a.CouponId, c.Title as CouponName , a.CoulumnCoupon          
   from Dynamic.data_WorkProjectCost a       
   inner join Dynamic.data_WorkProjectCost b on a.ParentId = b.UserWorkflowId             
   inner join Workflow c on c.Id=a.CouponId      
   where ISNULL(a.IsDelete,'false') ='false' and  ISNULL(a.ParentId,'false') <>'false'and  a.ProjectId =@projectId         
   order by a.UserWorkflowId  asc           
   end
go

