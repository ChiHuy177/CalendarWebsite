-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CO3.GetDetailById] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@WorkflowId BIGINT
		,@TableName AS NVARCHAR(MAX)
		,@Sql NVARCHAR(4000)
	SET @WorkflowId = (
			SELECT WorkflowId
			FROM [dbo].[UserWorkflow]
			WHERE Id = @UserWorkflowId
			);
	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	set @Sql='
	SELECT u.*,dw.[Data]
	FROM UserWorkflow u
	INNER JOIN '+ @TableName +' dw ON dw.UserWorkflowId = u.Id
	
	WHERE u.IsDeleted = 0
		AND dw.UserWorkflowId =' + CAST(@UserWorkflowId AS VARCHAR) 
		PRINT @SQL

	EXEC sp_ExecuteSql @SQL;
		
END
go

