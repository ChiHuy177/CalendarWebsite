CREATE PROCEDURE [dbo].[proc_DTClearRelationshipFromChild](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128)
)
AS
    SET NOCOUNT ON
    UPDATE 
        Docs
    SET
        ParentVersion = NULL,
        TransformerId = NULL,
        ParentLeafName = NULL
    FROM
        TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS Docs
    DECLARE @FullUrl nvarchar(260)
    SET @FullUrl = CASE WHEN (DATALENGTH(@DirName) = 0) THEN @LeafName WHEN (DATALENGTH(@LeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @LeafName END
    DELETE 
        D
    FROM
        TVF_Deps_SiteDelIdUrl(@SiteId, 0x, @FullUrl) AS D
    WHERE
        D.DepType = 8

go

