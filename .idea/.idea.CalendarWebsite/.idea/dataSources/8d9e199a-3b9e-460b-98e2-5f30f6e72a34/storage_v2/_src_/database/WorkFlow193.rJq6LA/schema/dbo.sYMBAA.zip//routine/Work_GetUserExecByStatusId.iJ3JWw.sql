CREATE   PROC [dbo].[Work_GetUserExecByStatusId]
   @statusId as bigint 
   as 
   select 
   b.Id 
   , b.Ten as Name  
   , b.Duan as ProjectId  
   , b.TrangThaiCongViec 
   ,isnull(b.NguoiChinhSua,'') as [user]  
   ,b.UserWorkflowId 
   ,c.Step  
   --,c.WorkflowId  
   ,c.NextStep  
   ,ISNULL(a.QuanLy,'') as Manager 
   , b.QuyenXacNhanHoanThanhCV 
   from [Dynamic].Data_RESOURCEDA a 
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan 
   inner join Dynamic.Data_LSQTCV c on a.UserWorkflowId = c.ProjectId and b.nodeid=c.Nodeid and c.Title<>''  
   where b.UserWorkflowId=@statusId  
   order by c.Step 
go

