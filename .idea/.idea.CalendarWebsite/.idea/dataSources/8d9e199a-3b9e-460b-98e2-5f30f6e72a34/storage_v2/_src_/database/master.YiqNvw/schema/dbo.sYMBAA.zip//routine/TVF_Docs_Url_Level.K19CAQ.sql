CREATE FUNCTION [dbo].[TVF_Docs_Url_Level]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName = @DirName AND
        LeafName = @LeafName AND
        Level = @Level

go

