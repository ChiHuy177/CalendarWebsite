CREATE FUNCTION [dbo].[TVF_AllWebParts_NoLock_Site]
(
    @tp_SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebParts] WITH (NOLOCK, INDEX=PageUrlID_FK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId

go

