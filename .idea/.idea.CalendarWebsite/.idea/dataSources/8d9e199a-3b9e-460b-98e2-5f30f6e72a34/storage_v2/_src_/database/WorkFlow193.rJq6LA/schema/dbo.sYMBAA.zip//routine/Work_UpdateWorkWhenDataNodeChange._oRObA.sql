-- Work_UpdateWorkWhenDataNodeChange 21617      
   CREATE   PROC  [dbo].[Work_UpdateWorkWhenDataNodeChange]      
   @id as char(50) ,    
   @userId as char(50)=null    
   as      
   update a set a.Nguoixuly=b.Nguoixuly      
   ,a.Nguoiphoihop=b.Nguoiphoihop      
   ,a.Nguoitheodoi=b.Nguoitheodoi      
   ,a.Noidung=b.Mota      
   ,a.Tieude=b.Tieude      
   ,a.Loaicv=b.Loaicv      
   ,a.QuyTrinhDinhKem=b.QuyTrinhDinhKem      
   ,a.Quytrinh=b.Quytrinh      
   ,a.TudonghoanthanhCV=b.TudonghoanthanhCV      
   ,a.IsCompeleteWhenAllChildDone=b.IsCompeleteWhenAllChildDone      
   ,a.NguoiGiaoDauTien=@userId    
   ,a.NguoiXuLyDauTien=b.Nguoixuly     
   ,a.Nguoigiao=b.Nguoigiao  
   from Dynamic.Data_WORK a       
   inner join Dynamic.Data_FOLLOWCHART b on a.Nodeid=b.Nodeid and a.CongViecCha=b.IsUseForWork      
   where b.Id=@id and (ISNULL(a.IsActive,'True')='False' or ISNULL(a.IsActive,'True')='ActiveManual')
   ;
go

