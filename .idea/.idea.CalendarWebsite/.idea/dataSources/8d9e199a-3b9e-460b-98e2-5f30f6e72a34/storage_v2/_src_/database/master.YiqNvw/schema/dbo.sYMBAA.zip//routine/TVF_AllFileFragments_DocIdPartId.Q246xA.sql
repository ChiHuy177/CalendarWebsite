CREATE FUNCTION [dbo].[TVF_AllFileFragments_DocIdPartId]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @Partition tinyint,
    @Id bigint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllFileFragments] WITH (INDEX=AllFileFragments_PartId_UCI, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DocId = @DocId AND
        Partition = @Partition AND
        Id = @Id

go

