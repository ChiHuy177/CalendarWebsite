-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicData_EditColumns]
	-- Add the parameters for the stored procedure here
	@PropertyId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @Title NVARCHAR(MAX);
	DECLARE @TitleEN NVARCHAR(MAX);
	DECLARE @ColumnName NVARCHAR(MAX);
	DECLARE @WorkflowId BIGINT;
	DECLARE @SqlScript NVARCHAR(4000);

	SELECT @WorkflowId = c.WorkflowId
		,@ColumnName = c.Name
		,@Title = c.[Label]
		,@TitleEN = c.LabelEN
	FROM Property c
	WHERE c.Id = @PropertyId

	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @TableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	SET @SqlScript = 'IF OBJECT_ID(N''' + @TableName + ''', N''U'') IS NOT NULL AND COL_LENGTH(N''' + @TableName + ''', ''' + @ColumnName + ''') IS NOT NULL 
					BEGIN ALTER TABLE ' + @TableName + ' alter  column [' + @ColumnName + ']' + (
			SELECT (
					CASE 
						WHEN p.IsSingle = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsMultiLine = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsChoice = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsNumber = 1
							AND p.IsViewOnly <> 1
							THEN ' decimal(22,4) null'
						WHEN p.IsNumber = 1
							AND p.IsViewOnly = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsCurrency = 1
							AND p.IsViewOnly <> 1
							THEN ' decimal(22,4) null'
						WHEN p.IsCurrency = 1
							AND p.IsViewOnly = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsDateAndTime = 1
							THEN ' datetime2(7) NULL'
						WHEN p.IsLookup = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsYesNo = 1
							THEN ' bit NULL'
						WHEN p.IsUser = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsCalculated = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsFile = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						WHEN p.IsApi = 1
							THEN ' [nvarchar](' + (
									CASE 
										WHEN p.SqlLength IS NULL
											THEN 'max'
										ELSE CAST(p.SqlLength AS NVARCHAR(max))
										END
									) + ') NULL'
						ELSE ' [nvarchar](' + (
								CASE 
									WHEN p.SqlLength IS NULL
										THEN 'max'
									ELSE CAST(p.SqlLength AS NVARCHAR(max))
									END
								) + ') NULL'
						END
					)
			FROM Property p
			WHERE p.Id = @PropertyId
			) + ' END'

	PRINT @SqlScript;

	EXEC sp_ExecuteSql @SqlScript;

	UPDATE r
	SET r.Title = @Title
		,r.TitleEN = @TitleEN
	FROM [Report].[ReportBaseColumn] r WITH (NOLOCK)
	WHERE r.PropertyId = @PropertyId

	UPDATE r
	SET r.Title = @Title
		,r.TitleEN = @TitleEN
	FROM [Resource].[ResourceBaseColumn] r WITH (NOLOCK)
	WHERE r.PropertyId = @PropertyId
END
go

