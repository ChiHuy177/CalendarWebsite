CREATE Procedure [dbo].[proc_App_InvalidatePackage] (
    @PackageFingerprint binary(64),
    @SiteId uniqueidentifier    
)
AS
SET NOCOUNT ON
--shouldn't need an applock for this, always know what we're getting/setting when using this data
UPDATE TVF_AppPackages_PackageFingerprint(@SiteId, @PackageFingerprint)
    SET IsDownloadInvalidated = 1

go

