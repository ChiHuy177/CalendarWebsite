CREATE FUNCTION [dbo].[TVF_EventSubsMatches_SiteSubEvent]
(
    @SiteId uniqueidentifier,
    @SubId uniqueidentifier,
    @EventId bigint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[EventSubsMatches] WITH (INDEX=EventSubsMatches_EventIdSubId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SubId = @SubId AND
        EventId = @EventId

go

