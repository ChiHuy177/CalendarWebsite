CREATE FUNCTION [dbo].[TVF_AppSourceInfo_AssetId]
(
    @SiteId uniqueidentifier,
    @AssetId nvarchar(16)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppSourceInfo] WITH (INDEX=AppSourceInfo_AssetId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@AssetId IS NULL AND AssetId IS NULL) OR @AssetId=AssetId)

go

