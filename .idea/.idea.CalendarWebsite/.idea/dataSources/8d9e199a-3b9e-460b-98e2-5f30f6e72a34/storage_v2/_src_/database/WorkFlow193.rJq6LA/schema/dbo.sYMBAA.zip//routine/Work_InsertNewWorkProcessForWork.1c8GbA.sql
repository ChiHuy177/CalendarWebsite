CREATE   PROC [dbo].[Work_InsertNewWorkProcessForWork]                     
   @UserWorkflowId as bigint                      
   ,@workId as bigint                      
   as                     
   if(@workId<0)                    
   begin                     
   delete [Dynamic].[Data_TMDSQTCV] where IsUseForWork= TRIM(STR( @workId ))                     
   delete [Dynamic].[Data_LSQTCV] where IsUseForWork= TRIM(STR( @workId ))                     
   delete [Dynamic].[Data_FOLLOWCHART] where IsUseForWork= TRIM(STR( @workId ))                     
   end                     
   declare @pk as bigint                     
   -- thêm vào bảng danh sách quy trình CV                     
   INSERT INTO [Dynamic].[Data_TMDSQTCV]                     
   ([UserWorkflowId]                     
   ,[Title]                     
   ,[WorkflowId]                     
   ,[FlowChartData]                     
   ,[Version]                     
   ,[IsUseForWork]                     
   ,[PermissionEdit]                     
   ,[IsDelete]                     
   ,[PermissionUser]      
   ,RootFlowchart   
   ,[ActiveManual] 
   ,AllowShowAllDataInWorkProcess
   )                   
   select [UserWorkflowId]                     
   ,[Title]                     
   ,[WorkflowId]                     
   ,[FlowChartData]                     
   ,[Version]                     
   ,@workId as [IsUseForWork]                     
   ,[PermissionEdit]                     
   ,[IsDelete]                     
   ,[PermissionUser]          
   ,@UserWorkflowId  as RootFlowchart      
   ,[ActiveManual]  
   ,AllowShowAllDataInWorkProcess
   from Dynamic.Data_TMDSQTCV                     
   where IsUseForWork is null and UserWorkflowId=@UserWorkflowId              
   set @pk =(select @@IDENTITY )                     
   update Dynamic.Data_TMDSQTCV set UserWorkflowId = @pk where Id=@pk                     
   -- thêm vào bảng chi lưu node chi tiết của quy trình cv                     
   INSERT INTO [Dynamic].[Data_LSQTCV]                     
   ([UserWorkflowId]                     
   ,[Title]                     
   ,[Step]                     
   ,[NextStep]                     
   ,[Nodeid]                     
   ,[Version]                     
   ,[CategoryWorkProcessId]                     
   ,[IsUseForWork]                     
   ,[ProjectId]                     
   )                     
   select [UserWorkflowId]                     
   ,[Title]                     
   ,[Step]                     
   ,[NextStep]                     
   ,[Nodeid]                     
   ,[Version]                     
   ,@pk as [CategoryWorkProcessId]                     
   , @workId as [IsUseForWork]                     
   ,[ProjectId]         
   from Dynamic.Data_LSQTCV                     
   where CategoryWorkProcessId= @UserWorkflowId                     
   -- cập nhật workId vào quy trình mới thêm                     
   update Dynamic.Data_WORK set QuyTrinhDinhKem=@pk where UserWorkflowId=@workId                     
   -- thêm mới vào bảng lưu node cv khi thêm mới quy trình bằng thêm cv                     
   INSERT INTO [Dynamic].[Data_FOLLOWCHART]                     
   ([UserWorkflowId]                     
   ,[Nguoixuly]                     
   ,[Nguoiphoihop]                     
   ,[Nguoitheodoi]       
   ,[Nguoigiao]    
   ,[Mota]                     
   ,[Tieude]                     
   ,[Loaicv]                     
   ,[Douutien]                     
   ,[Thoigian]                     
   ,[Nodeid]                     
   ,[QuyTrinhDinhKem]                     
   ,[IsUseForWork]                     
   ,[Quytrinh]                     
   ,[TudonghoanthanhCV]                     
   ,ChoiceUserExecBefore                     
   ,IsCompeleteWhenAllChildDone             
   ,GetUserInWork                     
   ,CategoryWorkProcessId        
   ,TimeUnit                  
   ,ChoiceWorkflowRelationshipBefore         
   ,RequireAttachFileToCompleteWork        
   ,RootFlowchart        
   )                     
   select                     
   null as [UserWorkflowId]                   
   ,[Nguoixuly]                    
   ,[Nguoiphoihop]                     
   ,[Nguoitheodoi]      
   ,[Nguoigiao]    
   ,[Mota]                     
   ,[Tieude]                     
   ,[Loaicv]           
   ,[Douutien]                     
   ,[Thoigian]                     
   ,[Nodeid]                     
   ,[QuyTrinhDinhKem]                     
   , @workId as [IsUseForWork]              
   ,[Quytrinh]                     
   ,[TudonghoanthanhCV]                     
   ,ChoiceUserExecBefore                     
   ,IsCompeleteWhenAllChildDone                     
   ,GetUserInWork                     
   , @pk as CategoryWorkProcessId                    
   ,TimeUnit              
   ,ChoiceWorkflowRelationshipBefore            
   ,RequireAttachFileToCompleteWork        
   ,@UserWorkflowId  as RootFlowchart      
   from [Dynamic].[Data_FOLLOWCHART] where CategoryWorkProcessId= trim(str(@UserWorkflowId))                     
   -- thêm vào bảng công việc con của công việc quy trình                
   INSERT INTO [Dynamic].[Data_WorkChildFlowChart]                
   ([UserWorkflowId]                
   ,[Nguoixuly]                
   ,[Nguoiphoihop]                
   ,[Nguoitheodoi]                
   ,[Noidung]                
   ,[Tieude]                
   ,[Loaicv]                
   ,[Douutien]                
   ,[Thoigian]                
   ,[TimeUnit]                
   ,[FlowChartWorkId]                
   ,[IsDelete]                
   ,[NodeId]                
   ,[CategoryWorkProcessId])                
   select [UserWorkflowId]                 
   ,[Nguoixuly]                
   ,[Nguoiphoihop]                
   ,[Nguoitheodoi]                
   ,[Noidung]                
   ,[Tieude]                
   ,[Loaicv]                
   ,[Douutien]                
   ,[Thoigian]                
   ,[TimeUnit]                
   ,[FlowChartWorkId]                
   ,[IsDelete]                
   ,[NodeId]                
   ,@pk as [CategoryWorkProcessId]                
   from Dynamic.Data_WorkChildFlowChart                
   where CategoryWorkProcessId = trim(str(@UserWorkflowId)) and ISNULL(IsDelete,'False')='False'                   
   ;                
   update a set a.FlowChartWorkId=b.Id                
   from Dynamic.Data_WorkChildFlowChart a                
   inner join Dynamic.Data_FOLLOWCHART b on a.CategoryWorkProcessId=b.CategoryWorkProcessId and a.NodeId=b.Nodeid                
   where a.CategoryWorkProcessId = @pk                 
   -- thêm vào bảng check list          
   INSERT INTO [Dynamic].Data_WorkChecklist                
   ([UserWorkflowId]          
   ,[WorkId]          
   ,[Title]          
   ,[UserExec]          
   ,[Note]          
   ,[IsComplete]          
   ,[IsDelete]          
   ,[UserUpdateComplete]          
   ,[NodeId]          
   ,[FlowchartId]          
   ,[CategoryWorkProcessId])                
   select [UserWorkflowId]          
   ,[WorkId]          
   ,[Title]          
   ,[UserExec]          
   ,[Note]          
   ,[IsComplete]          
   ,[IsDelete]          
   ,[UserUpdateComplete]          
   ,[NodeId]          
   ,[FlowchartId]                        
   ,@pk as [CategoryWorkProcessId]                
   from Dynamic.Data_WorkChecklist                
   where CategoryWorkProcessId = trim(str(@UserWorkflowId)) and ISNULL(IsDelete,'False')='False'                   
   ;           
   update a set a.FlowchartId=b.Id                
   from Dynamic.Data_WorkChecklist a                
   inner join Dynamic.Data_FOLLOWCHART b on a.CategoryWorkProcessId=b.CategoryWorkProcessId and a.NodeId=b.Nodeid                
   where a.CategoryWorkProcessId = @pk                 
   select @pk
go

