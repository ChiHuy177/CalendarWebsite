-- Work_GetPriorityValue '333573'  
   CREATE   PROC Work_GetPriorityValue  
   @statusId as nvarchar(500)  
   AS    
   select b.Value,b.Priority, case when Priority =N'Thấp' then -1   
   when Priority =N'Bình thường' then -2  
   when Priority =N'Cao' then -3  
   else -4 end as rowIndex  
   ,b.Id  
   , a.Ten as Name
   into #a   
   from  DYNAMIC.Data_RESOURCETTFC AS a     
   inner join Dynamic.Data_PriorityValue b on a.UserWorkflowId=b.StatusId and a.Duan=b.ProjectId  
   WHERE b.StatusId=@statusId  
   if(select COUNT(*) from #a)>0  
   begin   
   select Id , Value, Priority as Label,Name  from #a order by rowIndex desc   
   end  
   else  
   begin   
   select * from (  
   select -1 as Id,  null as Value,N'Thấp' as Label  
   union   
   select -2 as Id, null as Value,N'Bình thường' as Label  
   union   
   select -3 as Id, null as Value,N'Cao' as Label  
   union   
   select -4 as Id, null as Value,N'Khẩn cấp' as Label  
   ) a order by Id desc   
   end
go

