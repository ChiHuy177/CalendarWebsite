CREATE PROCEDURE [dbo].[proc_RemoveUrlFromSite]
(   
    @SiteId uniqueidentifier,
    @HostHeader nvarchar(128),
    @HostHeaderSiteUrlScheme tinyint
)
AS
    SET NOCOUNT ON
    DECLARE @SchemeStr nvarchar(5)
    DECLARE @SiteUrlsTable tvpSiteUrls2
    DECLARE @CurSiteUrlsStr nvarchar(MAX)
    BEGIN TRAN
    SELECT @CurSiteUrlsStr = SiteUrls
    FROM TVF_Sites_UpdLock_Id(@SiteId)
    INSERT INTO @SiteUrlsTable
    (
        HostHeader,
        Scheme,
        UrlZone,
        AppSiteDomainId
    )
    SELECT
        HostHeader,
        Scheme,
        UrlZone,
        AppSiteDomainId
    FROM dbo.fn_Split_SiteUrls(@CurSiteUrlsStr)
    SET @SchemeStr = 
        CASE @HostHeaderSiteUrlScheme
            WHEN 2 THEN 'http'
            WHEN 3 THEN 'https'
            ELSE ''
        END
    DELETE FROM @SiteUrlsTable
    WHERE
        HostHeader = @HostHeader AND
        Scheme = @SchemeStr
    EXEC dbo.proc_UpdateSiteUrlsColumn @SiteId, @SiteUrlsTable
    COMMIT TRAN

go

