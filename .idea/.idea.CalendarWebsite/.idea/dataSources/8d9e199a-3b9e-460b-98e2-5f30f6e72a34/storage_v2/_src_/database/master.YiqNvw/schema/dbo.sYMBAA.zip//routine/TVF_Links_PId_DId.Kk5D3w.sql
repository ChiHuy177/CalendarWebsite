CREATE FUNCTION [dbo].[TVF_Links_PId_DId]
(
    @SiteId uniqueidentifier,
    @ParentId uniqueidentifier,
    @DocId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllLinks] WITH (INDEX=Links_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        ParentId = @ParentId AND
        DocId = @DocId

go

