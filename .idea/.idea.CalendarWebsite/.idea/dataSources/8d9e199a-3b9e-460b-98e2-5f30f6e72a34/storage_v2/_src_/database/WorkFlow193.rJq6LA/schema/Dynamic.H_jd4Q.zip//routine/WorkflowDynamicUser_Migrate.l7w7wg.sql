
-- =============================================
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_Migrate] @UserWorkflowId BIGINT
	,@WorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@TableName AS NVARCHAR(MAX)
		,@DataTableName AS NVARCHAR(MAX)
		,@Data_Json AS NVARCHAR(MAX)
		,@Sql NVARCHAR(MAX)

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	SET @Sql = 'DECLARE @Data_Json AS NVARCHAR(MAX); SET @Data_Json = (SELECT TOP 1 [Data] from ' + @TableName + ' where UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ');' + 'IF (@Data_Json IS NOT NULL AND NOT EXISTS (SELECT top 1 Id from ' + @DataTableName + ' where UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + '))
BEGIN exec [Dynamic].[WorkflowDynamicData_Insert] ' + CAST(@UserWorkflowId AS VARCHAR) + ', @Data_Json END';

	PRINT @Sql;

	EXEC sp_ExecuteSql @Sql;
END

go

