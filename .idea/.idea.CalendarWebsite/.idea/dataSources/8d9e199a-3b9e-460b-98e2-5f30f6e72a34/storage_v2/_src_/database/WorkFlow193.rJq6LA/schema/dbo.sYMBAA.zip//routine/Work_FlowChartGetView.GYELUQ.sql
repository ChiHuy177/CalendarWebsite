CREATE   PROC [dbo].[Work_FlowChartGetView] 
   @workProcessId as nvarchar(250)='' 
   as 
   SELECT a.Id 
   ,a.UserWorkflowId 
   ,Title 
   ,a.WorkflowId 
   ,c.CreatedTime 
   ,REPLACE(FlowChartData,'"strokeDasharray": "5 5"','"strokeDasharray": ""') as FlowChartData 
   --,FlowChartData 
   ,ISNULL(a.Version,1) as Version 
   FROM Dynamic.Data_TMDSQTCV a 
   left join Dynamic.Workflow_TMDSQTCV c on c.UserWorkflowId = a.UserWorkflowId 
   where a.UserWorkflowId=@workProcessId 
   order by a.UserWorkflowId desc 
go

