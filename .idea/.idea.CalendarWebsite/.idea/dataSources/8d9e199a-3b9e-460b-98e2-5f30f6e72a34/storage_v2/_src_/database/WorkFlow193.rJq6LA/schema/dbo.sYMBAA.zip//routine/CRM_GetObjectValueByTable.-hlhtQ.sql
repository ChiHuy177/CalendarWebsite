  CREATE   PROC [dbo].[CRM_GetObjectValueByTable]   
     @tableName as nvarchar(500)='Dynamic.Data_RESOURCEDA'  
 	,@value as  nvarchar(200) ='CONCAT(''P:'', a.id)'
     ,@columnName as nvarchar(200) ='Ten'  
 	,@join as nvarchar(150)=''
     ,@where as nvarchar(150)=''
 	
     as   
     declare @sql as nvarchar(max)   
   
      
       
  
     set @sql=N'   
   
     select ' + @value + ' as Value ,' +@columnName+' as Label from '+@tableName +' '+ @join + ' '+  @where
 
     exec(@sql)   
     print(@sql)
  go

