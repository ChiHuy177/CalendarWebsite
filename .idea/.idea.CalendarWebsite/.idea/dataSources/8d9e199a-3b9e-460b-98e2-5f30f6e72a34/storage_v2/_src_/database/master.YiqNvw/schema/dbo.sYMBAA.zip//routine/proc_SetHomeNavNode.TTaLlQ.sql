CREATE PROCEDURE [dbo].[proc_SetHomeNavNode](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @DirName nvarchar(256),
    @NewWelcomeName nvarchar(128),
    @ChangedHome bit OUTPUT
    )
AS
    SET NOCOUNT ON
    DECLARE @EidNewHome int
    SET @ChangedHome = 0
    SELECT TOP 1
        @EidNewHome = NV.Eid
    FROM
        TVF_Docs_Url(@SiteId, @DirName, @NewWelcomeName) AS D
    CROSS APPLY
        TVF_NavNodes_DocId(D.Id) AS NV
    WHERE
        D.SiteId = NV.SiteId AND
        D.WebId = NV.WebId AND
        NV.ChildOfSequence = 0
    IF @EidNewHome IS NOT NULL AND
        @EidNewHome <> 1000 AND
        NOT EXISTS(
            SELECT TOP 1
                1 
            FROM 
                TVF_NavNodes_PK(@SiteId, @WebId, 1000))
    BEGIN
        UPDATE
            NV
        SET
            NV.Eid = 1000
        FROM
            TVF_NavNodes_PK(@SiteId, @WebId, @EidNewHome) AS NV
        UPDATE
            NV
        SET
            NV.EidParent = 1000
        FROM
            TVF_NavNodes_SiteWebParent(@SiteId, @WebId, @EidNewHome) AS NV
        SET @ChangedHome = 1
        EXEC proc_NavStructLogChangesAndUpdateSiteChangedTime @SiteId, @WebId, NULL
    END

go

