CREATE FUNCTION [dbo].[TVF_AppInstallations_WebId]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppInstallations] WITH (INDEX=AppInstallations_WebIdSourceInfoId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId

go

