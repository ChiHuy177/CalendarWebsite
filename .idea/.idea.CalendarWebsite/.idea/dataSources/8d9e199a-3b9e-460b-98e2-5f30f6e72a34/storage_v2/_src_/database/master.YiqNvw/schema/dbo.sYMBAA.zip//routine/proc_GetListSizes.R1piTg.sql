CREATE PROCEDURE [dbo].[proc_GetListSizes](
    @SiteId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS 
    SET NOCOUNT ON
    SELECT 
        (ISNULL(DocSizes,0) + ISNULL(UserDataSize,0)) As TotalSize, 
        nLists.tp_ID,
        nLists.tp_WebID,
        nLists.tp_Modified,
        nLists.tp_ServerTemplate,
        nLists.DirName,
        nLists.LeafName,
        nLists.tp_ImageUrl,
        nLists.tp_Title,
        nLists.tp_ItemCount,
        Webs.WebTemplate,
        Webs.Language,
        Webs.FullUrl
    FROM
        Webs
    INNER JOIN
        (
        SELECT 
            ALAux.ItemCount as tp_ItemCount, 
            Lists.tp_Title, 
            Lists.tp_ID, 
            Lists.tp_WebID, 
            ALAux.Modified as tp_Modified, 
            Lists.tp_ServerTemplate, 
            Docs.DirName, 
            Docs.LeafName, 
            Lists.tp_ImageUrl
        FROM 
            Lists
        CROSS APPLY
            TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
        INNER JOIN 
            Docs
        ON 
            Lists.tp_RootFolder = Docs.Id AND 
            Lists.tp_WebId = Docs.WebId 
        WHERE 
            tp_BaseType <> 1 AND
            Lists.tp_SiteId = @SiteId
        ) As nLists
        ON
            Webs.Id = nLists.tp_WebId
        LEFT OUTER JOIN
            (
            SELECT 
                (SUM(CAST((ISNULL(Docs.Size,0)) AS BIGINT))) As DocSizes, 
                Docs.ListId,
                Docs.SiteId
            FROM 
                Docs 
            WHERE
                Docs.Type = 0 AND SiteId = @SiteId
            GROUP BY
                Docs.ListId,Docs.SiteId
            ) As DocsInList
            ON
                DocsInList.ListId = nLists.tp_ID
            LEFT OUTER JOIN
                (
                SELECT 
                    (SUM(CAST((ISNULL(tp_Size,0)) AS BIGINT))) As UserDataSize, 
                    tp_ListId 
                FROM
                    UserData 
                GROUP BY 
                    UserData.tp_ListId
                ) AS UserDataInList
                ON
                    UserDataInList.tp_ListId = DocsInList.ListId

go

