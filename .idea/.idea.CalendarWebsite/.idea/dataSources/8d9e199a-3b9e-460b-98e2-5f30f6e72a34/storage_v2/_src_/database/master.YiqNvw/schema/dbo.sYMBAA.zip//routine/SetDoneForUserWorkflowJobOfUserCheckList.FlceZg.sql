
-- =============================================
-- Author:		DuyDam
-- Create date: 15/04/2022
-- Description:	Set done for job and update IsWaitingForAppoved for UserWorkflowS
-- =============================================
CREATE PROCEDURE [dbo].[SetDoneForUserWorkflowJobOfUserCheckList] @UserWorkflowId BIGINT
	,@UserCheckListId BIGINT
	,@IsFail BIT
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE [dbo].[UserWorkflowJob]
	SET IsDone = 1
		,IsFail = (
			CASE @IsFail
				WHEN CAST(1 AS BIT)
					THEN CAST(1 AS BIT)
				ELSE CAST(0 AS BIT)
				END
			)
		,IsSucess = (
			CASE @IsFail
				WHEN CAST(1 AS BIT)
					THEN CAST(0 AS BIT)
				ELSE CAST(1 AS BIT)
				END
			)
	WHERE @UserWorkflowId = @UserWorkflowId
		AND UserCheckListId = @UserCheckListId;

	IF NOT EXISTS (
			SELECT TOP 1 Id
			FROM [dbo].[UserWorkflowJob]
			WHERE IsDeleted = CAST(0 AS BIT)
				AND IsDone = CAST(0 AS BIT)
				AND UserWorkflowId = @UserWorkflowId
			)
	BEGIN
		UPDATE [dbo].[UserWorkflow]
		SET IsWaitingForAppoved = 0
		WHERE Id = @UserWorkflowId;
	END
END
go

