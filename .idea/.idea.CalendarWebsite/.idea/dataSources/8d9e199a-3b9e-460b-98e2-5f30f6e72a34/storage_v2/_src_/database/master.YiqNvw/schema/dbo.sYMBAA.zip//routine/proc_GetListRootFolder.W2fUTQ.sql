CREATE PROC [dbo].[proc_GetListRootFolder](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @DirName nvarchar(256) OUTPUT
    )
AS
    SET NOCOUNT ON
    SELECT TOP 1
        @DirName = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END
    FROM
        TVF_Lists_Id(@SiteId, @ListId) AS L
    CROSS APPLY
        TVF_Docs_NoLock_Id(L.tp_SiteId, L.tp_RootFolder) AS D

go

