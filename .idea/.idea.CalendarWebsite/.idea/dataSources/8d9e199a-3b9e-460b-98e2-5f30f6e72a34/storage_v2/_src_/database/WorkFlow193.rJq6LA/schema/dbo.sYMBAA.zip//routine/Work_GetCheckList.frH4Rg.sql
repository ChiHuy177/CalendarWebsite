-- Work_GetCheckList 343091 ,102  
   CREATE   PROC Work_GetCheckList    
   @workId as nvarchar(50)  
   ,@workflowId as nvarchar(50)  
   as    
   declare @flowchartId as nvarchar(50)    
   set @flowchartId =(    
   select top 1 c.RootFlowchart from Dynamic.Data_WORK a     
   inner join Dynamic.Data_WORK b on a.CongViecCha=b.UserWorkflowId    
   inner join Dynamic.Data_TMDSQTCV c on c.IsUseForWork=b.UserWorkflowId    
   where a.UserWorkflowId=@workId and a.RequireAttachFileToCompleteWork='1')    
   select 
   d.Title as Title 
   ,d.TitleEN as TitleEN
   ,c.Id
   ,[WorkflowStepId]
   ,[TypeId]
   ,c.[IsRequired]
   ,[IsQRCode]
   ,[IsSignature]
   ,c.[CreatedBy]
   ,c.[CreatedTime]
   ,c.[LastModified]
   ,c.[ModifiedBy]
   ,c.[IsDeleted]
   ,c.[Order]
   ,[IsReplaceText]
   ,[IsReplaceSignature]
   ,[IsPublicForEveryone]
   ,[IsReplaceFlashSignature]
   ,[Permission]
   ,[IsOnlyAllowedAttachedAfterApproving]
   ,[IsAutoWatermarkEmbedWhenDownload]
   ,[IsSignaturedManually]
   ,[CustomFile] from Workflow a       
   inner join WorkflowStep b on a.Id=b.WorkflowId      
   inner join CheckList c on c.WorkflowStepId=b.Id 
   inner join DocumentType d on  c.TypeId = d.Id
   where a.Id = @workflowId and @flowchartId = (select * from Split(CustomFile,','))   
go

