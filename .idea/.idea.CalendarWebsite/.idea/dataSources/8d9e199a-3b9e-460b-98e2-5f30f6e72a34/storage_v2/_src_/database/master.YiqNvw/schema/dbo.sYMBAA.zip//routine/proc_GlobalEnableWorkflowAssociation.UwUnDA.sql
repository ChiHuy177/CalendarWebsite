CREATE PROCEDURE [dbo].[proc_GlobalEnableWorkflowAssociation] (
    @SiteId uniqueidentifier,
    @BaseId uniqueidentifier,
    @Enabled int)
AS
    SET NOCOUNT ON
    UPDATE
        WFA
    SET
        WFA.Configuration = 
            CASE 
                WHEN (@Enabled = 1) THEN (WFA.Configuration & ~1024)
                ELSE (WFA.Configuration | 1024) 
            END
    FROM
        TVF_WorkflowAssoc_Site(@SiteId) AS WFA
    WHERE    
        (@BaseId IS NULL OR
            WFA.BaseId = @BaseId)

go

