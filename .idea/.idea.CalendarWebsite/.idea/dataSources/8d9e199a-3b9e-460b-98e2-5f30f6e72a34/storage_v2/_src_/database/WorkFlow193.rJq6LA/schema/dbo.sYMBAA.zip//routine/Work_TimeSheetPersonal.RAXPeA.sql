-- Work_TimeSheetPersonal N'2023-11-01', '','','P:285','5',1                     
   CREATE   PROC  [dbo].[Work_TimeSheetPersonal]                             
   @date AS CHAR(50)                              
   ,@projectName AS NVARCHAR(250) = ''                              
   ,@email AS NVARCHAR(50) = ''                        
   ,@defaulUser AS NVARCHAR(50) = ''                     
   ,@department AS NVARCHAR(50) = ''      
   ,@isManagerDepartment as bit    
   AS                              
   -- start và lấy ngày hiện tại để lên báo cáo time sheet logtime                                 
   SELECT a.Duan                              
   ,a.Id                              
   ,trim(CONVERT(CHAR, a.ngay, 23)) AS title                              
   ,ISNULL(b.Tieude, N'Chưa nhập tên công việc') AS WorkLogtime                  
   ,ISNULL(a.Mota, b.Tieude) AS description                  
   ,isnull(a.SoGio, 0) Total                                   
   ,trim(CONVERT(CHAR, GETDATE(), 23)) + ' 08:00:00' AS [start]                                   
   ,trim(convert(CHAR, dateadd(HOUR, isnull(a.SoGio+1, 0), trim(CONVERT(CHAR, GETDATE(), 23)) + ' 08:00:00'), 120)) AS [end]                              
   ,a.UserWorkflowId                               
   ,a.Ngay Ngaybatdau                              
   ,a.Ngay Ngayhoantat                               
   ,a.Congviec as WorkId                          
   ,a.Congviec                          
   ,c.Id as UserId                   
   ,d.Data                  
   ,trim(CONVERT(CHAR, a.ngay, 23)) as DateLogtime    
   FROM [Dynamic].Data_VNTTSLT AS a                     
   inner join Dynamic.Data_WORK b on a.Congviec=b.UserWorkflowId                    
   inner join PersonalProfile c on c.Email=a.Email                    
   inner join [Dynamic].Workflow_VNTTSLT d on d.UserWorkflowId =a .UserWorkflowId              
   inner join Dynamic.Data_RESOURCEDA  e on e.UserWorkflowId =a.Duan              
   inner join Department f on c.DepartmentId=f.Id and isnull(f.IsDeleted,0)=0    
   WHERE  LEFT( trim(CONVERT(CHAR, a.Ngay, 23)),7) =  LEFT( trim(CONVERT(CHAR, @date, 23)),7)                   
   and ISNULL(a.IsDelete,'False')='False'                       
   AND a.Duan like N'%' + @projectName + '%' and  ( a.Email LIKE '%' + @email + '%')  
   and f.Id=@department  
go

