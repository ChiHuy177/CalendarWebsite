-- Work_ExportExcelListWorkInProject '265667,259902,265659,273427,264583,262108,262759,259904,272620,267263,259894,264727,263949,261598,259816,260823,272465,264365,264730,264750,264739,269816,261047,259820,259813,259837,260825,264256,315242,262156,286806,   287717,286803,288628,286807,286808,286810,286811,286813,286812,261565,259833,271539,264255,262159,259809,264484,269419,259900,325428,325898,325947,325985,320306,271222,259835,263109,266383,264406,330529,262162,262151,262667,262663,271244,262723,269493,   262   048,264371,331079,259831,331655,337047,341090,337053','https://localhost:44356'
   CREATE   PROC Work_ExportExcelListWorkInProject 
   @workId as nvarchar(max)
   ,@domain as nvarchar(200)
   as
   select 
   ROW_NUMBER() OVER (Order by a.UserWorkflowId) AS Stt
   ,Tieude 
   , e.giatrihd
   , e.giatriqt
   ,a.Noidung 
   ,a.Tiendo
   ,b.Ten as GroupProject
   ,Nguoixuly = STUFF((
   SELECT ', ' + FullName
   FROM PersonalProfile d
   cross apply Split((ISNULL(a.Nguoixuly,'') +';'+ ISNULL(a.NguoiXuLyDauTien,'')),';') c 
   where REPLACE(c.Item,'P:','') = d.Id
   group by FullName
   FOR XML PATH('')
   ), 1, 1, '')
   , TRIM(@domain)+'/work/mywork?workId='+trim( str(a.UserWorkflowId)) as link
   from Dynamic.Data_WORK a
   left join Dynamic.Data_ProjectGroup b on a.GroupProject=b.UserWorkflowId
   left join Dynamic.Data_ProjectLinkCoupon c on c.WorkId=a.UserWorkflowId and c.Type=4
   left join Dynamic.data_PLTTGTCV e on e.UserWorkflowId=c.CouponId    
   where  a.UserWorkflowId in (select * from Split(@workId,',')) and
   c.Type = 4 and ISNULL(a.CongViecCha,'')=''  and ISNULL(c.IsDelete,'False')='False'            
   and isnull(b.IsDelete,'False')='False' and ISNULL(b.Status,'')<>'Closed' 
go

