CREATE   PROC [dbo].[Work_GetManagerByWork]
   @id AS NVARCHAR(max) ='39898'
   as
   declare @tab1 table(WorkId bigint, userId nvarchar(50))
   insert into @tab1
   select a.* from ( 
   SELECT 
   c.UserWorkflowId
   , b.value AS userId 
   FROM DYNAMIC.Data_RESOURCEDA AS a  
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   inner join Dynamic.Data_WORK c on a.UserWorkflowId = c.Duan 
   WHERE c.Id in (select * from STRING_SPLIT(@id,',')) and left(trim(b.value ),2)='P:'
   union 
   SELECT  
   e.UserWorkflowId
   ,'P:'+trim(str(d.Id)) AS userId 
   FROM DYNAMIC.Data_RESOURCEDA AS a  
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   inner join GroupPersonalProfile c on REPLACE(a.QuanLy,'G:','')=c.GroupsId 
   INNER JOIN PersonalProfile d ON d.Id =c.PersonalProfilesId 
   inner join Dynamic.Data_WORK e on a.UserWorkflowId = e.Duan 
   WHERE e.Id in (select * from STRING_SPLIT(@id,',')) and left(trim(b.value ),2)='G:'
   ) a 
   group by a.UserWorkflowId,a.userId 
   SELECT b.WorkId, b.userId as Id 
   ,AccountName 
   ,Name 
   ,FullName 
   ,Email 
   FROM [dbo].[PersonalProfile] a 
   --INNER JOIN @tab b ON a.Id in (select REPLACE(ttt.value, 'P:', '') from STRING_SPLIT(b.userId,',') ttt) --CAST( REPLACE(b.userId, 'P:', '') as int) 
   INNER JOIN @tab1 b ON a.Id = ( REPLACE(b.userId, 'P:', '') ) 
   WHERE LEFT(b.userId,2)= 'P:' 
go

