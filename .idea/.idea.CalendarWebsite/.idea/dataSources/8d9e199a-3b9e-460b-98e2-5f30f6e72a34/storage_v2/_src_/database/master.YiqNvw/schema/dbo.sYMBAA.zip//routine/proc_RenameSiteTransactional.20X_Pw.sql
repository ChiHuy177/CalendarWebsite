CREATE PROCEDURE [dbo].[proc_RenameSiteTransactional](
    @SiteId uniqueidentifier,
    @OldUrl nvarchar(260),
    @NewUrl nvarchar(260),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @Result int SET @Result = 0 BEGIN TRAN
    DECLARE @OldScheme BIT, @OldHost NVARCHAR(260), @OldPath NVARCHAR(260)
    DECLARE @NewScheme BIT, @NewHost NVARCHAR(260), @NewPath NVARCHAR(260)
    EXEC @Result = proc_GetUrlComponents 
                        @OldUrl,
                        @OldScheme OUTPUT,
                        @OldHost OUTPUT,
                        @OldPath OUTPUT
    IF (@Result <> 0)
        GOTO Cleanup
    EXEC @Result = proc_GetUrlComponents 
                        @NewUrl,
                        @NewScheme OUTPUT,
                        @NewHost OUTPUT,
                        @NewPath OUTPUT
    IF (@Result <> 0)
        GOTO Cleanup
    DECLARE @RenamePath BIT
    SET @RenamePath = CASE WHEN (@OldPath COLLATE Latin1_General_BIN <> @NewPath COLLATE Latin1_General_BIN) THEN 1 ELSE 0 END
    DECLARE @IsHostHeaderSite BIT
    SELECT
        @IsHostHeaderSite = CASE WHEN HostHeader IS NULL THEN 0 ELSE 1 END
    FROM
        TVF_Sites_Id(@SiteId)
    IF (@IsHostHeaderSite = 1 AND 
        (@OldScheme <> @NewScheme OR 
         @OldHost COLLATE Latin1_General_BIN <> @NewHost COLLATE Latin1_General_BIN)
       )
    BEGIN
        IF (@RenamePath = 0)
        BEGIN
            EXEC proc_DirtyDocWithForwardLinksInSite @SiteId
            EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                32768,  8, NULL
        END
        DECLARE @OldFlags INT = 0
        DECLARE @NewFlags INT = 0
        UPDATE
            S
        SET
            S.HostHeader = @NewHost,
            S.BitFlags = (S.BitFlags & ~536870912) |
                         (@NewScheme * 536870912),
            @OldFlags = S.BitFlags
        FROM
            TVF_Sites_Id(@SiteId) AS S
        IF (@OldScheme <> @NewScheme)
        BEGIN
            SET @NewFlags = (@OldFlags & ~536870912) |
                         (@NewScheme * 536870912)
            EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, @OldFlags, NULL,
                8192, 8, NULL, NULL, @NewFlags
        END
    END
    IF (@RenamePath = 1)
    BEGIN
        EXEC @Result = proc_RenameSite 
                        @SiteId,
                        @OldPath,
                        @NewPath,
                        @NewUrl,
                        @IsHostHeaderSite,
                        @RequestGuid OUTPUT
        IF EXISTS(
            SELECT
                1
            FROM
                TVF_RecycleBin_HoldLock_Site(@SiteId))
        BEGIN
            SET @Result = 50
            GOTO Cleanup
        END
    END
Cleanup:
    IF (@Result <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Result

go

