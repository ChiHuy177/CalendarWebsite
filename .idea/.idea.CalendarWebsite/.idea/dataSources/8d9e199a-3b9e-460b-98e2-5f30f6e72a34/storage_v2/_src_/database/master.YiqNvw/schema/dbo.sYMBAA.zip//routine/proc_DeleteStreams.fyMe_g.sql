CREATE PROCEDURE [dbo].[proc_DeleteStreams] (
    @SiteId uniqueidentifier,
    @docsToDelete tvpStreamMetadata2 READONLY)
AS
    SET NOCOUNT ON
    DECLARE @err int, @rowc int
    DELETE
        DTS
    FROM
        @docsToDelete dd
    CROSS APPLY
        TVF_DocsToStreams_SiteIdDocId(@SiteId, dd.DocId) AS DTS
    WHERE
        dd.HistVersion IS NULL OR dd.Level IS NULL
    OPTION (FORCE ORDER)
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    DELETE
        DS
    FROM
        @docsToDelete dd
    CROSS APPLY
        TVF_DocStreams_SiteIdDocId(@SiteId, dd.DocId) AS DS
    WHERE
        dd.HistVersion IS NULL OR dd.Level IS NULL
    OPTION (FORCE ORDER)
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    DECLARE @bsnsToGC tvpBSNMetadata
    DELETE
        DTS
    OUTPUT
        DELETED.DocId, DELETED.Partition, DELETED.BSN
    INTO
        @bsnsToGC (DocId, Partition, BSN)
    FROM
        @docsToDelete dd
    CROSS APPLY
        TVF_DocsToStreams_SiteDocHistVerLvl(@SiteId, dd.DocId, dd.HistVersion, dd.Level) AS DTS
    WHERE
        dd.HistVersion IS NOT NULL AND dd.Level IS NOT NULL
    OPTION (FORCE ORDER)
    DELETE
        DS
    FROM
        @bsnsToGC bn
    CROSS APPLY
        TVF_DocStreams_CI(@SiteId, bn.DocId, bn.Partition, bn.BSN) AS DS
    OUTER APPLY
        TVF_DocsToStreams_SiteDocPartBSN(@SiteId, DS.DocId, DS.Partition, DS.BSN) AS DTS
    WHERE
        DTS.Partition IS NULL AND DTS.BSN IS NULL
    OPTION (FORCE ORDER, LOOP JOIN)
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    RETURN 0

go

