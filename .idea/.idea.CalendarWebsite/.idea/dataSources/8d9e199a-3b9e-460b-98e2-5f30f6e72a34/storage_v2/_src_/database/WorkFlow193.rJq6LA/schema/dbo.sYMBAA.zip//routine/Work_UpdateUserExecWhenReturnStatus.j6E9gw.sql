CREATE   PROC  [dbo].[Work_UpdateUserExecWhenReturnStatus]
   @workId as nvarchar(500),
   @newValue as nvarchar(500)
   as
   select * 
   into #a
   from Dynamic.Data_LSCNTTCV where WorkId=@workId and 
   ColumnName='TrangThaiCongViec' and OldValue=@newValue
   declare @nguoixuly as nvarchar(500)
   if(select count (*) from #a)>0
   begin 
   set @nguoixuly = (select top 1 UpdateUser from #a order by id)
   exec [Work_UpdateJsonData] @workId,'Nguoixuly',@nguoixuly,'[Dynamic].Workflow_WORK'
   end 
   drop table #a
   -- select * from  Dynamic.Data_WORK
   -- select * from Dynamic.Data_LSCNTTCV
go

