-- Work_GetPersonInfWorkChecklist '3,4'  
   CREATE   PROC Work_GetPersonInfWorkChecklist
   @id AS NVARCHAR(max)                 
   as                   
   declare @tab1 table(WorkId bigint, userId nvarchar(50))                
   insert into @tab1        
   SELECT a.Id as Id         
   , c.[value] AS kq         
   FROM [Dynamic].Data_WorkChecklist AS a 
   inner join Dynamic.Data_WORK b on a.WorkId=b.UserWorkflowId
   CROSS APPLY STRING_SPLIT(case when ISNULL(a.UserExec,'') = '' then ISNULL(b.Nguoixuly,'') else ISNULL(a.UserExec,'') end  ,';') AS c         
   where a.Id in (select * from STRING_SPLIT(@id,','))         
   group by a.Id,c.[value]  
   SELECT b.WorkId, b.userId as Id          
   ,AccountName          
   ,Name          
   ,FullName          
   ,Email        
   ,EnableEmail    
   ,EnableNotification    
   FROM [dbo].[PersonalProfile] a               
   INNER JOIN @tab1 b ON a.Id = ( REPLACE(b.userId, 'P:', '') )         
   WHERE LEFT(b.userId,2)= 'P:'
go

