
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_UpdateDefaultWorkflowStep] @WorkflowId BIGINT
	,@UserWorkflowId BIGINT
	,@Data_Json NVARCHAR(max)
	,@Email NVARCHAR(MAX) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@TableName AS NVARCHAR(MAX)
		,@Sql NVARCHAR(MAX)
		,@LineBreak NCHAR(2) = NCHAR(13) + NCHAR(10);

	IF (
			EXISTS (
				SELECT *
				FROM [dbo].[UserWorkflow]
				WHERE Id = @UserWorkflowId
				)
			)
	BEGIN
		SET @WorkflowCode = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @WorkflowId
				);
		SET @TableName = CONCAT (
				'Dynamic.Workflow_'
				,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
				);
		SET @Sql = 'BEGIN TRANSACTION' + @LineBreak + 'BEGIN TRY' + @LineBreak + 'UPDATE ' + @TableName + @LineBreak + 'SET DefaultWorkflowStep = ' + CONCAT (
				'N'
				,''''
				,@Data_Json
				,''''
				) + @LineBreak + 'WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';' + @LineBreak + 'COMMIT TRANSACTION' + @LineBreak + 'END TRY' + @LineBreak + 'BEGIN CATCH' + @LineBreak + 'IF @@TRANCOUNT > 0' + @LineBreak + '    ROLLBACK TRANSACTION' + @LineBreak + 'END CATCH' + @LineBreak;

		EXEC sp_ExecuteSql @SQL;
	END
END
go

