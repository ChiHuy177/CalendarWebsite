CREATE PROCEDURE [dbo].[proc_DeleteFieldTemplateInScope](
    @SiteId uniqueidentifier,
    @Scope nvarchar(256),
    @FieldId uniqueidentifier,
    @FieldName nvarchar(256),
    @BaseTypes int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @Count int
    DECLARE @WebId uniqueidentifier
    DECLARE @ScopeDir nvarchar(256)
    DECLARE @ScopeLeaf nvarchar(128)
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    EXEC proc_SplitUrl @Scope, @ScopeDir OUTPUT, @ScopeLeaf OUTPUT
    SELECT TOP 1
        @WebId = D.WebId
    FROM
        TVF_Docs_Url(@SiteId, @ScopeDir, @ScopeLeaf) AS D
    WHERE
        D.Type = 2
    IF @WebId IS NULL
    BEGIN
        SET @Ret = 144
        GOTO cleanup
    END
    EXEC @Count = proc_IsFieldTemplateUsedInContentTypeTemplate
        @SiteId,
        @FieldId, 
        @RequestGuid OUTPUT
    IF (@Count <> 0)
    BEGIN
        SET @Ret = 4307
        GOTO cleanup
    END
    EXEC @Count = proc_IsBaseTypeUsedInList @SiteId, @BaseTypes
    IF (@Count <> 0)
    BEGIN
        SET @Ret = 4307
        GOTO cleanup
    END
    DELETE 
        FCTU
    FROM
        TVF_ContentTypeUsage_SiteIsFListClass(
            @SiteId, 
            1, 
            @FieldId,
            0) AS FCTU
    WHERE
        FCTU.WebId = @WebId
    IF @@ERROR <> 0
    BEGIN
        SET @Ret = 30
        GOTO cleanup
    END
    DELETE 
        CT
    FROM
        TVF_ContentTypes_SiteClassCTId(
            @SiteId, 
            0, 
            @FieldId) AS CT
    WHERE
        CT.Scope = @Scope
    IF (@@ROWCOUNT = 0 OR @@ERROR <> 0)
    BEGIN
        SET @Ret = 2
        GOTO cleanup
    END
    DECLARE @ResourceName nvarchar(520)
    SET @ResourceName = N'_FieldTitle' + @FieldName
    EXEC proc_DeleteUserResource 
        @SiteId, @WebId, '00000000-0000-0000-0000-000000000000', @ResourceName
    SET @ResourceName = N'_FieldDesc' + @FieldName
    EXEC proc_DeleteUserResource 
        @SiteId, @WebId, '00000000-0000-0000-0000-000000000000', @ResourceName
    EXEC proc_LogContentTypeChange @SiteId, NULL, NULL, 0, @Scope,
        @FieldId, 16384
    EXEC proc_UpdateDiskUsed @SiteId
cleanup:
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

