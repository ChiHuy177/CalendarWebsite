-- Work_GetUserByDepartment '5','P:287'  
   CREATE   PROC [dbo].[Work_GetUserByDepartment]  
   @departmentId as nvarchar(50),  
   @userId as nvarchar(50)  
   as  
   select * into #a from Department a 
   where id in (   
   select b.value from Dynamic.Data_RuleViewProject a  
   cross apply string_split(Department,';') b  
   where [User]=@userId  
   ) and Id=@departmentId  and a.IsDeleted=0
   select a.* into #b from PersonalProfile a   
   inner join Department b on a.DepartmentId=b.Id  
   where 'P:'+ trim(str(b.ManagerId)) =@userId  and b.IsDeleted=0
   if(select COUNT(*) from #a)>0  
   begin   
   select 'P:'+ trim(str(id)) as Id,FullName,Email from PersonalProfile where DepartmentId in (select Id from #a) and UserStatus=1  
   end  
   else if(select COUNT(*) from #b)>0  
   begin   
   select 'P:'+ trim(str(id)) as Id,FullName,Email from PersonalProfile where DepartmentId in (select DepartmentId from #b) and UserStatus=1  
   end  
   else  
   begin   
   select 'P:'+ trim(str(id)) as Id,FullName,Email from PersonalProfile where 'P:'+ trim(str(id))=@userId  
   end  
go

