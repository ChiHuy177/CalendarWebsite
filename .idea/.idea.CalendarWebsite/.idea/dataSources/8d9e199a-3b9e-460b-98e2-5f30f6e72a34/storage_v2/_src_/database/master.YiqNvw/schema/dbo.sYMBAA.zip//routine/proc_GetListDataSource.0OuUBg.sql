CREATE PROC [dbo].[proc_GetListDataSource](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT
        DataSource,
        EntityId
    FROM
        TVF_AllListsPlus_ListId(@SiteId, @ListId) AS ALP

go

