CREATE Procedure [dbo].[proc_App_SetStatesOnAppsList] (
    @SPApps tvpArrayOfSPApps READONLY)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
-- When an app has a state other than "upgrade immediately" or "flagged", we set that state on the app source info, if
-- the app state is "upgrade immediately" or "flagged" we check the app version to be equal to or less than the 
-- specified unsafe version (or the latest version in the flagged case) and only in that case set the state accordingly. 
-- The app is disabled if it is revoked.
UPDATE AppSourceInfo
    SET IsDisabled = CASE
                    WHEN Apps.State = 0 THEN 1
                    ELSE IsDisabled
                    END,
        SourceState = CASE 
                      --If the current state is revoked, there is no way to change the state. If the new state is removed,
                      -- we can apply it only if the current state is withdrawn.
                      WHEN AppSourceInfo.SourceState = 0 OR 
                           (AppSourceInfo.SourceState <> 2 AND Apps.State = 255) THEN SourceState
                      --Special casing flagged state acording to the latest version here in order not to mark a safe app instance as unsafe
                      --because of a race condition that right after we query omex for app states, new safe version of the app might get published 
                      --and installed to this instance of SharePoint until we run this stored procedure.
                      WHEN (Apps.State <> 254 AND Apps.State <> 3) OR 
                          (Apps.VersionMajor > Packages.VersionMajor OR
                          (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor > Packages.VersionMinor) OR
                          (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor = Packages.VersionMinor AND Apps.VersionBuild > Packages.VersionBuild) OR
                          (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor = Packages.VersionMinor AND Apps.VersionBuild = Packages.VersionBuild AND Apps.VersionRevision > Packages.VersionRevision) OR
                          (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor = Packages.VersionMinor AND Apps.VersionBuild = Packages.VersionBuild AND Apps.VersionRevision = Packages.VersionRevision))
                        THEN Apps.State
                      --We are marking the app instances with version greater than the unsafe version as OK when the state is upgrade immediatelly.
                      WHEN Apps.State = 254 AND
                          (Packages.VersionMajor > Apps.VersionMajor OR
                          (Packages.VersionMajor = Apps.VersionMajor AND Packages.VersionMinor > Apps.VersionMinor) OR
                          (Packages.VersionMajor = Apps.VersionMajor AND Packages.VersionMinor = Apps.VersionMinor AND Packages.VersionBuild > Apps.VersionBuild) OR
                          (Packages.VersionMajor = Apps.VersionMajor AND Packages.VersionMinor = Apps.VersionMinor AND Packages.VersionBuild = Apps.VersionBuild AND Packages.VersionRevision > Apps.VersionRevision))
                        THEN Apps.SafeState
                      ELSE SourceState
                      END
    FROM @SPApps as Apps
    CROSS APPLY TVF_AppSourceInfo_AssetIdAllSites_AppSource(Apps.AssetId, 1) as AppSourceInfo
    CROSS APPLY TVF_AppPackages_PackageFingerprint(AppSourceInfo.SiteId, AppSourceInfo.PackageFingerprint) as Packages
COMMIT TRANSACTION

go

