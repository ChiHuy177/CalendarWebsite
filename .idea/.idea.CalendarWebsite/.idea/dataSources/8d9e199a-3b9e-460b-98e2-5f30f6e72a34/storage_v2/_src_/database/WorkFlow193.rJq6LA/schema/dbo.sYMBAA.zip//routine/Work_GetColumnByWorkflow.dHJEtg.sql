-- Work_GetColumnByWorkflow 326
   CREATE   PROC [dbo].[Work_GetColumnByWorkflow]
   @workFlowId as bigint
   as
   select 'Code' as [Value], N'Mã' as Name, '' as type, 100 as Width, -1 as [Order]
   union
   select [Name] as [Value], [Label] as [Name],case when IsNumber=1 then 'Number' when IsDateAndTime=1 then 'Datetime' else '' end as type ,ISNULL(WidthInReport,'') as Width 
   ,ISNULL([Order],0) as [Order]
   from Property where WorkflowId = @workFlowId and IsDeleted = 0 and IgnoreInReport = 0 
   order by [Order]
go

