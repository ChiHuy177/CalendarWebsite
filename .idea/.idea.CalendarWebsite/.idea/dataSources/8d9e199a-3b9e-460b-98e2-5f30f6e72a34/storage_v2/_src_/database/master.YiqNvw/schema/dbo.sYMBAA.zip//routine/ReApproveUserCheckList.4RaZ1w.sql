CREATE   PROCEDURE [dbo].[ReApproveUserCheckList] @Id BIGINT
	,@UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@WorkflowId BIGINT
		,@Sql NVARCHAR(4000)
		,@TableName AS NVARCHAR(MAX);

	SET @WorkflowId = (
			SELECT WorkflowId
			FROM [dbo].[UserWorkflow]
			WHERE Id = @UserWorkflowId
			);
	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[WorkFlow165]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);


	SET @Sql = 'DECLARE @fileName AS NVARCHAR(max);
				DECLARE @checkListId AS bigint;
				SET @fileName = (
						SELECT REPLACE(left(c.Name, len(c.Name) - charindex(''.'', Reverse(c.Name))), ''_Approve'', '''')
						FROM ' + @TableName + ' c
						WHERE c.Id = ' + CAST(@Id as varchar(max)) + ' 
						)
				SET @checkListId = (
					SELECT CheckListId
					FROM ' + @TableName + ' c
					WHERE c.Id = ' + CAST(@Id as varchar(max)) + ' 
					)
				UPDATE '+ @TableName + ' SET IsDeleted = 1 WHERE Id = ' + CAST(@Id as varchar(max)) + '
				UPDATE c
				set c.IsDone= 0, IsSucess = 0
				FROM UserWorkflowJob c
				WHERE c.UserWorkflowId = ' + CAST(@UserWorkflowId as varchar(max)) + ' 
					AND EXISTS (
						SELECT c.Name, c.CheckListId
						FROM OPENJSON(RawData) WITH (Name NVARCHAR(max) ''$.userCheckList.Name'', CheckListId bigint ''$.userCheckList.CheckListId'') AS c
						WHERE left(c.Name, len(c.Name) - charindex(''.'', Reverse(c.Name))) = @fileName and c.CheckListId = @checkListId
						)'
	print @SQL;
	EXEC sp_ExecuteSql @SQL;
END
go

