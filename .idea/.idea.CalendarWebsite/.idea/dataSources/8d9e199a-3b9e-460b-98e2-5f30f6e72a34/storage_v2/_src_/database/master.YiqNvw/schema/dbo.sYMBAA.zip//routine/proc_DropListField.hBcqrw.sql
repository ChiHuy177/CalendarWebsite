CREATE PROCEDURE [dbo].[proc_DropListField](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier,
    @ColName nvarchar(64),
    @RowOrdinal int,
    @ColName2 nvarchar(64),
    @RowOrdinal2 int,
    @IsIndexedField bit,
    @NeedRemoveLinks bit,
    @Fields varbinary(max),
    @FieldsSize int,
    @ContentTypes varbinary(max),
    @ContentTypesSize int,
    @Version int,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    DECLARE @guidT uniqueidentifier
    SELECT TOP 1
        @guidT = ListID
    FROM
        TVF_AllListsAux_XLock_ListId(@SiteId, @ListId) AS ALAux
    SELECT TOP 1
        @guidT = tp_ID
    FROM
        TVF_Lists_XLock_CI(@SiteId, @WebId, @ListId) AS L
    IF @ColName IS NOT NULL
    BEGIN         
        EXEC proc_DropUserField @SiteId, @WebId, @ListId, @FieldId, @ColName, @RowOrdinal, @IsIndexedField
    END
    IF @ColName2 IS NOT NULL
    BEGIN
        EXEC proc_DropUserField @SiteId, @WebId, @ListId, @FieldId, @ColName2, @RowOrdinal2,@IsIndexedField
    END
    IF @NeedRemoveLinks = 1
    BEGIN
        EXEC proc_RemoveListFieldLinks @SiteId, @WebId, @ListId, @FieldId
    END
    DECLARE @Result int
    EXEC @Result = proc_UpdateListFields 
        @SiteId, 
        @WebId, 
        @ListId, 
        @Fields, 
        @FieldsSize, 
        @ContentTypes, 
        @ContentTypesSize, 
        @Version, 
        1, 
        @FieldId
    RETURN @Result

go

