-- [Work_CheckUserInProject] 210281,'P:287'        
            
CREATE PROC [dbo].[Work_CheckProjectRuleDeleteEdit]                       
@projectId AS NVARCHAR(50)                          
,@UserId as nvarchar(50)=''        
AS                          
;                      
               
            
declare @tb table (Id  nvarchar(50) , AccountId nvarchar(50), AccountName nvarchar(150), Name nvarchar(250), FullName nvarchar(250), Email nvarchar(150) )                    
               
    
select * into #a from (  

SELECT                         
 b.value AS userId                          
                     
FROM DYNAMIC.Data_RESOURCEDA AS a                           
CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b                        
WHERE a.UserWorkflowId = @projectId          
  
union  

SELECT                         
 'P:'+trim(str(c.Id)) AS userId                          
                     
FROM DYNAMIC.Data_RESOURCEDA AS a                           
inner join DYNAMIC.Workflow_RESOURCEDA b on a.UserWorkflowId=b.UserWorkflowId
inner join PersonalProfile c on b.CreatedBy=c.Email
WHERE a.UserWorkflowId = @projectId 

) a    
;            
            
insert into @tb            
select * from (            
SELECT 'P:'+ trim(str(c.Id)) AS Id                          
 ,[AccountId]                          
 ,[AccountName]                          
 ,[Name]                          
 ,[FullName]                         
 ,[Email]                        
                  
FROM #a a                          
INNER JOIN PersonalProfile c ON REPLACE(a.userId,'P:','') =trim(str(c.Id))            
where left(trim(a.userId),1)='P'            
            
) a
      
select COUNT(*) as dem from @tb where Id=@UserId      
              
go

