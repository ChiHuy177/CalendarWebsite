CREATE FUNCTION [dbo].[fn_Lists_DocRootFolder](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @RootFolder uniqueidentifier)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        TVF_Lists_NoLock_CI(@SiteId, @WebId, @ListId)
    WHERE
        tp_RootFolder = @RootFolder

go

