
-- =============================================
-- Author:		Duy Dam
-- Create date: 04/04/2022
-- Description: Get file path of old wf
-- =============================================
CREATE   PROCEDURE [dbo].[GetPathOfOldWorkflow] @Id BIGINT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TOP 1 [ImageUrl]
	FROM [dbo].[OldWorkflowData]
	WHERE OldWorkflowId = @Id
END
go

