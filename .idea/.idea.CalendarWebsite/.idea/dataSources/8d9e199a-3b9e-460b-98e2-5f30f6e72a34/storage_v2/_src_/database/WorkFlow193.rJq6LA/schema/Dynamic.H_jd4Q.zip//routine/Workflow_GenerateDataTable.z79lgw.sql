-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE     PROCEDURE [Dynamic].[Workflow_GenerateDataTable]
	 @WorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @QueryString NVARCHAR(MAX);
    DECLARE @DataTableName NVARCHAR(MAX);
	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	print @DataTableName
	DECLARE @SqlScript NVARCHAR(MAX);
	IF (
			NOT EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'Dynamic'
					AND TABLE_NAME = CONCAT('Data_', dbo.fn_StripCharacters(@TableName, '^a-z0-9'))
				)
			AND @TableName IS NOT NULL
			)
	BEGIN
		/* Check Schema Dynamic is exited*/
		IF NOT EXISTS (
				SELECT *
				FROM sys.schemas
				WHERE name = 'Dynamic'
				)
		BEGIN
			EXEC ('CREATE SCHEMA Dynamic')
		END
			   
		SET @SqlScript = 'CREATE TABLE ' + @DataTableName + '([Id] [bigint] primary key IDENTITY(1,1) NOT NULL,
			[UserWorkflowId] [bigint] NULL,';				
			SELECT CONCAT (
					'['
					,p.Name
					,']'
					,(
						CASE 
							WHEN p.IsSingle = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsMultiLine = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsChoice = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsNumber = 1 AND p.IsViewOnly <> 1
								THEN ' decimal(22,4) NULL'
							WHEN p.IsNumber = 1 AND p.IsViewOnly = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsCurrency = 1 AND p.IsViewOnly <> 1
								THEN ' decimal(22,4) NULL'
							WHEN p.IsCurrency = 1 AND p.IsViewOnly = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsDateAndTime = 1
								THEN ' datetime2(7) NULL'
							WHEN p.IsLookup = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsYesNo = 1
								THEN ' bit NULL'
							WHEN p.IsUser = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsCalculated = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsFile = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							WHEN p.IsApi = 1
								THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							ELSE ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
							END
						)
					) AS QueryString
				,p.*
			INTO #tempProperties
			FROM Property p
			WHERE p.WorkflowId = @WorkflowId
				AND p.IsDeleted = 0

			SET @QueryString = (SELECT STRING_AGG(QueryString, ', ') FROM #tempProperties);
			DROP TABLE #tempProperties;
			SET @SqlScript = CONCAT(@SqlScript, @QueryString, ')');

			--print @SqlScript;
			EXEC sp_ExecuteSql @SqlScript;
	END
END
go

