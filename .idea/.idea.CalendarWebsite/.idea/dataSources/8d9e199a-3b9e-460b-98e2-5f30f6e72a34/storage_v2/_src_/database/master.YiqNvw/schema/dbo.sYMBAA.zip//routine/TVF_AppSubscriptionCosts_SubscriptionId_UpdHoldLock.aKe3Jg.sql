CREATE FUNCTION [dbo].[TVF_AppSubscriptionCosts_SubscriptionId_UpdHoldLock]
(
    @SubscriptionId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppSubscriptionCosts] WITH (INDEX=AppSubscriptionCosts_PK, FORCESEEK)
    WHERE
        SubscriptionId = @SubscriptionId

go

