CREATE   PROC Work_GetWorkChildFlowChart  
   @FlowChartWorkId as nvarchar(50)  
   as  
   select Id,Id as WorkId, Id as UserWorkflowId , Tieude as Title,FlowChartWorkId  from Dynamic.Data_WorkChildFlowChart  
   where FlowChartWorkId=@FlowChartWorkId  and ISNULL(IsDelete,'False')='False'
go

