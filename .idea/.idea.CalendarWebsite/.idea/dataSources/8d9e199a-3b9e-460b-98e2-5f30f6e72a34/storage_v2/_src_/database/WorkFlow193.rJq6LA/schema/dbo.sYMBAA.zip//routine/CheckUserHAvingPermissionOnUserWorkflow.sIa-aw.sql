CREATE  
 
 PROCEDURE [dbo].[CheckUserHAvingPermissionOnUserWorkflow]
	-- Add the parameters for the stored procedure here
	@UserWorkflowId BIGINT
	,@UserId BIGINT
	,@IsNeedUpdate BIT = 0
	,@IsAll BIT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	BEGIN TRAN
	
	DECLARE @SeenPermission AS NVARCHAR(MAX), @AllowSeenUserLinking as bit = 0, 
	@AllowSeenUserLinkingFromShare as bit = 0, @AllowNotActivedFollow as bit = 0,
	@IsOutdated as bit = 0;

	IF (EXISTS (select top 1 Id from dbo.WorkflowPara WHERE ParaName = 'AllowSeenUserLinking' AND IsSystemPara = 1 AND Value = '1'))
	BEGIN
		SET @AllowSeenUserLinking = 1;
	END

	IF (EXISTS (select top 1 Id from dbo.WorkflowPara WHERE ParaName = 'AllowSeenUserLinkingFromShare' AND IsSystemPara = 1 AND Value = '1'))
	BEGIN
		SET @AllowSeenUserLinkingFromShare = 1;
	END

	IF (EXISTS (select top 1 Id from dbo.WorkflowPara WHERE ParaName = 'AllowNotActivedFollow' AND IsSystemPara = 1 AND Value = '1'))
	BEGIN
		SET @AllowNotActivedFollow = 1;
	END

	SET @SeenPermission = (
			SELECT SeenPermission
			FROM [dbo].[Workflow] WITH (NOLOCK)
			WHERE Id = (
					SELECT WorkflowID
					FROM UserWorkflow
					WHERE Id = @UserWorkflowId
					)
			);
	SET @IsOutdated = ISNULL((SELECT top 1 IsOutdated FROM UserWorkflow where ID = @UserWorkflowId), 0);

	IF EXISTS (
			SELECT TOP 1 ID
			FROM UserWorkflow WITH (NOLOCK)
			WHERE Id = @UserWorkflowId
				AND UserId = @UserId
			)
		SET @IsAll = 1
	ELSE IF EXISTS (
			SELECT TOP 1 ID
			FROM UserWorkflowStep WITH (NOLOCK)
			WHERE UserWorkflowId = @UserWorkflowId
				AND UserId = @UserId
				AND IsDeleted = 0
				AND (@AllowNotActivedFollow = 1 OR (FinishTime is not null OR IsActived = 1 OR IsIdea = 1))
			)
		SET @IsAll = 1
	ELSE IF EXISTS (
			SELECT TOP 1 gp.PersonalProfilesId
			FROM GroupPersonalProfile gp WITH (NOLOCK)
			INNER JOIN dbo.[Group] g ON g.ID = gp.GroupsId
			WHERE gp.PersonalProfilesId = @UserId
				AND g.Title = N'SuperManagementAdmin'
			)
		SET @IsAll = 1
	ELSE IF @IsOutdated = 1
		SET @IsAll = 0
	ELSE IF EXISTS (
			SELECT TOP 1 ID
			FROM UserWorkflowShare WITH (NOLOCK)
			WHERE UserWorkflowId = @UserWorkflowId
				AND UserId = @UserId
				AND IsDeleted = 0
			)
		SET @IsAll = 1
	ELSE IF EXISTS (
			SELECT TOP 1 ID
			FROM UserWorkflowStep WITH (NOLOCK)
			WHERE UserWorkflowId IN (
					SELECT LinkUserWorkflowId
					FROM UserWorkflowLinking WITH (NOLOCK)
					WHERE MainUserWorkflowId = @UserWorkflowId
					)
				AND UserId = @UserId
				AND IsDeleted = 0
			) AND @AllowSeenUserLinking = 1
		SET @IsAll = 1
	ELSE IF EXISTS (
			SELECT TOP 1 ID
			FROM UserWorkflowShare WITH (NOLOCK)
			WHERE UserWorkflowId IN (
					SELECT LinkUserWorkflowId
					FROM UserWorkflowLinking WITH (NOLOCK)
					WHERE MainUserWorkflowId = @UserWorkflowId
					)
				AND UserId = @UserId
				AND IsDeleted = 0
			) AND @AllowSeenUserLinkingFromShare = 1
		SET @IsAll = 1
	ELSE IF EXISTS (
			SELECT TOP 1 ID
			FROM [dbo].[PropertyUserAuthorize] WITH (NOLOCK)
			WHERE UserWorkflowId = @UserWorkflowId
				AND UserId = @UserId
			)
		SET @IsAll = 1
	ELSE IF (@SeenPermission LIKE '%P:' + CAST(@UserId AS VARCHAR) + '%')
		OR EXISTS (
			SELECT TOP 1 [gp].*
			FROM [dbo].[GroupPersonalProfile] [gp] WITH (NOLOCK)
			JOIN dbo.splitPermissionGroup(CONCAT (
						@SeenPermission
						,','
						)) [sl] ON [sl].[Name] = [gp].[GroupsId]
			WHERE [gp].[PersonalProfilesId] = @UserId
			)
		SET @IsAll = 1
	ELSE IF EXISTS(SELECT 1 FROM [dbo].[GetAllPropertyUserAuthorizeAndRecursivePermission](@UserId) as f WHERE f.ID = @UserWorkflowId)
		SET @IsAll = 1
	ELSE
		SET @IsAll = 0

	IF @IsNeedUpdate = CAST(1 AS BIT)
	BEGIN
		-- DELETE UserWorkflowLinking
		-- WHERE MainUserWorkflowId = @UserWorkflowId
		-- 	AND LinkUserWorkflowId IS NULL;
		UPDATE UserWorkflow
		SET IsWaitingForAppoved = (
				CASE 
					WHEN (
							NOT EXISTS (
								SELECT TOP 1 ID
								FROM UserWorkflowJob
								WHERE UserWorkflowId = @UserWorkflowId
									AND IsDone = 0
								)
							AND NOT EXISTS (
								SELECT TOP 1 ID
								FROM VnptSmartCAQueue
								WHERE UserWorkflowId = @UserWorkflowId
									AND IsActived = 1
								)
							)
						THEN 0
					ELSE 1
					END
				)
			,Approver = (
				CASE 
					WHEN (
							UserWorkflowStatus = 1
							AND (
								Approver IS NULL
								OR Approver = ''
								)
							)
						THEN (
								SELECT TOP 1 p.FullNAme
								FROM UserWorkflowStep us WITH (NOLOCK)
								JOIN PersonalProfile p ON p.Id = us.UserId
								WHERE us.UserWorkflowId = @UserWorkflowId
									AND us.IsDeleted = 0
								ORDER BY us.[Index] DESC
									,us.FinishTime DESC
								)
					ELSE Approver
					END
				)
		WHERE ID = @UserWorkflowId
	END

	COMMIT TRAN
END
go

