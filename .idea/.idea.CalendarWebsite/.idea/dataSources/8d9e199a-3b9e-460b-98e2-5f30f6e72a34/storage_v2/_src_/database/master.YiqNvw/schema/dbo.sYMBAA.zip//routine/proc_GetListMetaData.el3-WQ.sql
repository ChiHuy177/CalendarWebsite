CREATE PROCEDURE [dbo].[proc_GetListMetaData](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @PrefetchListScope bit = 0,
    @ThresholdScopeCount int = 0,
    @PrefetchRelatedFields bit = 0,
    @CurrentFolderUrl nvarchar(260) = NULL    
    )
AS
    SET NOCOUNT ON
    DECLARE @WebFullUrl nvarchar(256)
    DECLARE @WebTitle nvarchar(255)
    DECLARE @WebFlags int
    DECLARE @WebTemplate int
    DECLARE @WebLanguage int
    DECLARE @WebCollation smallint
    DECLARE @AllowMUI bit
    DECLARE @TitleResource nvarchar(520)
    DECLARE @DescriptionResource nvarchar(520)
    SELECT TOP 1
        @WebFullUrl = W.FullUrl,
        @WebTitle = W.Title,
        @WebFlags = W.Flags,
        @WebTemplate = W.WebTemplate,
        @WebLanguage = W.Language,
        @WebCollation = W.Collation,
        @AllowMUI = W.AllowMUI
    FROM
        TVF_Webs_NoLock_Id(@SiteId, @WebId) AS W
    SET @WebFullUrl = N'/' + @WebFullUrl
    IF (@AllowMUI <> 0)
    BEGIN
        SELECT TOP 1
            @TitleResource = ALP.TitleResource,
            @DescriptionResource = ALP.DescriptionResource
        FROM
            TVF_AllListsPlus_ListId(@SiteId, @ListId) AS ALP
    END
    ELSE
    BEGIN
        SET @TitleResource = NULL
        SET @DescriptionResource = NULL        
    END
    DECLARE @FolderScopeId uniqueidentifier
    DECLARE @FolderWebId uniqueidentifier
    DECLARE @FolderListId uniqueidentifier
    DECLARE @FolderId int
    DECLARE @CurrentFolderItemCount int
    IF @CurrentFolderUrl IS NOT NULL AND
       NOT @CurrentFolderUrl = N''
    BEGIN
        EXEC proc_GetFolderInfo 
            @SiteId, 
            @CurrentFolderUrl, 
            @FolderScopeId OUTPUT, 
            @FolderWebId OUTPUT,
            @FolderId OUTPUT,
            @CurrentFolderItemCount OUTPUT,
            @FolderListId OUTPUT
        IF @FolderListId IS NULL OR @FolderListId <> @ListId
            SET @CurrentFolderItemCount = NULL
    END
    SELECT
        tp_ID,
        tp_Title,
        ALAux.Modified AS tp_Modified,
        tp_Created,
        ALAux.LastDeleted AS tp_LastDeleted,
        tp_Version,
        tp_BaseType,
        tp_FeatureId,
        tp_ServerTemplate,
        Docs1.DirName,        
        Docs1.LeafName,
        Docs2.DirName,        
        Docs2.LeafName,
        tp_ReadSecurity,
        tp_WriteSecurity,
        tp_Description,
        CASE WHEN @WebFlags & 0x200 = 0x200 OR
                  tp_Flags & 0x200000000 = 0x200000000
        THEN
             NULL
        ELSE
             tp_Fields
        END,
        tp_Direction,
        Perms.AnonymousPermMask,
        tp_Flags,
        tp_ThumbnailSize,
        tp_WebImageWidth,
        tp_WebImageHeight,
        tp_ImageUrl,
        ALAux.ItemCount AS tp_ItemCount,
        tp_Author,
        tp_HasInternalFGP,
        tp_ScopeId,
        Perms.Acl,
        tp_EventSinkAssembly,
        tp_EventSinkClass,
        tp_EventSinkData,
        tp_EmailAlias,
        @WebFullUrl AS tp_WebFullUrl,
        @WebId AS tp_WebId,
        @WebTitle AS tp_WebTitle,
        @WebTemplate AS tp_WebTemplate,
        @WebLanguage AS tp_WebLanguage,
        @WebCollation AS tp_WebCollation,
        tp_SendToLocation,
        ISNULL(Lists.tp_MaxMajorVersionCount, 0),
        ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),       
        tp_MaxRowOrdinal,
        tp_ListDataDirty,
        tp_DefaultWorkflowId,
        CAST((CASE WHEN @WebFlags & 16384 = 16384
        THEN
            CASE WHEN EXISTS( SELECT TOP 1 1 FROM TVF_AllLookupRelationships_SiteLookupList(@SiteId, @ListId) AS ALR CROSS APPLY TVF_Lists_CI(@SiteId, @WebId, ALR.ListId) WHERE ALR.DeleteBehavior <> 0) THEN 1 ELSE 0 END
        ELSE
            0
        END)as bit),
        Lists.tp_ContentTypes,
        Lists.tp_Subscribed,
        CASE WHEN @CurrentFolderItemCount IS NULL
        THEN
            Docs1.ItemChildCount + Docs1.FolderChildCount
        ELSE
            @CurrentFolderItemCount
        END,
        Lists.tp_NoThrottleListOperations,
        @TitleResource AS tp_TitleResource,
        @DescriptionResource AS tp_DescriptionResource,
        NULL AS tp_ValidationFormula,
        NULL AS tp_ValidationMessage,
        ALAux.Followable
    FROM
        TVF_Lists_NoLock_CI(@SiteId, @WebId, @ListId) AS Lists
    CROSS APPLY
        TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
    CROSS APPLY
        TVF_Docs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_RootFolder, 1) AS Docs1
    OUTER APPLY
        TVF_Docs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS Docs2     
    CROSS APPLY
        TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
    OPTION (FORCE ORDER)
    IF (@PrefetchListScope <> 0)
    BEGIN
        EXEC proc_GetUniqueScopesInList 
            @SiteId, 
            @WebId, 
            @ListId, 
            0,  
            @ThresholdScopeCount    
    END
    IF (@PrefetchRelatedFields <> 0)
    BEGIN
        EXEC proc_GetRelatedFieldsForList @SiteId, @ListId
    END

go

