-- =============================================
-- Author:		DuyDAm
-- Create date: 17/03/2025
-- Description:	LẤy ds những bước được set tự động phê duyệt nếu gần đến deadline hoặc đã trễ deadline
-- =============================================
CREATE   PROCEDURE [dbo].[GetAllStepsWhichIsAutoApprovedConfiguredWhenDeadlineArrives]

AS
BEGIN
	SET NOCOUNT ON;

	SELECT us.*, p.Email as UserEmail
	FROM UserworkflowStep us
	INNER JOIN PersonalProfile p on p.ID = us.UserId
	INNER JOIN UserWorkflow u on u.Id = us.UserWorkflowId
	INNER JOIN Workflow w on w.ID = u.WorkflowId
	INNER JOIN WorkflowStep ws on ws.Id = us.WorkflowStepId
	WHERE 
		us.IsDeleted = 0
		and us.DueDate is not null
		and (us.DueDate < GETDATE() OR us.DueDate BETWEEN GETDATE() AND DATEADD(MINUTE, 5, GETDATE()))
		and us.FinishTime is null
		and w.IsDeleted = 0
		and u.IsDeleted = 0
		and u.IsDraft = 0
		and w.WorkflowType in (0, 3)
		and ws.AutomaticallyCompleteWhenDeadlineArrives = 1

END
go

