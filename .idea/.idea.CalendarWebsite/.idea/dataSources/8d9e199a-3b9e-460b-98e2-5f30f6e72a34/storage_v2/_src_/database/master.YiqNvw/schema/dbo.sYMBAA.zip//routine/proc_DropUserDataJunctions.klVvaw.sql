CREATE PROC [dbo].[proc_DropUserDataJunctions]
(
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier
)
AS
    SET NOCOUNT ON
    DELETE 
        UDJV
    FROM
        TVF_UserDataJunctionsVersioned_ListFldId(
            @ListId,
            @FieldId) As UDJV
    WHERE
        UDJV.tp_SiteId = @SiteId
    DELETE
        AUDJ
    FROM
        TVF_RecycleBin_List(@ListId) AS R
    CROSS APPLY
        TVF_AllUserDataJunctions_ListDelFldId(
            R.ListId,
            R.EffectiveDeleteTransactionId, 
            @FieldId) AS AUDJ

go

