CREATE FUNCTION [dbo].[TVF_UserData_List_Mtg]
(
    @tp_SiteId uniqueidentifier,
    @tp_ListId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        tp_ID,
        tp_ListId,
        tp_SiteId,
        tp_RowOrdinal,
        tp_Version,
        tp_Author,
        tp_Editor,
        tp_Modified,
        tp_Created,
        tp_Ordering,
        tp_ThreadIndex,
        tp_HasAttachment,
        tp_ModerationStatus,
        tp_IsCurrent,
        tp_ItemOrder,
        tp_InstanceID,
        tp_GUID,
        tp_CopySource,
        tp_HasCopyDestinations,
        tp_AuditFlags,
        tp_InheritAuditFlags,
        tp_Size,
        tp_WorkflowVersion,
        tp_WorkflowInstanceID,
        tp_ParentId,
        tp_DocId,
        tp_DeleteTransactionId,
        tp_ContentTypeId,
        tp_Level,
        tp_IsCurrentVersion,
        tp_UIVersion,
        tp_CalculatedVersion,
        tp_UIVersionString,
        tp_DraftOwnerId,
        tp_CheckoutUserId,
        tp_AppAuthor,
        tp_AppEditor,
        bit1,
        bit2,
        bit3,
        bit4,
        datetime1,
        datetime2,
        datetime3,
        datetime4,
        datetime5,
        int1,
        int2,
        int3,
        int4,
        int5,
        int6,
        ntext1,
        ntext2,
        ntext3,
        nvarchar1,
        nvarchar3,
        nvarchar4,
        nvarchar5,
        uniqueidentifier1
    FROM
        [dbo].[AllUserData] WITH (INDEX=AllUserData_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_ListId = @tp_ListId AND
        tp_DeleteTransactionId = 0x AND
        tp_IsCurrentVersion = CONVERT(bit, 1)

go

