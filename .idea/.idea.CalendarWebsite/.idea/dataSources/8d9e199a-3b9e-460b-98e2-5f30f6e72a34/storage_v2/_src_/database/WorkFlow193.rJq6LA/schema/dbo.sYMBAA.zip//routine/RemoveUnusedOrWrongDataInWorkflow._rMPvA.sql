
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[RemoveUnusedOrWrongDataInWorkflow] @WorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @SqlScript NVARCHAR(MAX);

	IF EXISTS (
			SELECT TOP 1 Id
			FROM Workflow
			WHERE Id = @WorkflowId
			)
	BEGIN
		SET @TableName = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @WorkflowId
				)
		SET @TableName = CONCAT (
				'Dynamic.Workflow_'
				,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
				);
		SET @SqlScript = 
			N'
					DELETE dy
					FROM dbo.[UserWorkflowSeen] dy
					INNER JOIN UserWorkflow u ON u.Id = dy.UserWorkflowId
					WHERE u.WorkflowId = @WorkflowId
						AND (
							NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
								)
							OR NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
									AND [Data] IS NOT NULL
								)
							)

					DELETE dy
					FROM dbo.[UserWorkflowStep] dy
					INNER JOIN UserWorkflow u ON u.Id = dy.UserWorkflowId
					WHERE u.WorkflowId = @WorkflowId
						AND (
							NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
								)
							OR NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
									AND [Data] IS NOT NULL
								)
							)

					DELETE dy
					FROM dbo.[UserWorkflowShare] dy
					INNER JOIN UserWorkflow u ON u.Id = dy.UserWorkflowId
					WHERE u.WorkflowId = @WorkflowId
						AND (
							NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
								)
							OR NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
									AND [Data] IS NOT NULL
								)
							)

					DELETE dy
					FROM dbo.[UserWorkflowLinking] dy
					INNER JOIN UserWorkflow u ON u.Id = dy.MainUserWorkflowId
					WHERE u.WorkflowId = @WorkflowId
						AND (
							NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
								)
							OR NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
									AND [Data] IS NOT NULL
								)
							)

					DELETE dy
					FROM dbo.[UserWorkflowLinking] dy
					INNER JOIN UserWorkflow u ON u.Id = dy.LinkUserWorkflowId
					WHERE u.WorkflowId = @WorkflowId
						AND (
							NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
								)
							OR NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
									AND [Data] IS NOT NULL
								)
							)

					DELETE dy
					FROM dbo.[UserWorkflowRelated] dy
					INNER JOIN UserWorkflow u ON u.Id = dy.UserWorkflowId
					WHERE u.WorkflowId = @WorkflowId
						AND (
							NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
								)
							OR NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
									AND [Data] IS NOT NULL
								)
							)

					DELETE u
					FROM dbo.[UserWorkflow] u
					WHERE u.WorkflowId = @WorkflowId
						AND (
							NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
								)
							OR NOT EXISTS (
								SELECT TOP 1 Id
								FROM @TableName
								WHERE UserWorkflowId = u.Id
									AND [Data] IS NOT NULL
								)
							)
					'
			SET @SqlScript = REPLACE(REPLACE(@SqlScript, '@WorkflowId', CAST(@WorkflowId as varchar(max))), '@TableName' , @TableName); 
			select  @SqlScript;
	END
END
go

