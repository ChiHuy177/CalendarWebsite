-- =============================================
-- Author:		Duy Dam
-- Create date: 27/10/2021
-- Description:	Get All UserWorkflowStep depend on multiple conditions
-- Changelog: 25/07/2022 TIENTH - Change ORDER BY query
-- =============================================
CREATE   PROCEDURE [dbo].[UserWorkflowStep_GetAll] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT us.[Id] AS Id
		,us.[FromUserWorkflowId] AS [FromUserWorkflowId]
		,us.[Index] AS index_v
		,us.[IsActived] AS [IsActived]
		,CASE us.IsRecall
			WHEN 1
				THEN CONCAT (
						ws.Title
						,N' thu hồi'
						)
			WHEN 0
				THEN (
						CASE us.IsAddInfo
							WHEN 1
								THEN CONCAT (
										ws.Title
										,N' yêu cầu bổ sung'
										)
							WHEN 0
								THEN (
										CASE us.IsReplace
											WHEN 1
												THEN CONCAT (
														ws.Title
														,N' chuyển xử lý'
														)
											WHEN 0
												THEN ws.Title
											ELSE ws.Title
											END
										)
							ELSE ws.Title
							END
						)
			ELSE ws.Title
			END AS Title
		,pp.FullName AS [User]
		,ps.Title AS Position
		,ps.TitleEN AS PositionEN
		,us.Action AS Action
		,us.FinishTime AS FinishTime
		,us.Note AS Note
		,(
			CASE 
				WHEN (us.FinishTime IS NOT NULL)
					THEN CONVERT(BIT, 1)
				ELSE CONVERT(BIT, 0)
				END
			) AS Executed
		,(
			CASE 
				WHEN us.StartTime IS NULL
					THEN us.CreatedTime
				ELSE us.StartTime
				END
			) AS StartTime
		,us.DueDate AS EndTime
		,us.IsDefault
		,us.CreatedTime
		,u.IsConverted
	FROM [dbo].[UserWorkflowStep] us
	INNER JOIN [dbo].[UserWorkflow] u ON u.Id = us.UserWorkflowId
	LEFT JOIN [dbo].[WorkflowStep] ws ON ws.Id = us.WorkflowStepId
	LEFT JOIN [dbo].[PersonalProfile] pp ON pp.Id = us.UserId
	LEFT JOIN [dbo].[Position] ps ON ps.Id = pp.PositionId
	WHERE us.UserWorkflowId = @UserWorkflowId
		AND us.IsDeleted = 0
	ORDER BY (
			CASE 
				WHEN u.IsConverted = CAST(1 AS BIT) AND u.UserWorkflowStatus <> 0
					THEN us.CreatedTime
				ELSE NULL
				END
			) DESC
		,[Index] DESC
		--,CASE [us].[Action] WHEN N'Từ chối' THEN 0 ELSE 1 END
		--,[IsIdea] DESC
		,CASE WHEN us.[IsIdea] = 1 Then us.StartTime ELSE null END ASC
		,CASE 
			WHEN FinishTime IS NULL
				THEN GETDATE()
			ELSE FinishTime
			END DESC
		,Id DESC
		--ORDER BY 
		--	us.[Index] DESC
		--	,CASE 
		--		WHEN (
		--				us.FinishTime IS NULL
		--				AND (
		--					us.IsIdea = 1
		--					OR us.IsReplace = 1
		--					)
		--				)
		--			THEN GETDATE()
		--		ELSE (CASE WHEN us.LastModified is null THEN us.CreatedTime ELSE us.LastModified END)
		--		END DESC
		--	,CASE 
		--		WHEN (
		--				us.FinishTime IS NULL
		--				AND (
		--					us.IsIdea = 1
		--					OR us.IsReplace = 1
		--					)
		--				)
		--			THEN GETDATE()
		--		ELSE us.FinishTime
		--		END DESC
		--	--,us.FinishTime DESC
		--	,us.Id DESC
END
go

