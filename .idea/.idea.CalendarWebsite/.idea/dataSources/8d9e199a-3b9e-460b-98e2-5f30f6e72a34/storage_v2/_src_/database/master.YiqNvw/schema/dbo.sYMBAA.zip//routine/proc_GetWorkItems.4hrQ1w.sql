CREATE PROCEDURE [dbo].[proc_GetWorkItems] (
        @SiteId                uniqueidentifier,
        @ParentId              uniqueidentifier,
        @WorkItemType          uniqueidentifier,
        @BatchId               uniqueidentifier,
        @WorkItemId            uniqueidentifier,
        @RequestGuid           uniqueidentifier = NULL OUTPUT   
        )
AS
    SET NOCOUNT ON
    IF (@WorkItemId IS NOT NULL)
        BEGIN
            SELECT TOP 1
                DeliveryDate, Type, ProcessMachineId as SubType, Id, SiteId, ParentId, ItemId, BatchId, ItemGuid, WebId, UserId, Created, BinaryPayload, TextPayload,
                InternalState
            FROM
                dbo.ScheduledWorkItems
            WHERE
                SiteId = @SiteId AND
                Id = @WorkItemId
        END
    ELSE
        BEGIN
            SELECT ALL
                DeliveryDate, Type, ProcessMachineId as SubType, Id, SiteId, ParentId, ItemId, BatchId, ItemGuid, WebId, UserId, Created, BinaryPayload, TextPayload,
                InternalState
            FROM
                dbo.ScheduledWorkItems
            WHERE
                Type = @WorkItemType AND
                SiteId = @SiteId AND
                (@ParentId IS NULL OR
                    ParentId = @ParentId) AND
                (@BatchId IS NULL OR
                    BatchId = @BatchId)
        END

go

