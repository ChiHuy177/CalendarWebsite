CREATE FUNCTION [dbo].[TVF_Resources_Web]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Resources] WITH (INDEX=Resources_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId

go

