CREATE FUNCTION [dbo].[TVF_Docs_NoLock_CI]
(
    @SiteId uniqueidentifier,
    @ParentId uniqueidentifier,
    @Id uniqueidentifier,
    @Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (NOLOCK, INDEX=AllDocs_ParentId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        ParentId = @ParentId AND
        Id = @Id AND
        Level = @Level

go

