-- [CRM_GetValueByWorkFlowIdAndId] 370,324338,'CustomerID'
 CREATE   PROC [dbo].[CRM_GetValueByWorkFlowIdAndId]                  
   @workFlowId as bigint =102                  
   ,@UserWorkflowId as bigint = 213301
   ,@column as nvarchar(250)=''
   as                              
   DECLARE @colsUnpivot AS NVARCHAR(MAX),@colsUnpivotValues as nvarchar(max)
   ,   @query  AS NVARCHAR(MAX), @table as nvarchar(250),@tableDynamic as nvarchar(250),@code as nvarchar(250)
   , @where as nvarchar(500)  = N' where UserWorkflowId = '+str(@UserWorkflowId)+''
   if(@column<>'')
   begin 
   set @where='where '+@column+' = '+str(@UserWorkflowId)+''
   end
   set @code= replace((select Code from Workflow where Id=@workFlowId),'-','')               
   set @code= replace(@code,'_','')
   
   set @table= ('Data_' +trim(@code))                  
   set @tableDynamic = ('Dynamic.Data_' +trim(@code))  
 
   select @colsUnpivot                   
     = stuff((select ','+quotename(C.column_name)        
              from information_schema.columns as C                  
              where C.table_name = @table --and                  
                    --C.column_name like 'Indicator%'                  
              for xml path('')), 1, 1, '')        
   select @colsUnpivotValues        
     = stuff((select ', isnull( CAST (' + quotename(C.column_name)+' as nvarchar(max)),''-999'') as '+ quotename(C.column_name)                  
              from information_schema.columns as C                  
              where C.table_name = @table --and                  
                    --C.column_name like 'Indicator%'                  
              for xml path('')), 1, 1, '')        
           
   set @query                   
     = '    
     select ''Code'' as name, WorkflowCode as value   from UserWorkflow where id='+str(@UserWorkflowId)+'    
     union    
     select  name12345, case when name12345=N''IsActive'' and value ='''' then ''True''               
         when value =''-999'' then null              
          else value end as  value                  
        from (select top 1 '+@colsUnpivotValues+' from  '+@tableDynamic+' '+@where+' ) p                  
        unpivot                  
        (                  
           value                  
           for name12345 in ('+ @colsunpivot +')                  
        ) u '                  
                       
              
   exec(@query) 
   print(@query)
go

