CREATE PROCEDURE [dbo].[proc_InsertItemIntoNameValuePairCollated](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ItemId int,
    @Collation smallint,
    @Level tinyint = 1,
    @FieldId1 uniqueidentifier = NULL,
    @FieldValue1 nvarchar(255) = NULL,
    @FieldId2 uniqueidentifier = NULL,
    @FieldValue2 nvarchar(255) = NULL,
    @FieldId3 uniqueidentifier = NULL,
    @FieldValue3 nvarchar(255) = NULL,
    @FieldId4 uniqueidentifier = NULL,
    @FieldValue4 nvarchar(255) = NULL,
    @FieldId5 uniqueidentifier = NULL,
    @FieldValue5 nvarchar(255) = NULL,
    @FieldId6 uniqueidentifier = NULL,
    @FieldValue6 nvarchar(255) = NULL,
    @FieldId7 uniqueidentifier = NULL,
    @FieldValue7 nvarchar(255) = NULL,
    @FieldId8 uniqueidentifier = NULL,
    @FieldValue8 nvarchar(255) = NULL,
    @FieldId9 uniqueidentifier = NULL,
    @FieldValue9 nvarchar(255) = NULL,
    @FieldId10 uniqueidentifier = NULL,
    @FieldValue10 nvarchar(255) = NULL)
AS
    SET NOCOUNT ON
    DECLARE @ReturnCode int
    SET @ReturnCode = 0
    DECLARE @RowsAffected int
    SET @RowsAffected = 0
    IF @Collation = 0
    BEGIN
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Albanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 1
    BEGIN
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Arabic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 2
    BEGIN
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 3
    BEGIN
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_PRC_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 4
    BEGIN
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 5
    BEGIN
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Taiwan_Stroke_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 6
    BEGIN
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Croatian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 7
    BEGIN
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Cyrillic_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 8
    BEGIN
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Czech_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 9
    BEGIN
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Danish_Norwegian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 10
    BEGIN
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Estonian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 11
    BEGIN
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Finnish_Swedish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 12
    BEGIN
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_French_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 13
    BEGIN
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Georgian_Modern_Sort_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 14
    BEGIN
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_German_PhoneBook_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 15
    BEGIN
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Greek_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 16
    BEGIN
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hebrew_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 17
    BEGIN
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hindi_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 18
    BEGIN
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 19
    BEGIN
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Hungarian_Technical_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 20
    BEGIN
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Icelandic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 21
    BEGIN
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 22
    BEGIN
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Japanese_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 23
    BEGIN
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 24
    BEGIN
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Korean_Wansung_Unicode_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 25
    BEGIN
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latin1_General_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 26
    BEGIN
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Latvian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 27
    BEGIN
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 28
    BEGIN
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Lithuanian_Classic_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 29
    BEGIN
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Traditional_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 30
    BEGIN
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Modern_Spanish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 31
    BEGIN
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Polish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 32
    BEGIN
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Romanian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 33
    BEGIN
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovak_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 34
    BEGIN
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Slovenian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 35
    BEGIN
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Thai_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 36
    BEGIN
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Turkish_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 37
    BEGIN
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Ukrainian_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 38
    BEGIN
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Vietnamese_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 39
    BEGIN
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Cyrillic_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 40
    BEGIN
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Azeri_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 41
    BEGIN
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 42
    BEGIN
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Divehi_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 43
    BEGIN
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Indic_General_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 44
    BEGIN
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Kazakh_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 45
    BEGIN
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Macedonian_FYROM_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 46
    BEGIN
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Syriac_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 47
    BEGIN
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Tatar_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    ELSE
    IF @Collation = 48
    BEGIN
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1
            WHERE
                @FieldId1 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2
            WHERE
                @FieldId2 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3
            WHERE
                @FieldId3 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4
            WHERE
                @FieldId4 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5
            WHERE
                @FieldId5 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6
            WHERE
                @FieldId6 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7
            WHERE
                @FieldId7 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8
            WHERE
                @FieldId8 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9
            WHERE
                @FieldId9 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
        INSERT INTO NameValuePair_Uzbek_Latin_90_CI_AS(SiteId, WebId, ListId, ItemId, Level, FieldId, Value)
            SELECT
                @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10
            WHERE
                @FieldId10 IS NOT NULL
        SET @RowsAffected = @RowsAffected + @@ROWCOUNT
    END
    IF @RowsAffected = 0
    BEGIN
        SET @ReturnCode = 87
        GOTO CLEANUP
    END
CLEANUP:
    RETURN @ReturnCode

go

