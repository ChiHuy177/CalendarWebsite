
CREATE FUNCTION [dbo].[fnCleanString] (@input VARCHAR(max), @Pattern 
VARCHAR (20))
RETURNS VARCHAR(max)
BEGIN
    DECLARE @str VARCHAR(max) = @input;
    DECLARE @Len INT;
    DECLARE @INDEX INT;
    SELECT @Len = LEN(@input); 
    WHILE @Len > 0  
    BEGIN
        SET @INDEX = PATINDEX(@Pattern,@str);
        IF (@INDEX > 0)
            BEGIN
                SET @str=REPLACE(@str,SUBSTRING(@str,@INDEX, 1), '');               
            END         
        ELSE
            BEGIN
                BREAK;
            END
    END     
    RETURN @str
END
go

