CREATE PROCEDURE [dbo].[proc_ReplaceCtoOffset](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @ParentId uniqueidentifier,
    @DocId uniqueidentifier,
    @CtoOffset int,
    @NewCtoOffset int)
AS
    SET NOCOUNT ON
    IF @CtoOffset = @NewCtoOffset OR
        @CtoOffset IS NULL AND @NewCtoOffset IS NULL
    BEGIN
        RETURN 0
    END
    DECLARE @FullUrl nvarchar(260)
    DECLARE @UrlLike nvarchar(260)
    SET @FullUrl = CASE WHEN (DATALENGTH(@DirName) = 0) THEN @LeafName WHEN (DATALENGTH(@LeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @LeafName END
    EXEC proc_EscapeForLike @FullUrl, @UrlLike OUTPUT
    UPDATE
        D
    SET
        D.CtoOffset = @NewCtoOffset
    FROM
        TVF_Docs_PId_DId(@SiteId, @ParentId, @DocId) AS D
    WHERE
        D.Type = 1 AND
        (D.CtoOffset = @CtoOffset OR D.CtoOffset IS NULL AND @CtoOffset IS NULL)
    UPDATE
        D
    SET
        D.CtoOffset = @NewCtoOffset
    FROM
        TVF_Docs_DirNameEqLike_NotForDelete(@SiteId, @FullUrl, @UrlLike) AS D
    WHERE
        D.Type = 1 AND
        (D.CtoOffset = @CtoOffset OR D.CtoOffset IS NULL AND @CtoOffset IS NULL)
    RETURN 0

go

