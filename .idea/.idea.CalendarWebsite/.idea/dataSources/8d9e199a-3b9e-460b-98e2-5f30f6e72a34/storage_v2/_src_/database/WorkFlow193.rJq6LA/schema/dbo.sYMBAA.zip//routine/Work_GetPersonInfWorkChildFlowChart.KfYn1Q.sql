-- Work_GetPersonInfWorkChildFlowChart '1,2'
   CREATE   PROC Work_GetPersonInfWorkChildFlowChart       
   @id AS NVARCHAR(max) ='39898'              
   as                 
   declare @tab1 table(WorkId bigint, userId nvarchar(50))              
   insert into @tab1      
   SELECT a.Id as Id       
   , c.[value] AS kq       
   FROM [Dynamic].Data_WorkChildFlowChart AS a       
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoixuly,'')+';'+ISNULL(a.Nguoiphoihop,'')+';'+ISNULL(a.Nguoitheodoi,''),';') AS c       
   where a.Id in (select * from STRING_SPLIT(@id,','))       
   group by a.Id,c.[value]
   SELECT b.WorkId, b.userId as Id        
   ,AccountName        
   ,Name        
   ,FullName        
   ,Email      
   ,EnableEmail  
   ,EnableNotification  
   FROM [dbo].[PersonalProfile] a             
   INNER JOIN @tab1 b ON a.Id = ( REPLACE(b.userId, 'P:', '') )       
   WHERE LEFT(b.userId,2)= 'P:'
go

