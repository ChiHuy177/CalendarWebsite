CREATE PROCEDURE [dbo].[proc_UrlToWebUrl](
    @WebSiteId uniqueidentifier,
    @Url nvarchar(260),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @WebUrl nvarchar(256)
    DECLARE @retval int
    DECLARE @WebDirName nvarchar(256)
    DECLARE @WebLeafName nvarchar(128)
    EXEC @retval = proc_UrlToWebUrlOutput @WebSiteId, @Url, 
        @WebDirName OUTPUT, @WebLeafName OUTPUT
    SET @WebUrl = CASE WHEN (DATALENGTH(@WebDirName) = 0) THEN @WebLeafName WHEN (DATALENGTH(@WebLeafName) = 0) THEN @WebDirName ELSE @WebDirName + N'/' + @WebLeafName END
    SELECT @WebUrl
    RETURN @retval

go

