CREATE PROC [dbo].[proc_RemoveTargetWebSolution](
    @SiteId uniqueidentifier,
	@WebId uniqueidentifier,
	@SolutionId uniqueidentifier)
AS
    SET NOCOUNT ON
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN 
    DELETE 
        C
    FROM 
	    TVF_CustomActions_Solution(@SiteId, @WebId, @SolutionId) AS C
    SELECT @Ret=@@ERROR
    IF @Ret <> 0
    BEGIN
       GOTO CLEANUP
    END
    DELETE 
        F
    FROM 
        TVF_Features_BySolution(@SiteId, @WebId, @SolutionId) as F
    DELETE 
        W
    FROM 
        TVF_AllWebParts_BySolution(@SiteId, @WebId, @SolutionId) as W
    SELECT @Ret=@@ERROR
    IF @Ret <> 0
    BEGIN
       GOTO CLEANUP
    END
    DELETE 
        S
    FROM 
        TVF_SolutionFiles_AllFilesForSolutionAtAllLevels(@SiteId, @WebId, @SolutionId) AS S
    SELECT @Ret=@@ERROR
    IF @Ret <> 0
    BEGIN
       GOTO CLEANUP
    END
    DELETE 
        S
    FROM 
        TVF_Solutions_SolutionBySiteIdWebIdAndSolutionId(@SiteId, @WebId, @SolutionId) AS S
    SELECT @Ret=@@ERROR
    IF @Ret <> 0
    BEGIN
       GOTO CLEANUP
    END
    IF (NOT EXISTS ( 
        SELECT TOP 1 
            1
        FROM 
            TVF_Solutions_AllSolutionsInSiteCollection(@SiteId) AS Solution))
    BEGIN
        UPDATE
            S
        SET
            S.BitFlags = S.BitFlags & ~1048576 --todo: what is this doing?
        FROM
            TVF_Sites_Id(@SiteId) AS S
    END
CLEANUP:
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

