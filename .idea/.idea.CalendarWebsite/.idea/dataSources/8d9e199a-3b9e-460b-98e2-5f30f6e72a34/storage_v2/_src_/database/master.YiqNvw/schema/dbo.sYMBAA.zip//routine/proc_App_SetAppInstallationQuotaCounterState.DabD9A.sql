CREATE Procedure [dbo].[proc_App_SetAppInstallationQuotaCounterState](
    @InstallationId uniqueidentifier,
    @SiteId uniqueidentifier,
    @NewStatus tinyint, 
    @TransitionStatus int OUTPUT
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
DECLARE @iRet int
SET @iRet = 0
SET @TransitionStatus = 0
IF (NOT EXISTS(
        SELECT TOP 1 1
            FROM TVF_AppInstallations_Id(@SiteId, @InstallationId) 
    ))
BEGIN
    SET @iRet = 7
    GOTO cleanup;
END
DECLARE @oldStatus tinyint
SELECT @oldStatus = Installations.QuotaCounterState
    FROM TVF_AppInstallations_UpdLock_Id(@SiteId, @InstallationId) as Installations
SET @TransitionStatus = CASE
    WHEN (@NewStatus = 0) AND
            (@oldStatus IS NULL OR 
            @oldStatus = 0)
    THEN 0
    WHEN (@NewStatus = 1) AND
            (@oldStatus IS NULL OR 
            @oldStatus = 4 OR 
            @oldStatus = 1 OR 
            @oldStatus = 0)
    THEN 0
    WHEN (@NewStatus = 2) AND
            (@oldStatus = 1 OR
            @oldStatus = 2 )
    THEN 0
    WHEN (@NewStatus = 3) AND
            (@oldStatus = 2 OR 
            @oldStatus = 3)
    THEN 0
    WHEN (@NewStatus = 4) AND
            (@oldStatus = 3 OR
            @oldStatus = 4 OR
            @oldStatus IS NULL OR 
            @oldStatus = 0 OR
            @oldStatus = 1)
    THEN 0
    WHEN (@NewStatus = 1) AND
            (@oldStatus = 2)
    THEN 1
    WHEN (@NewStatus = 3) AND
            (@oldStatus = 1 OR
            @oldStatus IS NULL OR 
            @oldStatus = 0 OR
            @oldStatus = 4)
    THEN 1
    ELSE 2
END
IF (@TransitionStatus <> 0)
BEGIN
    GOTO cleanup;
END
UPDATE TVF_AppInstallations_UpdLock_Id(@SiteId, @InstallationId)
    SET QuotaCounterState = @NewStatus
cleanup:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    return @iRet

go

