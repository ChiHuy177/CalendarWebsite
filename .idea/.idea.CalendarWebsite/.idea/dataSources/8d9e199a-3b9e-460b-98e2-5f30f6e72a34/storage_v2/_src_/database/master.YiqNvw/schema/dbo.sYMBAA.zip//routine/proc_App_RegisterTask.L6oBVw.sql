CREATE Procedure [dbo].[proc_App_RegisterTask] (
    @JobId uniqueidentifier,
    @TaskType nvarchar(255),
    @TaskData varbinary(max),
    @EstimatedDurationMinutes int,
    @SiteId uniqueidentifier,
    @TaskOperation int,
    @IsRollback bit,
    @IsolationKey uniqueidentifier,
    @TaskId uniqueidentifier output
)
AS
SET NOCOUNT ON
--Shouldn't need an applock for this. These won't do anything until the job is finalized.
SELECT @TaskId = NEWID()
INSERT INTO
    AppTasks(
        JobId,
        TaskType,
        TaskData,
        TaskOperation,
        IsRollback,
        EstimatedDurationMinutes,
        TaskId,
        RegisteredTime,
        SiteId,
        TimeoutTime,
        CancelledWhileInProgress,
        IsolationKey
    )
VALUES 
    (
        @JobId,
        @TaskType,
        @TaskData,
        @TaskOperation,
        @IsRollback,
        @EstimatedDurationMinutes,
        @TaskId,
        GETUTCDATE(),
        @SiteId,
        NULL, --pulled time is null...
        0,
        @IsolationKey
    )

go

