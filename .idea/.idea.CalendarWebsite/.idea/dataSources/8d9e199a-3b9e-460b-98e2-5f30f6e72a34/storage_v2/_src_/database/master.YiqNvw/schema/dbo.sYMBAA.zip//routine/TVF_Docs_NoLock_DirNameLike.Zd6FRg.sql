CREATE FUNCTION [dbo].[TVF_Docs_NoLock_DirNameLike]
(
    @SiteId uniqueidentifier,
    @DirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (NOLOCK, INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName LIKE @DirNameLike

go

