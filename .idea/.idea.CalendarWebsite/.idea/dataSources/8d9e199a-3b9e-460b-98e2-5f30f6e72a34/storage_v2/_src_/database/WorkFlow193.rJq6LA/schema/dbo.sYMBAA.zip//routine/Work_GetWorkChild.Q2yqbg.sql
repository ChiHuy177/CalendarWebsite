-- [Work_GetWorkChild] 225534   
   CREATE   PROC [dbo].[Work_GetWorkChild]   
   @WorkId AS NVARCHAR(500)   
   ,@listId as nvarchar(1000)=''   
   AS    
   SELECT a.Duan   
   ,a.Id   
   ,a.tieude AS title   
   ,ISNULL(a.noidung, '') AS description   
   ,a.TrangThaiCongViec AS STATUS   
   ,tieude   
   ,noidung    
   ,ISNULL(Nguoiphoihop, '') AS Nguoiphoihop   
   ,isnull(a.Nguoixuly, '') AS Nguoixuly   
   ,ISNULL(a.Nguoigiao, '') AS Nguoigiao   
   ,ISNULL(a.Nguoitheodoi, '') AS Nguoitheodoi   
   ,a.UserWorkflowId   
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau,null), 120)) AS [start]   
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS [end]   
   ,trim(CONVERT(CHAR, ISNULL(f.CreatedTime, getdate()), 120)) AS CreatedTime   
   ,ISNULL(a.Loaicv, '') AS Loaicv   
   ,ISNULL(CongViecCha,'') as CongViecCha    
   ,a.Tiendo as Progress    
   ,b.Ten as projectName    
   ,d.Ten as statusName    
   ,a.Douutien Priority    
   ,c.TenCV as CategoryName    
   ,d.TrangThaiCongViec as StatusType   
   ,f.Id as Id1   
   ,f.CreatedBy   
   ,case when ISNULL(e.value,'')<>'' then 1 else 0 end as IsMyWork   
   ,case when d.TrangThaiCongViec=N'Hoàn thành' then trim(CONVERT(CHAR, ISNULL(f.LastModified, null), 120)) else null end as DateComplete   
   ,CONVERT(CHAR, ISNULL(f.LastModified, f.CreatedTime), 120) as DateModified   
   --,case when exists ( select UserWorkflowId as abc from [Dynamic].[Data_WORK] where CongViecCha=a.UserWorkflowId) then 'True' else 'False' end as Haschildren   
   FROM [Dynamic].[Data_WORK] AS a    
   inner join DYNAMIC.Data_RESOURCEDA b on a.Duan=b.UserWorkflowId   
   left join DYNAMIC.Data_NHOMCV c on a.Loaicv=c.UserWorkflowId   
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId and a.Duan=d.Duan
   left join (select * from STRING_SPLIT(@listId,',')) e on e.value=a.UserWorkflowId   
   inner join Dynamic.Workflow_WORK f on a.UserWorkflowId=f.UserWorkflowId   
   where ISNULL(a.CongViecCha,'')=@WorkId and ISNULL(a.IsActive,'True')='True'   
   order by a.IndexWork
go

