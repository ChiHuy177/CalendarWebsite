CREATE FUNCTION [dbo].[TVF_AppInstallations_PreviousSourceInfoId]
(
    @SiteId uniqueidentifier,
    @PreviousSourceInfoId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppInstallations] WITH (INDEX=AppInstallations_PreviousSourceInfoId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@PreviousSourceInfoId IS NULL AND PreviousSourceInfoId IS NULL) OR @PreviousSourceInfoId=PreviousSourceInfoId)

go

