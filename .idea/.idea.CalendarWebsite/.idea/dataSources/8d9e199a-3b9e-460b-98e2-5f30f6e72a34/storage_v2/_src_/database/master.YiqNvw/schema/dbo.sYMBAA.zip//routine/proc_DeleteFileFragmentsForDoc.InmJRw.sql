CREATE PROCEDURE [dbo].[proc_DeleteFileFragmentsForDoc]
(
    @SiteId uniqueidentifier,
    @DocumentId uniqueidentifier,
    @FileFragmentPartitionToCheck tinyint,
    @FileFragmentIdToCheck bigint,
    @FileFragmentPartitionsToDelete nvarchar(max), 
    @QuotaChange bigint OUTPUT
)
AS
    SET NOCOUNT ON
    SET @QuotaChange = 0
    DECLARE @rowsDel int
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    IF (@FileFragmentPartitionToCheck IS NOT NULL AND @FileFragmentIdToCheck IS NOT NULL)
    BEGIN
        DECLARE @latestFragId bigint
        EXEC proc_GetLastFileFragmentId 
            @SiteId,
            @DocumentId, 
            @FileFragmentPartitionToCheck, 
            @latestFragId OUTPUT
        IF (@latestFragId IS NULL OR @latestFragId <> @FileFragmentIdToCheck)
        BEGIN
            SET @iRet = 21 
            GOTO cleanup
        END
    END
    IF (@FileFragmentPartitionsToDelete IS NOT NULL)
    BEGIN
        WHILE (1=1)
        BEGIN
            SELECT
                @QuotaChange = @QuotaChange - (ISNULL((SUM(CAST((FD.BlobSize) AS BIGINT))),0)),
                @rowsDel = COUNT(1)
            FROM
            (
                SELECT TOP(4500)
                    F.*
                FROM
                    dbo.fn_UnpackCsvString(@FileFragmentPartitionsToDelete) AS P
                INNER LOOP JOIN
                    AllFileFragments AS F WITH (XLOCK, INDEX=AllFileFragments_PartTagId_UNCI)
                ON
                    F.SiteId = @SiteId AND 
                    F.DocId = @DocumentId AND
                    F.Partition = CAST(P.val as tinyint)
                ORDER BY
                    F.Tag ASC,
                    F.Id ASC
            ) AS FD
            OPTION (FORCE ORDER, MAXDOP 1)
            IF @rowsDel IS NULL OR @rowsDel = 0
                BREAK
            DELETE
                FDForDelete
            FROM
            (
                SELECT TOP(@rowsDel)
                    F.*
                FROM
                    dbo.fn_UnpackCsvString(@FileFragmentPartitionsToDelete) AS P
                INNER LOOP JOIN
                    AllFileFragments AS F WITH (INDEX=AllFileFragments_PartTagId_UNCI)
                ON
                    F.SiteId = @SiteId AND
                    F.DocId = @DocumentId AND
                    F.Partition = CAST(P.val as tinyint)
                ORDER BY
                    F.Tag ASC,
                    F.Id ASC
            ) AS FD
            CROSS APPLY
                TVF_AllFileFragments_DocIdPartId(FD.SiteId, FD.DocId, FD.Partition, FD.Id) AS FDForDelete
            OPTION (FORCE ORDER, MAXDOP 1)
            IF @@ERROR <> 0
            BEGIN
                SET @iRet = 30
                GOTO cleanup
            END
        END
    END
    ELSE
    BEGIN
        WHILE (1=1)
        BEGIN
            SELECT
                @QuotaChange = @QuotaChange - (ISNULL((SUM(CAST((FD.BlobSize) AS BIGINT))),0)),
                @rowsDel = COUNT(1)
            FROM
            (
                SELECT TOP(4500)
                    F.*
                FROM
                    AllFileFragments AS F WITH (XLOCK, INDEX=AllFileFragments_PartTagId_UNCI)
                WHERE
                    F.SiteId = @SiteId AND
                    F.DocId = @DocumentId
                ORDER BY
                    F.Partition ASC, 
                    F.Tag ASC, 
                    F.Id ASC
            ) AS FD
            OPTION (FORCE ORDER, MAXDOP 1)
            IF @rowsDel IS NULL OR @rowsDel = 0
                BREAK
            DELETE
                FD
            FROM
            (
                SELECT TOP(@rowsDel)
                    F.*
                FROM
                    AllFileFragments AS F WITH (INDEX=AllFileFragments_PartTagId_UNCI)
                WHERE
                    F.SiteId = @SiteId AND 
                    F.DocId = @DocumentId
                ORDER BY
                    F.Partition ASC, 
                    F.Tag ASC, 
                    F.Id ASC
            ) AS FD
            OPTION (FORCE ORDER, MAXDOP 1)
            IF @@ERROR <> 0
            BEGIN
                SET @iRet = 30
                GOTO cleanup
            END
        END
    END
cleanup:
     IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
     RETURN @iRet   

go

