-- =============================================
-- Author:		DuyDam
-- Create date: 09/08/2023
-- Description:	Get dataJson of dynamic table
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_GetDataJson] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on
	BEGIN TRAN
	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@WorkflowId BIGINT
		,@TableName AS NVARCHAR(MAX)
		,@Sql NVARCHAR(4000)
		,@IsHavingMasterDetail BIT;

	SET @WorkflowId = (
			SELECT WorkflowId
			FROM [dbo].[UserWorkflow]
			WHERE Id = @UserWorkflowId
			);
            
	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);

	SET @TableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);

	SET @Sql = 'IF EXISTS (SELECT * FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ')' + 'BEGIN
			SELECT [Data] FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ' END';
	
	EXEC sp_ExecuteSql @SQL;
	COMMIT TRAN
END
go

