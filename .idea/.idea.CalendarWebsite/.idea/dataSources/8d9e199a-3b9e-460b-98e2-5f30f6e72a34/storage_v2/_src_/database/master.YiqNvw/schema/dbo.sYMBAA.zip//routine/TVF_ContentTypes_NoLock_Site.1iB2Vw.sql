CREATE FUNCTION [dbo].[TVF_ContentTypes_NoLock_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[ContentTypes] WITH (NOLOCK, INDEX=ContentTypes_SiteClassCTId, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

