CREATE Procedure [dbo].[proc_App_SetTenantAppDataOnAppInstance] (
    @SiteId uniqueidentifier,
    @InstallationId uniqueidentifier,
    @TenantAppData nvarchar(max)
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
DECLARE @UpdateTime datetime
IF (@TenantAppData is NULL)
    SET @UpdateTime = NULL
ELSE    
    SET @UpdateTime = GETUTCDATE()
UPDATE TVF_AppInstallations_Id(@SiteId, @InstallationId)
    SET TenantAppDataUpdateTime = @UpdateTime,
        TenantAppData = @TenantAppData
COMMIT TRANSACTION

go

