CREATE FUNCTION [dbo].[TVF_BuildDependencies_DirName]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[BuildDependencies] WITH (INDEX=BuildDependencies_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DirName = @DirName

go

