CREATE PROCEDURE [dbo].[proc_HTGetSetting]
    @settingKey nchar(10)
AS
    SET NOCOUNT ON    
    SELECT [value]
    FROM HT_Settings
    WHERE [key] = @settingKey

go

