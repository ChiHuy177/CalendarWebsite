CREATE PROC [dbo].[proc_GetListIdsToSync](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @Scope nvarchar(256)
    DECLARE @Scopes table (
        Scope nvarchar(256) COLLATE Latin1_General_CI_AS_KS_WS)
    IF @WebId IS NULL
        RETURN 144
    DECLARE @WebIdT uniqueidentifier
    SET @WebIdT = @WebId
    WHILE @WebIdT IS NOT NULL
    BEGIN
        SELECT TOP 1
            @WebIdT = W.ParentWebId,
            @Scope = W.FullUrl
        FROM
            TVF_Webs_Id(@SiteId, @WebIdT) AS W
        IF (@@ROWCOUNT = 0)
        BEGIN
            RETURN 3            
        END    
        INSERT INTO @Scopes (
            Scope)
        VALUES (
            @Scope)        
    END
    SELECT
        CTU.ListId
    FROM
        @Scopes AS S
    CROSS APPLY
        TVF_ContentTypes_SiteClassScope(
            @SiteId, 
            0, 
            S.Scope) AS CT
    CROSS APPLY
        TVF_ContentTypeUsage_SiteIsFClassCTIdWeb(
            @SiteId, 
            0, 
            0,
            CT.ContentTypeId,
            @WebId) AS CTU
    WHERE
        CT.Definition IS NOT NULL
    UNION
    SELECT
        CTU.ListId
    FROM
        @Scopes AS S
    CROSS APPLY
        TVF_ContentTypes_SiteClassScope(
            @SiteId, 
            1, 
            S.Scope) AS CT
    CROSS APPLY
        TVF_ContentTypeUsage_SiteIsFClassCTIdLEQCTIdGEQ(
            @SiteId,
            0, 
            1,
            CT.ContentTypeId + 0xFF,
            CT.ContentTypeId) AS CTU
    WHERE
        CT.Definition IS NOT NULL AND
        CTU.WebId = @WebId
    OPTION (FORCE ORDER)

go

