-- =============================================
-- Author:		DuyDam
-- Create date: 19/11/2021
-- Description:	Format UTC time into Local time
-- =============================================
CREATE FUNCTION [dbo].[fn_ToLocalTime]
(
    @utc_date datetime,
	@datetimeoffset nvarchar(10)
)
RETURNS datetime
AS
BEGIN
	--RETURN DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()),@utc_date)
	RETURN SWITCHOFFSET(@utc_date, @datetimeoffset)
END
go

