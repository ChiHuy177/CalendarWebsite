
-- =============================================
-- Author:		DuyDam
-- Create date: 21/07/2021
-- Description:	Insert only value into dynamic table
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_Insert_DynamicTableOnly] @WorkflowId BIGINT
	,@UserWorkflowId BIGINT = NULL
	,@Email NVARCHAR(MAX) = NULL
	,@Data_Json NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@TableName AS NVARCHAR(MAX)
		,@LineBreak NCHAR(2) = NCHAR(13) + NCHAR(10)
		,@Sql NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);

	PRINT @WorkflowId

	SET @TableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	/* Insert into dynamic table*/
	SET @Sql = 'BEGIN TRANSACTION' + @LineBreak + 'BEGIN TRY' + @LineBreak + 'INSERT INTO ' + @TableName + '([Data], UserWorkflowId, IsDeleted, CreatedBy,CreatedTime)' + @LineBreak + 'SELECT ' + CONCAT (
			'N'
			,''''
			,REPLACE(@Data_Json, '''', '''''')
			,''''
			) + ', ' + CAST(@UserWorkflowId AS VARCHAR) + ' as UserWorkflowId, 0 as IsDeleted, ' + CONCAT (
			''''
			,@Email
			,''''
			) + ' as CreatedBy, ' + CONCAT (
			''''
			,GETDATE()
			,''''
			) + ' as CreatedTime' + @LineBreak + 'COMMIT TRANSACTION' + @LineBreak + 'END TRY' + @LineBreak + 'BEGIN CATCH' + @LineBreak + 'IF @@TRANCOUNT > 0' + @LineBreak + '    ROLLBACK TRANSACTION' + @LineBreak + 'END CATCH' + @LineBreak;

	PRINT @SQL;

	EXEC sp_ExecuteSql @SQL;
END
go

