CREATE PROCEDURE [dbo].[proc_DeleteSmartPagePersonalization](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @UserId int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocId uniqueidentifier
    SELECT TOP 1
        @DocId = D.Id
    FROM
        TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS D
    IF @DocId IS NULL
    BEGIN
        RETURN 2
    END
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    IF @UserId IS NULL    
    BEGIN
        DELETE 
            P
        FROM
            TVF_Personalization_SitePage(@SiteId, @DocId) AS P
        IF (@@ERROR <> 0)
        BEGIN
            SET @Ret = 1
            GOTO cleanup
        END
        DELETE 
            WPL
        FROM
            TVF_WebPartLists_SitePage(@SiteId, @DocId) AS WPL
        WHERE
            WPL.tp_UserID IS NOT NULL
        IF (@@ERROR <> 0)
        BEGIN
            SET @Ret = 1
            GOTO cleanup
        END
        DELETE 
            WP
        FROM
            TVF_WebParts_SitePageId(@SiteId, @DocId) AS WP
        WHERE
            WP.tp_UserID IS NOT NULL
    END
    ELSE                    
    BEGIN
        DELETE 
            P
        FROM
            TVF_Personalization_SitePage(@SiteId, @DocId) AS P
        WHERE
            P.tp_UserID = @UserId
        IF (@@ERROR <> 0)
        BEGIN
            SET @Ret = 1
            GOTO cleanup
        END
        DELETE 
            WPL
        FROM
            TVF_WebPartLists_SitePage(@SiteId, @DocId) AS WPL
        WHERE
            WPL.tp_UserID = @UserId
        IF (@@ERROR <> 0)
        BEGIN
            SET @Ret = 1
            GOTO cleanup
        END
        DELETE 
            WP
        FROM
            TVF_WebParts_SitePageId(@SiteId, @DocId) AS WP
        WHERE
            WP.tp_UserID = @UserId
        IF (@@ERROR <> 0)
        BEGIN
            SET @Ret = 1
            GOTO cleanup
        END
    END
cleanup:
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

