CREATE PROCEDURE [dbo].[proc_ValidateLookupParents](
    @SiteId             uniqueidentifier, 
    @ListId             uniqueidentifier,
    @IsInsert           bit,
    @ItemId             int,
    @LookupFieldId1     uniqueidentifier = NULL,
    @ParentId1          int = NULL,
    @IsInvalid1         bit = NULL output,
    @LookupFieldId2     uniqueidentifier = NULL,
    @ParentId2          int = NULL,
    @IsInvalid2         bit = NULL output,
    @LookupFieldId3     uniqueidentifier = NULL,
    @ParentId3          int = NULL,
    @IsInvalid3         bit = NULL output,
    @LookupFieldId4     uniqueidentifier = NULL,
    @ParentId4          int = NULL,
    @IsInvalid4         bit = NULL output,
    @LookupFieldId5     uniqueidentifier = NULL,
    @ParentId5          int = NULL,
    @IsInvalid5         bit = NULL output,
    @LookupFieldId6     uniqueidentifier = NULL,
    @ParentId6          int = NULL,
    @IsInvalid6         bit = NULL output,
    @LookupFieldId7     uniqueidentifier = NULL,
    @ParentId7          int = NULL,
    @IsInvalid7         bit = NULL output,
    @LookupFieldId8     uniqueidentifier = NULL,
    @ParentId8          int = NULL,
    @IsInvalid8         bit = NULL output,
    @LookupFieldId9     uniqueidentifier = NULL,
    @ParentId9          int = NULL,
    @IsInvalid9         bit = NULL output,
    @LookupFieldId10    uniqueidentifier = NULL,
    @ParentId10         int = NULL,
    @IsInvalid10        bit = NULL output,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    SET @Ret = 0;
    SELECT 
        @IsInvalid1 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId1) THEN 1 ELSE 0 END),
        @IsInvalid2 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId2) THEN 1 ELSE 0 END),
        @IsInvalid3 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId3) THEN 1 ELSE 0 END),
        @IsInvalid4 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId4) THEN 1 ELSE 0 END),
        @IsInvalid5 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId5) THEN 1 ELSE 0 END),
        @IsInvalid6 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId6) THEN 1 ELSE 0 END),
        @IsInvalid7 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId7) THEN 1 ELSE 0 END),
        @IsInvalid8 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId8) THEN 1 ELSE 0 END),
        @IsInvalid9 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId9) THEN 1 ELSE 0 END),
        @IsInvalid10 = MAX(CASE WHEN (FP.FieldId = @LookupFieldId10) THEN 1 ELSE 0 END)
    FROM
        (
            SELECT @LookupFieldId1 AS FieldId, @ParentId1 AS ParentId
            WHERE @LookupFieldId1 IS NOT NULL
            UNION
            SELECT @LookupFieldId2 AS FieldId, @ParentId2 AS ParentId
            WHERE @LookupFieldId2 IS NOT NULL
            UNION
            SELECT @LookupFieldId3 AS FieldId, @ParentId3 AS ParentId
            WHERE @LookupFieldId3 IS NOT NULL
            UNION
            SELECT @LookupFieldId4 AS FieldId, @ParentId4 AS ParentId
            WHERE @LookupFieldId4 IS NOT NULL
            UNION
            SELECT @LookupFieldId5 AS FieldId, @ParentId5 AS ParentId
            WHERE @LookupFieldId5 IS NOT NULL
            UNION
            SELECT @LookupFieldId6 AS FieldId, @ParentId6 AS ParentId
            WHERE @LookupFieldId6 IS NOT NULL
            UNION
            SELECT @LookupFieldId7 AS FieldId, @ParentId7 AS ParentId
            WHERE @LookupFieldId7 IS NOT NULL
            UNION
            SELECT @LookupFieldId8 AS FieldId, @ParentId8 AS ParentId
            WHERE @LookupFieldId8 IS NOT NULL
            UNION
            SELECT @LookupFieldId9 AS FieldId, @ParentId9 AS ParentId
            WHERE @LookupFieldId9 IS NOT NULL
            UNION
            SELECT @LookupFieldId10 AS FieldId, @ParentId10 AS ParentId
            WHERE @LookupFieldId10 IS NOT NULL
        ) AS FP
    CROSS APPLY
        TVF_AllLookupRelationships_SiteListField(@SiteId, @ListId, FP.FieldId) AS ALR
    CROSS APPLY
        TVF_Lists_Id(ALR.SiteId, ALR.LookupListId) AS L
    OUTER APPLY
        TVF_UserData_ListItem(ALR.SiteId, ALR.LookupListId, FP.ParentId) AS LU 
    WHERE 
        LU.tp_ID IS NULL
        AND FP.ParentId IS NOT NULL
        AND ALR.DeleteBehavior <> 0
        AND NOT (@IsInsert = 0 AND 
                 LU.tp_ListId IS NOT NULL AND LU.tp_ListId = @ListId AND 
                 LU.tp_ID IS NOT NULL AND LU.tp_ID = @ItemId)
     OPTION (FORCE ORDER)
    IF (@IsInvalid1 IS NULL) SET @IsInvalid1 = 0;
    IF (@IsInvalid2 IS NULL) SET @IsInvalid2 = 0;
    IF (@IsInvalid3 IS NULL) SET @IsInvalid3 = 0;
    IF (@IsInvalid4 IS NULL) SET @IsInvalid4 = 0;
    IF (@IsInvalid5 IS NULL) SET @IsInvalid5 = 0;
    IF (@IsInvalid6 IS NULL) SET @IsInvalid6 = 0;
    IF (@IsInvalid7 IS NULL) SET @IsInvalid7 = 0;
    IF (@IsInvalid8 IS NULL) SET @IsInvalid8 = 0;
    IF (@IsInvalid9 IS NULL) SET @IsInvalid9 = 0;
    IF (@IsInvalid10 IS NULL) SET @IsInvalid10 = 0;
cleanup:
    IF (@IsInvalid1 = 1 OR 
        @IsInvalid2 = 1 OR 
        @IsInvalid3 = 1 OR 
        @IsInvalid4 = 1 OR 
        @IsInvalid5 = 1 OR 
        @IsInvalid6 = 1 OR 
        @IsInvalid7 = 1 OR 
        @IsInvalid8 = 1 OR 
        @IsInvalid9 = 1 OR 
        @IsInvalid10 = 1)
        SET @Ret = 6;
    RETURN @Ret

go

