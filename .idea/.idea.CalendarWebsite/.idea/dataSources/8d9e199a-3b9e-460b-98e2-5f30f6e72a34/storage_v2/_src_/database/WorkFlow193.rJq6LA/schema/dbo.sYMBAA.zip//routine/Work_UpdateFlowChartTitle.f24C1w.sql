-- Work_Work_UpdateFlowChartTitle 140645      
   CREATE   PROC  [dbo].[Work_UpdateFlowChartTitle]
   @nodeId as nvarchar(250),  
   @projectId as nvarchar(50)  
   as      
   select b.Id as StatusId, b.Ten as Name, b.Duan as ProjectId, b.TrangThaiCongViec           
   ,b.NguoiChinhSua as [user],b.UserWorkflowId,      
   a.TrangThaiDuAnTheoQuyTrinh      
   ,c.Id as StepId
   from [Dynamic].Data_RESOURCEDA a             
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan            
   inner join WorkflowStep c on a.TrangThaiDuAnTheoQuyTrinh = c.WorkflowId     
   where b.nodeid=@nodeId and b.Duan=@projectId  
   order by c.Step  
go

