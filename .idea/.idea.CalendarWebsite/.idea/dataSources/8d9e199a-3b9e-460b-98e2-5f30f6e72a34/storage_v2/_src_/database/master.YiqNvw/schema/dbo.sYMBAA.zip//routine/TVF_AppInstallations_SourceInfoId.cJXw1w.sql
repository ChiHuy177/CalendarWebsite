CREATE FUNCTION [dbo].[TVF_AppInstallations_SourceInfoId]
(
    @SiteId uniqueidentifier,
    @SourceInfoId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppInstallations] WITH (INDEX=AppInstallations_SourceInfoIdAllWebs, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SourceInfoId = @SourceInfoId

go

