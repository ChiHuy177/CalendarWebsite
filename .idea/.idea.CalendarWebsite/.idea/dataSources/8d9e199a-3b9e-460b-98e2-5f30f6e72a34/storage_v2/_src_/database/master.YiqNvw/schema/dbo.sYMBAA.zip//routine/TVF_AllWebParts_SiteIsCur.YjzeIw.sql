CREATE FUNCTION [dbo].[TVF_AllWebParts_SiteIsCur]
(
    @tp_SiteId uniqueidentifier,
    @tp_IsCurrentVersion bit
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebParts] WITH (INDEX=PageUrlID_FK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_IsCurrentVersion = @tp_IsCurrentVersion

go

