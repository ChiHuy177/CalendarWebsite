CREATE FUNCTION [dbo].[TVF_NavNodes_NoLock_PK]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @Eid int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NavNodes] WITH (NOLOCK, INDEX=NavNodes_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId AND
        Eid = @Eid

go

