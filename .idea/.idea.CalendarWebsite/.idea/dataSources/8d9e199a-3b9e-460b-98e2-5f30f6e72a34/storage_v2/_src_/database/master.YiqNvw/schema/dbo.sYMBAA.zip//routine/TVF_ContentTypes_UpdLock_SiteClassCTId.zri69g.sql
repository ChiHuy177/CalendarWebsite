CREATE FUNCTION [dbo].[TVF_ContentTypes_UpdLock_SiteClassCTId]
(
    @SiteId uniqueidentifier,
    @Class tinyint,
    @ContentTypeId tContentTypeId
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[ContentTypes] WITH (UPDLOCK, INDEX=ContentTypes_SiteClassCTId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Class = @Class AND
        ContentTypeId = @ContentTypeId

go

