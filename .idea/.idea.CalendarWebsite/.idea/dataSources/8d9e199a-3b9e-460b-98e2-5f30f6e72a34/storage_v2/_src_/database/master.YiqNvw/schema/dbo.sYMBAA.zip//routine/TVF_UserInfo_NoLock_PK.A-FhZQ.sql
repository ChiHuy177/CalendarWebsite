CREATE FUNCTION [dbo].[TVF_UserInfo_NoLock_PK]
(
    @tp_SiteID uniqueidentifier,
    @tp_ID int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[UserInfo] WITH (NOLOCK, INDEX=UserInfo_PK, FORCESEEK)
    WHERE
        tp_SiteID = @tp_SiteID AND
        tp_ID = @tp_ID

go

