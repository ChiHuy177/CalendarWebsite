-- =============================================
-- Author:		DuyDAm
-- Create date: 15/06/2023
-- Description:	Clan up and format UserWorkflow aster user press send
-- =============================================
CREATE   PROCEDURE CleanAndFormatUserWorkflowAfterSend
	-- Add the parameters for the stored procedure here
	@UserWorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on
	BEGIN TRAN
		UPDATE u
		SET u.WorkflowStepId = (
				CASE 
					WHEN us.WorkflowStepId IS NULL
						THEN u.WorkflowStepId
					ELSE us.WorkflowStepId
					END
				)
		FROM UserWorkflow u WITH (NOLOCK)
		OUTER APPLY (
			SELECT TOP 1 WorkflowStepId
			FROM UserWorkflowStep WITH (NOLOCK)
			WHERE UserWorkflowId = u.Id
				AND IsActived = 1
				AND IsDeleted = 0
				AND IsDefault = 1
			) us
		WHERE u.Id = @UserWorkflowId;

		UPDATE us
		SET us.FromUserWorkflowId = firstUserWorkflowStep.Id
		FROM UserWorkflowStep us WITH (NOLOCK)
		INNER JOIN UserWorkflowStep firstUserWorkflowStep ON (
				firstUserWorkflowStep.[Index] = 1
				AND firstUserWorkflowStep.UserWorkflowId = us.UserWorkflowId
				)
		WHERE us.[Index] = 2
			AND us.FromUserWorkflowId IS NULL
			AND us.UserWorkflowId = @UserWorkflowId;

		DELETE u
		FROM UserWorkflowShare u
		WHERE Id NOT IN (
				SELECT MIN(Id)
				FROM UserWorkflowShare WITH (NOLOCK)
				WHERE UserWorkflowId = @UserWorkflowId
				GROUP BY UserId
					,UserWorkflowId
				)
			AND u.UserWorkflowId = @UserWorkflowId
	COMMIT TRAN
END
go

