CREATE 
   
    PROCEDURE [Dynamic].[WorkflowDynamicData_GetIdFromUserWorkflowId] 
	@UserWorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX), @TableCode NVARCHAR(MAX),@WorkflowId BIGINT;
		DECLARE @SqlScript NVARCHAR(MAX) = '';

	SET @WorkflowId = (
			SELECT top 1 WorkflowId
			FROM [dbo].[UserWorkflow]
			WHERE Id = @UserWorkflowId
			)
	SET @TableCode = (
			SELECT top 1 Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @TableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableCode, '^a-z0-9')
			);

	
		SET @SqlScript =  'SELECT TOP 1 Id FROM ' +  @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ' ORDER BY Id DESC;';
		print @SqlScript
		EXEC sp_ExecuteSql @SqlScript;
END
go

