CREATE FUNCTION [dbo].[TVF_NameValuePair_UDItem]
(
    @ListId uniqueidentifier,
    @ItemId int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NameValuePair] WITH (INDEX=NameValuePair_MatchUserData, FORCESEEK)
    WHERE
        ListId = @ListId AND
        ItemId = @ItemId

go

