CREATE PROCEDURE [dbo].[proc_UpdateSiteUrlsColumn]
(
    @SiteId uniqueidentifier,
    @SiteUrlsTable tvpSiteUrls2 READONLY
)
AS
    SET NOCOUNT ON
    DECLARE @SiteUrlsStr nvarchar(MAX)
    DECLARE @UrlZone tinyint
    DECLARE @Scheme nvarchar(5)
    DECLARE @HostHeader nvarchar(128)
    DECLARE @AppSiteDomainId varchar(6)
    DECLARE @OneEntry nvarchar(142) 
    DECLARE SiteUrls_Cursor CURSOR FOR
    SELECT 
        HostHeader,
        Scheme,
        UrlZone,
        AppSiteDomainId
    FROM
        @SiteUrlsTable
    OPEN SiteUrls_Cursor
    FETCH NEXT FROM SiteUrls_Cursor
    INTO @HostHeader, @Scheme, @UrlZone, @AppSiteDomainId
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @OneEntry = CONVERT(nvarchar(1), @UrlZone) + ',' + @Scheme + ',' + @HostHeader + ',' + @AppSiteDomainId
        IF @SiteUrlsStr IS NULL OR LEN(@SiteUrlsStr) < 1
            SET @SiteUrlsStr = @OneEntry
        ELSE
            SET @SiteUrlsStr = @SiteUrlsStr + ';' + @OneEntry
        FETCH NEXT FROM SiteUrls_Cursor
        INTO @HostHeader, @Scheme, @UrlZone, @AppSiteDomainId
    END
    CLOSE SiteUrls_Cursor
    DEALLOCATE SiteUrls_Cursor
    UPDATE Sites
    SET SiteUrls = @SiteUrlsStr
    FROM TVF_AllSites_Id(@SiteId) AS Sites

go

