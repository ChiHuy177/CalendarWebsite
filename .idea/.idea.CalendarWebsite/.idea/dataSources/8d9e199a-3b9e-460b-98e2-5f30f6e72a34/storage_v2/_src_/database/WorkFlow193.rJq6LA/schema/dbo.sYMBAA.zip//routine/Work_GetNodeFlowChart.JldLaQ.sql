-- Work_Work_UpdateFlowChartTitle 140645     
   -- Work_GetNodeFlowChart 'node-c482d096-ae6c-492d-8b26-d93c4c520370','210281'     
   CREATE   PROC [dbo].[Work_GetNodeFlowChart]     
   @nodeId as nvarchar(250),     
   @projectId as nvarchar(50)     
   as     
   select b.Id as StatusId,b.Ten as Name, b.Duan as ProjectId, b.TrangThaiCongViec      
   ,b.NguoiChinhSua as [user],b.UserWorkflowId,     
   a.TrangThaiDuAnTheoQuyTrinh     
   ,c.Id as StepId     
   ,a.FlowChartData     
   ,b.nodeid     
   from [Dynamic].Data_RESOURCEDA a      
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan     
   inner join Dynamic.Data_LSQTCV c on c.ProjectId = a.UserWorkflowId and b.nodeid=c.Nodeid     
   where b.nodeid=@nodeId and b.Duan=@projectId     
   -- order by c.Step 
go

