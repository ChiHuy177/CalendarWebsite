CREATE   PROC  [dbo].[Work_CheckCompleteWorkNormal] 
   @workId as nvarchar(1000) 
   as 
   declare @Total as int,@Compelete as int 
   select b.* into #a from Dynamic.Data_WORK a 
   inner join Dynamic.Data_RESOURCETTFC b on a.TrangThaiCongViec=b.UserWorkflowId 
   where a.UserWorkflowId in (select Item from Split(@workId,',')) and ISNULL(a.IsActive,'True')='True' 
   set @Total=( select COUNT(*) from #a) 
   set @Compelete=( select COUNT(*) from #a where TrangThaiCongViec=N'Hoàn thành') 
   if(@Total= @Compelete and @Total >0) 
   begin 
   select 1 
   end 
   else 
   begin 
   select 0 
   end 
   drop table #a 
go

