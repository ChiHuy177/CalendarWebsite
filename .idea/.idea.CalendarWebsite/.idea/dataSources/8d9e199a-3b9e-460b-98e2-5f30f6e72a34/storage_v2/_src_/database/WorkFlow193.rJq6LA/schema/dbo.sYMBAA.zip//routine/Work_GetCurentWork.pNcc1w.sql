-- [Work_GetCurentWork] 266905    
   CREATE   PROC [dbo].[Work_GetCurentWork]      
   @WorkId AS NVARCHAR(1000)     
   AS     
   CREATE TABLE #duan (UserWorkflowId char(50), Ten nvarchar(500), Loai nvarchar(500),NotAllowShowExtendInWorkChild nvarchar(50) )     
   insert into #duan select UserWorkflowId,Ten,Loai, NotAllowShowExtendInWorkChild from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False'      
   insert into #duan select '','','',''     
   SELECT a.Duan     
   ,a.Id     
   ,a.tieude AS title     
   ,ISNULL(a.noidung, '') AS description     
   ,a.TrangThaiCongViec AS STATUS       
   ,a.noidung     
   ,ISNULL(a.Nguoiphoihop, '') AS Nguoiphoihop     
   ,isnull(a.Nguoixuly, '') AS Nguoixuly     
   ,ISNULL(a.Nguoigiao, '') AS Nguoigiao     
   ,ISNULL(a.Nguoitheodoi, '') AS Nguoitheodoi     
   ,a.UserWorkflowId     
   ,a.IsCompeleteWhenAllChildDone     
   ,q.Title as FlowChartWorkName     
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau,null), 120)) AS [start]     
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS [end]      
   ,trim(CONVERT(CHAR, ISNULL(f.CreatedTime, getdate()), 120)) AS CreatedTime     
   ,ISNULL(a.Loaicv, '') AS Loaicv     
   ,ISNULL(a.CongViecCha,'') as CongViecCha     
   ,a.Tiendo as Progress     
   ,b.Ten as projectName     
   ,b.NotAllowShowExtendInWorkChild as IsShowExtendInWorkChild     
   ,b.UserWorkflowId as ProjectCode     
   ,d.Ten as statusName     
   ,a.Douutien Priority     
   ,c.TenCV as CategoryName      
   ,d.TrangThaiCongViec as StatusType     
   ,u.Tieude as ParentName     
   ,f.Id as Id1     
   ,f.CreatedBy     
   ,a.PhieuQuyTrinhId     
   ,a.Quytrinh     
   ,a.TudonghoanthanhCV     
   ,case when ISNULL(a.PhieuQuyTrinhId,'')='' then v.Title else w.WorkflowCode +' - '+ w.ShortContent end as PROCedureName     
   ,case when d.TrangThaiCongViec=N'Hoàn thành' then trim(CONVERT(CHAR, ISNULL(f.LastModified, null), 120)) else null end as DateComplete     
   ,CONVERT(CHAR, ISNULL(f.LastModified, f.CreatedTime), 120) as DateModified      
   ,ISNULL(g.rate,0) as ReviewsWork     
   ,a.WorkRepeat as IsWorkRepeat     
   ,h.UserWorkflowId as WorkRepeatId     
   ,a.CouponIdInfoExtend     
   ,i.Ten as GroupProject    
   ,a.RequireAttachFileToCompleteWork  
   ,ISNULL(a.RequestChangeUser,0) as RequestChangeUser
   FROM [Dynamic].[Data_WORK] AS a      
   inner join #duan b on ISNULL(a.Duan,'')=b.UserWorkflowId      
   left join DYNAMIC.Data_NHOMCV c on a.Loaicv=c.UserWorkflowId     
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId      
   inner join Dynamic.Workflow_WORK f on a.UserWorkflowId=f.UserWorkflowId     
   left join [Dynamic].[Data_WORK] u on a.CongViecCha=u.UserWorkflowId     
   left join Dynamic.Data_TMDSQTCV q on a.QuyTrinhDinhKem =q.UserWorkflowId     
   left join UserWorkflow w on a.PhieuQuyTrinhId = w.Id     
   left join Workflow v on a.Quytrinh=v.Id     
   left join     
   (     
   select ISNULL( AVG(CAST(Rate as int)),0) as rate, WorkId     
   from Dynamic.Data_ReviewsWork a     
   where WorkId in(select * from string_split(@WorkId,',' ))     
   group by WorkId     
   ) g on g.WorkId=a.UserWorkflowId     
   left join Dynamic.Data_WorkRepeat h on h.WorkId=a.UserWorkflowId     
   left join Dynamic.Data_ProjectGroup i on a.GroupProject=i.UserWorkflowId     
   where a.UserWorkflowId in(select * from string_split(@WorkId,',' ))and ISNULL(a.IsActive,'True')='True'
go

