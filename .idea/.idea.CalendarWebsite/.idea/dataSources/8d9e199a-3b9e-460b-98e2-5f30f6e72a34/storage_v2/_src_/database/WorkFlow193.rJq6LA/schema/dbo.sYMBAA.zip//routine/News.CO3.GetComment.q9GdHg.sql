
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.GetComment] @userWorkflowId VARCHAR(max)
	,@WorkflowId VARCHAR(max)
AS
BEGIN
DECLARE @TableName NVARCHAR(MAX);
DECLARE @DataTableName NVARCHAR(MAX);
	DECLARE @QueryString NVARCHAR(MAX);
SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	SET NOCOUNT ON;

	DECLARE @sql AS NVARCHAR(max)
	set @QueryString='
	SELECT dw.*
	FROM '+@DataTableName+' dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE u.IsDeleted = 0
	and u.UserWorkflowStatus=1
		AND  dw.PostId=' +@userWorkflowId+ '
		'
		
	PRINT @QueryString;

	EXEC sp_ExecuteSql @QueryString;
END
go

