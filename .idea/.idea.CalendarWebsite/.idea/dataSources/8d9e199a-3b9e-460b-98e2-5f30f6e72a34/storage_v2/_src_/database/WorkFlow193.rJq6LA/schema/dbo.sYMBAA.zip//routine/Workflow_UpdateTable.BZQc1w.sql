-- =============================================
-- Author:		Duy Dam
-- Create date: 1/10/2021
-- Description:	Update the table name when update the Workflow Code
-- =============================================
CREATE     PROCEDURE [dbo].[Workflow_UpdateTable] @OldWorkflowCode NVARCHAR(MAX)
	,@NewWorkflowCode NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @OldTableName NVARCHAR(MAX)
		,@NewTableName NVARCHAR(MAX);

	/* Update table for workflow*/
	SET @OldTableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9')
			);
	SET @NewTableName = CONCAT (
			'Workflow_'
			,dbo.fn_StripCharacters(@NewWorkflowCode, '^a-z0-9')
			);

	IF (
			EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'Dynamic'
					AND TABLE_NAME = CONCAT('Workflow_', dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9'))
				)
			)
	BEGIN
		EXEC sp_rename @OldTableName
			,@NewTableName;
	END

	/* Update table for Checklist*/
	SET @OldTableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9')
			);
	SET @NewTableName = CONCAT (
			'CheckList_'
			,dbo.fn_StripCharacters(@NewWorkflowCode, '^a-z0-9')
			);

	IF (
			EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'Dynamic'
					AND TABLE_NAME = CONCAT('CheckList_', dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9'))
				)
			)
	BEGIN
		EXEC sp_rename @OldTableName
			,@NewTableName;
	END

	/* Update table for DAta*/
	SET @OldTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9')
			);
	SET @NewTableName = CONCAT (
			'Data_'
			,dbo.fn_StripCharacters(@NewWorkflowCode, '^a-z0-9')
			);

	IF (
			EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'Dynamic'
					AND TABLE_NAME = CONCAT('Data_', dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9'))
				)
			)
	BEGIN
		EXEC sp_rename @OldTableName
			,@NewTableName;
	END

	/* Update table for Detail*/
	SET @OldTableName = CONCAT (
			'Dynamic.Detail_'
			,dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9')
			);
	SET @NewTableName = CONCAT (
			'Detail_'
			,dbo.fn_StripCharacters(@NewWorkflowCode, '^a-z0-9')
			);

	IF (
			EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'Dynamic'
					AND TABLE_NAME = CONCAT('Detail_', dbo.fn_StripCharacters(@OldWorkflowCode, '^a-z0-9'))
				)
			)
	BEGIN
		EXEC sp_rename @OldTableName
			,@NewTableName;
	END
END
go

