CREATE PROCEDURE [dbo].[proc_ResolveWikiLinkItem](
    @SiteId uniqueidentifier,
    @LinkId int,
    @ListId uniqueidentifier,
    @ItemId int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @ResolvedUrl nvarchar(260)
    SELECT TOP 1
        @ResolvedUrl = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END
    FROM
        TVF_UserData_ListItem(@SiteId, @ListId, @ItemId) AS UD
    CROSS APPLY
        TVF_Docs_CI(UD.tp_SiteId, UD.tp_ParentId, UD.tp_DocId, UD.tp_Level) AS D
    SELECT @LinkId AS LinkId, @ResolvedUrl AS ResolvedUrl
    RETURN 0

go

