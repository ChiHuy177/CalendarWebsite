CREATE FUNCTION [dbo].[TVF_Webs_NoLock_Id]
(
    @SiteId uniqueidentifier,
    @Id uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebs] WITH (NOLOCK, INDEX=Webs_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Id = @Id AND
        DeleteTransactionId = 0x

go

