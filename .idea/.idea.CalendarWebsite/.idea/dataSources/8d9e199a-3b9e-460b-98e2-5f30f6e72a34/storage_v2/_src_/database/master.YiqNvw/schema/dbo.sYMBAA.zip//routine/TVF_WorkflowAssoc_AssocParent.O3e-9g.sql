CREATE FUNCTION [dbo].[TVF_WorkflowAssoc_AssocParent]
(
    @SiteId uniqueidentifier,
    @WebId varbinary(16),
    @ListId varbinary(16),
    @ContentTypeId tContentTypeId
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[WorkflowAssociation] WITH (INDEX=WorkflowAssociation_Parent, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@WebId IS NULL AND WebId IS NULL) OR @WebId=WebId) AND
        ((@ListId IS NULL AND ListId IS NULL) OR @ListId=ListId) AND
        ((@ContentTypeId IS NULL AND ContentTypeId IS NULL) OR @ContentTypeId=ContentTypeId)

go

