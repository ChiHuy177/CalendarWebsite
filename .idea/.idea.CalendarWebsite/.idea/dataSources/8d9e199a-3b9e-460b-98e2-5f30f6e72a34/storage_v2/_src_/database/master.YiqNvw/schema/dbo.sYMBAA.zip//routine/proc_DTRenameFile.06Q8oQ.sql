CREATE PROCEDURE [dbo].[proc_DTRenameFile](
    @SiteId uniqueidentifier,
    @OldFullUrl nvarchar(260),
    @NewFullUrl nvarchar(260),
    @DirName nvarchar(256),
    @NewUrlLeafName nvarchar(128)
)
AS
    SET NOCOUNT ON
    UPDATE
        Docs
    SET
        Docs.ParentLeafName = @NewUrlLeafName
    FROM 
        TVF_Deps_SiteDescType(@SiteId, @OldFullUrl, 8) AS Deps
    CROSS APPLY
        TVF_Docs_Url(Deps.SiteId, CASE WHEN (CHARINDEX(N'/', REVERSE(Deps.FullUrl)) > 0) THEN LEFT(Deps.FullUrl, DATALENGTH(Deps.FullUrl)/2 - CHARINDEX(N'/', REVERSE(Deps.FullUrl) COLLATE Latin1_General_BIN)) ELSE N'' END, CASE WHEN (CHARINDEX(N'/', REVERSE(Deps.FullUrl) COLLATE Latin1_General_BIN) > 0) THEN RIGHT(Deps.FullUrl, CHARINDEX(N'/', REVERSE(Deps.FullUrl) COLLATE Latin1_General_BIN) - 1) ELSE Deps.FullUrl END) AS Docs
    WHERE
        Deps.DeleteTransactionId = 0x

go

