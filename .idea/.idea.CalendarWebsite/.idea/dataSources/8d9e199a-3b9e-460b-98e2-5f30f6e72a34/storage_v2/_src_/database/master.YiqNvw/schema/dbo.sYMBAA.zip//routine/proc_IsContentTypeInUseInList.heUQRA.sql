CREATE PROC [dbo].[proc_IsContentTypeInUseInList](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @ContentTypeId tContentTypeId,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_UserData_List(@SiteId, @ListId) AS UD
        WHERE
            @ContentTypeId = UD.tp_ContentTypeId)
    BEGIN
        RETURN 1
    END
    RETURN 0

go

