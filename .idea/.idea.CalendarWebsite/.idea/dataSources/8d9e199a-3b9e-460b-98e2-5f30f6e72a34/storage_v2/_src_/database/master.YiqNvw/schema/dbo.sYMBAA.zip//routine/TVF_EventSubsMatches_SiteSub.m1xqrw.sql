CREATE FUNCTION [dbo].[TVF_EventSubsMatches_SiteSub]
(
    @SiteId uniqueidentifier,
    @SubId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[EventSubsMatches] WITH (INDEX=EventSubsMatches_EventIdSubId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SubId = @SubId

go

