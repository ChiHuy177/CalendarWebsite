
-- =============================================
-- Author:		Duy Dam
-- Create date: 12/09/2022
-- Description:	Get the root of a flow of userworkflow
-- =============================================
CREATE   PROCEDURE [dbo].[GetRootOfFlowByUserWorkflowId] @UserWorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Insert statements for procedure here	
	WITH TEMP (
		[Id]
		,[UserId]
		,[WorkflowId]
		,[WorkflowStepId]
		,[WorkflowCode]
		,[ShortContent]
		,[Status]
		,[CreatedBy]
		,[CreatedTime]
		,[LastModified]
		,[ModifiedBy]
		,[IsDeleted]
		,[IsDraft]
		,[UserWorkflowStatus]
		,[Content]
		,[Note]
		,[Approver]
		,[IsWaitingForAppoved]
		,[IsConverted]
		,[MainUserWorkflowId]
		)
	AS (
		SELECT DISTINCT [u].[Id]
			,[u].[UserId]
			,[u].[WorkflowId]
			,[u].[WorkflowStepId]
			,[u].[WorkflowCode]
			,[u].[ShortContent]
			,[u].[Status]
			,[u].[CreatedBy]
			,[u].[CreatedTime]
			,[u].[LastModified]
			,[u].[ModifiedBy]
			,[u].[IsDeleted]
			,[u].[IsDraft]
			,[u].[UserWorkflowStatus]
			,[u].[Content]
			,[u].[Note]
			,[u].[Approver]
			,[u].[IsWaitingForAppoved]
			,[u].[IsConverted]
			,[u].[MainUserWorkflowId]
		FROM UserWorkflow u
		WHERE u.IsDeleted <> 1
			AND u.Id = @UserWorkflowId
		
		UNION ALL
		
		SELECT [b].[Id]
			,[b].[UserId]
			,[b].[WorkflowId]
			,[b].[WorkflowStepId]
			,[b].[WorkflowCode]
			,[b].[ShortContent]
			,[b].[Status]
			,[b].[CreatedBy]
			,[b].[CreatedTime]
			,[b].[LastModified]
			,[b].[ModifiedBy]
			,[b].[IsDeleted]
			,[b].[IsDraft]
			,[b].[UserWorkflowStatus]
			,[b].[Content]
			,[b].[Note]
			,[b].[Approver]
			,[b].[IsWaitingForAppoved]
			,[b].[IsConverted]
			,[b].[MainUserWorkflowId]
		FROM TEMP AS a
			,UserWorkflow AS b
		WHERE b.Id IN (
				SELECT uws.UserWorkflowId
				FROM UserWorkflowStepRelation ur
				JOIN UserWorkflowStep uws ON uws.Id = ur.UserWorkflowStepId
				WHERE ur.UserWorkflowId = a.Id
				)
			AND b.Id <> a.Id
			AND b.IsDeleted <> 1
		)
	SELECT *
	FROM TEMP
	WHERE [Id] NOT IN (
			SELECT TOP (
					(
						SELECT count(*)
						FROM TEMP
						) - 1
					) [Id]
			FROM TEMP
			)
END
go

