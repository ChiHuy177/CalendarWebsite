CREATE FUNCTION [dbo].[TVF_UserData_UpdLock_ListItemLevelRow]
(
    @tp_SiteId uniqueidentifier,
    @tp_ListId uniqueidentifier,
    @tp_Id int,
    @tp_Level tinyint,
    @tp_RowOrdinal tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserData] WITH (UPDLOCK, INDEX=AllUserData_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_ListId = @tp_ListId AND
        tp_DeleteTransactionId = 0x AND
        tp_IsCurrentVersion = CONVERT(bit, 1) AND
        tp_ID = @tp_Id AND
        tp_CalculatedVersion = 0 AND
        tp_Level = @tp_Level AND
        tp_RowOrdinal = @tp_RowOrdinal

go

