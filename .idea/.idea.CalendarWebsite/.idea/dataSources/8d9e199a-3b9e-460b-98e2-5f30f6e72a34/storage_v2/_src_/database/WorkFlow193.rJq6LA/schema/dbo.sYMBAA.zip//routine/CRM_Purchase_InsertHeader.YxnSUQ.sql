CREATE   PROC [dbo].[CRM_Purchase_InsertHeader]    
  @UserWorkflowId as bigint,
  @Code as nvarchar(100),
  @Name as nvarchar(200),
  @RevisionNumber as decimal(18, 4) =null   ,
  @OrderDate as datetime2(7) =null    ,
  @ShipDate as datetime2(7) =null   ,
  @SubTotal as decimal(18, 4 )=null   ,
  @Vat as decimal(18, 4) =null   ,
  @Discount  as decimal(18, 4) =null   ,
  @TaxAmt  as decimal(18, 4) =null   ,
  @Freight  as decimal(18, 4) =null   ,
  @TotalDue  as decimal(18, 4) =null   ,
  @Note as nvarchar(max),
  @ShipAddress as nvarchar(200) ,
  @ModifiedDate as datetime2(7) =null   ,
  @UserCreate  as nvarchar(200) ,
  @UserModified  as nvarchar(200),
  @CreateDate as datetime2(7),
  @WareHouseID as bigint,
  @ShipMethodID as bigint,
  @EmployeeID as bigint,
  @Currency as nvarchar(50),
  @Status  as  bigint,
  @SupplierID as bigint,
  @IsDelete as bit 
 
 as    
 
    select * from   Dynamic.Data_CRMPurchaseOrderHeader   
 insert into Dynamic.Data_CRMPurchaseOrderHeader   
 (  
 	UserWorkflowId,
 	Code,
 	Name,
 	RevisionNumber,
 	OrderDate,
 	ShipDate,
 	SubTotal,
 	Vat,
 	Discount,
 	TaxAmt,
 	Freight,
 	TotalDue,
 	Note,
 	ShipAddress,
 	ModifiedDate,
 	UserCreate,
 	UserModified,
 	CreateDate,
 	WareHouseID,
 	ShipMethodID,
 	EmployeeID,
 	Currency,
 	Status,
 	SupplierID,
 	IsDelete
 
 
 
 )  
   
 values (  
   
  @UserWorkflowId,  
  @Code,  
  @Name,  
  @RevisionNumber,  
  @OrderDate,  
  @ShipDate,  
  @SubTotal,  
  @Vat,  
  @Discount,   
  @TaxAmt,  
  @Freight,   
  @TotalDue,
  @Note,
  @ShipAddress,
  @ModifiedDate,
  @UserCreate,
  @UserModified,
  @CreateDate,
  @WareHouseID,
  @ShipMethodID,
  @EmployeeID,
  @Currency,
  @Status,
  @SupplierID,
  @IsDelete
 )
go

