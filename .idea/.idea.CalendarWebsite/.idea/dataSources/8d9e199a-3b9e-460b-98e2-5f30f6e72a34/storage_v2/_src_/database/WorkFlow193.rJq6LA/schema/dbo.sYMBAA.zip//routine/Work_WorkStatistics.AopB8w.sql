CREATE   PROC Work_WorkStatistics
   as
   declare @tb as table
   (
   TotalProject int -- Tổng số dự án đang có trên hệ thống
   , ProjectNotStart int -- Tổng số dự án chia theo các trạng thái Chưa bắt đầu
   , ProjectInPROCess int -- Tổng số dự án chia theo các trạng thái đang hoạt động
   , ProjectCompelete int -- Tổng số dự án chia theo các trạng thái hoàn thành
   , ProjectCancel int -- Tổng số dự án chia theo các trạng thái Hủy
   , TotalWork int -- Tổng số công việc đang có trên hệ thống
   , WorkNew int -- công việc trạng thái Cơ bản	
   , UserExecCompelete int -- -- công việc trạng thái người xử lý hoàn thành
   , WorkCompelete int -- công việc trạng thái hoàn thành
   , WorkCancel int -- công việc trạng thái Hủy
   )
   insert into @tb values(0,0,0,0,0,0,0,0,0,0)
   -- ******************************** dự án*************************************
   select COUNT(UserWorkflowId) as TotalProject, TrangThai into #b from Dynamic.Data_RESOURCEDA where  ISNULL(IsDeleted,'False')='False' group by TrangThai
   update @tb set TotalProject = (select sum(TotalProject) from #b)
   update @tb set ProjectNotStart = (select TotalProject from #b where TrangThai =N'Chưa bắt đầu')
   update @tb set ProjectInPROCess = (select TotalProject from #b where TrangThai =N'Đang thực hiện')
   update @tb set ProjectCompelete = (select TotalProject from #b where TrangThai =N'Hoàn thành')
   update @tb set ProjectCancel = (select TotalProject from #b where TrangThai =N'Hủy')
   -- *********************************************************************
   -- ******************************** Công việc *************************************
   select COUNT(a.UserWorkflowId) as TotalWork,b.TrangThaiCongViec into #a
   from Dynamic.Data_WORK a 
   inner join Dynamic.Data_RESOURCETTFC b on a.TrangThaiCongViec=b.UserWorkflowId 
   where ISNULL(a.IsActive,'True')='True'
   group by b.TrangThaiCongViec
   update @tb set TotalWork = (select SUM(TotalWork) from #a)
   update @tb set WorkNew = (select TotalWork from #a where TrangThaiCongViec=N'Cơ bản')
   update @tb set UserExecCompelete = (select TotalWork from #a where TrangThaiCongViec=N'Người xử lý hoàn thành')
   update @tb set WorkCompelete = (select TotalWork from #a where TrangThaiCongViec=N'Hoàn thành')
   update @tb set WorkCancel = (select TotalWork from #a where TrangThaiCongViec=N'Hủy')
   -- *********************************************************************
   select * from @tb
   drop table #a
   drop table #b
go

