CREATE FUNCTION [dbo].[TVF_AllUserDataJunctions_Site]
(
    @tp_SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserDataJunctions] WITH (INDEX=AllUserDataJunctions_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId

go

