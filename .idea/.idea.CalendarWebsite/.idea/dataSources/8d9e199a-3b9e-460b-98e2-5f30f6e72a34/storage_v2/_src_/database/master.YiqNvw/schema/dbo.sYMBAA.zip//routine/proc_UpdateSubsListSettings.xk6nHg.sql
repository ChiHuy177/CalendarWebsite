CREATE PROCEDURE [dbo].[proc_UpdateSubsListSettings](
    @SiteId         uniqueidentifier,
    @ListId         uniqueidentifier,
    @ListTitle      nvarchar(255),
    @ReadSecurity   int,
    @RemoveSystemAlerts bit)
AS
    SET NOCOUNT ON
    IF (@ReadSecurity = 0x00000002)
    BEGIN
        DELETE
            TVF_ImmedSubscriptions_SiteIdListId(@SiteId, @ListId)
        DELETE
            TVF_SchedSubscriptions_SiteIdListId(@SiteId, @ListId)
    END
    ELSE
    BEGIN
        UPDATE
            I
        SET
            I.ListTitle      = ISNULL(@ListTitle, I.ListTitle)
        FROM
            TVF_ImmedSubscriptions_SiteIdListId(@SiteId, @ListId) AS I
        UPDATE
            S
        SET
            S.ListTitle      = ISNULL(@ListTitle, S.ListTitle)
        FROM
            TVF_SchedSubscriptions_SiteIdListId(@SiteId, @ListId) AS S
        IF (@RemoveSystemAlerts = 1)
        BEGIN
            DELETE
                I
            FROM
                TVF_ImmedSubscriptions_SiteIdListId(@SiteId, @ListId) AS I
            WHERE
                I.UserId = 0 AND
                I.SystemBit = 1
        END
    END
    RETURN 0

go

