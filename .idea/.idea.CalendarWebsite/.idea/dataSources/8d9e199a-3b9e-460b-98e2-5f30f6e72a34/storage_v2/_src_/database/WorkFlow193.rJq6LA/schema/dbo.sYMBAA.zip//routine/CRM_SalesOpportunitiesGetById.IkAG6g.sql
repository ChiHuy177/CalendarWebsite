-- SalesOpportunities_getHeader 2          
 CREATE   PROC [dbo].CRM_SalesOpportunitiesGetById                
 @id as bigint                  
 as                  
 if(@id=0)                  
 begin                   
 SELECT a.[ID]                  
       ,a.[Code]                  
       ,a.[Name]                  
       ,a.[Description]                  
       ,a.[Note]                  
       ,a.[CustomerID]      
    ,b.PhoneNumber as CustomerPhone 
    ,b.Address as CustomerAddress   
       ,a.[SourceID]                  
       ,a.[CampaignID]                  
       ,a.[DescriptionSource]  
       ,a.[IsDelete]     
 	  ,a.UserExec
    ,ISNULL( a.SuccessRate,0) as SuccessRate        
    ,Case when  SuccessRate=0 then '0%'          
   when SuccessRate=1 then '20%'          
   when SuccessRate=2 then '40%'          
   when SuccessRate=3 then '60%'          
   when SuccessRate=4 then '80%'          
   when SuccessRate=5 then '100%'          
   
  else '0%' end SuccessRate1       
     ,a.IsLead  
    ,a.LeadContent  
    ,a.Revenue  
   FROM Dynamic.data_CRMSalesOpportunitiesHeader a                  
   inner join Dynamic.Data_CRMCustormer b on a.CustomerID=b.ID   
   where ISNULL(a.IsDelete,0) =0                
  order by a.ID desc          
 end                  
 else                  
 begin                  
                   
 SELECT a.[ID]                  
       ,a.[Code]                  
       ,a.[Name]                  
       ,a.[Description]                  
       ,a.[Note]                  
       ,a.[CustomerID]      
    ,b.PhoneNumber as CustomerPhone 
    ,b.Address as CustomerAddress   
       ,a.[SourceID]                  
       ,a.[CampaignID]                  
       ,a.[DescriptionSource]  
       ,a.[IsDelete]     
 	  ,a.UserExec
    ,ISNULL( a.SuccessRate,0) as SuccessRate
    ,Case when  SuccessRate=0 then '0%'
   when SuccessRate=1 then '20%'
   when SuccessRate=2 then '40%'
   when SuccessRate=3 then '60%'
   when SuccessRate=4 then '80%'
   when SuccessRate=5 then '100%'
   
  else '0%' end SuccessRate1       
     ,a.IsLead  
    ,a.LeadContent  
    ,a.Revenue  
   FROM Dynamic.data_CRMSalesOpportunitiesHeader a                  
   inner join Dynamic.Data_CRMCustormer b on a.CustomerID=b.ID   
   where ISNULL(a.IsDelete,0) =0         and a.UserWorkflowId=@id       
  order by a.ID desc    
   end
go

