CREATE Procedure [dbo].[proc_App_SetRuntimeIconActive] (
    @SiteId uniqueidentifier,
    @IconId uniqueidentifier,
    @AppInstanceId uniqueidentifier
)
AS
SET NOCOUNT ON
BEGIN TRANSACTION
UPDATE TVF_AppRuntimeIcons_AppInstanceId(@SiteId, @AppInstanceId)
    --not worth building an index for this because the TVF never has more than two records
    SET IsActive = CASE IconId
    WHEN @IconId THEN 1
    ELSE 0
    END
UPDATE TVF_AppInstallations_Id(@SiteId, @AppInstanceId)
    SET IsIconHosted = 1
COMMIT TRANSACTION

go

