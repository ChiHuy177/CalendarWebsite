
CREATE   PROCEDURE [dbo].[UserWorkflowSeen_Insert] @UserWorkflowId BIGINT
	,@UserId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Email AS NVARCHAR(MAX);

	SET @Email = (
			SELECT Email
			FROM [dbo].[PersonalProfile]
			WHERE Id = @UserId
			);

	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[UserWorkflowSeen]
				WHERE UserWorkflowId = @UserWorkflowId
					AND UserId = @UserId
				)
			)
	BEGIN
		INSERT INTO [dbo].[UserWorkflowSeen] (
			UserWorkflowId
			,UserId
			,Email
			,IsDeleted
			,CreatedTime
			)
		VALUES (
			@UserWorkflowId
			,@UserId
			,@Email
			,0
			,GETDATE()
			);
	END
END
go

