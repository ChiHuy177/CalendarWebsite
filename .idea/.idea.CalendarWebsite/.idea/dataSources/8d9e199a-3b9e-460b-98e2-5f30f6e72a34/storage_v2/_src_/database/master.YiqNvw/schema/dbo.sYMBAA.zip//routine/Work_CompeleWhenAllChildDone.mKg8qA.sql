  -- 230100
CREATE PROC [dbo].[Work_CompeleWhenAllChildDone]            
@parentId as bigint    
as         
   
declare @tong as int , @tonghoanthanh as int
   
select  a.UserWorkflowId,a.TrangThaiCongViec,b.UserWorkflowId as WorkId  into #b from Dynamic.Data_RESOURCETTFC a 
inner join Dynamic.Data_WORK b on b.TrangThaiCongViec=a.UserWorkflowId and b.Duan=a.Duan
where b.CongViecCha = @parentId 

set @tong = (select count (*) from #b)

set @tonghoanthanh = (select count (*) from #b where TrangThaiCongViec=N'Hoàn thành')

select top 1 UserWorkflowId into #C from Dynamic.Data_RESOURCETTFC     
where Duan= (select  Duan from Dynamic.Data_WORK where UserWorkflowId=@parentId ) and TrangThaiCongViec=N'Hoàn thành'            

           
if(@tong=@tonghoanthanh)            
begin         
	if(select COUNT(*) from #C)>0     
	begin 
	update Dynamic.Data_WORK set TrangThaiCongViec= (select top 1 * from #c),Tiendo='100%' where UserWorkflowId=@parentId    
	end        
 end 


  
go

