-- =============================================
-- Author:		Duy Dam
-- Create date: 17/07/2023
-- Description:	Clean up userWorkflow after accept or approving
-- Changelog	05/08/2024	Duy Dam		recheck current userWorkflowStepId with WorkflowStepId 
--										of actived userWorkflowStep
-- =============================================
CREATE       PROCEDURE [dbo].[CleanAndFormatUserWorkflowAfterAcceptArrprove] @UserWorkflowId BIGINT
	,@CurrentUserWorkflowStepId BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;-- turn it on

	BEGIN TRAN

	DECLARE @Index INT;
	DECLARE @Pattern NVARCHAR(max);
	DECLARE @Status NVARCHAR(max);
	DECLARE @WorkflowStepId BIGINT;

	SET @Index = (
			SELECT [Index]
			FROM [dbo].[UserWorkflowStep] WITH (NOLOCK)
			WHERE Id = @CurrentUserWorkflowStepId
			)

	--remove duplicate UserWorkflowShare
	IF (
			EXISTS (
				SELECT TOP 1 Id
				FROM [dbo].[UserWorkflow] WITH (NOLOCK)
				WHERE Id = @UserWorkflowId
					AND UserWorkflowStatus = 1
				)
			)
	BEGIN
		DELETE u
		FROM UserWorkflowShare u WITH (ROWLOCK)
		WHERE Id NOT IN (
				SELECT MIN(Id)
				FROM UserWorkflowShare WITH (NOLOCK) 
				WHERE UserWorkflowId = @UserWorkflowId
				GROUP BY UserId
					,UserWorkflowId
				)
			AND u.UserWorkflowId = @UserWorkflowId
	END

	--remove UserWorkflowStep which is Idea of CurrentUserWorkflow
	DELETE u 
	FROM UserWorkflowStep u WITH (ROWLOCK)
	WHERE u.[Index] = @Index
		AND (
			u.FinishTime IS NULL
			OR u.Action IS NULL
			OR u.Action = ''
			)
		AND u.IsIdea = 1
		AND u.UserWorkflowId = @UserWorkflowId
		AND u.FromUserWorkflowId = @CurrentUserWorkflowStepId

	IF EXISTS (
			SELECT TOP 1 Id
			FROM [dbo].[UserWorkflow] WITH (NOLOCK)
			WHERE Id = @UserWorkflowId
				AND UserWorkflowStatus = 0
			)
	BEGIN
		IF NOT EXISTS (
				SELECT TOP 1 Id
				FROM [dbo].[UserWorkflowStep] WITH (NOLOCK)
				WHERE UserWorkflowId = @UserWorkflowId
					AND FinishTime IS NULL
					--AND Action = N'Phê duyệt'
					--AND IsDefault = 1
					AND IsDeleted = 0
				)
		BEGIN
			UPDATE u
			SET u.UserWorkflowStatus = 1
				,STATUS = N'Đã phê duyệt'
				,Approver = (
					SELECT TOP 1 p.FullName
					FROM UserWorkflowStep us WITH (NOLOCK)
					INNER JOIN PersonalProfile p WITH (NOLOCK) ON p.Id = us.UserId
					WHERE us.UserWorkflowId = @UserWorkflowId
					ORDER BY us.FinishTime DESC
					)
			FROM [dbo].[UserWorkflow] u WITH (NOLOCK)
			WHERE u.Id = @UserWorkflowId
		END
				--Set IsActive if no userWorkflowStep isActive when UserWorkflow is Not done
		ELSE IF NOT EXISTS (
				SELECT TOP 1 Id
				FROM [dbo].[UserWorkflowStep] WITH (NOLOCK)
				WHERE UserWorkflowId = @UserWorkflowId
					AND IsDeleted = 0
					AND IsActived = 1
				)
		BEGIN
			SET @WorkflowStepId = (
					SELECT [WorkflowStepId] 
					FROM [dbo].[UserWorkflow] WITH (NOLOCK)
					WHERE Id = @UserWorkflowId
					);
			SET @Pattern = (
					SELECT [Pattern]
					FROM [dbo].[WorkflowStep] WITH (NOLOCK)
					WHERE Id = @WorkflowStepId
					);
			SET @Status = (
					SELECT [Status]
					FROM [dbo].[WorkflowStep] WITH (NOLOCK)
					WHERE Id = @WorkflowStepId
					);

			IF @Pattern = 'Sequential'
			BEGIN
				UPDATE u
				SET u.IsActived = 1
				FROM [dbo].[UserWorkflowStep] u WITH (NOLOCK)
				WHERE u.WorkflowStepId = @WorkflowStepId
					AND u.UserWorkflowId = @UserWorkflowId
					AND u.IsDeleted = 0
					AND u.IsDefault = 1
					AND u.FinishTime IS NULL
					AND u.Id IN (
						SELECT TOP 1 Id
						FROM [dbo].[UserWorkflowStep] WITH (NOLOCK)
						WHERE WorkflowStepId = @WorkflowStepId
							AND UserWorkflowId = @UserWorkflowId
							AND IsDeleted = 0
							AND IsDefault = 1
							AND FinishTime IS NULL
						ORDER BY [Index] ASC
						)
			END
			ELSE
			BEGIN
				UPDATE u
				SET u.IsActived = 1
				FROM [dbo].[UserWorkflowStep] u WITH (NOLOCK)
				WHERE u.WorkflowStepId = @WorkflowStepId
					AND u.UserWorkflowId = @UserWorkflowId
					AND u.IsDeleted = 0
					AND u.IsDefault = 1
					AND u.FinishTime IS NULL
			END

			UPDATE u
			SET u.WorkflowStepId = @WorkflowStepId
				,STATUS = @Status
			FROM [dbo].[UserWorkflow] u WITH (NOLOCK)
			WHERE u.Id = @UserWorkflowId
		END
		ELSE --Set WorkflowStepId depennds on Actived userWorkflowStep
		BEGIN
			UPDATE u
			SET u.WorkflowStepId = (
					SELECT TOP 1 WorkflowStepId
					FROM [dbo].[UserWorkflowStep] WITH (NOLOCK)
					WHERE IsActived = 1
						AND UserWorkflowId = @UserWorkflowId
						AND IsDeleted = 0
					)
			FROM [dbo].[UserWorkflow] u WITH (NOLOCK)
			WHERE u.Id = @UserWorkflowId
		END
	END

	--Update USerWorkflowStatus in case dont exists any waiting step
	UPDATE u
	SET u.UserWorkflowStatus = 1
		,STATUS = N'Đã phê duyệt'
		,Approver = finalUStep.FullName
	FROM UserWorkflow u WITH (NOLOCK) 
	OUTER APPLY (
		SELECT TOP 1 p.FullName
		FROM UserWorkflowStep us WITH (NOLOCK)
		INNER JOIN PersonalProfile p WITH (NOLOCK) ON p.ID = us.USerId
		WHERE us.UserWorkflowId = u.id
			AND us.IsDeleted = 0
			AND us.FinishTime IS NOT NULL
		ORDER BY us.FinishTime DESC
		) AS finalUStep
	WHERE u.Id = @UserWorkflowId
		AND NOT EXISTS (
			SELECT 1
			FROM UserWorkflowStep WITH (NOLOCK) 
			WHERE UserWorkflowId = u.Id
				AND IsDeleted = 0
				AND FinishTime IS NULL
			)

	----------------------------------------------------------------

	--Update PositionTitle and PositionTitleEN if not existed
	UPDATE us
	SET us.PositionTitle = p.PositionTitle, us.PositionTitleEN = p.PositionTitleEN
	FROM UserWorkflowStep us WITH (NOLOCK) 
	CROSS APPLY (
		SELECT TOP 1 po.Title AS PositionTitle
			,po.TitleEN AS PositionTitleEN
		FROM PersonalProfile p WITH (NOLOCK) 
		LEFT JOIN Position po WITH (NOLOCK) ON po.Id = p.PositionId
		WHERE p.Id = us.UserId
		) p
	where us.UserWorkflowId = @UserWorkflowId and us.PositionTitle IS NULL
	----------------------------------------------------------------

	--recheck active step & current step of userWorkflow
	UPDATE u
	SET u.WorkflowStepId = (
			CASE 
				WHEN us.Id IS NOT NULL
					THEN us.WorkflowStepId
				ELSE u.WorkflowStepId
				END
			)
		,u.STATUS = (
			CASE 
				WHEN us.Id IS NOT NULL
					THEN us.STATUS
				ELSE u.STATUS
				END
			)
	FROM UserWorkflow u WITH (NOLOCK) 
	CROSS APPLY (
		SELECT TOP 1 us.Id
			,us.WorkflowStepId
			,ws.STATUS
		FROM UserWorkflowStep us WITH (NOLOCK) 
		JOIN WorkflowStep ws WITH (NOLOCK) ON ws.Id = us.WorkflowStepId
		WHERE us.IsDeleted = 0
			AND us.IsActived = 1
			AND us.FinishTime IS NULL
			AND us.UserWorkflowId = u.Id
		) us
	WHERE u.Id = @UserWorkflowId

	----------------------------------------------------------------

	--recheck WorkApiQueryDataResult
	IF NOT EXISTS (SELECT 1 FROM WorkApiQueryDataResult WHERE UserWorkflowId = @UserWorkflowId)
	BEGIN
		INSERT INTO [dbo].[WorkApiQueryDataResult]
           ([IsSuccess]
           ,[Response]
           ,[RequestData]
           ,[CreatedBy]
           ,[CreatedTime]
           ,[LastModified]
           ,[ModifiedBy]
           ,[IsDeleted]
           ,[UserWorkflowId]
           ,[WorkId])
		 SELECT
			   0
			   ,NULL
			   ,NULL
			   ,CreatedBy
			   ,CreatedTime
			   ,NULL
			   ,NULL
			   ,0
			   ,@UserWorkflowId
			   ,WorkId
			   FROM UserWorkflow where ID = @UserWorkflowId
	END
	----------------------------------------------------------------
	
	COMMIT TRAN

	SELECT UserWorkflowStatus
	FROM UserWorkflow WITH (NOLOCK)
	WHERE ID = @UserWorkflowId
END
go

