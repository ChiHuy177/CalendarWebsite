CREATE FUNCTION dbo.RegexSplit (@input NVARCHAR(MAX), @pattern NVARCHAR(MAX))
RETURNS @output TABLE (Item NVARCHAR(MAX))
AS
BEGIN
    DECLARE @pos INT = 1, @nextpos INT, @match NVARCHAR(MAX)
    WHILE @pos <= LEN(@input)
    BEGIN
        SET @nextpos = PATINDEX(@pattern, SUBSTRING(@input, @pos, LEN(@input) - @pos + 1))
        IF @nextpos = 0
            SET @nextpos = LEN(@input) - @pos + 2
        SET @match = SUBSTRING(@input, @pos, @nextpos - 1)
        INSERT INTO @output (Item) VALUES (@match)
        SET @pos = @pos + @nextpos
    END
    RETURN
END
go

