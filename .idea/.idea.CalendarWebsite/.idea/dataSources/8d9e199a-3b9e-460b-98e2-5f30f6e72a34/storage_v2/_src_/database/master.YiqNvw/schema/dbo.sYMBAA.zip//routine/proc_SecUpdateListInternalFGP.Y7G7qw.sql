CREATE PROCEDURE [dbo].[proc_SecUpdateListInternalFGP](
    @SiteId       uniqueidentifier,
    @WebId        uniqueidentifier,
    @ListId       uniqueidentifier,
    @ClearOp      bit = 0)  
AS
    SET NOCOUNT ON
    DECLARE @HasInternalFGP bit
    DECLARE @NewHasInternalFGP bit
    SELECT TOP 1
        @HasInternalFGP = AL.tp_HasInternalFGP
    FROM
        TVF_AllLists_NoLock_CI(@SiteId, @WebId, @ListId) AS AL
    IF (@ClearOp = @HasInternalFGP)
    BEGIN
        DECLARE @ListFullUrl nvarchar(260)
        DECLARE @ListLike nvarchar(1024)
        SELECT TOP 1
            @ListFullUrl = CASE WHEN (DATALENGTH(AD.DirName) = 0) THEN AD.LeafName WHEN (DATALENGTH(AD.LeafName) = 0) THEN AD.DirName ELSE AD.DirName + N'/' + AD.LeafName END
        FROM
            TVF_AllLists_NoLock_CI(@SiteId, @WebId, @ListId) AS AL
        CROSS APPLY
            TVF_AllDocs_NoLock_Id_Level(AL.tp_SiteId, AL.tp_RootFolder, 1) AS AD
        EXEC proc_EscapeForLike @ListFullUrl, @ListLike OUTPUT
        SET @NewHasInternalFGP = CASE WHEN EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_Perms_ScopeUrlLike(@SiteId, @ListLike)) 
        THEN 1 ELSE 0 END
        IF @NewHasInternalFGP <> @HasInternalFGP
        BEGIN
            UPDATE
                AL
            SET
                AL.tp_HasFGP = 1,
                AL.tp_HasInternalFGP = @NewHasInternalFGP
            FROM
                TVF_AllLists_CI(@SiteId, @WebId, @ListId) AS AL
            EXEC proc_SecReCalculateWebFGP @SiteId, @WebId
        END
    END
    RETURN 0

go

