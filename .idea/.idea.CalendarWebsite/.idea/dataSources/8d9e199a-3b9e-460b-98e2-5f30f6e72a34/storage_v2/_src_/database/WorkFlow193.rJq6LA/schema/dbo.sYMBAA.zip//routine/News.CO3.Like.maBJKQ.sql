-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.Like] @UserWorkflowId BIGINT,
@Email nvarchar(Max)
AS
BEGIN
DECLARE @CommentId bigint
set @CommentId= (select dw.UserWorkflowId 
	FROM [Dynamic].[Workflow_Like] dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE  u.UserWorkflowStatus=1
		AND dbo.JSON_VALUE(dw.Data, '$.PostId') = @userWorkflowId
		and dw.CreatedBy= @email) 
	SET NOCOUNT ON;
	IF EXISTS (
	SELECT dw.*,u.IsDeleted
	FROM [Dynamic].[Workflow_Like] dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE  u.UserWorkflowStatus=1
		AND dbo.JSON_VALUE(dw.Data, '$.PostId') = @userWorkflowId
		and dw.CreatedBy= @email)
		begin
		
			update UserWorkflow set   IsDeleted=(
	  select (
    CASE WHEN IsDeleted = CAST(0 as bit) then CAST(1 as bit) else CAST(0 as bit)  END
  ) as result) where Id=@CommentId
	SELECT dw.*,u.IsDeleted
	FROM [Dynamic].[Workflow_Like] dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE  u.UserWorkflowStatus=1
		AND dbo.JSON_VALUE(dw.Data, '$.PostId') = @userWorkflowId
		and dw.CreatedBy= @email
		end

END
go

