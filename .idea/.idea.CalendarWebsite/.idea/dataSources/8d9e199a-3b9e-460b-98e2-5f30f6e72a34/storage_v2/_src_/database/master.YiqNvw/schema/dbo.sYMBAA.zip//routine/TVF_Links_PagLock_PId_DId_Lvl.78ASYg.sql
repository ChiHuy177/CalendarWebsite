CREATE FUNCTION [dbo].[TVF_Links_PagLock_PId_DId_Lvl]
(
    @SiteId uniqueidentifier,
    @ParentId uniqueidentifier,
    @DocId uniqueidentifier,
    @Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllLinks] WITH (PAGLOCK, INDEX=Links_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        ParentId = @ParentId AND
        DocId = @DocId AND
        Level = @Level

go

