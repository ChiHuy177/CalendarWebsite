CREATE FUNCTION [dbo].[TVF_Resources_PK]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ResourceName nvarchar(520),
    @LCID int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Resources] WITH (INDEX=Resources_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId AND
        ListId = @ListId AND
        ResourceName = @ResourceName AND
        LCID = @LCID

go

