-- =============================================
-- Author:		DuyDam
-- Create date: 05/11/2021
-- Description:	Get data of dynamic table
-- Changelog: 27/06/2024 - duydd1 - USerOpenJson for extract key + value
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_GetData] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@WorkflowId BIGINT
		,@TableName AS NVARCHAR(MAX)
		,@Sql NVARCHAR(4000)
		,@IsNewVersionOfSQL BIT
		,@IsHavingMasterDetail BIT;

	SET @IsNewVersionOfSQL = ISNULL((
				SELECT TOP 1 [Value]
				FROM WorkflowPara
				WHERE ParaName = 'IsNewVersionOfSQL'
					AND IsSystemPara = 1
				), 0);
	SET @WorkflowId = (
			SELECT WorkflowId
			FROM [dbo].[UserWorkflow]
			WHERE Id = @UserWorkflowId
			);
	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @IsHavingMasterDetail = (
			CASE 
				WHEN EXISTS (
						SELECT *
						FROM Property
						WHERE WorkflowId = @WorkflowId
							AND IsMasterDetail = 1
							AND IsDeleted = 0
						)
					THEN 1
				ELSE 0
				END
			);
	SET @TableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	--IF (
	--		@IsNewVersionOfSQL = 1
	--		AND @IsHavingMasterDetail = 0
	--		)
	--BEGIN
	--	SET @Sql = 'IF EXISTS (SELECT * FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ')' + 'BEGIN
	--		SELECT  [Param] as Name, (CASE [Value] WHEN ''null'' THEN null ELSE [Value] END) as Value from [dbo].[SmartParseJSON]((select  top 1 [Data]  FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ' order by Id desc))
	--		END';
	--END
	--ELSE
	--BEGIN
	--SET @Sql = 'IF EXISTS (SELECT * FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ')' + 'BEGIN
	--	SELECT [Name] as Name, (CASE [StringValue] WHEN ''null'' THEN null ELSE REPLACE([StringValue], CONCAT(''\'', char(9)),'''') END) as Value from parseJSON((select top 1 [Data]  FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ' order by Id desc)) Where Parent_ID is not null
	--	END';
	SET @Sql = 'IF EXISTS (SELECT * FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ')' + 'BEGIN
			SELECT x.[Key] as Name, (CASE x.[Value] WHEN ''null'' THEN null ELSE REPLACE(x.[Value] , CONCAT(''\'', char(9)),'''') END) as Value from OPENJSON((select top 1 [Data]  FROM ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ' order by Id desc), ''$'') AS x
			END';

	--END
	PRINT @SQL

	EXEC sp_ExecuteSql @SQL;
END
go

