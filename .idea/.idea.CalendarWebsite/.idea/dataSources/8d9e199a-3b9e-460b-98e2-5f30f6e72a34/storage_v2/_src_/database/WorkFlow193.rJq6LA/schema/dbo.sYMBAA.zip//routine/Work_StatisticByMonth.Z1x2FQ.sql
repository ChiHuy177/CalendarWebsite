CREATE   PROC  [dbo].[Work_StatisticByMonth]  
   @UserId as char(50)='P:287'  
   ,@month as datetime='2023-06-01'  
   as 
   declare @tb table (UserId char(50),[Month] nvarchar(250), Compelete  int, NotCompelete int)  
   insert @tb select trim(@UserId),FORMAT (@month, 'yyyy-MM-dd')  ,0,0  
   select @UserId as UserId,   
   a.UserWorkflowId,b.TrangThaiCongViec, Ngaybatdau  
   into #a  
   from Dynamic.Data_WORK a  
   inner join Dynamic.Data_RESOURCETTFC b on a.TrangThaiCongViec=b.UserWorkflowId and a.Duan=b.Duan  
   where ISNULL(a.IsActive,'False')='False' and @UserId =(case when  (select count (*) from Split(Nguoixuly,';') where item=@UserId)>0 then @UserId else '' end)  
   and right(CONVERT(nvarchar,Ngaybatdau,103),7)=right(CONVERT(nvarchar,@month,103),7)   
   update @tb set Compelete= (select COUNT(*) from #a where TrangThaiCongViec=N'Hoàn thành' )  
   update @tb set NotCompelete= (select COUNT(*) from #a where TrangThaiCongViec <> N'Hoàn thành' or TrangThaiCongViec <> N'Hủy')  
   select TRIM(UserId) as UserId, [Month], Compelete,NotCompelete
   from @tb  
   drop table #a  
   -- công việc ***************************************************************************************************  
   -- select DATEDIFF(day,'2023-09-21',GETDATE())
go

