CREATE PROCEDURE [dbo].[proc_UpdateWebPartCache](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @Level tinyint,
    @bAllUser bit,
    @SystemId tSystemID,
    @WebPartId uniqueidentifier,
    @Cache varbinary(max),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @cbDelta bigint
    DECLARE @DocId uniqueidentifier
    DECLARE @PartDocId uniqueidentifier
    DECLARE @UserId int
    DECLARE @CurrentUserId int
    DECLARE @CacheSize int
    DECLARE @NewSize bigint
    DECLARE @IsCurrentVersion bit
    DECLARE @IsForceCheckout bit
    DECLARE @EnableMinorVersions bit
    DECLARE @IsModerate bit
    SET @CurrentUserId = dbo.fn_UserIDFromSid(@SiteId, @SystemId)
    SELECT TOP 1
        @DocId = D.Id
    FROM
        TVF_Docs_Url_Level(@SiteId, @DirName, @LeafName, @Level) AS D
    IF @DocId IS NULL
    BEGIN
        RETURN 2
    END
    SELECT TOP 1
        @PartDocId = WP.tp_PageUrlID,
        @UserId = WP.tp_UserID
    FROM
        TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
    IF (@DocId <> @PartDocId)
    BEGIN
        RETURN 5
    END
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    IF (@bAllUser = 1 OR @UserId IS NOT NULL)
    BEGIN
        SET @CacheSize = ISNULL(DATALENGTH(@Cache), 0)
        EXEC @Ret = proc_OnUpdateWebParts
            @SiteId,
            @WebPartId,
            @Level,
            NULL,    
            NULL,    
            NULL,    
            NULL,    
            @CacheSize,
            NULL,    
            NULL,
            @NewSize OUTPUT
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        UPDATE
            WP
        SET
            WP.tp_Cache = @Cache,
            WP.tp_Size = @NewSize
        FROM
            TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
        IF (@@ERROR <> 0)
        BEGIN
            SET @Ret = -2147467259
            GOTO cleanup
        END
    END
    ELSE
    BEGIN
        SET @UserId = dbo.fn_UserIDFromSid(@SiteId, @SystemId)
        IF ((@Level = 1) AND 
            EXISTS (
                SELECT TOP 1
                    1
                FROM
                    TVF_Personalization_PK(@SiteId, @DocId, @WebPartId, @UserId)))
        BEGIN
            SET @CacheSize = ISNULL(DATALENGTH(@Cache), 0)
            EXEC @Ret = proc_OnUpdatePersonalization
                @SiteId,
                @DocId,
                @UserId,
                @WebPartId,
                NULL,    
                @CacheSize,
                @NewSize OUTPUT
            IF (@@ERROR <> 0 OR @Ret <> 0)
            BEGIN
                IF (@Ret = 0)
                    SET @Ret = -2147467259
                GOTO cleanup
            END
            UPDATE
                P
            SET
                P.tp_Cache = @Cache,
                P.tp_Size = @NewSize
            FROM
                TVF_Personalization_PK(@SiteId, @DocId, @WebPartId, @UserId) AS P
            IF (@@ERROR <> 0)
            BEGIN
                SET @Ret = -2147467259
                GOTO cleanup
            END
        END
    END
    IF NOT EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level))
    BEGIN
        SET @Ret = 2  
        GOTO cleanup
    END
    EXEC proc_UpdateDiskUsed @SiteId
cleanup:    
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

