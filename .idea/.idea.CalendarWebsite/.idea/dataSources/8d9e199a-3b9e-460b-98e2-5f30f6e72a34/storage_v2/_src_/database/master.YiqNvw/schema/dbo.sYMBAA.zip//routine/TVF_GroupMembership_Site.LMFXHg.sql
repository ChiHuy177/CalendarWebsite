CREATE FUNCTION [dbo].[TVF_GroupMembership_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[GroupMembership] WITH (INDEX=GroupMembership_GroupId, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

