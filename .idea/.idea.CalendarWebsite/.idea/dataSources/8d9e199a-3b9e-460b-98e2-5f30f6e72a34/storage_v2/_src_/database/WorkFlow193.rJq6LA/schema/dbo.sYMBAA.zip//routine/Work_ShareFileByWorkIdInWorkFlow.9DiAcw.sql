-- Work_ShareFileByWorkIdInWorkFlow 343105,'P:287'          
   CREATE   PROC  [dbo].[Work_ShareFileByWorkIdInWorkFlow]
   @UserWorkflowId as bigint =215815
   ,@userId as nvarchar(50)=''
   as       
   declare @code as nvarchar(250), @user as nvarchar(500),@userManagerProject as nvarchar(500)        
   set @code= (select Code from Workflow where Id in ( select WorkflowId from UserWorkflow where Id=@UserWorkflowId  ))      
   if(@code='WORK')      
   begin       
   set @user=( select  ISNULL( Nguoixuly,'')+';'+ ISNULL(Nguoigiao,'') +';'+ ISNULL(Nguoiphoihop,'') +';'+ISNULL(Nguoitheodoi,'')+';'+ISNULL(NguoiXuLyDauTien,'')       
   from Dynamic.Data_WORK where UserWorkflowId=@UserWorkflowId)          
   SET @userManagerProject=(select ISNULL(QuanLy,'') from Dynamic.Data_RESOURCEDA where UserWorkflowId in  (select ISNULL(Duan,0) as Duan  from Dynamic.Data_WORK where UserWorkflowId=@UserWorkflowId))          
   select REPLACE(value,'P:','') as Id              
   ,@UserWorkflowId as WorkId              
   into #a              
   from string_split(TRIM(@user)+';'+@userManagerProject ,';')              
   where value<>''  group by value      
   delete  [UserWorkflowShare] where [UserWorkflowId]=@UserWorkflowId;        
   INSERT INTO [dbo].[UserWorkflowShare]          
   ([UserId]          
   ,[UserWorkflowId]          
   ,[Note]          
   ,[CreatedBy]          
   ,[CreatedTime]          
   ,[LastModified]          
   ,[ModifiedBy]          
   ,[IsDeleted])          
   select           
   b.Id          
   ,b.WorkId          
   ,'' as [Note]          
   ,a.[CreatedBy]          
   ,GETDATE() as  [CreatedTime]          
   ,GETDATE()  as [LastModified]          
   , a.[CreatedBy]  as [ModifiedBy]          
   ,0 as [IsDeleted]          
   from UserWorkflow a           
   inner join #a b on a.Id=b.WorkId and a.UserId<>b.Id     
   inner join PersonalProfile c on  b.Id=c.Id  
   where a.Id= @UserWorkflowId         
   drop table #a          
   end      
   else if( @code='RESOURCEDA')      
   begin       
   declare @tb table (Id  bigint , WorkId bigint  )        
   set  @userManagerProject =(select QuanLy from Dynamic.Data_RESOURCEDA where UserWorkflowId= @UserWorkflowId)      
   SELECT                         
   b.value AS userId                            
   into #user                    
   FROM DYNAMIC.Data_RESOURCEDA AS a                           
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b                        
   WHERE a.UserWorkflowId = @UserWorkflowId                        
   insert into @tb            
   select * from (      
   SELECT c.Id AS Id  ,                        
   @UserWorkflowId as UserWorkflowId      
   FROM #user a                          
   INNER JOIN PersonalProfile c ON REPLACE(a.userId,'P:','') =trim(str(c.Id))            
   where left(trim(a.userId),1)='P'            
   union      
   SELECT b.Id AS Id,                          
   @UserWorkflowId as UserWorkflowId          
   FROM #user a                    
   inner join GroupPersonalProfile c on REPLACE(a.userId,'G:','')=c.GroupsId            
   INNER JOIN PersonalProfile b ON b.Id =c.PersonalProfilesId            
   where left(trim(a.userId),1)='G'        
   union      
   select REPLACE(value,'P:','') as Id              
   ,@UserWorkflowId as UserWorkflowId         
   from string_split(@userManagerProject ,';')              
   where value<>''        
   ) a group by Id,UserWorkflowId      
   -- insert to table share      
   delete  [UserWorkflowShare] where [UserWorkflowId]=@UserWorkflowId;        
   INSERT INTO [dbo].[UserWorkflowShare]          
   ([UserId]          
   ,[UserWorkflowId]          
   ,[Note]          
   ,[CreatedBy]          
   ,[CreatedTime]    
   ,[LastModified]          
   ,[ModifiedBy]          
   ,[IsDeleted])          
   select           
   b.Id          
   ,b.WorkId          
   ,'' as [Note]          
   ,a.[CreatedBy]          
   ,GETDATE() as  [CreatedTime]          
   ,GETDATE()  as [LastModified]          
   , a.[CreatedBy]  as [ModifiedBy]          
   ,0 as [IsDeleted]          
   from UserWorkflow a           
   inner join @tb b on a.Id=b.WorkId and a.UserId<>b.Id          
   inner join PersonalProfile c on b.Id=c.Id  
   where a.Id= @UserWorkflowId         
   end 
   else
   begin 
   if( select COUNT(*) from [UserWorkflowShare] where UserWorkflowId = @UserWorkflowId and UserId=REPLACE(@userId,'P:',''))<=0
   begin 
   INSERT INTO [dbo].[UserWorkflowShare]          
   ([UserId]          
   ,[UserWorkflowId]          
   ,[Note]          
   ,[CreatedBy]          
   ,[CreatedTime]          
   ,[LastModified]          
   ,[ModifiedBy]          
   ,[IsDeleted])          
   select           
   REPLACE(@userId,'P:','')
   ,a.Id
   ,'' as [Note]          
   ,a.[CreatedBy]          
   ,GETDATE() as  [CreatedTime]          
   ,GETDATE()  as [LastModified]          
   , a.[CreatedBy]  as [ModifiedBy]          
   ,0 as [IsDeleted]          
   from UserWorkflow a  
   where a.Id= @UserWorkflowId  
   end
   end
go

