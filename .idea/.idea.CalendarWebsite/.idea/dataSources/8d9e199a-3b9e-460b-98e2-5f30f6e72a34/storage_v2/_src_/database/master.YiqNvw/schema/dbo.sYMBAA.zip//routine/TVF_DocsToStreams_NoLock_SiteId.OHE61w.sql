CREATE FUNCTION [dbo].[TVF_DocsToStreams_NoLock_SiteId]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[DocsToStreams] WITH (NOLOCK, INDEX=DocsToStreams_CI, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

