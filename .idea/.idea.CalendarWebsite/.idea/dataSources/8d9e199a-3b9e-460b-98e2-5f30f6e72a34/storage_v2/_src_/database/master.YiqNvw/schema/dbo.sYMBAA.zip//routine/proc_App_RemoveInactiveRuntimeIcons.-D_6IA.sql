CREATE Procedure [dbo].[proc_App_RemoveInactiveRuntimeIcons] (
    @SiteId uniqueidentifier,
    @AppInstanceId uniqueidentifier
)
AS
SET NOCOUNT ON
DELETE FROM TVF_AppRuntimeIcons_AppInstanceId(@SiteId, @AppInstanceId)
    --not worth building an index for this because the TVF never has more than two records
    WHERE IsActive = 0

go

