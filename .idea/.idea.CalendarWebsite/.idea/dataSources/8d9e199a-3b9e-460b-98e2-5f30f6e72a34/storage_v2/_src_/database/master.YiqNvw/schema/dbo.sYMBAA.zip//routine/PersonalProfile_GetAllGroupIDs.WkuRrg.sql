
-- =============================================
-- Author:		Duy Dam
-- Create date: 05/04/2022
-- Description:	Get the list of group id of User
-- =============================================
CREATE   PROCEDURE [dbo].[PersonalProfile_GetAllGroupIDs] @UserId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT STUFF((
				SELECT ', ' + CAST([GroupsId] AS VARCHAR(MAX))
				FROM GroupPersonalProfile
				inner join dbo.[Group] on (GroupsId = Id and IsDeleted = 0)
				WHERE (PersonalProfilesId = @UserId)
				FOR XML PATH('')
					,TYPE
				).value('.', 'VARCHAR(MAX)'), 1, 2, '')
	FROM GroupPersonalProfile
	WHERE PersonalProfilesId = @UserId
	GROUP BY PersonalProfilesId
END
go

