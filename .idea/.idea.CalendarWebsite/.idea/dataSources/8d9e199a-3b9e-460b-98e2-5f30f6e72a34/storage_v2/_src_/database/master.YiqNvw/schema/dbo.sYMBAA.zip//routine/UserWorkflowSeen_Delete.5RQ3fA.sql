
-- =============================================
-- Author:		Duy Dam
-- Create date: 14/04/2022
-- Description:	Remove UserWorkflowSeen for AddInfo  
-- =============================================
CREATE   PROCEDURE [dbo].[UserWorkflowSeen_Delete] @UserWorkflowId BIGINT
	,@UserId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DELETE [dbo].[UserWorkflowSeen]
	WHERE UserId = @UserId
		AND UserWorkflowId = @UserWorkflowId;
END
go

