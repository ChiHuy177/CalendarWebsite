CREATE PROCEDURE [dbo].[proc_DeleteOneRecycleBinItem](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @DeleteUserId int,
    @ItemType tinyint,
    @ListId uniqueidentifier,
    @ListItemId int,
    @DocId uniqueidentifier,
    @DocVersionId int,
    @ThresholdRowCount int,
    @DeleteTransactionId varbinary(16),
    @ChildDeleteTransactionId varbinary(16),
    @FreedSpace bigint OUTPUT,
    @FreedRecycleBinSpace bigint OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @SessionID smallint
    SET @SessionID = @@SPID
    IF @SessionID IS NULL
    SET @SessionID = 0
    DECLARE @Ret int
    DECLARE @Collation smallint
    SET @Ret = 1359
    DECLARE @EffectiveDeleteTransactionId varbinary(16)
    IF (@ChildDeleteTransactionId = 0x)
        SET @EffectiveDeleteTransactionId = @DeleteTransactionId
    ELSE
        SET @EffectiveDeleteTransactionId = @ChildDeleteTransactionId
    IF ((@ThresholdRowCount > 0) AND (@ItemType = 4 OR
                @ItemType = 5 OR
                @ItemType = 6 OR
                @ItemType = 10))
    BEGIN
        DECLARE   @Count int
        SET @Count = 0
        SELECT TOP (@ThresholdRowCount + 1)
            @Count = count(1) 
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        WHERE
            AD.Level = 1
        IF @Count > @ThresholdRowCount
        BEGIN
            SET @Ret = 36
            GOTO cleanup
        END
    END
    IF (@ItemType = 2)
    BEGIN
        DECLARE @docsToDelete1 tvpStreamMetadata2
        INSERT INTO @docsToDelete1 (
            DocId, HistVersion, Level)
        SELECT
            ADV.Id, ADV.UIVersion, ADV.Level
        FROM
            TVF_AllDocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @DocVersionId) AS ADV
        EXEC proc_DeleteStreams @SiteId, @docsToDelete1
        DELETE
            ADV
        FROM
            TVF_AllDocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @DocVersionId) AS ADV
        DELETE
            AUD
        FROM
            TVF_AllUserData_ListDelVerItemCal(
                @SiteId, 
                @ListId,
                @EffectiveDeleteTransactionId,
                CONVERT(bit, 0),
                @ListItemId,
                @DocVersionId) AS AUD
        DELETE 
            AWP
        FROM
            TVF_AllWebParts_SiteIsCurPageIdPageVer(
                @SiteId,
                CONVERT(bit, 0),
                @DocId,
                @DocVersionId) AS AWP
        DELETE
            AUDJ
        FROM
            AllUserDataJunctions AS AUDJ WITH (INDEX=AllUserDataJunctions_ReverseNCI)
        WHERE
            tp_SourceListId = @ListId AND
            tp_DeleteTransactionId = @EffectiveDeleteTransactionId AND
            tp_IsCurrentVersion = CONVERT(bit, 0)
        SET @Ret = 0
        GOTO cleanup
    END
    ELSE IF (@ItemType = 8)
    BEGIN
        DECLARE @docsToDelete2 tvpStreamMetadata2
        INSERT INTO @docsToDelete2 (
            DocId, HistVersion, Level)
        SELECT
            ADV.Id, ADV.UIVersion, ADV.Level
        FROM
            TVF_AllDocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @DocVersionId) AS ADV
        EXEC proc_DeleteStreams @SiteId, @docsToDelete2
        DELETE
            ADV
        FROM
            TVF_AllDocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @DocVersionId) AS ADV
        DELETE
            AUD
        FROM
            TVF_AllUserData_ListDelVerItemCal(
                @SiteId,
                @ListId,
                @EffectiveDeleteTransactionId,
                CONVERT(bit, 0),
                @ListItemId,
                @DocVersionId) AS AUD
        DELETE
            AUDJ
        FROM
            AllUserDataJunctions AS AUDJ WITH (INDEX=AllUserDataJunctions_ReverseNCI)
        WHERE
            tp_SourceListId = @ListId AND
            tp_DeleteTransactionId = @EffectiveDeleteTransactionId AND
            tp_IsCurrentVersion = CONVERT(bit, 0)
        SET @Ret = 0
        GOTO cleanup
    END
    ELSE IF (@ItemType = 7)
    BEGIN
        DECLARE @docsToDelete3 tvpStreamMetadata2
        INSERT INTO @docsToDelete3 (
            DocId, HistVersion, Level)
        SELECT
            AD.Id, 0, AD.Level
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        EXEC proc_DeleteStreams @SiteId, @docsToDelete3
        INSERT INTO SiteQuota
            (SiteId, SessionId, SMOpCode, DocId, DiskUsed, UpdateTimeStamp)
        SELECT
            @SiteId,
            @SessionID,
            2,
            AD.Id,
            0,
            0
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        DELETE 
            AD
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        SET @Ret = 0
        GOTO cleanup
    END
    ELSE IF (@ItemType = 10)
    BEGIN
        EXEC @Ret = proc_DeleteWeb @SiteId, NULL, @ThresholdRowCount, @EffectiveDeleteTransactionId
        GOTO cleanup
    END
    DECLARE @TransactionsDeleted table (
        DeleteTransactionId varbinary(16),
        BinId tinyint,
        Size bigint)
    INSERT INTO @TransactionsDeleted
        (DeleteTransactionId, BinId, Size)
    VALUES
        (@EffectiveDeleteTransactionId, 0, 0)
    DECLARE @ListsDeleted table (
        ListId uniqueidentifier)
    DECLARE @DocsDeleted table (
        DocId uniqueidentifier)
    IF @ItemType = 6
    BEGIN
        INSERT INTO 
            @ListsDeleted (ListId)
        SELECT
            AL.tp_ID
        FROM
            TVF_AllLists_WebId(@SiteId, @WebId) AS AL
        WHERE
            AL.tp_DeleteTransactionId = @EffectiveDeleteTransactionId
        INSERT INTO @TransactionsDeleted 
            (DeleteTransactionId, BinId, Size)
        SELECT
            R.DeleteTransactionId, R.BinId, R.Size
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_RecycleBin_List(LD.ListId) AS R
        OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE IF @ItemType = 4
    BEGIN
        INSERT INTO @TransactionsDeleted
            (DeleteTransactionId, BinId, Size)
        SELECT
            R.DeleteTransactionId, R.BinId, R.Size
        FROM
            TVF_RecycleBin_List(@ListId) AS R
    END
    ELSE IF @ItemType = 3
    BEGIN
        INSERT INTO @TransactionsDeleted
            (DeleteTransactionId, BinId, Size)
        SELECT
            R.DeleteTransactionId, R.BinId, R.Size
        FROM
            TVF_RecycleBin_ListItem(@ListId, @ListItemId) AS R
    END
    ELSE IF @ItemType = 5
    BEGIN
        INSERT INTO @TransactionsDeleted
            (DeleteTransactionId, BinId, Size)
        SELECT
            R.DeleteTransactionId, R.BinId, R.Size
        FROM
            TVF_AllUserData_SiteDelId(@SiteId, @EffectiveDeleteTransactionId) AS AUD
        CROSS APPLY
            TVF_RecycleBin_ListItem(AUD.tp_ListId, AUD.tp_ID) AS R
        WHERE
            AUD.tp_ListId = @ListId
    END
    IF (EXISTS(SELECT TOP 1 1 FROM @TransactionsDeleted))
    BEGIN
        INSERT INTO @DocsDeleted (
            DocId)
        SELECT
            AD.Id
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_AllDocs_SiteDelTransId(@SiteId, TD.DeleteTransactionId) AS AD
        OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    BEGIN
        INSERT INTO @DocsDeleted (
            DocId)
        SELECT
            AD.Id
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
    END
    DECLARE @docsToDelete4 tvpStreamMetadata2
    INSERT INTO @docsToDelete4 (DocId)
    SELECT DocId FROM @DocsDeleted
    EXEC proc_DeleteStreams @SiteId, @docsToDelete4
    IF (@ItemType = 4)
    BEGIN
        DELETE FROM
            TVF_ImmedSubscriptions_SiteIdListId(@SiteId, @ListId)
        DELETE FROM
            TVF_SchedSubscriptions_SiteIdListId(@SiteId, @ListId)
        DELETE
            AUD
        FROM
            TVF_AllUserData_List(@SiteId, @ListId) AS AUD
        DELETE
            AUDJ
        FROM
            AllUserDataJunctions AS AUDJ WITH (INDEX=AllUserDataJunctions_ReverseNCI)
        WHERE
            AUDJ.tp_SourceListId = @ListId
        EXEC proc_DeleteFromNVP @SiteId, @ListId
        DELETE 
            AL
        FROM
            TVF_AllLists_CI(@SiteId, @WebId, @ListId) AS AL
        DELETE
            AllListsPlus
        FROM
            TVF_AllListsPlus_ListId(@SiteId, @ListId) AS AllListsPlus
        DELETE
            ALAux
        FROM
            TVF_AllListsAux_ListId(@SiteId, @ListId) AS ALAux
        DELETE FROM
            Resources
        WHERE
            WebId = @WebId AND
            ListId = @ListId
        DELETE 
            ALR
        FROM
            TVF_AllLookupRelationships_SiteList(@SiteId, @ListId) AS ALR
        DELETE 
            ALUF
        FROM
            TVF_AllListUniqueFields_SiteList(@SiteId, @ListId) AS ALUF
        DELETE 
            ER
        FROM
            TVF_EventReceivers_SiteWebHost(@SiteId, @WebId, @ListId) AS ER
        DELETE 
            CTU
        FROM
            TVF_ContentTypeUsage_SiteIsFListClass(
                @SiteId,
                0, 
                @ListId,
                1) AS CTU
        DELETE 
            CTU
        FROM
            TVF_ContentTypeUsage_SiteIsFListClass(
                @SiteId, 
                0, 
                @ListId,
                0) AS CTU
        UPDATE
            WFA
        SET
            WFA.Configuration = WFA.Configuration | 512
        FROM
            TVF_WorkflowAssoc_SiteWebList(@SiteId, @WebId, @ListId) AS WFA
        DELETE FROM
            ScheduledWorkItems
        WHERE
            SiteId = @SiteId AND
            ParentId = @ListId
        DELETE 
            CA
        FROM
            TVF_CustomActions_CIAllLevels(@SiteId, @WebId, @ListId) AS CA
    END
    ELSE IF (@ItemType = 6)
    BEGIN
        DELETE 
            ImmedSubscriptions
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_ImmedSubscriptions_SiteIdListId(
                @SiteId, LD.ListId) AS ImmedSubscriptions
        OPTION (FORCE ORDER)
        DELETE 
            SS
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_SchedSubscriptions_SiteIdListId(@SiteId, LD.ListId) AS SS
        OPTION (FORCE ORDER)
        DELETE
            AUD
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllUserData_List(@SiteId, LD.ListId) AS AUD
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE
            AUDJ
        FROM
            @ListsDeleted AS LD
        INNER JOIN
            AllUserDataJunctions AS AUDJ WITH (INDEX=AllUserDataJunctions_ReverseNCI)
        ON
            LD.ListId = AUDJ.tp_SourceListId
        EXEC proc_GetCollation @SiteId, @ListId, @Collation OUTPUT, @RequestGuid OUTPUT
    IF @Collation = 0
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 1
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 2
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 3
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 4
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 5
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 6
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 7
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 8
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 9
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 10
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 11
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 12
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 13
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 14
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 15
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 16
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 17
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 18
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 19
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 20
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 21
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 22
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 23
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 24
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 25
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 26
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 27
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 28
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 29
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 30
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 31
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 32
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 33
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 34
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 35
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 36
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 37
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 38
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 39
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 40
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 41
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 42
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 43
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 44
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 45
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 46
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 47
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 48
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_CI)
        ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
    END
    DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
        NameValuePair AS NVP WITH (INDEX=NameValuePair_CI)
    ON NVP.ListId = LD.ListId WHERE SiteId = @SiteId OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            ALP
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_AllListsPlus_ListId(@SiteId, LD.ListId) AS ALP
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE
            ALAux
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllListsAux_ListId(@SiteId, LD.ListId) AS ALAux
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            R
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_Resources_SiteWebList(@SiteId, @WebId, LD.ListId)
        OPTION (FORCE ORDER)
        DELETE 
            AL
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_AllLists_CI(@SiteId, @WebId, LD.ListId) AS AL
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            ALR
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllLookupRelationships_SiteList(@SiteId, LD.ListId) AS ALR
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            ALUF
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllListUniqueFields_SiteList(@SiteId, LD.ListId) AS ALUF
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            ER
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_EventReceivers_SiteWebHost(@SiteId, @WebId, LD.ListId) AS ER
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            CTU
        FROM
            @ListsDeleted LD
        CROSS APPLY        
            TVF_ContentTypeUsage_SiteIsFListClass(
                @SiteId, 
                0, 
                LD.ListId,                
                1) AS CTU
        WHERE
            CTU.WebId = @WebId
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            CTU
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_ContentTypeUsage_SiteIsFListClass(
                @SiteId, 
                0, 
                LD.ListId,
                0) AS CTU
        WHERE
            CTU.WebId = @WebId
        OPTION (FORCE ORDER, MAXDOP 1)
        UPDATE
            WFA
        SET
            WFA.Configuration = WFA.Configuration | 512
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_WorkflowAssoc_SiteWebList(@SiteId, @WebId, LD.ListId) AS WFA
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE FROM
            ScheduledWorkItems
        WHERE
            SiteId = @SiteId AND
            ParentId IN (SELECT ListId FROM @ListsDeleted)
        DELETE 
            CA
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_CustomActions_CIAllLevels(@SiteId, @WebId, LD.ListId) AS CA
        OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE IF (@ItemType = 5)
    BEGIN
        DELETE FROM
            I
        FROM
            TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD
        CROSS APPLY
            TVF_ImmedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, AUD.tp_ID) AS I
        OPTION(FORCE ORDER)
        DELETE FROM
            S
        FROM
            TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD
        CROSS APPLY
            TVF_SchedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, AUD.tp_ID) AS S
        OPTION(FORCE ORDER)
        EXEC proc_GetCollation @SiteId, @ListId, @Collation OUTPUT, @RequestGuid OUTPUT
    IF @Collation = 0
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 1
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 2
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 3
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 4
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 5
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 6
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 7
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 8
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 9
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 10
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 11
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 12
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 13
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 14
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 15
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 16
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 17
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 18
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 19
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 20
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 21
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 22
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 23
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 24
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 25
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 26
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 27
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 28
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 29
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 30
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 31
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 32
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 33
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 34
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 35
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 36
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 37
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 38
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 39
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 40
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 41
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 42
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 43
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 44
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 45
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 46
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 47
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    IF @Collation = 48
    BEGIN
        DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
            NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_MatchUserData)
        ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
    END
    DELETE NVP FROM TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD INNER JOIN
        NameValuePair AS NVP WITH (INDEX=NameValuePair_MatchUserData)
    ON AUD.tp_ID = NVP.ItemId WHERE SiteId = @SiteId AND ListId = @ListId OPTION (FORCE ORDER, MAXDOP 1)
        DELETE
            AUDJ
        FROM
            AllUserDataJunctions AS AUDJ WITH (INDEX=AllUserDataJunctions_ReverseNCI)
        WHERE
            AUDJ.tp_SourceListId = @ListId AND
            AUDJ.tp_DeleteTransactionId = @EffectiveDeleteTransactionId
        DELETE
            AUD
        FROM
            TVF_AllUserData_ListDel(@SiteId, @ListId, @EffectiveDeleteTransactionId) AS AUD
    END
    ELSE
    BEGIN
        IF @ListItemId IS NOT NULL
        BEGIN
            DELETE FROM
                TVF_ImmedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, @ListItemId)
            DELETE FROM
                TVF_SchedSubscriptions_SiteIdListIdItemId(@SiteId, @ListId, @ListItemId)
            EXEC proc_DeleteFromNVP @SiteId, @ListId, @ListItemId
            EXEC proc_AutoDropWorkflows 
                @SiteId, @WebId, @ListId, @ListItemId, NULL, 
                NULL, 1 , 5, 
                @RequestGuid OUTPUT
            DELETE
                AUDJ
            FROM
                TVF_AllUserDataJunctions_SiteDel(@SiteId, @EffectiveDeleteTransactionId) AS AUDJ
            DELETE 
                AUD
            FROM
                TVF_AllUserData_ListDelItem(@SiteId, @ListId, @EffectiveDeleteTransactionId, @ListItemId) AS AUD
        END
    END
    DELETE 
        ER
    FROM
        @DocsDeleted DD
    CROSS APPLY
        TVF_EventReceivers_SiteWebHost(@SiteId, @WebId, DD.DocId) AS ER
    OPTION (FORCE ORDER, MAXDOP 1)
    IF @ItemType = 4 OR
        @ItemType = 6 OR
        @ItemType = 1 OR
        @ItemType = 5 OR
        @ItemType = 3
    BEGIN
        INSERT INTO @TransactionsDeleted
            (DeleteTransactionId, BinId, Size)
        SELECT
            RB.DeleteTransactionId, RB.BinId, RB.Size
        FROM
            @DocsDeleted AS DD
        CROSS APPLY
            TVF_AllDocVersions_SiteDocId(@SiteId, DD.DocId) AS ADV
        CROSS APPLY
            TVF_RecycleBin_EffDelId(ADV.SiteId, ADV.DeleteTransactionId) AS RB
        WHERE
            ADV.DeleteTransactionId <> 0x AND
            ADV.DeleteTransactionId <> @EffectiveDeleteTransactionId
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE
            ADV
        FROM
            @DocsDeleted AS DD
        CROSS APPLY
            TVF_AllDocVersions_SiteDocId(@SiteId, DD.DocId) AS ADV
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            AWP
        FROM
            @DocsDeleted DD
        CROSS APPLY
            TVF_AllWebParts_SitePageId(
                @SiteId,                
                DD.DocId) AS AWP
        OPTION (FORCE ORDER, MAXDOP 1)
    END
    IF (EXISTS(SELECT TOP 1 1 FROM @TransactionsDeleted))
    BEGIN
        SELECT
            @FreedSpace = @FreedSpace + ISNULL(SUM(
                CASE
                WHEN BinId <> 2 THEN Size 
                ELSE 0
                END),0),
            @FreedRecycleBinSpace = @FreedRecycleBinSpace + ISNULL(SUM(
                CASE
                WHEN BinId = 2 THEN Size 
                ELSE 0
                END),0)
        FROM
            @TransactionsDeleted TD
        DELETE 
            R
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_RecycleBin_EffDelId(@SiteId, TD.DeleteTransactionId) AS R
        WHERE
            R.WebId = @WebId
        OPTION (FORCE ORDER, MAXDOP 1)
        INSERT INTO SiteQuota
            (SiteId, SessionId, SMOpCode, DocId, DiskUsed, UpdateTimeStamp)
        SELECT
            @SiteId,
            @SessionID,
            2,
            AD.Id,
            0,
            0
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_AllDocs_SiteDelTransId(@SiteId, TD.DeleteTransactionId) AS AD
        DELETE 
            AD
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_AllDocs_SiteDelTransId(@SiteId, TD.DeleteTransactionId) AS AD
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            ALK
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_AllLinks_SiteDelTransId(@SiteId, TD.DeleteTransactionId) AS ALK
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            DP
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_Deps_SiteDelId(@SiteId, TD.DeleteTransactionId) AS DP
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE 
            P
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_Perms_SiteDelTransId(@SiteId, TD.DeleteTransactionId) AS P
        OPTION (FORCE ORDER, MAXDOP 1)
    END
    ELSE
    BEGIN
        INSERT INTO SiteQuota
            (SiteId, SessionId, SMOpCode, DocId, DiskUsed, UpdateTimeStamp)
        SELECT
            @SiteId,
            @SessionID,
            2,
            AD.Id,
            0,
            0
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        DELETE 
            AD
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS AD
        DELETE 
            ALK
        FROM
            TVF_AllLinks_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS ALK
        DELETE 
            DP
        FROM
            TVF_Deps_SiteDelId(@SiteId, @EffectiveDeleteTransactionId) AS DP
        DELETE 
            P
        FROM
            TVF_Perms_SiteDelTransId(@SiteId, @EffectiveDeleteTransactionId) AS P
    END
    SET @Ret = 0
cleanup:
    RETURN @Ret

go

