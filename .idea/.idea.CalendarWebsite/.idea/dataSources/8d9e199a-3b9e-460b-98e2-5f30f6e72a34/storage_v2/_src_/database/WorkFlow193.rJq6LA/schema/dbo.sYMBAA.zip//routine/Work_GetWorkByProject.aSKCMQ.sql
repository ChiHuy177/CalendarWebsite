-- Work_GetWorkByProject 'CO3.Workflow' 
   CREATE   PROC [dbo].[Work_GetWorkByProject] @projectName AS NVARCHAR(500)
   AS
   SELECT a.projectName
   ,Tab.Id
   ,a.tieude AS title
   ,ISNULL(a.noidung, '') AS description
   ,a.TrangThai AS STATUS
   INTO #a
   FROM [Dynamic].[Workflow_WORK] AS Tab
   CROSS APPLY OPENJSON(Tab.data, N'$') WITH (
   projectName NVARCHAR(500) N'$.Duan'
   ,tieude NVARCHAR(500) N'$.tieude'
   ,noidung NVARCHAR(500) N'$.Noidung'
   ,TrangThai NVARCHAR(500) N'$.TrangThai'
   ) AS a
   -- inner join UserWorkflow c on Tab.UserWorkflowId =c.Id 
   -- where c.UserWorkflowStatus<> 3 
   SELECT *
   FROM #a a
   WHERE a.projectName = @projectName
   DROP TABLE #a
go

