-- [Work_CheckUserInProject] 210281,'P:287' 
   CREATE   PROC [dbo].[Work_CheckUserInProject] 
   @projectId AS NVARCHAR(50) 
   ,@UserId as nvarchar(50)='' 
   AS 
   ;  
   declare @tb table (Id nvarchar(50) , AccountId nvarchar(50), AccountName nvarchar(150), Name nvarchar(250), FullName nvarchar(250), Email nvarchar(150) )  
   select * into #a from (  
   SELECT 
   b.value AS userId 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b  
   WHERE a.UserWorkflowId = @projectId  
   union 
   SELECT 
   b.value AS userId 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b  
   WHERE a.UserWorkflowId = @projectId 
   union 
   SELECT 
   'P:'+trim(str(c.Id)) AS userId 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   inner join DYNAMIC.Workflow_RESOURCEDA b on a.UserWorkflowId=b.UserWorkflowId 
   inner join PersonalProfile c on b.CreatedBy=c.Email 
   WHERE a.UserWorkflowId = @projectId 
   union 
   select 
   @UserId AS userId 
   from Dynamic.Data_RuleViewProject a 
   cross apply Split(a.Department,';' ) b 
   inner join Dynamic.Data_RESOURCEDA c on c.Department=b.Item 
   where a.[User]=@UserId and c.UserWorkflowId=@projectId 
   ) a 
   ; 
   insert into @tb 
   select * from ( 
   SELECT 'P:'+ trim(str(c.Id)) AS Id 
   ,[AccountId] 
   ,[AccountName] 
   ,[Name] 
   ,[FullName] 
   ,[Email]  
   FROM #a a 
   INNER JOIN PersonalProfile c ON REPLACE(a.userId,'P:','') =trim(str(c.Id)) 
   where left(trim(a.userId),1)='P' 
   union 
   SELECT 'P:'+trim(str(b.Id)) AS Id 
   ,[AccountId] 
   ,[AccountName] 
   ,[Name] 
   ,[FullName] 
   ,[Email]  
   FROM #a a  
   inner join GroupPersonalProfile c on REPLACE(a.userId,'G:','')=c.GroupsId 
   INNER JOIN PersonalProfile b ON b.Id =c.PersonalProfilesId 
   where left(trim(a.userId),1)='G') a 
   select COUNT(*) as dem from @tb where Id=@UserId 
go

