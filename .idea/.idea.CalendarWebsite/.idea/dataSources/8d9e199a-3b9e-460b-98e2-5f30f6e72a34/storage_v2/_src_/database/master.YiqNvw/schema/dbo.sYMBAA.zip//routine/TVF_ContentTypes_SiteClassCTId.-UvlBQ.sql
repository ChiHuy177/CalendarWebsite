CREATE FUNCTION [dbo].[TVF_ContentTypes_SiteClassCTId]
(
    @SiteId uniqueidentifier,
    @Class tinyint,
    @ContentTypeId tContentTypeId
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[ContentTypes] WITH (INDEX=ContentTypes_SiteClassCTId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Class = @Class AND
        ContentTypeId = @ContentTypeId

go

