-- store PROCedure truyền vào id trạng thái lấy ra trạng thái kế tiếp        
   -- Work_GetNextStatus 342570,333572,0       
   CREATE   PROC [dbo].[Work_GetNextStatus]        
   @statusId as bigint        
   ,@projectId as bigint       
   ,@useForChild as bit      
   as    
   if(@statusId>0)        
   begin        
   select       
   b.Id       
   , b.Ten as Name        
   , b.Duan as ProjectId        
   , b.TrangThaiCongViec        
   ,isnull(b.NguoiChinhSua,'') as [user]        
   ,b.UserWorkflowId       
   ,c.Step        
   --,c.WorkflowId        
   ,c.NextStep        
   ,ISNULL(a.QuanLy,'') as Manager       
   , b.QuyenXacNhanHoanThanhCV       
   ,b.IsSetting
   ,b.ColumnFormExtendId
   ,b.FormExtendId
   into #a        
   from [Dynamic].Data_RESOURCEDA a       
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan        
   inner join Dynamic.Data_LSQTCV c on a.UserWorkflowId = c.ProjectId and b.nodeid=c.Nodeid and c.Title<>''        
   where b.UserWorkflowId=@statusId        
   order by c.Step    
   ;        
   with tab as        
   (        
   select b.Id       
   , b.Name        
   , b.ProjectId        
   , b.TrangThaiCongViec        
   ,b.[user]        
   ,b.UserWorkflowId        
   ,b.Step        
   ,b.Manager       
   ,QuyenXacNhanHoanThanhCV       
   ,b.IsSetting     
   ,b.ColumnFormExtendId
   ,b.FormExtendId
   from #a b where UserWorkflowId=@statusId        
   union        
   select b.Id       
   , b.Ten as Name        
   , b.Duan as ProjectId        
   , b.TrangThaiCongViec        
   ,isnull(b.NguoiChinhSua,'') as [user]       
   ,b.UserWorkflowId        
   ,c.Step        
   ,ISNULL(a.QuanLy,'') as Manager       
   , b.QuyenXacNhanHoanThanhCV       
   ,b.IsSetting     
   ,b.ColumnFormExtendId
   ,b.FormExtendId
   from [Dynamic].Data_RESOURCETTFC b        
   inner join       
   (        
   select Title,a.ProjectId,a.Step,a.Nodeid from Dynamic.Data_LSQTCV a       
   inner join #a b on a.Step in (select * from string_split(b.NextStep,',')) and a.ProjectId=b.ProjectId        
   ) c on b.nodeid=c.Nodeid and b.Duan=c.ProjectId        
   inner join [Dynamic].Data_RESOURCEDA a on a.UserWorkflowId=b.Duan       
   )       
   select * from tab order by Step        
   drop table #a        
   end        
   else       
   begin        
   declare @nextStep as nvarchar(250)       
   set @nextStep= (       
   select NextStep from Dynamic.Data_LSQTCV where ProjectId=@projectId and Step =0       
   )       
   select       
   b.Id       
   , b.Ten as Name        
   , b.Duan as ProjectId        
   , b.TrangThaiCongViec       
   ,isnull(b.NguoiChinhSua,'') as [user]       
   ,b.UserWorkflowId       
   ,c.Step        
   --,c.WorkflowId        
   ,c.NextStep        
   ,ISNULL(a.QuanLy,'') as Manager       
   , b.QuyenXacNhanHoanThanhCV       
   ,ISNULL(b.UseForChild,'0') as UseForChild     
   ,b.IsSetting  
   ,b.ColumnFormExtendId
   ,b.FormExtendId
   into #cv      
   from [Dynamic].Data_RESOURCEDA a       
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan        
   inner join Dynamic.Data_LSQTCV c on a.UserWorkflowId = c.ProjectId and b.nodeid=c.Nodeid        
   where b.Duan=@projectId and c.Step in (select * from string_split(@nextStep,','))       
   -- nếu lấy trạng thái chỉ cho cv con kiểm tra có thì lấy không thì lấy mặc định      
   --if(@useForChild=1)    
   --begin       
   if(select COUNT(*) from #cv where UseForChild=@useForChild)>0      
   begin       
   select * from #cv where UseForChild=@useForChild      
   end       
   else       
   begin       
   select * from #cv      
   end      
   drop table #cv     
   end       
   --else      
   --begin       
   -- select * from #cv     
   --end      
   -- select * from Dynamic.Data_LSQTCV 
go

