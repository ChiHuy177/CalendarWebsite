CREATE PROCEDURE [dbo].[proc_DeleteEvalSiteRequest]
(
    @SiteId uniqueidentifier
)
AS
    SET NOCOUNT ON
    DELETE PS 
    FROM TVF_PreviewSiteRequests_SiteId(@SiteId) AS PS

go

