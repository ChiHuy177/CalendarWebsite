CREATE FUNCTION [dbo].[TVF_SolutionFiles_UniqueFile]
(
    @SiteId uniqueidentifier,
    @SolutionWebId uniqueidentifier,
    @SolutionId uniqueidentifier,
    @SolutionLevel int,
    @SolutionFilePath nvarchar(255)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SolutionFiles] WITH (INDEX=SolutionFiles_BySolutionAndFilePath, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@SolutionWebId IS NULL AND SolutionWebId IS NULL) OR @SolutionWebId=SolutionWebId) AND
        SolutionId = @SolutionId AND
        SolutionLevel = @SolutionLevel AND
        SolutionFilePath = @SolutionFilePath

go

