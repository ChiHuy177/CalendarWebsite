CREATE PROC [dbo].[proc_UpdateSolution](
    @SiteId uniqueidentifier,
	@WebId uniqueidentifier,
    @SolutionId uniqueidentifier,
    @SolutionLevel int,
    @Hash nvarchar(50),
    @ValidatorsHash char(64),
    @ValidationErrorUrl     nvarchar(1024),
    @ValidationErrorMessage nvarchar(1024))
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    UPDATE
        Solutions
    SET
        ValidatorsHash = @ValidatorsHash,
        ValidationErrorUrl = @ValidationErrorUrl,
        ValidationErrorMessage = @ValidationErrorMessage
    FROM
        TVF_Solutions_UniqueSolution(@SiteId, @WebId, @SolutionId, @SolutionLevel) AS Solutions
    WHERE
        Hash = @Hash
    IF @@ROWCOUNT = 1
    BEGIN
        SET @Ret = 0
    END
    ELSE
    BEGIN
        SET @Ret = 1
    END
    RETURN @Ret

go

