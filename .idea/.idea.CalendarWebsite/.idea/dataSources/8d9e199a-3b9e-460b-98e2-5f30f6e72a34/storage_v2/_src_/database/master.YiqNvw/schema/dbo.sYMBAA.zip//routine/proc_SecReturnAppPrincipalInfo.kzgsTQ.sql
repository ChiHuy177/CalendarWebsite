CREATE PROCEDURE [dbo].[proc_SecReturnAppPrincipalInfo](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @AppPrincipalName nvarchar(256),
    @ReturnAppPrincipalInfo bit)
AS
    SET NOCOUNT ON
    IF @AppPrincipalName IS NULL
    BEGIN
        RETURN 0
    END
    DECLARE @WebTemplateId int
    DECLARE @WebTemplateConfigurationId int
    SELECT
        @WebTemplateId = W.WebTemplate,
        @WebTemplateConfigurationId = W.ProvisionConfig
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
    SELECT @AppPrincipalName, @ReturnAppPrincipalInfo, @WebTemplateId, @WebTemplateConfigurationId
    IF @AppPrincipalName IS NOT NULL AND @ReturnAppPrincipalInfo = 1
    BEGIN
        EXEC proc_SecGetAppPrincipalAndPerms @SiteId, @AppPrincipalName, @WebId
    END
    RETURN 0

go

