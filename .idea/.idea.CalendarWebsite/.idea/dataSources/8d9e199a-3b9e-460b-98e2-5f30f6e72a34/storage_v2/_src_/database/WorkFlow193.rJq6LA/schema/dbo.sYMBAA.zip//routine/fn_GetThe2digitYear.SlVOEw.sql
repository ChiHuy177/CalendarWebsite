-- =============================================
-- Author:		DuyDam
-- Create date: 29/09/2021
-- Description:	Get two last digit in current year
-- =============================================
CREATE FUNCTION [dbo].[fn_GetThe2digitYear]
(
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @Result NVARCHAR(MAX);
	SET @Result = RIGHT(CONVERT(VARCHAR(8), GETDATE(), 1),2);
	RETURN @Result
END
go

