CREATE Procedure [dbo].[proc_App_PullTask] (
    @HostName nvarchar(255)
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
DECLARE @iRet int
SET @iRet = 0
--todo: we can make this partitioned if it becomes a bottleneck
--It seems pretty hard to get away from "serializing" this, since it's essentially crossing things off a list in order
--So the "pop a task" portion is treated as a critical section
DECLARE @LockReturnValue int
EXEC @LockReturnValue = sp_getapplock 'Tasks', 'Exclusive', 'Transaction'; IF (@LockReturnValue < 0) BEGIN; SET @iRet = 11; GOTO cleanup; END; 
EXEC @iRet = sub_CleanupLostTasks
if(@iRet <> 0) GOTO cleanup
--don't need to check for max retries, we already do that
--every time that we increment retries (in finishTask)
DECLARE @task uniqueidentifier
DECLARE @siteId uniqueidentifier
EXEC sub_SelectTaskForPull @task OUTPUT, @siteId OUTPUT
--mark that we are going to take this one
EXEC sub_MarkTaskPulled @task, @siteId, @HostName
--end critical section
--this will get released anyways at the end of the transaction...
EXEC sp_releaseapplock 'Tasks' 
SELECT Task.JobId, Task.TaskId, Task.TaskType, Task.PulledTime, Task.FinishedTime, Task.Retries, Task.TaskCloneId, Task.EstimatedDurationMinutes, Task.RegisteredTime, Task.TimeoutTime, Task.IsRollback, Task.TaskOperation, Task.CancelledWhileInProgress, Task.LastPullerHostName, Task.IsolationKey, Task.SiteId, Installation.WebId, Installation.Id as InstallationId, Installation.SiteSubscriptionId, Job.JobCreatorId, Task.TaskData FROM TVF_AppTasks_TaskId(@siteId, @task) AS Task
    CROSS APPLY TVF_AppJobs_Id(@siteId, Task.JobId) as Job
    CROSS APPLY TVF_AppInstallations_Id(@siteId, Job.InstallationId) as Installation
cleanup:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    return @iRet

go

