CREATE PROCEDURE [dbo].[proc_GetListRoot](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ListRoot nvarchar(256) OUTPUT)
AS
    SET NOCOUNT ON
    SELECT TOP 1
        @ListRoot = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END
    FROM
        TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
    CROSS APPLY
        TVF_Docs_NoLock_Id_Level(L.tp_SiteId, L.tp_RootFolder, 1) AS D

go

