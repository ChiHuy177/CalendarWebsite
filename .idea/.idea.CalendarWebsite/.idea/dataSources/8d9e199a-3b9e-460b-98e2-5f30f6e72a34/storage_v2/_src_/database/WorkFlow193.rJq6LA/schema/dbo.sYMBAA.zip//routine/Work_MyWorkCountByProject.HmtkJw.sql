-- Work_MyWorkCountByProject 'P:287',N'Việc cần đánh giá'
   CREATE   PROC  Work_MyWorkCountByProject                          
   @userId as nvarchar(50)=''  
   ,@typeWork as nvarchar(100)=N'Xử lý'
   as                                                               
   declare @sql as nvarchar(max)=N'', @type as nvarchar(max)=N'', @in as nvarchar(50)=N' not in ', @where as nvarchar(max)=N'',@join as nvarchar(max)=''
   CREATE TABLE #duan (UserWorkflowId char(50) NOT NULL PRIMARY KEY, Ten nvarchar(500), Loai nvarchar(500), RemindReviewsWork char(10))                     
   if(@typeWork=N'Việc đã xử lý')
   begin 
   set @in=' in '
   end
   set @type=
   (
   case when @typeWork=N'Xử lý' then ' STRING_SPLIT(ISNULL(a.Nguoixuly,''''), '';'') '
   when @typeWork=N'Theo dõi' then  ' STRING_SPLIT(ISNULL(a.Nguoitheodoi,''''), '';'') '
   when @typeWork=N'Việc giao' then ' STRING_SPLIT(ISNULL(a.Nguoigiao,''''), '';'') '
   when @typeWork=N'Phối hợp' then ' STRING_SPLIT(ISNULL(a.Nguoiphoihop,''''), '';'') '
   when @typeWork=N'Việc đã xử lý' then ' STRING_SPLIT(ISNULL(a.NguoiXuLyDauTien,'''')    
   +'';''+ISNULL(a.Nguoiphoihop,'''')+'';''+ISNULL(a.Nguoigiao,'''')+'';''+ISNULL(a.Nguoitheodoi,''''), '';'')     '
   when @typeWork=N'Việc cần đánh giá' then ' STRING_SPLIT(ISNULL(a.Nguoigiao,''''), '';'') '			
   else '' end
   )
   if(@typeWork=N'Việc cần đánh giá')
   begin 
   set @join ='  left join Dynamic.Data_ReviewsWork e on e.WorkId=a.UserWorkflowId     '
   set @where= ' isnull(d.TrangThaiCongViec,'''') =N'''+N'Hoàn thành'+''' and b.RemindReviewsWork=''1'' and e.WorkId is null '
   end 
   else
   begin 
   set @where= ' isnull(d.TrangThaiCongViec,'''') '+@in+' ( N'''+N'Hoàn thành'+''',N'''+N'Hủy'+''')  '
   end
   insert into #duan select UserWorkflowId,Ten,Loai,RemindReviewsWork   
   from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False'   
   and TrangThai <>N'Hủy'                                         
   insert into #duan select '','','',''
   set @sql=N'
   SELECT   
   b.UserWorkflowId as Value  
   ,b.Ten as Name  
   ,COUNT(a.UserWorkflowId) as Qty  
   from  [Dynamic].Data_WORK a               
   inner join  DYNAMIC.Data_RESOURCETTFC d  on a.TrangThaiCongViec=d.UserWorkflowId and a.Duan=d.Duan           
   inner join  #duan b on  isnull(a.Duan, '''') = b.UserWorkflowId   
   '+ @join +'
   WHERE ISNULL(a.WorkRepeat,''False'')=''False''          
   and '''+@userId+''' =   
   (  
   select top 1 value                    
   from '+@type+'      
   where value='''+@userId+'''
   group by value   
   )      
   and ISNULL(a.IsActive,''True'')=''True''     
   and  '+@where+'
   group by b.UserWorkflowId,b.Ten  
   order by b.UserWorkflowId
   '
   exec(@sql)
   print(@sql)
   drop table #duan
go

