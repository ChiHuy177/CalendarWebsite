CREATE PROCEDURE [dbo].[proc_DeleteSiteCoreAsync](
    @SiteId uniqueidentifier,
    @DeletionId bigint)
AS
    SET NOCOUNT ON
    UPDATE
        SD
    SET
        SD.InDeletion = 1
    FROM
        TVF_SiteDeletion_SiteId(@SiteId) AS SD
    WHERE
        (SD.LockTime IS NULL OR DATEADD(hour, 24, SD.LockTime) < GETUTCDATE())
    IF (@@ROWCOUNT = 0)
    BEGIN
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                SiteDeletion
            WHERE
                SiteId = @SiteId AND
                (LockTime IS NOT NULL AND DATEADD(hour, 24, LockTime) >= GETUTCDATE()))
        BEGIN
            RETURN 212
        END
        RETURN 2
    END
    DECLARE @ReturnStatus int = 0
    DECLARE @rc int
    DECLARE @DeleteIsForMigration bit
    SELECT TOP 1 @DeleteIsForMigration = DeleteIsForMigration
    FROM
        TVF_SiteDeletion_SiteId(@SiteId)
    EXEC @ReturnStatus = proc_DeleteContentPartition @SiteId, @DeleteIsForMigration
    SET @rc = 1
    WHILE (@rc <> 0)
    BEGIN
        DELETE
            PreviewRequests 
        FROM 
            (SELECT TOP (1000) * FROM TVF_PreviewSiteRequests_SiteId(@SiteId)) AS PreviewRequests
        WHERE 
            PreviewRequests.Status <> 1
        SET @rc = @@rowcount
    END
    DECLARE @RbsCollectionId int
    SELECT
        @RbsCollectionId = S.RbsCollectionId
    FROM
        TVF_AllSites_XLock_Id(@SiteId) AS S
    IF @RbsCollectionId <> 0
    BEGIN
        EXEC proc_RbsDeleteCollection @RbsCollectionId
    END
    DELETE FROM
        TVF_SiteQuota_Site(@SiteId)
    DELETE FROM
        TVF_AllSites_Id(@SiteId)
    DELETE FROM
        TVF_SiteDeletion_SiteId(@SiteId)
    RETURN 0

go

