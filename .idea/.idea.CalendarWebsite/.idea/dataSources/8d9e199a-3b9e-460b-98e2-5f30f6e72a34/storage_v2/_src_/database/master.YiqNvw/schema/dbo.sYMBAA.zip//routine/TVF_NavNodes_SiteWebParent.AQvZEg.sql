CREATE FUNCTION [dbo].[TVF_NavNodes_SiteWebParent]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @EidParent int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NavNodes] WITH (INDEX=NavNodes_AltPK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId AND
        EidParent = @EidParent

go

