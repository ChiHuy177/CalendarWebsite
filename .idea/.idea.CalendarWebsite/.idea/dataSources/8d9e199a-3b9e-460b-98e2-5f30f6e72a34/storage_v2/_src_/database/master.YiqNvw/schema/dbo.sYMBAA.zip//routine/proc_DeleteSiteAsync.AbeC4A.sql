CREATE PROCEDURE [dbo].[proc_DeleteSiteAsync](
    @SiteId uniqueidentifier,
    @Restorable bit,
    @DeleteIsForMigration bit,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @BitFlags int
    SELECT TOP 1
        @BitFlags = BitFlags 
    FROM
        TVF_Sites_Id(@SiteId)
    SELECT @BitFlags
    SELECT 
        G.DLAlias 
    FROM
        TVF_Groups_Site(@SiteId) AS G
    WHERE
        G.DLAlias IS NOT NULL AND
        G.DLAlias != ''
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    UPDATE
        ALLS
    SET
        ALLS.Deleted = 1
    FROM
        TVF_AllSites_Id(@SiteId) AS ALLS
    INSERT INTO SiteDeletion( 
        SiteId,
        DeletionTime,
        Restorable,
        DeleteIsForMigration)
    VALUES( 
        @SiteId,
        CASE WHEN @Restorable = 1 THEN GETUTCDATE() ELSE 0 END,
        @Restorable,
        @DeleteIsForMigration)
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
        16384,  8, NULL, NULL, NULL, NULL, 
        NULL, NULL, @RequestGuid OUTPUT
cleanup:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @iRet

go

