-- =============================================
-- Author:		DuyDam
-- Create date: 04/10/2021
-- Description:	Insert data in to dynamic checklist
-- Changelog:   duydd 09/12/2024    insert with position column
-- =============================================
CREATE     PROCEDURE [dbo].[ChekListDynamic_Insert] @WorkflowId BIGINT
	,@UserWorkflowId BIGINT
	,@CheckListId BIGINT
	,@Name NVARCHAR(MAX)
	,@Note NVARCHAR(MAX)
	,@Path NVARCHAR(MAX)
	,@Type NVARCHAR(MAX)
	,@CreatedBy NVARCHAR(MAX)
	,@ModifiedBy NVARCHAR(MAX)
	,@CreatedTime DATETIME2
	,@LastModified DATETIME2 = NULL
	,@Position NVARCHAR(MAX) = 'bottomRight'
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	SET @Sql = 'INSERT INTO ' + @TableName + ' (
		CheckListId
		,UserWorkflowId
		,Name
		,Note
		,Path
		,Position
		,Type
		,CreatedBy
		,ModifiedBy
		,CreatedTime
		,IsDeleted
		,LastModified
		)
	VALUES (' + '''' + CAST(@CheckListId AS VARCHAR) + '''' + + ',' + '''' + CAST(@UserWorkflowId AS VARCHAR) + '''' + ',' + 'N''' + REPLACE(@Name, '''', '''''') + '''' + ',' + 'N''' + (
			CASE 
				WHEN @Note IS NULL
					THEN ''
				ELSE REPLACE(@Note, '''', '''''')
				END
			) + '''' + ',' + 'N''' + (
			CASE 
				WHEN @Path IS NULL
					THEN ''
				ELSE REPLACE(@Path, '''', '''''')
				END
			) + '''' + ',' + 'N''' + (
			CASE 
				WHEN @Position IS NULL
					THEN 'bottomRight'
				ELSE REPLACE(@Position, '''', '''''')
				END
			) + '''' + ',' + 'N''' + (
			CASE 
				WHEN @Type IS NULL
					THEN ''
				ELSE REPLACE(@Type, '''', '''''')
				END
			) + '''' + ',' + 'N''' + @CreatedBy + '''' + ',' + 'N''' + @ModifiedBy + '''' + ',' + '''' + CAST(@CreatedTime AS VARCHAR) + '''' + ', 0,' + (
			CASE 
				WHEN @LastModified IS NULL
					THEN 'NULL'
				ELSE ('''' + CAST(@LastModified AS VARCHAR) + '''')
				END
			) + ')';

	PRINT @Sql;

	EXEC sp_executesql @Sql;

	SET @Sql = 'SELECT top (1) * FROM ' + @TableName + ' Order by Id desc';

	EXEC sp_executesql @Sql;
END
go

