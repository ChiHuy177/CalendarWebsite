
-- =============================================
-- Author:		Duy Dam
-- Create date: 21/10/2021
-- Description:	Update Dynamic value from Draft UserWorkflow
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_Update] @WorkflowId BIGINT
	,@UserWorkflowId BIGINT
	,@Data_Json NVARCHAR(MAX)
	,@Email NVARCHAR(MAX) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@TableName AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX)
		,@LineBreak NCHAR(2) = NCHAR(13) + NCHAR(10);

	IF (
			EXISTS (
				SELECT *
				FROM [dbo].[UserWorkflow]
				WHERE Id = @UserWorkflowId
				)
			)
		--AND IsDraft = 1
	BEGIN
		SET @WorkflowCode = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @WorkflowId
				);
		SET @TableName = CONCAT (
				'Dynamic.Workflow_'
				,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
				);
		SET @Sql = 'BEGIN TRANSACTION' + @LineBreak + 'BEGIN TRY' + @LineBreak + 'UPDATE ' + @TableName + ' SET [Data] = ' + CONCAT (
				'N'
				,''''
				,REPLACE(@Data_Json, '''', '''''')
				,''''
				) + @LineBreak + ', LastModified = ' + CONCAT (
				''''
				,GETDATE()
				,''''
				) + @LineBreak + ', ModifiedBy = ' + + CONCAT (
				''''
				,@Email
				,''''
				) + @LineBreak + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';' + @LineBreak + 'COMMIT TRANSACTION' + @LineBreak + 'END TRY' + @LineBreak + 'BEGIN CATCH' + @LineBreak + 'IF @@TRANCOUNT > 0' + @LineBreak + '    ROLLBACK TRANSACTION' + @LineBreak + 'END CATCH' + @LineBreak;

		EXEC sp_ExecuteSql @SQL;
	END
END
go

