CREATE PROCEDURE [dbo].[proc_SaveFileFragmentById]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @DocVersion int,
    @UserId int,
    @Id bigint,
    @Partition tinyint,
    @Tag varbinary(40),
    @BlobData varbinary(max),
    @BlobSize int,
    @QuotaChange int OUTPUT,
    @NewId bigint OUTPUT
)
AS
    SET NOCOUNT ON
    DECLARE @quotaOrLockStatus int
    DECLARE @OldBlobSize int
    DECLARE @ERR int, @ROWC int
    SET @QuotaChange = 0
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    IF @Id IS NULL
    BEGIN
        INSERT INTO AllFileFragments 
            (SiteId, DocId, Partition, Tag, BlobData, BlobSize)
        VALUES 
            (@SiteId, @DocId, @Partition, @Tag, @BlobData, @BlobSize)
        SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
        IF @ROWC <> 1 OR @ERR <> 0        
        BEGIN
            SET @iRet = 4317
            GOTO cleanup
        END
        SET @NewId = SCOPE_IDENTITY()
        SET @QuotaChange = @BlobSize
    END
    ELSE
    BEGIN
        SELECT TOP 1
            @OldBlobSize = F.BlobSize
        FROM
            TVF_AllFileFragments_UpdLock_DocIdPartId(@SiteId, @DocId, @Partition, @Id) AS F
        IF @@ROWCOUNT <> 1
        BEGIN
    	    SET IDENTITY_INSERT AllFileFragments ON
	        INSERT INTO AllFileFragments 
	            (SiteId, DocId, Id, Partition, Tag, BlobData, BlobSize)
	        VALUES 
	            (@SiteId, @DocId, @Id, @Partition, @Tag, @BlobData, @BlobSize)
	        SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
	        SET @QuotaChange = @BlobSize
        END
        ELSE
        BEGIN
	        UPDATE 
	            F
	        SET
	            F.DocId = @DocId,
	            F.Partition = @Partition,
	            F.Tag = @Tag,
	            F.BlobData = @BlobData,
	            F.BlobSize = @BlobSize
	        FROM
	            TVF_AllFileFragments_DocIdPartId(@SiteId, @DocId, @Partition, @Id) AS F
	        SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
	        SET @QuotaChange = @BlobSize-@OldBlobSize
	    END
        IF @ROWC <> 1 OR @ERR <> 0
        BEGIN
            SET @iRet = 4317
            GOTO cleanup
        END
        SET @NewId = @Id
    END
cleanup:
     IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
     RETURN @iRet

go

