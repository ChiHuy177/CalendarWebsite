CREATE FUNCTION [dbo].[TVF_Docs_XLock_DirNameEqLike_Value]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @DirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        AllDocs WITH (XLOCK, INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName = @DirName
    UNION ALL
    SELECT
        *
    FROM
        AllDocs WITH (XLOCK, INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName LIKE @DirNameLike

go

