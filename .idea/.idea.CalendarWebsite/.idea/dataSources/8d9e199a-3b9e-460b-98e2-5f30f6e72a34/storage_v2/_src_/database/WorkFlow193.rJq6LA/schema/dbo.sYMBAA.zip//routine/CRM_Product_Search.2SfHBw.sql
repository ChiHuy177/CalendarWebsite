CREATE   PROC [dbo].[CRM_Product_Search]                          
  @search as nvarchar(150)          
          
  as                          
                    
  if(@search<>'')                  
  begin                   
                       
  SELECT a.[ID]                          
     ,a.ID as [key]     
     ,a.UserWorkflowId  
        ,0 as [SalesOrderID]                        
        ,0 as  [SalesOrderDetailID]                        
        ,0 as  [CarrierTrackingNumber]                        
        ,1 as [OrderQty]               
       ,1 as[ReceivedQty]              
    ,0 as [RejectedQty]              
        ,a.ID as [ProductID]                        
     ,a.Code as productCode                
     ,a.Name as productName                
        ,0 as [SpecialOfferID]                        
        ,ISNULL(d.Price,0) as [UnitPrice]                              
         ,ISNULL(d.Price,0) as LineTotal                    
        ,a.Code as ProductCode                        
        ,a.Name as ProductName                        
        ,ISNULL(c.Price,0) as StandardCost                      
     ,case when ISNULL(b.Discount,0)=0 then 0 else ROUND(isnull(a.ListPrice,0)/ Discount/CONVERT(float,100),2) end as UnitPriceDiscount                    
    FROM Dynamic.Data_CRMProduct a                    
    left join Dynamic.Data_CRMPromotionProductDetail b on a.ID=b.ProductId                    
    left join Dynamic.Data_CRMPurchasePrice c on a.ID=c.ProductID and ISNULL(c.Active,0)=1 and ISNULL(c.IsDelete,0) =0                  
    left join Dynamic.Data_CRMSalePrice d on a.ID=d.ProductID and ISNULL(d.Active,0)=1 and ISNULL(d.IsDelete,0)=0                  
                        
    where a.Code like N'%'+@search+'%' or a.Name like N'%'+@search+'%' or a.Description like N'%'+@search+'%'                    
            
    and ISNULL(a.IsDelete,0)=0          
    end                  
    else                  
    begin                  
            
    SELECT a.[ID]                          
     ,a.ID as [key]     
   ,a.UserWorkflowId  
        ,0 as [SalesOrderID]                        
        ,0 as  [SalesOrderDetailID]                        
        ,0 as  [CarrierTrackingNumber]                        
        ,1 as [OrderQty]                  
      ,1 as[ReceivedQty]              
    ,0 as [RejectedQty]              
        ,a.ID as [ProductID]                        
        ,a.Code as productCode                
     ,a.Name as productName                
        ,0 as [SpecialOfferID]                        
        ,ISNULL(d.Price,0) as [UnitPrice]                              
         ,ISNULL(d.Price,0) as LineTotal                      
        ,a.Code as ProductCode                        
        ,a.Name as ProductName                        
        ,ISNULL(c.Price,0) as StandardCost                      
     ,case when ISNULL(b.Discount,0)=0 then 0 else ROUND(isnull(a.ListPrice,0)/ Discount/CONVERT(float,100),2) end as UnitPriceDiscount                    
    FROM Dynamic.Data_CRMProduct a                    
    left join Dynamic.Data_CRMPromotionProductDetail b on a.ID=b.ProductId                    
    left join Dynamic.Data_CRMPurchasePrice  c on a.ID=c.ProductID and ISNULL(c.Active,0)=1 and ISNULL(c.IsDelete,0) =0                  
    left join Dynamic.Data_CRMSalePrice d on a.ID=d.ProductID and ISNULL(d.Active,0)=1 and ISNULL(d.IsDelete,0)=0                  
    where  ISNULL(a.IsDelete,0)=0          
    end
go

