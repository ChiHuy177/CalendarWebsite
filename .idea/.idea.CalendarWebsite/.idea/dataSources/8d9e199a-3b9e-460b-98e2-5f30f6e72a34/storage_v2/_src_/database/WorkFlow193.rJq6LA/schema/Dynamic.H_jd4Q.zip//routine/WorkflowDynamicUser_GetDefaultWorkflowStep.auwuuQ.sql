
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_GetDefaultWorkflowStep] @WorkflowId BIGINT
	,@UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@TableName AS NVARCHAR(MAX)
		,@Sql NVARCHAR(MAX)
		,@LineBreak NCHAR(2) = NCHAR(13) + NCHAR(10);

	IF (
			EXISTS (
				SELECT *
				FROM [dbo].[UserWorkflow]
				WHERE Id = @UserWorkflowId
				)
			)
	BEGIN
		SET @WorkflowCode = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @WorkflowId
				);
		SET @TableName = CONCAT (
				'Dynamic.Workflow_'
				,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
				);
		SET @Sql = 'SELECT ISNULL(DefaultWorkflowStep, ' + '''' + '''' + ') FROM ' + @TableName + @LineBreak + 'WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + @LineBreak;

		EXEC sp_ExecuteSql @SQL;
	END
END
go

