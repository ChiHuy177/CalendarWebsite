-- Update trigger for events
CREATE TRIGGER trg_events_update
    ON events
    AFTER UPDATE
    AS
BEGIN
    UPDATE events
    SET updated_at = GETDATE()
    FROM events e
             INNER JOIN inserted i ON e.event_id = i.event_id;
END;
go

