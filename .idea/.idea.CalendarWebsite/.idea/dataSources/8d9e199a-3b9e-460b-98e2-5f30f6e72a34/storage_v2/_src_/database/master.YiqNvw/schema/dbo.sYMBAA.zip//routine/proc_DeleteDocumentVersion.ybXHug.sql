CREATE PROCEDURE [dbo].[proc_DeleteDocumentVersion](
    @DocSiteId uniqueidentifier,
    @DocDirName nvarchar(256),
    @DocLeafName nvarchar(128),
    @DocVersion int,
    @UserId int,
    @AppPrincipalId int,
    @DeleteOp int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @ProgId nvarchar(255)
    SET @ProgId = NULL
    DECLARE @ReturnStatus int SET @ReturnStatus = 0 BEGIN TRAN
    DECLARE @WebId uniqueidentifier
    DECLARE @ListId uniqueidentifier
    DECLARE @ItemId int
    DECLARE @DocId uniqueidentifier
    DECLARE @AuditEventData nvarchar(4000)
    SET @AuditEventData = STUFF(STUFF('</>', 3, 0, 'Version'), 1, 0, STUFF(STUFF(STUFF('</>', 3, 0, 'Major'), 1, 0, STUFF(@DocVersion/512, 1, 0, STUFF('<>', 2, 0, 'Major'))) + STUFF(STUFF('</>', 3, 0, 'Minor'), 1, 0, STUFF(@DocVersion%512, 1, 0, STUFF('<>', 2, 0, 'Minor'))), 1, 0, STUFF('<>', 2, 0, 'Version')))
    IF (@DeleteOp = 3) SET @AuditEventData = @AuditEventData + STUFF(STUFF('</>', 3, 0, 'Recycle'), 1, 0, STUFF('0', 1, 0, STUFF('<>', 2, 0, 'Recycle')))
    ELSE IF (@DeleteOp = 4) SET @AuditEventData = @AuditEventData + STUFF(STUFF('</>', 3, 0, 'Recycle'), 1, 0, STUFF('1', 1, 0, STUFF('<>', 2, 0, 'Recycle')))
    EXEC @ReturnStatus = proc_AddAuditEntryFromSql
            @DocSiteId,
            @DocDirName,
            @DocLeafName,
            1,
            @UserId,        
            @AppPrincipalId,
            4,
            @AuditEventData,
            0x00000008
    IF @ReturnStatus <> 0 GOTO cleanup
    SELECT TOP 1
        @WebId = WebId,
        @ListId = ListId,
        @ItemId = DoclibRowId,
        @DocId = Id,
        @ProgId = ProgId
    FROM
        TVF_Docs_Url(@DocSiteId, @DocDirName, @DocLeafName) AS Docs
    IF EXISTS (
        SELECT TOP 1
            1
        FROM
            TVF_Docs_Url(@DocSiteId, @DocDirName, @DocLeafName) AS Docs 
        WHERE
            Docs.UIVersion = @DocVersion)
    BEGIN
        SET @ReturnStatus = 186
        GOTO cleanup
    END
    IF (@DeleteOp = 3)
    BEGIN
        DECLARE @docsToDelete tvpStreamMetadata2
        INSERT INTO @docsToDelete (
            DocId, HistVersion, Level)
        SELECT
            DV.Id, DV.UIVersion, DV.Level
        FROM
            TVF_DocVersions_SiteDocIdUIVersion(
                @DocSiteId,
                @DocId,
                @DocVersion) AS DV
        EXEC proc_DeleteStreams @DocSiteId, @docsToDelete
        DELETE
            DV
        FROM
            TVF_DocVersions_SiteDocIdUIVersion(@DocSiteId, @DocId, @DocVersion) AS DV
        IF @@ROWCOUNT = 0
        BEGIN        
            SET @ReturnStatus = 2
            GOTO cleanup
        END
        IF @ListId IS NOT NULL AND @ItemId IS NOT NULL
        BEGIN
            DELETE
                AUD
            FROM
                TVF_AllUserData_ListDelVerItemCal(
                    @DocSiteId, 
                    @ListId, 
                    0x, 
                    CONVERT(bit, 0), 
                    @ItemId, 
                    @DocVersion) AS AUD
        END
        DELETE 
            AWP
        FROM
            TVF_AllWebParts_SiteIsCurPageIdPageVer(
                @DocSiteId,
                CONVERT(bit, 0),
                @DocId,
                @DocVersion) AS AWP
        EXEC proc_UpdateDiskUsed @DocSiteId
        SET @ReturnStatus = 0
    END
    ELSE IF (@DeleteOp = 4)
    BEGIN
        DECLARE @DeleteTransactionId varbinary(16)
        SET @DeleteTransactionId = NEWID()
        DECLARE @ListDirName nvarchar(256)
        SELECT TOP 1
            @ListDirName = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END
        FROM 
            TVF_Lists_CI(@DocSiteId, @WebId, @ListId) AS L
        CROSS APPLY
            TVF_Docs_Id(L.tp_SiteId, L.tp_RootFolder) AS D
        DECLARE @AuthorId int
        DECLARE @Size bigint
        SET @Size = (
            SELECT
                (ISNULL((SUM(CAST((ISNULL(Size, 0) + ISNULL(MetaInfoSize, 0)) AS BIGINT))),0))
            FROM
                TVF_DocVersions_SiteDocIdUIVersion(@DocSiteId, @DocId, @DocVersion) AS DV)
        IF @ListId IS NOT NULL AND @ItemId IS NOT NULL
        BEGIN
            SELECT TOP 1
                @Size = @Size + ISNULL(UD.tp_Size, 0),
                @AuthorId = UD.tp_Editor
            FROM
                TVF_UserDataVersioned_ListItemCal(@DocSiteId, @ListId, @ItemId, @DocVersion) AS UD
            ORDER BY
                UD.tp_Level DESC 
        END
        INSERT INTO RecycleBin (
            SiteId,
            WebId,
            BinId,
            DeleteUserId,
            DeleteTransactionId,
            ChildDeleteTransactionId, 
            DeleteDate,
            ItemType,
            ListId,
            DocId,
            DocVersionId,
            ListItemId,
            Title,
            DirName,
            LeafName,
            AuthorId,
            Size,
            ListDirName,
            ScopeId,
            ProgId,
            EffectiveDeleteTransactionId)
        VALUES (
            @DocSiteId,
            @WebId,
            1,
            @UserId,
            @DeleteTransactionId,
            0x,
            dbo.fn_RoundDateToNearestSecond(GETUTCDATE()),
            2,
            @ListId,
            @DocId,
            @DocVersion,
            @ItemId,
            @DocLeafName + ' (' + CAST(@DocVersion/512 AS nvarchar(10)) + 
                '.' + CAST(@DocVersion%512 AS nvarchar(10)) + ')',
            @DocDirName,
            @DocLeafName,
            @AuthorId,
            @Size,
            @ListDirName,
            NULL,
            @ProgId,
            CASE WHEN 0x = 0x THEN @DeleteTransactionId ELSE 0x END)
        UPDATE
            DV
        SET
            DeleteTransactionId = @DeleteTransactionId
        FROM
            TVF_DocVersions_SiteDocIdUIVersion(@DocSiteId, @DocId, @DocVersion) AS DV
        IF @@ROWCOUNT = 0
        BEGIN
            SET @ReturnStatus = 2
            GOTO cleanup
        END    
        IF @ListId IS NOT NULL AND @ItemId IS NOT NULL
        BEGIN
            UPDATE
                UD
            SET
                tp_DeleteTransactionId = @DeleteTransactionId
            FROM
                TVF_UserDataVersioned_ListItemCal(@DocSiteId, @ListId, @ItemId, @DocVersion) AS UD
        END
        UPDATE 
            AWP
        SET 
            AWP.tp_Deleted = 1
        FROM
            TVF_AllWebParts_SiteIsCurPageIdPageVer(
                @DocSiteId,
                CONVERT(bit, 0),
                @DocId,
                @DocVersion) AS AWP
        DECLARE @DeltaSize bigint
        SET @DeltaSize = -ISNULL(@Size, 0)
        EXEC proc_AddStorageMetricsChange @DocSiteId, @DocId, @DeltaSize, 1, 1
        SET @ReturnStatus = 0
    END
cleanup:
    IF (@ReturnStatus <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @ReturnStatus

go

