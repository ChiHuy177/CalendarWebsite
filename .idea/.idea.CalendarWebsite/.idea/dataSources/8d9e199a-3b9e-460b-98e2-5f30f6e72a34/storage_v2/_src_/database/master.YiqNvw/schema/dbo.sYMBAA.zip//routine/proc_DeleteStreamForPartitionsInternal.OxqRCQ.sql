CREATE PROCEDURE [dbo].[proc_DeleteStreamForPartitionsInternal] (
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @HistVersion int,
    @Level tinyint,
    @PartitionsToDelete nvarchar(max), 
    @QuotaChange bigint = NULL OUTPUT)
AS
    SET NOCOUNT ON
    DECLARE @err int, @rowc int
    SET @QuotaChange = 0
    DECLARE @bsnsToGC tvpBSNMetadata
    IF @PartitionsToDelete IS NULL
    BEGIN
        DELETE
            DTS
        OUTPUT
            DELETED.DocId, DELETED.Partition, DELETED.BSN
        INTO
            @bsnsToGC (DocId, Partition, BSN)
        FROM
            TVF_DocsToStreams_SiteDocHistVerLvl(@SiteId, @DocId, @HistVersion, @Level) AS DTS
        WHERE
            DTS.Partition <> 0
        OPTION (FORCE ORDER)
    END
    ELSE
    BEGIN
        DELETE
            DTS
        OUTPUT
            DELETED.DocId, DELETED.Partition, DELETED.BSN
        INTO
            @bsnsToGC (DocId, Partition, BSN)
        FROM
            dbo.fn_UnpackCsvString(@PartitionsToDelete) AS P
        CROSS APPLY
            TVF_DocsToStreams_SiteDocHistVerLvlPart(
                @SiteId, 
                @DocId, 
                @HistVersion, 
                @Level, 
                CAST(P.val as tinyint)) AS DTS
        OPTION (FORCE ORDER, LOOP JOIN)
    END
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    DECLARE @sizeForQuota TABLE (Size int)
    DELETE
        DS
    OUTPUT
        DELETED.Size 
    INTO 
        @sizeForQuota (Size)
    FROM
        @bsnsToGC bn
    CROSS APPLY
        TVF_DocStreams_CI(@SiteId, bn.DocId, bn.Partition, bn.BSN) AS DS
    OUTER APPLY
        TVF_DocsToStreams_SiteDocPartBSN(@SiteId, DS.DocId, DS.Partition, DS.BSN) AS DTS
    WHERE
        DTS.Partition IS NULL AND DTS.BSN IS NULL
    OPTION (FORCE ORDER, LOOP JOIN)
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    SELECT 
        @QuotaChange = @QuotaChange - SUM(CAST(Size AS bigint)) 
    FROM 
        @sizeForQuota
    RETURN 0

go

