CREATE FUNCTION [dbo].[TVF_Perms_XLock_ScopeUrlEqLike_Value]
(
    @SiteId uniqueidentifier,
    @ScopeUrl nvarchar(260),
    @ScopeUrlLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        Perms WITH (XLOCK, INDEX=Perms_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DelTransId = 0x AND
        ScopeUrl = @ScopeUrl
    UNION ALL
    SELECT
        *
    FROM
        Perms WITH (XLOCK, INDEX=Perms_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DelTransId = 0x AND
        ScopeUrl LIKE @ScopeUrlLike

go

