 CREATE   PROC [dbo].[Crm_GetCustomers]                                      
  @userName as nvarchar(50)=''                                      
  ,@Category as int=0                                  
  ,@SearchStr as nvarchar(150)=''                                
  ,@ID_StatusCustomer as bigint=0                         
  ,@type as char(1) ='1'                      
  ,@menuId as bigint  =1                 
  as                                      
                                        
  declare @sql as nvarchar(max), @where as nvarchar(500) =''                                      
                                        
  set @where=' where isnull(a.iSDelete,0)=0 and type= '+@type+' '                                
                                        
  if(@Category>0)                                      
  set @where= @where +' and b.ID = '+LTRIM(rtrim(STR( @Category)))+'';                                
                                    
  if(@SearchStr<>'')                                      
  set @where= @where +' and ( a.Code like N''%'+@SearchStr+'%'' or a.Name like N''%'+@SearchStr+'%'')'                                  
                                  
  if(@ID_StatusCustomer>0)                                
  set @where= @where +' and a.ID_StatusCustomer = '+LTRIM(rtrim(STR( @ID_StatusCustomer)))+'';                                
                                  
  set @where=@where + ' order by ID desc '                                      
                                        
  set @sql='                                      
  select               
  top 1000              
   a.[ID]                                      
   ,a.type                        
        ,a.[ID_Category]     as IDCustomerCategory                                 
     ,b.Name as CustomerCategoryName                                      
        ,a.[ID_Status]                                      
     ,c.Name as StatusName                                      
        ,a.[ID_Source]                                      
     ,d.Name as SourceName                                      
        ,a.[CountryRegionCode]                                      
     ,e.Name as CountryName                                      
        ,a.[UserWorkflowId]               
        ,a.[Code]                                      
        ,a.[Name]                                      
        ,a.[Address]                                      
        ,a.[Fax]                                      
        ,a.[Mobile]                                      
        ,a.[PhoneNumber]                                      
        ,a.[Email]                                      
        ,a.[TaxNumber]                                      
        ,a.[IdentityCard]                                      
        ,a.[Description]                                      
        ,a.[BirthDay]                                      
        ,a.[Website]                                      
        ,a.[BankAccount]                                      
        ,a.[BankName]                                      
        ,a.[AddressOffice]                                      
        ,a.[AddressDelivery]                                      
        ,a.[ProposalDueDate]                                      
        ,a.[Rating]                                      
        ,a.[Budget]                                      
        ,a.[BackgroundInfo]                                                                 
  from                                      
  Dynamic.Data_CRMCustormer a                            
                      
  left join Dynamic.Data_CRMCustomerCategory b  on a.ID_Category=b.ID                                      
  left join Dynamic.Data_CRMStatusCustomer c on a.ID_Status= c.UserWorkflowId                                      
  left join Dynamic.Data_CRMCustomerSource d on d.UserWorkflowId=a.ID_Source                             
  left join Dynamic.Data_CRMCountryRegion e on a.CountryRegionCode =e.Code                        
  --inner join                     
  --(select * from FnGetUserPermission('''+@userName+''','+STR(@menuId)+')) f on a.CreateBy=f.UserName                    
 '+@where+''                                      
                  
  print(@sql)                        exec(@sql)
 go

