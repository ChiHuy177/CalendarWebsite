-- =============================================
-- Author:		DuyDam
-- Create date: 22/06/2022
-- Description:	Get List Workflow
-- Changelog:	duydd - 23/04/2024 - add filters for workflowType 4 (application)
-- =============================================
CREATE     PROCEDURE [dbo].[GetWorkflow] @Title NVARCHAR(MAX) = NULL
	,@Status INT = NULL
	,@IsDetail BIT = NULL
	,@CategoryId BIGINT = NULL
	,@CreatePermission NVARCHAR(MAX) = NULL
	,@SeenPermission NVARCHAR(MAX) = NULL
	,@UserId BIGINT = NULL
	,@Page INT = NULL
	,@PageSize INT = NULL
	,@IsProcess BIT = NULL
	,@WorkflowType INT = NULL
	,@SortBy NVARCHAR(MAX) = NULL
	,@IsSortAscending BIT = NULL
	,@TotalItems BIGINT OUTPUT
	WITH RECOMPILE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Take INT = 0
		,@Skip INT = 0
		,@IsConfigureAdmin AS BIT = 0
		,@IsSuperAdmin AS BIT = 0;
	CREATE TABLE #TempGroup_New ([Code] [nvarchar](max) NULL);

	INSERT INTO #TempGroup_New (Code)
	SELECT CONCAT (
			'G:'
			,GroupsId
			)
	FROM [dbo].[GroupPersonalProfile]

	IF @PageSize IS NULL
		OR @PageSize <= 0
		SET @Take = 10
	ELSE
		SET @Take = @PageSize

	IF @Page IS NULL
		OR @Page <= 0
		SET @Skip = 0
	ELSE
		SET @Skip = (@Page - 1) * @Take

	IF @IsSortAscending IS NULL
		SET @IsSortAscending = 0;

	IF OBJECT_ID(N'tempdb..#TempUserWorkflow') IS NOT NULL
		DROP TABLE #TempUserWorkflow;

	UPDATE [dbo].[Workflow]
	SET [IsDetail] = 0
	WHERE [IsDetail] IS NULL;

	IF EXISTS (
			SELECT gp.*
			FROM GroupPersonalProfile gp
			INNER JOIN [dbo].[PersonalProfile] p
				ON p.Id = gp.PersonalProfilesId
			INNER JOIN [dbo].[Group] g
				ON g.Id = gp.GroupsId
			WHERE p.Id = @UserId
				AND (g.Title = 'Configure')
			)
	BEGIN
		SET @IsConfigureAdmin = CAST(1 AS BIT);
	END

	IF EXISTS (
			SELECT gp.*
			FROM GroupPersonalProfile gp
			INNER JOIN [dbo].[PersonalProfile] p
				ON p.Id = gp.PersonalProfilesId
			INNER JOIN [dbo].[Group] g
				ON g.Id = gp.GroupsId
			WHERE p.Id = @UserId
				AND (g.Title = 'SuperAdminEoffice')
			)
	BEGIN
		SET @IsSuperAdmin = CAST(1 AS BIT);
	END

	SELECT *
	INTO #TempUserWorkflow
	FROM (
		SELECT w.*
			,wc.Title AS CategoryName
		FROM [dbo].[Workflow] [w]
		LEFT JOIN [dbo].[WorkflowCategory] AS wc
			ON w.CategoryId = wc.ID
		WHERE [w].[IsDeleted] = 0
			AND (
				(dbo.fn_RemoveBracketsAndUnderLine(w.[Title]) LIKE N'%' + IIF(@Title IS NULL, dbo.fn_RemoveBracketsAndUnderLine(w.[Title]), dbo.fn_RemoveBracketsAndUnderLine(@Title)) + '%')
				OR (dbo.fn_RemoveBracketsAndUnderLine(w.[TitleEN]) LIKE N'%' + IIF(@Title IS NULL, dbo.fn_RemoveBracketsAndUnderLine(w.[TitleEN]), dbo.fn_RemoveBracketsAndUnderLine(@Title)) + '%')
				OR (dbo.fn_RemoveBracketsAndUnderLine(w.[Code]) LIKE N'%' + IIF(@Title IS NULL, dbo.fn_RemoveBracketsAndUnderLine(w.[Code]), dbo.fn_RemoveBracketsAndUnderLine(@Title)) + '%')
				--OR [w].[Title] like N'%' +  IIF(@Title IS NULL, w.[Title], @Title) + '%'
				)
			AND w.[Status] = IIF(@Status IS NULL, w.[Status], @Status)
			AND w.[IsDetail] = IIF(@IsDetail IS NULL, CAST(0 AS BIT), @IsDetail)
			AND w.[IsProcess] = IIF(@IsProcess IS NULL, w.[IsProcess], @IsProcess)
			AND w.[WorkflowType] = IIF(@WorkflowType IS NULL, w.[WorkflowType], @WorkflowType)
			AND IIF(w.[CategoryId] IS NULL, 0, w.[CategoryId]) = IIF(@CategoryId IS NULL, IIF(w.[CategoryId] IS NULL, 0, w.[CategoryId]), @CategoryId)
			AND (
				@WorkflowType IS NULL
				OR @WorkflowType <> 4
				OR @IsSuperAdmin = 1
				OR (
					w.[ConfigurePermission] IS NOT NULL
					AND w.[ConfigurePermission] <> ''
					AND (
						[w].[ConfigurePermission] LIKE '%P:' + CAST(@UserId AS VARCHAR) + '%'
						OR (
							[w].[ConfigurePermission] LIKE '%G:%'
							AND EXISTS (
								SELECT TOP 1 *
								FROM #TempGroup_New
								JOIN STRING_SPLIT([w].[ConfigurePermission], ',') [sl] ON RTRIM(value) = Code
								)
							)
						)
					)
				)
			AND (
				(
					[w].IsVisibleForAdmin IS NULL
					OR [w].IsVisibleForAdmin = 0
					)
				OR @IsConfigureAdmin = 1
				)
			AND (
				@CreatePermission IS NULL
				OR @CreatePermission = ''
				OR w.CreatePermission = @CreatePermission
				)
			AND (
				@SeenPermission IS NULL
				OR @SeenPermission = ''
				OR w.SeenPermission = @SeenPermission
				)
		) TB

	SET @TotalItems = (
			SELECT COUNT(*)
			FROM #TempUserWorkflow
			);

	SELECT *
	FROM #TempUserWorkflow
	ORDER BY CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy = N'Title'
				THEN [Title]
			END DESC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy = N'Title'
				THEN [Title]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy = N'Code'
				THEN [Code]
			END DESC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy = N'Code'
				THEN [Code]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy = N'CategoryName'
				THEN [CategoryName]
			END DESC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy = N'CategoryName'
				THEN [CategoryName]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy = N'StartDate'
				THEN [StartDate]
			END DESC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy = N'StartDate'
				THEN [StartDate]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy = N'EndDate'
				THEN [EndDate]
			END DESC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy = N'EndDate'
				THEN [EndDate]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy = N'Version'
				THEN [Version]
			END DESC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy = N'Version'
				THEN [Version]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy = N'CreatePermission'
				THEN [CreatePermission]
			END DESC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy = N'reatePermission'
				THEN [CreatePermission]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 1
				AND @SortBy IS NULL
				THEN [Id]
			END ASC
		,CASE 
			WHEN @IsSortAscending = 0
				AND @SortBy IS NULL
				THEN [Id]
			END DESC OFFSET @Skip ROWS

	FETCH NEXT @Take ROWS ONLY;

	DROP TABLE #TempUserWorkflow;
END
go

