CREATE PROCEDURE [dbo].[proc_UpdateWebPartIsIncluded](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @Level tinyint OUTPUT,
    @bAllUser bit,
    @UserId int,
    @WebPartId uniqueidentifier,
    @bCheckLock bit,
    @IsIncluded bit,
    @ZoneID nvarchar(64),
    @PartOrder int,
    @FrameState tinyint,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocId uniqueidentifier
    DECLARE @PartDocId uniqueidentifier
    DECLARE @IsCurrentVersion bit
    DECLARE @IsForceCheckout bit
    DECLARE @EnableMinorVersions bit
    DECLARE @IsModerate bit
    DECLARE @WebId uniqueidentifier
    DECLARE @ListId uniqueidentifier
    DECLARE @ItemId int
    DECLARE @cbDelta bigint
    DECLARE @DocClientId varbinary(16)
    SELECT TOP 1
       @IsForceCheckout =
           CASE 
               WHEN L.tp_Flags & 0x40000 <> 0 AND @bCheckLock = 1 AND D.DoclibRowId IS NOT NULL
                   THEN 1
               ELSE 0
           END,
        @EnableMinorVersions = 
            CASE 
                WHEN L.tp_Flags & 0x80000 <> 0 AND D.DoclibRowId IS NOT NULL
                    THEN 1
                ELSE 0
            END,
        @IsModerate = 
            CASE 
                WHEN L.tp_Flags & 0x400 <> 0 AND D.DoclibRowId IS NOT NULL
                    THEN 1
                ELSE 0
            END,
        @DocId = D.Id,
        @IsCurrentVersion = D.IsCurrentVersion,
        @WebId = D.WebId,
        @ListId = D.ListId,
        @ItemId = D.DoclibRowId,
        @DocClientId = D.ClientId
    FROM
        TVF_Docs_Url_Level(@SiteId, @DirName, @LeafName, @Level) AS D
    OUTER APPLY
        TVF_Lists_NoLock_CI(D.SiteId, D.WebId, D.ListId) AS L
    IF (@IsForceCheckout = 1
        AND @Level <> 255
        AND @bAllUser = 1)
        RETURN 158
    IF @DocId IS NULL
    BEGIN
        RETURN 2
    END
    IF @bCheckLock = 1
    BEGIN
        IF (@bAllUser = 0) AND (@Level = 255)
        BEGIN
            RETURN 12
        END
        IF (@bAllUser = 1) AND (@IsCurrentVersion = 0)
        BEGIN
            RETURN 33
        END
    END
    SELECT TOP 1
        @PartDocId = WP.tp_PageUrlID
    FROM
        TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
    IF (@DocId <> @PartDocId)
    BEGIN
        RETURN 5
    END
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    IF (@EnableMinorVersions = 1 OR @IsModerate = 1 ) AND
        @Level = 1 AND @bAllUser = 1 AND
        @bCheckLock = 1 AND
        @ItemId IS NOT NULL
    BEGIN
        EXEC @Ret = proc_CloneDoc 
            @SiteId,
            @DirName,
            @LeafName,
            NULL,
            NULL,
            NULL,
            @Level,
            2,
            @EnableMinorVersions,
            @IsModerate,
            @UserId,
            NULL, NULL, 
            @RequestGuid = @RequestGuid OUTPUT
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        SET @Level = 2
    END
    IF (@bAllUser = 1 OR
        EXISTS (
            SELECT TOP 1
                1
            FROM 
                TVF_WebParts_SitePartId(@SiteId, @WebPartId) AS WP
            WHERE 
                WP.tp_UserID = @UserId))
    BEGIN
        UPDATE
            WP
        SET
            WP.tp_Version = (CASE WHEN WP.tp_Version IS NULL THEN 2 WHEN WP.tp_Version >= 2147483647 THEN 1 ELSE WP.tp_Version + 1 END),
            WP.tp_IsIncluded = @IsIncluded,
            WP.tp_ZoneID = @ZoneID,
            WP.tp_PartOrder = @PartOrder,
            WP.tp_FrameState = @FrameState
        FROM
            TVF_WebParts_SitePartId(@SiteId, @WebPartId) AS WP
        WHERE
            (WP.tp_Level = @Level OR @bAllUser = 0)
    END
    ELSE
    BEGIN
        IF EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_Personalization_PK(@SiteId, @DocId, @WebPartId, @UserId))
        BEGIN
            UPDATE
                P
            SET
                P.tp_IsIncluded = @IsIncluded,
                P.tp_ZoneID = @ZoneID,
                P.tp_PartOrder = @PartOrder,
                P.tp_FrameState = @FrameState
            FROM
                TVF_Personalization_PK(@SiteId, @DocId, @WebPartId, @UserId) AS P
        END
        ELSE
        BEGIN
            DECLARE @quotaOrLockStatus int SELECT @quotaOrLockStatus = dbo.fn_IsOverQuotaOrWriteLocked(@SiteId) IF (@quotaOrLockStatus = 1) BEGIN SET @Ret = 1816 END ELSE IF (@quotaOrLockStatus > 1) BEGIN SET @Ret = 212 END
            IF @Ret <> 0
                GOTO cleanup
            SELECT
                @cbDelta = 66 + ISNULL(DATALENGTH(WP.tp_PerUserProperties), 0) + ISNULL(DATALENGTH(NULL), 0)
            FROM
                TVF_WebParts_SitePartId(@SiteId, @WebPartId) AS WP
            EXEC proc_AppendSiteQuota
                @SiteId, @cbDelta, 0, @DocId
            INSERT INTO Personalization(
                tp_SiteId,
                tp_WebPartID,
                tp_PageUrlID,
                tp_UserID,
                tp_PerUserProperties,
                tp_ZoneID,
                tp_PartOrder,
                tp_IsIncluded,
                tp_FrameState,
                tp_Size)
            SELECT
                @SiteId,
                @WebPartId,
                @DocId,
                @UserId,
                WP.tp_PerUserProperties,
                @ZoneID,
                @PartOrder,
                @IsIncluded,
                @FrameState,
                @cbDelta
            FROM
                TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
        END
    END
    IF (@@ERROR <> 0 OR @Ret <> 0)
    BEGIN
        IF (@Ret = 0)
            SET @Ret = -2147467259
        GOTO cleanup
    END
    IF NOT EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_WebParts_SitePartId(@SiteId, @WebPartId))
    BEGIN
        SET @Ret = 2  
    END
    IF (@@ERROR <> 0 OR @Ret <> 0)
    BEGIN
        IF (@Ret = 0)
            SET @Ret = -2147467259
        GOTO cleanup
    END
cleanup:
    IF (0 = @Ret)
    BEGIN
        IF (@ItemId IS NOT NULL)
        BEGIN
            EXEC proc_LogChange @SiteId, @WebId, @ListId, @ItemId, @DocId,
                NULL, NULL, NULL, 8192, 1, NULL,
                NULL, NULL, @DocClientId
        END
        ELSE
        BEGIN
            EXEC proc_LogChange @SiteId, @WebId, NULL, NULL, @DocId,
                NULL, NULL, NULL, 8192, 16, NULL,
                NULL, NULL, @DocClientId
        END
        EXEC proc_UpdateDiskUsed @SiteId
    END
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

