CREATE FUNCTION [dbo].[TVF_ContentTypes_SiteClass]
(
    @SiteId uniqueidentifier,
    @Class tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[ContentTypes] WITH (INDEX=ContentTypes_SiteClassCTId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Class = @Class

go

