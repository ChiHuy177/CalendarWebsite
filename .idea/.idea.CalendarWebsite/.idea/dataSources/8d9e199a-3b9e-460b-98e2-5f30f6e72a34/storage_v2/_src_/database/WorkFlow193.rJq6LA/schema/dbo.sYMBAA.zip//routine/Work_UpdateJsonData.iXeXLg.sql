--  
   CREATE   PROC [dbo].[Work_UpdateJsonData]                
   @UserWorkflowId AS BIGINT  
   ,@columnName AS NVARCHAR(500)   
   ,@value AS NVARCHAR(max)  
   ,@tableName as nvarchar(250)   
   ,@columnUpdate as nvarchar(250)='UserWorkflowId'   
   AS     
   declare @sql as nvarchar(max)  , @table as nvarchar(250)      
   if(@tableName like '%.data_%')
   begin 
   set @tableName=(select REPLACE(@tableName,'.Data_','.Workflow_')) 
   end 
   set @table =(select REPLACE(@tableName,'.Workflow_','.Data_'))                      
   set @sql=N' update '+@table+' set '+@columnName+'='+case when ISNULL(@value,'')='' then 'NULL' else 'N'+''''+@value+'''' end     
   +' where UserWorkflowId= '+ str(@UserWorkflowId)     
   +'  update '+ @tableName +' set LastModified = convert(nvarchar,getdate())'+' where UserWorkflowId= '+ str(@UserWorkflowId) +''                       
   exec(@sql)         
   print (@sql)
go

