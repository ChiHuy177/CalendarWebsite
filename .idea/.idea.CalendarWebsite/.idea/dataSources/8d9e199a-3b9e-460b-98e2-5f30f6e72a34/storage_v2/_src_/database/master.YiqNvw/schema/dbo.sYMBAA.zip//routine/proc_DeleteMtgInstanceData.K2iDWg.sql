CREATE PROCEDURE [dbo].[proc_DeleteMtgInstanceData]
(
    @SiteId         uniqueidentifier,
    @WebId          uniqueidentifier,
    @MtgListID      uniqueidentifier,
    @MtgItemId      int,        
    @ForAttendees   bit = NULL, 
    @UserId         int,
    @AppPrincipalId int,
    @UserTitle      nvarchar(255)
)
AS
    SET NOCOUNT ON
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    DECLARE @DelInstanceID int
    IF @MtgItemId IS NULL
        SET @DelInstanceID = 1
    ELSE    
    BEGIN
        DECLARE @DelEventType int
        SELECT TOP 1
            @DelEventType   = UD.int1,
            @DelInstanceID  = UD.tp_InstanceID
        FROM
            TVF_UserData_ListItem_Mtg(@SiteId, @MtgListID, @MtgItemId) AS UD
        WHERE
            UD.tp_RowOrdinal = 0
        IF @DelEventType = 1
        BEGIN
            SET @RET = 16
            GOTO cleanup
        END
        IF @DelEventType = 3
        BEGIN
            SET @RET = 0     
            GOTO cleanup
        END
        IF @DelInstanceID IS NULL
        BEGIN
            SET @RET = 13
            GOTO cleanup
        END
    END
    IF (@ForAttendees IS NULL OR @ForAttendees = 0)
    BEGIN
        DECLARE @DocLibFolders_cursor CURSOR
        DECLARE @Error int
        EXEC @Error = proc_GetDoclibFoldersCursor
            @SiteId,
            @WebId,
            NULL,       
            @DocLibFolders_cursor OUTPUT
        IF @Error <> 0
        BEGIN
            SET @RET = @Error
            GOTO cleanup
        END
        DECLARE @DelInstanceName nvarchar(8)
        SET @DelInstanceName = CONVERT( nvarchar(8), @DelInstanceID )
        DECLARE @DocLibUrl nvarchar(256)
        DECLARE @DelInstanceFolderUrl nvarchar(256)
        FETCH NEXT 
        FROM 
            @DocLibFolders_cursor
        INTO
            @DocLibUrl
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @DelInstanceFolderUrl = @DocLibUrl + N'/' + @DelInstanceName
            EXEC @Error = proc_DeleteUrlCore
                @SiteId,
                @WebId,
                @DelInstanceFolderUrl,
                @UserId,
                @AppPrincipalId,
                1,                      
                NULL,                   
                0,                      
                0,                      
                0   
            IF @Error <> 0
            BEGIN
                IF @Error <> 3
                    BREAK
                ELSE    
                    SET @Error = 0
            END
            FETCH NEXT 
            FROM 
                @DocLibFolders_cursor
            INTO
                @DocLibUrl
        END
        CLOSE @DocLibFolders_cursor
        DEALLOCATE @DocLibFolders_cursor
        IF @Error <> 0
        BEGIN
            SET @RET = @Error
            GOTO cleanup
        END
    END
    DECLARE DelInstanceData_cursor CURSOR
        LOCAL
        FAST_FORWARD
    FOR
    SELECT
        UserData.tp_ID,
        Lists.tp_ID,
        Lists.tp_ServerTemplate
    FROM    
        TVF_Lists_WebId(@SiteId, @WebId) AS Lists
    CROSS APPLY
        TVF_UserData_List(Lists.tp_SiteId, Lists.tp_ID) AS UserData
    WHERE
        (Lists.tp_Flags & 0x20) <> 0 AND
        (@ForAttendees IS NULL OR
            ((@ForAttendees = 1 AND Lists.tp_ServerTemplate  = 202) OR
                (@ForAttendees = 0 AND Lists.tp_ServerTemplate <> 202))) AND
        UserData.tp_InstanceID = @DelInstanceID AND
        UserData.tp_RowOrdinal = 0
    DECLARE @DelItemId int
    DECLARE @ListId uniqueidentifier
    DECLARE @ListServerTemplate int
    OPEN DelInstanceData_cursor
    FETCH NEXT 
    FROM 
        DelInstanceData_cursor
    INTO
        @DelItemId,
        @ListId,
        @ListServerTemplate
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @ListServerTemplate = 202
        BEGIN
            EXEC proc_ProcessDelMtgAttendeeListItem
                @SiteId,
                @WebId,
                @ListId,
                @DelItemId
        END
        DECLARE @RetDropRecord int SET @RetDropRecord = 0 BEGIN TRAN
        EXEC @RetDropRecord = proc_DropListRecord
            @SiteId,
            @WebId,
            @ListId,
            @ListServerTemplate,
            @DelItemId,
            1,
            0,
            @UserTitle,
            NULL,       
            @UserId,
            @AppPrincipalId,
            0,          
            NULL        
        IF (@RetDropRecord <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
        FETCH NEXT 
        FROM 
            DelInstanceData_cursor
        INTO
            @DelItemId,
            @ListId,
            @ListServerTemplate
    END
    CLOSE DelInstanceData_cursor
    DEALLOCATE DelInstanceData_cursor
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    IF (@RET = 0)
    BEGIN
        EXEC proc_UpdateListItemCount @SiteId, @ListId
        EXEC proc_UpdateDiskUsed @SiteId
    END
    RETURN @RET

go

