CREATE PROCEDURE [dbo].[proc_EnableRbs]
(
    @RequestGuid uniqueidentifier = NULL OUTPUT     --
)
AS
    SET NOCOUNT ON
    DECLARE @RbsInstalled int
    EXEC @RbsInstalled = proc_CheckRbsIntalled
    IF @RbsInstalled = 0
    BEGIN
        RETURN 1060
    END
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsReference(@RbsId varbinary(64)) 
        RETURNS varbinary(800)
        AS 
        BEGIN
            RETURN mssqlrbs.rbs_fn_get_blob_reference(@RbsId)
        END
        ')
    DECLARE @cmd nvarchar(4000),
        @params nvarchar(4000)
    SELECT @cmd = N'
        IF NOT EXISTS(SELECT 1 
            FROM mssqlrbs.rbs_columns AS rc 
            INNER JOIN sys.syscolumns AS sc 
            ON rc.table_object_id = sc.id AND rc.column_id = sc.colid 
            WHERE sc.id = OBJECT_ID(
                    N''['' + @schema + ''].['' + @table + N'']'') 
                AND sc.name = @column)
            EXEC mssqlrbs.rbs_sp_register_column @schema, @table, @column',
        @params = N'@schema sysname, @table sysname, @column sysname'
    EXEC sp_executesql @cmd, @params, 'dbo', 'DocStreams', 'RbsId'
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsStoreFromId(
            @RbsId varbinary(64))
        RETURNS INT
        AS
        BEGIN
            DECLARE @blobStoreId INT
            SELECT TOP 1 @blobStoreId = blob_store_id 
                FROM mssqlrbs.rbs_blob_details
                WHERE
                    blob_number = mssqlrbs.rbs_fn_get_blob_number(@RbsId) AND
                    collection_id = mssqlrbs.rbs_fn_get_collection_id(@RbsId)
            RETURN @blobStoreId
        END
        ')
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsStoreFromName(
            @RbsProviderName sysname)
        RETURNS INT
        AS
        BEGIN
            DECLARE @blobStoreId INT
            SELECT TOP 1 @blobStoreId = blob_store_id 
                FROM mssqlrbs.rbs_blob_stores 
                WHERE blob_store_name = @RbsProviderName
            RETURN @blobStoreId
        END
        ')
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsGetBlobId(
            @CollectionId int, 
            @BlobNumber AS bigint
        ) RETURNS varbinary(64)
        AS
        BEGIN
            RETURN mssqlrbs.rbs_fn_get_blob_id(@CollectionId, @BlobNumber)
        END
        ')
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsBlobDetails_RbsId(
            @RbsId varbinary(64)
        ) RETURNS TABLE AS RETURN
            SELECT TOP 1
                blob_number AS BlobNumber,
                collection_id AS CollectionId, 
                blob_store_id AS BlobStoreId, 
                store_pool_id AS StorePoolId, 
                store_blob_id AS StoreBlobId, 
                create_time AS CreateTime, 
                length AS Length 
            FROM mssqlrbs.rbs_blob_details
            WHERE
                blob_number = mssqlrbs.rbs_fn_get_blob_number(@RbsId) AND
                collection_id = mssqlrbs.rbs_fn_get_collection_id(@RbsId)
        ')
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsBlobDetails_CollectionId(
            @RbsCollectionId int
        ) RETURNS TABLE AS RETURN
            SELECT
                blob_number AS BlobNumber,
                collection_id AS CollectionId, 
                blob_store_id AS BlobStoreId, 
                store_pool_id AS StorePoolId, 
                store_blob_id AS StoreBlobId, 
                create_time AS CreateTime, 
                length AS Length 
            FROM mssqlrbs.rbs_blob_details
            WHERE
                collection_id = @RbsCollectionId
        ')
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsBlobDetails_StorePoolBlob(
            @RbsBlobStoreId tinyint,
            @RbsStorePoolId varbinary(255),
            @RbsStoreBlobId varbinary(255)
        ) RETURNS TABLE AS RETURN
            SELECT TOP 1
                blob_number AS BlobNumber,
                collection_id AS CollectionId, 
                blob_store_id AS BlobStoreId, 
                store_pool_id AS StorePoolId, 
                store_blob_id AS StoreBlobId, 
                create_time AS CreateTime, 
                length AS Length 
            FROM mssqlrbs.rbs_blob_details
            WHERE
                blob_store_id = @RbsBlobStoreId AND
                store_pool_id = @RbsStorePoolId AND
                store_blob_id = @RbsStoreBlobId
        ')
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsPools(
            @RbsCollectionId int
        ) RETURNS TABLE AS RETURN
            SELECT
                blob_store_id AS BlobStoreId,
                store_pool_id AS StorePoolId, 
                can_store_new_blobs AS CanStoreNewBlobs
            FROM mssqlrbs.rbs_pools WITH (REPEATABLEREAD)
            WHERE
                collection_id = @RbsCollectionId
        ')
    EXECUTE(N'
        ALTER FUNCTION dbo.fn_RbsGetCollectionId(
            @RbsId varbinary(64)
        ) RETURNS int
        AS
        BEGIN
            RETURN mssqlrbs.rbs_fn_get_collection_id(@RbsId)
        END
        ')
    DECLARE @RbsCollectionId int
    DECLARE siteCursor CURSOR LOCAL FORWARD_ONLY FOR
        SELECT RbsCollectionId
        FROM AllSites WITH (UPDLOCK)
        WHERE RbsCollectionId = 0 
        ORDER BY Id ASC
        FOR UPDATE OF RbsCollectionId
    OPEN siteCursor
    IF @@CURSOR_ROWS <> 0
    BEGIN
        WHILE 1 = 1
        BEGIN
            FETCH NEXT FROM siteCursor INTO @RbsCollectionId
            IF @@FETCH_STATUS <> 0
                BREAK
            EXEC dbo.proc_RbsAddCollection @RbsCollectionId OUTPUT
            UPDATE AllSites
            SET RbsCollectionId = @RbsCollectionId
            WHERE CURRENT OF siteCursor
        END
    END
    CLOSE siteCursor
    DEALLOCATE siteCursor
    EXEC proc_SetDatabaseInformation N'RbsEnabled', N'1'
    RETURN 0

go

