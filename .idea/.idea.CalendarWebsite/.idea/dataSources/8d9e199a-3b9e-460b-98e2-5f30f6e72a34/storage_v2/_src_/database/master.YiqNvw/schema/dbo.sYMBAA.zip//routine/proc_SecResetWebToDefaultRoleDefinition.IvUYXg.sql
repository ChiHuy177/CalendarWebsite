CREATE PROCEDURE [dbo].[proc_SecResetWebToDefaultRoleDefinition](
    @SiteId uniqueidentifier,
    @WebId                      uniqueidentifier,
    @AuthorID                   int,
    @AdminsName                 nvarchar(255),
    @AdminsDescription          nvarchar(512),
    @AdminsPermMask             tPermMask,
    @AuthorsName                nvarchar(255),
    @AuthorsDescription         nvarchar(512),
    @AuthorsPermMask            tPermMask,
    @EditorsName                nvarchar(255),
    @EditorsDescription         nvarchar(512),
    @EditorsPermMask            tPermMask,
    @ContributorsName           nvarchar(255),
    @ContributorsDescription    nvarchar(512),
    @ContributorsPermMask       tPermMask,
    @BrowsersName               nvarchar(255),
    @BrowsersDescription        nvarchar(512),
    @BrowsersPermMask           tPermMask,
    @GuestsName                 nvarchar(255),
    @GuestsDescription          nvarchar(512),
    @GuestsPermMask             tPermMask,
    @AnonymousPermMask          tPermMask,
    @ScopeId                    uniqueidentifier OUTPUT,
    @RequestGuid                uniqueidentifier = NULL OUTPUT) 
AS
    SET NOCOUNT ON
    DECLARE @WebFullUrl nvarchar(256)
    DECLARE @FirstUniqueAncestor uniqueidentifier
    DECLARE @RoleDefWebId uniqueidentifier
    DECLARE @DirName nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    DECLARE @RootWebId uniqueidentifier
    SELECT TOP 1
        @FirstUniqueAncestor = W.FirstUniqueAncestorWebId,
        @ScopeId = W.ScopeId,
        @RoleDefWebId = P.RoleDefWebId,
        @WebFullUrl = W.FullUrl
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
    CROSS APPLY
        TVF_Perms_ScopeId(W.SiteId, W.ScopeId) AS P
    WHERE
        P.RoleDefWebId <> @WebId
    IF @WebFullUrl IS NULL
    BEGIN
        RETURN 3
    END
    SELECT
        @RootWebId = RootWebId
    FROM
        TVF_Sites_Id(@SiteId) AS Sites    
    EXEC proc_SplitUrl @WebFullUrl, @DirName output, @LeafName output
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    IF @RootWebId  IS NOT NULL
    BEGIN
        SELECT TOP 1
            @RootWebId = Id
        FROM
           TVF_Webs_XLock_Id(@SiteId, @RootWebId) AS Webs
    END
    IF @WebId <> @FirstUniqueAncestor
    BEGIN
        SELECT @ScopeId = NEWID()
        EXEC proc_SecAddPermScopeForWeb @SiteId, @ScopeId, @WebId, @WebId, @AnonymousPermMask, @WebFullUrl, 1
    END
    ELSE
    BEGIN    
        UPDATE
            P
        SET
            P.RoleDefWebId = @WebId
        FROM
            TVF_Perms_ScopeId(@SiteId, @ScopeId) AS P
        DELETE 
            RA
        FROM
            TVF_RoleAssignment_SiteId_ScopeId(@SiteId, @ScopeId) AS RA
    END
    UPDATE
        W
    SET
        W.NextWebGroupId = 1073741824 + 100
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
    EXEC proc_SecResetAllSubwebsWithOldRoleDefs @SiteId, @WebId, @WebFullUrl, @ScopeId, @RoleDefWebId
    EXEC proc_CreateDefaultRoles 
        @SiteId, @WebId, @ScopeId,
        @AuthorID, NULL,
        @AdminsName, @AdminsDescription, @AdminsPermMask,
        @AuthorsName,@AuthorsDescription, @AuthorsPermMask,
        @EditorsName,@EditorsDescription, @EditorsPermMask,
        @ContributorsName,@ContributorsDescription, @ContributorsPermMask,
        @BrowsersName, @BrowsersDescription, @BrowsersPermMask,
        @GuestsName, @GuestsDescription, @GuestsPermMask
    EXEC proc_SecLogChange @SiteId, @WebId, @ScopeId, @WebFullUrl, NULL, @AuthorID,
                262144, 2
    EXEC proc_SecUpdateSiteLevelSecurityMetadata @SiteId, 0, 0
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @RET

go

