CREATE PROCEDURE [dbo].[proc_GetListContentTypeOrder](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier)
AS
    SET NOCOUNT ON
    SELECT
        CASE WHEN (DATALENGTH(Docs.DirName) = 0) THEN Docs.LeafName WHEN (DATALENGTH(Docs.LeafName) = 0) THEN Docs.DirName ELSE Docs.DirName + N'/' + Docs.LeafName END,
        CASE 
        WHEN Docs.DocFlags & 8192 = 8192 THEN MetaInfo 
        ELSE NULL 
        END
    FROM
        TVF_Lists_CI(@SiteId, @WebId, @ListId) AS Lists
    CROSS APPLY
        TVF_Docs_NoLock_Id(Lists.tp_SiteId, Lists.tp_RootFolder) AS Docs

go

