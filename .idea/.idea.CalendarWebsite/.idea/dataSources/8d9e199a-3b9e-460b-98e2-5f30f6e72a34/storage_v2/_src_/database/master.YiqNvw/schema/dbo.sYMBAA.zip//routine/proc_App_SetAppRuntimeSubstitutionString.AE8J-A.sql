CREATE Procedure [dbo].[proc_App_SetAppRuntimeSubstitutionString] (
    @AppInstanceId uniqueidentifier,
    @ValueKey nvarchar(50),
    @ValueString nvarchar(2080),
    @SiteId uniqueidentifier
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
UPDATE TVF_AppRuntimeSubstitutionDictionary_AppInstanceId(@SiteId, @AppInstanceId)
    SET ValueString = @ValueString,
    ValueWebId = NULL
    WHERE ValueKey = @ValueKey
IF(@@ROWCOUNT = 0) --then we're inserting rather than updating
BEGIN
    INSERT INTO AppRuntimeSubstitutionDictionary
        (AppInstanceId, ValueKey, ValueString, ValueWebId, SiteId)
    VALUES
        (@AppInstanceId, @ValueKey, @ValueString, NULL, @SiteId)
END
COMMIT TRANSACTION

go

