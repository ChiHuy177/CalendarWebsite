CREATE FUNCTION [dbo].[TVF_WebPartLists_SitePageLvl]
(
    @tp_SiteId uniqueidentifier,
    @tp_PageUrlID uniqueidentifier,
    @tp_Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[WebPartLists] WITH (INDEX=WebPartLists_PageUrlID, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_PageUrlID = @tp_PageUrlID AND
        tp_Level = @tp_Level

go

