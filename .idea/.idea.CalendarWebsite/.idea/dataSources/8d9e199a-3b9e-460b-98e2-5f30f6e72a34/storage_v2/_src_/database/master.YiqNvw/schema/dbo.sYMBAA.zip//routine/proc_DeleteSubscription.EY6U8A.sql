CREATE PROCEDURE [dbo].[proc_DeleteSubscription](
    @SiteId         uniqueidentifier,
    @SubId          uniqueidentifier,
    @UserId         int,
    @RequestGuid    uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @WebId uniqueidentifier
    DECLARE @ListId uniqueidentifier
    DECLARE @ItemId int
    DECLARE @AlertType tinyint
    SELECT TOP 1
        @WebId = WebId,
        @AlertType = AlertType,
        @ListId = ListId,
        @ItemId = ItemId
    FROM
        TVF_ImmedSubscriptions_SiteIdId(@SiteId, @SubId) AS I
    WHERE
        I.UserId = @UserId
    IF (@@ROWCOUNT = 0)
    BEGIN
        SELECT TOP 1
            @WebId = WebId,
            @AlertType = AlertType,
            @ListId = ListId,
            @ItemId = ItemId
        FROM
            TVF_SchedSubscriptions_SiteIdId(@SiteId, @SubId) AS S
        WHERE
            S.UserId = @UserId
    END
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    DELETE
        I
    FROM
        TVF_ImmedSubscriptions_SiteIdId(@SiteId, @SubId) AS I
    WHERE
        I.UserId = @UserId
    IF (@@ROWCOUNT = 0)
    BEGIN
        DELETE FROM
            TVF_EventSubsMatches_SiteSub(@SiteId, @SubId)
        DELETE
            S
        FROM
            TVF_SchedSubscriptions_SiteIdId(@SiteId, @SubId) AS S
        WHERE
            S.UserId = @UserId
        IF (@@ROWCOUNT = 0)
        BEGIN
            SET @Ret = 31
            GOTO cleanup
        END
    END
    EXEC proc_LogChange @SiteId, @WebId, @ListId, @ItemId, NULL, @SubId, NULL,
        NULL, 16384,  64, NULL
    IF ((@AlertType = 0 OR 
         @AlertType = 1) AND
        (0 = (SELECT COUNT(1) FROM TVF_ImmedSubscriptions_SiteIdListId(@SiteId, @ListId))) AND
        (0 = (SELECT COUNT(1) FROM TVF_SchedSubscriptions_SiteIdListId(@SiteId, @ListId))))
    BEGIN
        UPDATE
            L
        SET
            L.tp_Subscribed = 0
        FROM
            TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
    END
cleanup:
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

