CREATE   PROC [dbo].[Work_InsertNewProcessInWork] 
   @workId as nvarchar(250) 
   as 
   declare @QuyTrinhDinhKem as nvarchar(250) 
   set @QuyTrinhDinhKem=(select QuyTrinhDinhKem from Dynamic.Data_WORK where UserWorkflowid=@workId) 
   if not exists ( select * from Dynamic.Data_FOLLOWCHART where IsUseForWork=@workId) 
   begin 
   --INSERT INTO [Dynamic].[Data_FOLLOWCHART] 
   -- ( 
   -- [Nguoixuly] 
   -- ,[Nguoiphoihop] 
   -- ,[Nguoitheodoi] 
   -- ,[Mota] 
   -- ,[Tieude] 
   -- ,[Loaicv] 
   -- ,[Douutien] 
   -- ,[Thoigian] 
   -- ,[Nodeid] 
   -- ,[QuyTrinhDinhKem] 
   -- ,[IsUseForWork]) 
   select [Nguoixuly] 
   ,[Nguoiphoihop] 
   ,[Nguoitheodoi] 
   ,Noidung 
   ,[Tieude] 
   ,[Loaicv] 
   ,[Douutien] 
   ,DATEDIFF(DAY, CONVERT(date, ISNULL( Ngayketthuc,getdate()),103), CONVERT(date, ISNULL( Ngaybatdau,getdate()),103) ) as thoigian 
   ,[Nodeid] 
   ,@QuyTrinhDinhKem as QuyTrinhDinhKem
   ,UserWorkflowId as IsUseForWork
   from Dynamic.Data_WORK 
   where CongViecCha=@workId and Nodeid is not null 
   end 
go

