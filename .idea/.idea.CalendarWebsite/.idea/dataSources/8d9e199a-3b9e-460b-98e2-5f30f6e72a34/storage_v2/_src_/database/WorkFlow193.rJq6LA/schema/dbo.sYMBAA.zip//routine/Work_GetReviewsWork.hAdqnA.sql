CREATE   PROC [dbo].[Work_GetReviewsWork]   
   @workId as nvarchar(50)   
   as   
   declare @sum as bigint   
   set @sum=(select COUNT(*) as Dem from Dynamic.data_ReviewsWork where WorkId=@workId)   
   select a.Id,UserWorkflowId,Rate,ISNULL(Note,'') as Note,WorkId,UserCreate   
   ,b.FullName   
   ,@sum as Total   
   ,b.Id as UserId  
   from Dynamic.data_ReviewsWork a   
   inner join PersonalProfile b on a.UserCreate=b.Email   
   where WorkId=@workId   
   order by a.Id desc
go

