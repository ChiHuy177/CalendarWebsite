CREATE PROCEDURE [dbo].[proc_EnsureSiteRbsCollection](
    @SiteId uniqueidentifier,
    @Force bit,
    @RbsCollectionId int OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    BEGIN TRANSACTION
    IF @Force = CAST(0 AS bit)
    BEGIN
        SELECT
            @RbsCollectionId = RbsCollectionId
        FROM
            TVF_Sites_UpdLock_Id(@SiteId)
    END
    ELSE
    BEGIN
        SELECT @RbsCollectionId = 0
    END
    IF @RbsCollectionId = 0
    BEGIN
        EXEC proc_RbsAddCollection @RbsCollectionId OUTPUT
        UPDATE Sites
        SET RbsCollectionId = @RbsCollectionId
        FROM TVF_AllSites_Id(@SiteId) AS Sites
    END
    COMMIT TRANSACTION

go

