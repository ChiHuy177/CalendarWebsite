CREATE Procedure [dbo].[proc_App_ReadPackageForTask] (
    @TaskId uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
SET NOCOUNT ON
SELECT Package FROM
    --Get the task to get the job id
    TVF_AppTasks_TaskId(@SiteId, @TaskId) AS Task
    CROSS APPLY TVF_AppJobs_Id(@SiteId, Task.JobId) as Job
    --use the job to get the instance
    CROSS APPLY TVF_AppInstallations_Id(@SiteId, Job.InstallationId) as Installation
    --use the instance to get the Fingerprint
    CROSS APPLY TVF_AppSourceInfo_SourceInfoId(@SiteId, Installation.SourceInfoId) AS SourceInfo
    --use the Fingerprint to get the Package
    CROSS APPLY TVF_AppPackages_PackageFingerprint(@SiteId, SourceInfo.PackageFingerprint)

go

