-- =============================================
-- Author:		Duy Dam
-- Create date: 27/10/2021
-- Description:	Get All UserWorkflowStep depend on multiple conditions
-- Changelog: 25/07/2022 TIENTH - Change ORDER BY query
--			  08/04/2024 duydd - Support for En lang
-- =============================================
CREATE   PROCEDURE [dbo].[UserWorkflowStep_GetAll] 
@UserWorkflowId BIGINT ,
@Lang NVARCHAR(MAX) = 'vi'
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

	BEGIN TRAN

	SELECT us.[Id] AS Id
		,us.[FromUserWorkflowId] AS [FromUserWorkflowId]
		,us.[Index] AS index_v
		,us.[IsActived] AS [IsActived]
		,CASE us.IsRecall
			WHEN 1
				THEN CASE us.IsDefault
						WHEN 1
							THEN (CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
						ELSE CONCAT (
								(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
								,(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN N' recalled' ELSE N' thu hồi' END)
								)
						END
			WHEN 0
				THEN (
						CASE us.IsAddInfo
							WHEN 1
								THEN CONCAT (
									(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
										,(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN N' need more information' ELSE N' yêu cầu bổ sung' END)
										)
							WHEN 0
								THEN (
										CASE us.IsReplace
											WHEN 1
												THEN CONCAT (
														(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
														,(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN N' replaced' ELSE N' chuyển xử lý' END)
														)
											WHEN 0
												THEN (CASE 
													us.IsIdea 
													WHEN 1
													 THEN CONCAT (
														(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
														,(CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN N' request for idea' ELSE N' yêu cầu tham vấn' END)
														)
													 ELSE (CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
													 END
												)
											ELSE (CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
											END
										)
							ELSE (CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
							END
						)
			ELSE (CASE WHEN @Lang = 'en' AND ws.TitleEN IS NOT NULL AND ws.TitleEN <> '' THEN ws.TitleEN ELSE ws.Title END)
			END AS Title
		,pp.FullName AS [User]
		,ISNULL(us.PositionTitle ,ps.Title) AS Position
		,ISNULL(us.PositionTitleEN ,ps.TitleEN) AS PositionEN
		,us.Action AS Action
		,us.FinishTime AS FinishTime
		,us.Note AS Note
		,(
			CASE 
				WHEN (us.FinishTime IS NOT NULL)
					THEN CONVERT(BIT, 1)
				ELSE CONVERT(BIT, 0)
				END
			) AS Executed
		--,(
		--	CASE 
		--		WHEN us.StartTime IS NULL
		--			THEN us.CreatedTime
		--		ELSE us.StartTime
		--		END
		--	) AS StartTime
		,us.StartTime as StartTime
		,us.DueDate AS EndTime
		,us.IsDefault
		,us.CreatedTime
		,u.IsConverted
		,us.WorkflowStepId
		,(CASE WHEN @Lang = 'en' AND ws.StatusEN IS NOT NULL AND ws.StatusEN <> '' THEN ws.StatusEN ELSE ws.Status END) AS StepStatus
	FROM [dbo].[UserWorkflowStep] us WITH (NOLOCK)
	INNER JOIN [dbo].[UserWorkflow] u ON u.Id = us.UserWorkflowId
	LEFT JOIN [dbo].[WorkflowStep] ws ON ws.Id = us.WorkflowStepId
	LEFT JOIN [dbo].[PersonalProfile] pp ON pp.Id = us.UserId
	LEFT JOIN [dbo].[Position] ps ON ps.Id = pp.PositionId
	WHERE us.UserWorkflowId = @UserWorkflowId
		AND us.IsDeleted = 0
	ORDER BY (
			CASE 
				WHEN u.IsConverted = CAST(1 AS BIT)
					AND u.UserWorkflowStatus <> 0
					THEN us.CreatedTime
				ELSE NULL
				END
			) DESC
		,[Index] DESC
		--,CASE [us].[Action] WHEN N'Từ chối' THEN 0 ELSE 1 END
		--,[IsIdea] DESC
		,CASE 
			WHEN us.[IsIdea] = 1
				THEN us.StartTime
			ELSE NULL
			END ASC
		,CASE 
			WHEN FinishTime IS NULL
				THEN GETDATE()
			ELSE FinishTime
			END DESC
		,Id DESC

	--ORDER BY 
	--	us.[Index] DESC
	--	,CASE 
	--		WHEN (
	--				us.FinishTime IS NULL
	--				AND (
	--					us.IsIdea = 1
	--					OR us.IsReplace = 1
	--					)
	--				)
	--			THEN GETDATE()
	--		ELSE (CASE WHEN us.LastModified is null THEN us.CreatedTime ELSE us.LastModified END)
	--		END DESC
	--	,CASE 
	--		WHEN (
	--				us.FinishTime IS NULL
	--				AND (
	--					us.IsIdea = 1
	--					OR us.IsReplace = 1
	--					)
	--				)
	--			THEN GETDATE()
	--		ELSE us.FinishTime
	--		END DESC
	--	--,us.FinishTime DESC
	--	,us.Id DESC
	COMMIT TRAN
END
go

