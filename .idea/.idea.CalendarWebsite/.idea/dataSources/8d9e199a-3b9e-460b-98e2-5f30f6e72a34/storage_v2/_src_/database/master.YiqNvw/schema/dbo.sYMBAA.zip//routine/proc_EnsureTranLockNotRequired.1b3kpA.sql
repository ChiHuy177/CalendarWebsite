CREATE PROCEDURE [dbo].[proc_EnsureTranLockNotRequired](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @OnlyCheckForwardLink bit = 0)
AS
    SET NOCOUNT ON;
    DECLARE @Ret int;
    SET @Ret = 0;
    IF (@OnlyCheckForwardLink = 1)
    BEGIN
        IF (EXISTS(
            SELECT TOP 1
                1
            FROM 
                TVF_AllLookupRelationships_XLock_SiteList(@SiteId, @ListId) AS ALR
            WHERE
                ALR.DeleteBehavior <> 0
        ))
        BEGIN
            SET @Ret = 301
        END
    END
    ELSE
    BEGIN
        IF (EXISTS(
            SELECT TOP 1
                1
            FROM 
                TVF_AllLookupRelationships_XLock_SiteList(@SiteId, @ListId) AS ALR
            WHERE
                ALR.DeleteBehavior <> 0
            UNION
            SELECT TOP 1
                1
            FROM
                TVF_AllLookupRelationships_XLock_SiteLookupList(@SiteId, @ListId) AS ALR
            WHERE 
                ALR.DeleteBehavior <> 0
        ))
        BEGIN
            SET @Ret = 301
        END
    END
cleanup:
    RETURN @Ret;

go

