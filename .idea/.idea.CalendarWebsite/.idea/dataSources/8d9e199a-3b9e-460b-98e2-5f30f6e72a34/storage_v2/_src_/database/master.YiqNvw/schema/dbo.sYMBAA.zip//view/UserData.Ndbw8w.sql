
        CREATE VIEW [dbo].[UserData]
        AS
            SELECT
                *
            FROM
                AllUserData
            WHERE
                tp_IsCurrentVersion = CONVERT(bit,1)
              AND
                tp_CalculatedVersion = 0
              AND
                tp_DeleteTransactionId = 0x
    
go

