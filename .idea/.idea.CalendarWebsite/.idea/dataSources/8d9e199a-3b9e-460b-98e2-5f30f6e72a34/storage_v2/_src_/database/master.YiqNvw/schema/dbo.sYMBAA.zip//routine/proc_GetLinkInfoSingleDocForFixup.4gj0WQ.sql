CREATE PROCEDURE [dbo].[proc_GetLinkInfoSingleDocForFixup](
    @DocSiteId uniqueidentifier,
    @DocDirName nvarchar(256),
    @DocLeafName nvarchar(128),
    @Level tinyint)
AS
    SET NOCOUNT ON
    DECLARE @DocParentId uniqueidentifier
    DECLARE @DocId uniqueidentifier
    EXEC proc_GetParentIdAndDocIdForUrl 
        @DocSiteId, 
        @DocDirName, 
        @DocLeafName, 
        @DocParentId OUTPUT, 
        @DocId OUTPUT
    EXEC proc_GetLinkInfoSingleDocForFixupInternal
        @DocSiteId,
        @DocParentId,
        @DocId,
        @Level

go

