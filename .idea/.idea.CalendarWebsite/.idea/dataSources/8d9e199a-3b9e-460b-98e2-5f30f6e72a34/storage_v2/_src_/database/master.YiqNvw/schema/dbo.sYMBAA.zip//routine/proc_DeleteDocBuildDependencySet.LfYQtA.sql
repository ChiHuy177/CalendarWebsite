CREATE PROCEDURE [dbo].[proc_DeleteDocBuildDependencySet](
    @DocSiteId uniqueidentifier,
    @DocDirName  nvarchar(256),
    @DocLeafName nvarchar(128),
    @Level tinyint,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    BEGIN TRAN
    EXEC proc_UpdateDocBuildDependencySet
        @DocSiteId,
        @DocDirName,
        @DocLeafName,
        @Level,
        NULL,
        @RequestGuid OUTPUT
    DELETE
        BD
    FROM
        TVF_BuildDependencies_Url(@DocSiteId, @DocDirName, @DocLeafName) AS BD
    COMMIT
    RETURN 0

go

