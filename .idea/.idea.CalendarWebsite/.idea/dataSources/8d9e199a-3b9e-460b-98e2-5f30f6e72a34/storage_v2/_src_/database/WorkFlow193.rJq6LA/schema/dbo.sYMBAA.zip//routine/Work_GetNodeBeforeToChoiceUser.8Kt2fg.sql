CREATE   PROC [dbo].[Work_GetNodeBeforeToChoiceUser] 
   @PROCessId as char(50) 
   ,@step as int 
   as 
   select Nodeid as value,Title as label from Dynamic.Data_Lsqtcv 
   where CategoryWorkProcessId=@PROCessId 
   and Title not in (N'Bắt đầu',N'Hoàn thành',N'Chỉ chạy 1 quy trình',N'Kết thúc',N'Đồng thời',N'Từ chối') 
   and Step < @step 
   order by Step desc
go

