CREATE PROCEDURE [dbo].[proc_InsertDocEventReceiver](
    @DocUrl nvarchar(260),
    @Id uniqueidentifier,
    @Name nvarchar(256),
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ItemId int,
    @Synchronization int,
    @Type int,
    @SequenceNumber int,
    @Assembly nvarchar(256),
    @Class nvarchar(256),
    @SolutionId uniqueidentifier,
    @Data nvarchar(256),
    @Filter nvarchar(256),
    @Credential int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocDirName nvarchar(256)
    DECLARE @DocLeafName nvarchar(128)
    DECLARE @DocId uniqueidentifier
    EXEC proc_SplitUrl @DocUrl, @DocDirName OUTPUT, @DocLeafName OUTPUT
    SELECT TOP 1
        @DocId = Id
    FROM
        TVF_Docs_Url(@SiteId, @DocDirName, @DocLeafName) AS Docs
    WHERE
        WebId = @WebId
    IF (@DocId IS NULL)
        RETURN 3
    DECLARE @RC int
    EXEC @RC = proc_InsertEventReceiver
                @Id,
                @Name,
                @SiteId,
                @WebId,
                @DocId,
                3,
                @ItemId,
                NULL,
                NULL,
                @Synchronization,
                @Type,
                @SequenceNumber,
                @Assembly,
                @Class,
                @SolutionId,
                @Data,
                @Filter,
                NULL , 
                0 ,
                @Credential,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                @RequestGuid OUTPUT
    RETURN @RC

go

