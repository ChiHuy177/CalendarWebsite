CREATE FUNCTION [dbo].[TVF_AllDocs_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (INDEX=AllDocs_ParentId, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

