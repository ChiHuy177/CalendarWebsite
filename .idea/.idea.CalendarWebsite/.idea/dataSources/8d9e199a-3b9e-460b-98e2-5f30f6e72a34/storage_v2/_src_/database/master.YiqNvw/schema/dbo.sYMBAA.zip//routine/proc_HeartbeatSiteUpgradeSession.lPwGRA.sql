CREATE PROCEDURE [dbo].[proc_HeartbeatSiteUpgradeSession](
    @SiteId uniqueidentifier,
    @SessionId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @TimeRightNow datetime
    SET @TimeRightNow = GETUTCDATE()
    UPDATE 
        SiteUpgradeSessions
    SET
        LastUpdated = @TimeRightNow
    FROM
        TVF_SiteUpgradeSessions_SiteId(@SiteId) AS SiteUpgradeSessions
    WHERE
        SessionId = @SessionId
    IF (@@ROWCOUNT = 0)
        RETURN 1
    ELSE
        RETURN 0

go

