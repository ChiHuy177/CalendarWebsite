CREATE PROC [dbo].[proc_UpdateUserResource](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ResourceName nvarchar(520),
    @ResourceCategory int,
    @BitType bit,
    @BitDirty bit,
    @LCID int,
    @NVarCharVal nvarchar(256),
    @NtextVal nvarchar(max)
    )
AS
    SET NOCOUNT ON
    DECLARE @WebLCID int
    SELECT TOP 1
        @WebLCID = W.Language
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
    IF EXISTS (
        SELECT TOP 1
            1
        FROM
            TVF_Resources_PK(@SiteId, @WebId, @ListId, @ResourceName, @LCID))
    BEGIN
        UPDATE
            R
        SET
            R.BitDirty = 0,
            R.NvarcharVal = @NVarCharVal,
            R.NtextVal = @NtextVal
        FROM
            TVF_Resources_PK(@SiteId, @WebId, @ListId, @ResourceName, @LCID) AS R
    END
    ELSE
    BEGIN
        EXEC proc_AddUserResource
            @SiteId,
            @WebId,
            @ListId,
            @ResourceName,
            @ResourceCategory,
            @BitType,
            @LCID,
            @NVarCharVal,
            @NtextVal
    END
    IF @WebLCID = @LCID
    BEGIN
        IF @ResourceCategory = 1
        BEGIN
            UPDATE 
                W
            SET 
                W.Title = @NVarCharVal 
            FROM
                TVF_Webs_Id(@SiteId, @WebId) AS W
        END
        ELSE IF @ResourceCategory = 2
        BEGIN
            UPDATE 
                W
            SET 
                W.Description = @NtextVal 
            FROM
                TVF_Webs_Id(@SiteId, @WebId) AS W
        END
        ELSE IF @ResourceCategory = 3
        BEGIN
            UPDATE 
                L
            SET 
                L.tp_Title = @NVarCharVal 
            FROM
                TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
        END
        ELSE IF @ResourceCategory = 4
        BEGIN
            UPDATE 
                L
            SET 
                L.tp_Description = @NtextVal 
            FROM
                TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
        END
        ELSE IF @ResourceCategory = 5
        BEGIN
            DECLARE @Eid int
            SET @Eid = CAST(SUBSTRING(@ResourceName, 9, LEN(@ResourceName)-8) AS int)
            UPDATE 
                NV
            SET 
                NV.Name = @NVarCharVal 
            FROM
                TVF_NavNodes_PK(@SiteId, @WebId, @Eid) AS NV
        END
        UPDATE
            R
        SET
            R.BitDirty = 1
        FROM
            TVF_Resources_SiteWebListResName(@SiteId, @WebId, @ListId, @ResourceName) AS R
        WHERE
            R.LCID <> @WebLCID            
    END   

go

