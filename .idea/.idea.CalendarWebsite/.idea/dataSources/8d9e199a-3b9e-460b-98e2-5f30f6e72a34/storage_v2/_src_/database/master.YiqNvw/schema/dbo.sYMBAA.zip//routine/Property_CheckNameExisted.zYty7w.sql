
-- =============================================
-- Author:		duydam
-- Create date: 24/09/2021
-- Description:	Find Name is belong to another property in the same workflow
-- =============================================
CREATE   PROCEDURE [dbo].[Property_CheckNameExisted] @Name NVARCHAR(max)
	,@WorkflowId BIGINT
	,@PropertyId BIGINT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	IF (@PropertyId IS NULL)
	BEGIN
		SELECT CASE 
				WHEN EXISTS (
						SELECT TOP 1 *
						FROM [dbo].[Property]
						WHERE Name = @Name
							AND WorkflowId = @WorkflowId
							AND IsDeleted = 0
						)
					THEN CAST(1 AS BIT)
				ELSE CAST(0 AS BIT)
				END;
	END
	ELSE
	BEGIN
		SELECT CASE 
				WHEN EXISTS (
						SELECT TOP 1 *
						FROM [dbo].[Property]
						WHERE Name = @Name
							AND WorkflowId = @WorkflowId
							AND Id != @PropertyId
							AND IsDeleted = 0
						)
					THEN CAST(1 AS BIT)
				ELSE CAST(0 AS BIT)
				END;
	END
END
go

