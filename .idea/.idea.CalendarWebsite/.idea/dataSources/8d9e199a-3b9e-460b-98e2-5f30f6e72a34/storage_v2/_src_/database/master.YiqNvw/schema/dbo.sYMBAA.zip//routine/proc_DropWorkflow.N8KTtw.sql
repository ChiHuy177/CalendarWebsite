CREATE PROCEDURE [dbo].[proc_DropWorkflow] (
        @WorkflowInstanceId    uniqueidentifier,
        @SiteId                uniqueidentifier,
        @WebId                 uniqueidentifier,
        @ListId                uniqueidentifier,
        @RequestGuid           uniqueidentifier = NULL OUTPUT   
        )
AS
    SET NOCOUNT ON
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN    
    DECLARE @ProcessingId uniqueidentifier
    DECLARE @InternalState int
    DECLARE @TaskListId uniqueidentifier
    DECLARE @TemplateId uniqueidentifier    
    DECLARE @cbDelta bigint
    SET @cbDelta = 0
    DECLARE @NULL_GUID uniqueidentifier
    SET @NULL_GUID = CONVERT(uniqueidentifier, '00000000-0000-0000-0000-000000000000')
    SELECT TOP 1
        @ProcessingId = WF.LockMachineId,
        @InternalState = WF.InternalState,
        @TaskListId = WF.TaskListId,
        @TemplateId = WF.TemplateId,
        @cbDelta = 
            CASE 
                WHEN @ProcessingId IS NULL THEN ISNULL(-WF.InstanceDataSize,0) 
                ELSE ISNULL(-WF.HistorySize,0) 
            END,
        @WebId = WF.WebId,
        @ListId = WF.ListId
    FROM
        TVF_Workflow_XLock_Id(@SiteId, @WorkflowInstanceId) AS WF
    IF (@InternalState & 2) <> 0
    BEGIN
        IF @TemplateId <> @NULL_GUID
        BEGIN    
            UPDATE
                WFA
            SET
                WFA.InstanceCount = WFA.InstanceCount - 1
            FROM
                TVF_WorkflowAssoc_Id(@SiteId, @TemplateId) AS WFA
        END
    END
    IF @ProcessingId IS NOT NULL
    BEGIN
        EXEC proc_RemoveFailOver @ProcessingId, @SiteId
    END
    DELETE 
        WF
    FROM
        TVF_Workflow_Id(@SiteId, @WorkflowInstanceId) AS WF
    EXEC proc_AppendSiteQuota @SiteId, @cbDelta, 1, NULL
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    EXEC proc_DropWorkflowTasks @WorkflowInstanceId, @SiteId, @WebId, @TaskListId
    IF (@InternalState & 2) <> 0
    BEGIN
        EXEC proc_DeleteContextCollectionEventReceivers @SiteId, @WorkflowInstanceId
        DELETE FROM
            dbo.ScheduledWorkItems
        WHERE
            Type = CAST (N'BDEADF09-C265-11d0-BCED-00A0C90AB50F' as uniqueidentifier) AND
            ParentId = @ListId AND
            SiteId = @SiteId AND
            BatchId = @WorkflowInstanceId
    END

go

