CREATE PROCEDURE [dbo].[proc_GetMetaInfoForSingleDoc](
    @DocSiteId uniqueidentifier,
    @DocDirName nvarchar(256),
    @DocLeafName nvarchar(128),
    @UserId int,
    @Level tinyint,
    @DocWebId uniqueidentifier = NULL)
AS
    SET NOCOUNT ON
    DECLARE @DocParentId uniqueidentifier
    DECLARE @DocId uniqueidentifier
    EXEC proc_GetParentIdAndDocIdForUrl
        @DocSiteId,
        @DocDirName,
        @DocLeafName,
        @DocParentId OUTPUT,
        @DocId OUTPUT
    EXEC proc_GetMetaInfoForSingleDocInternal
        @DocSiteId,
        @DocParentId,
        @DocId,
        @UserId,
        @Level,
        @DocWebId

go

