CREATE     PROCEDURE [Dynamic].[WorkflowDynamicDetailData_Insert] @UserWorkflowId BIGINT
	,@WorkflowId BIGINT
	,@Data_Json NVARCHAR(MAX)
	,@IsRemoveAll BIT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX), @TableCode NVARCHAR(MAX);
	DECLARE @SqlScript NVARCHAR(MAX) = '';

	IF EXISTS (
			SELECT TOP 1 Id
			FROM UserWorkflow
			WHERE Id = @UserWorkflowId
			)
	BEGIN
		SET @TableName =(
			SELECT Title
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
		SET @TableCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)

		SET @TableName = CONCAT (
			'Dynamic.Detail_'
			,dbo.fn_StripCharacters(@TableCode, '^a-z0-9')
			);

		SELECT CONCAT (
				'['
				,p.Name
				,']'
				,(
					CASE 
						WHEN p.IsSingle = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsMultiLine = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsChoice = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsNumber = 1 AND p.IsViewOnly <> 1
							THEN ' decimal(22,4)'
						WHEN p.IsNumber = 1 AND p.IsViewOnly = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsCurrency = 1 AND p.IsViewOnly <> 1
							THEN ' decimal(22,4)'
						WHEN p.IsCurrency = 1 AND p.IsViewOnly = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsDateAndTime = 1
							THEN ' datetime2(7)'
						WHEN p.IsLookup = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsYesNo = 1
							THEN ' bit'
						WHEN p.IsUser = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsCalculated = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsFile = 1
							THEN ' [nvarchar](max)'
						WHEN p.IsApi = 1
							THEN ' [nvarchar](max)'
						ELSE ' [nvarchar](max)'
						END
					)
				) AS QueryString
			,CONCAT (
				'['
				,p.Name
				,']'
				) AS QueryInsert
			--,p.*


		INTO #tempProperties
		FROM Property p
		WHERE p.WorkflowId = @WorkflowId
			AND p.IsDeleted = 0

		Insert INTO #tempProperties (QueryString, QueryInsert)
		VALUES ('[id] bigint', '[id]'); 

		IF @IsRemoveAll = 1
		BEGIN
			SET @SqlScript = @SqlScript + 'DELETE ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';';
		END

		SET @SqlScript = @SqlScript  + ' INSERT INTO ' + @TableName + '(
			[UserWorkflowId] ,' + (
				SELECT STRING_AGG(QueryInsert, ', ')
				FROM #tempProperties
				) + ')' + ' SELECT ' + CAST(@UserWorkflowId AS VARCHAR) + ',* FROM OPENJSON(' + CONCAT (
				'N'
				,''''
				,REPLACE(@Data_Json, '''', '''''')
				,''''
				) + ') WITH (' + (
				SELECT STRING_AGG(QueryString, ', ')
				FROM #tempProperties
				) + ')';

		DROP TABLE #tempProperties;
		print @SqlScript
		EXEC sp_ExecuteSql @SqlScript;
	END
END
go

