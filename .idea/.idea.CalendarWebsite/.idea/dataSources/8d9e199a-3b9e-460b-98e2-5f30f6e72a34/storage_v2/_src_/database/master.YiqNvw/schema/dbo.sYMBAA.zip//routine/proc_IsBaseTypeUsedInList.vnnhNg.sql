CREATE PROC [dbo].[proc_IsBaseTypeUsedInList](
    @SiteId uniqueidentifier,
    @BaseTypes int)
AS
    SET NOCOUNT ON
    IF @BaseTypes = 0 
        RETURN 0
    IF EXISTS (
        SELECT TOP 1
            1
        FROM
            TVF_Webs_SiteId(@SiteId) AS W
        CROSS APPLY
            TVF_Lists_WebId(W.SiteId, W.Id) AS L
        WHERE
            L.tp_BaseType < 31 AND
            (POWER(2, L.tp_BaseType) & @BaseTypes) <> 0)
    BEGIN
        RETURN 1
    END
    RETURN 0

go

