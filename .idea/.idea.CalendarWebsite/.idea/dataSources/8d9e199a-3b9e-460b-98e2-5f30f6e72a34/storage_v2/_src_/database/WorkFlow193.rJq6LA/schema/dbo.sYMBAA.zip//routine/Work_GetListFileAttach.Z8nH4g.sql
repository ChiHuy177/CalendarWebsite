CREATE   PROC [dbo].[Work_GetListFileAttach] 
   @workFlowId as bigint =102 
   ,@UserWorkflowId as nvarchar(1000) 
   as 
   DECLARE @tableDynamic as nvarchar(250),@code as nvarchar(250),@sql as nvarchar(max) 
   set @code=(select Code from Workflow where Id=@workFlowId) 
   set @tableDynamic = ('Dynamic.CheckList_' +trim(@code)) 
   set @sql=' 
   select 
   a.[Id] 
   ,a.[UserWorkflowId] 
   ,a.[CheckListId] 
   ,a.[Name] 
   ,a.[Note] 
   ,a.[Path] 
   ,a.[Type] 
   ,a.[CreatedBy] 
   ,a.[CreatedTime] 
   ,a.[LastModified] 
   ,a.[ModifiedBy] 
   ,a.[IsDeleted] 
   ,b.FullName as modifiedByName
   ,concat(''P:'',b.Id) as userId
   ,c.Title as documentTypeTitle 
   from '+@tableDynamic+' a 
   inner join PersonalProfile b on a.CreatedBy = b.Email 
   inner join CheckList c on a.CheckListId=c.Id 
   where a.UserWorkflowId in (select value from string_split('''+@UserWorkflowId+''','','')) and a.IsDeleted=0 
   ' 
   exec(@sql) 
   print(@sql) 
go

