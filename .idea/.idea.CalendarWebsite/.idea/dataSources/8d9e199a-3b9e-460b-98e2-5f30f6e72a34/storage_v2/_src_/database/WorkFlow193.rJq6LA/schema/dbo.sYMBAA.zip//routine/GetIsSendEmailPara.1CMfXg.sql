
-- =============================================
-- Author:		Duy Dam
-- Create date: 30/11/2021
-- Description:	Get SendEmail Para in this system
-- =============================================
CREATE   PROCEDURE [dbo].[GetIsSendEmailPara] @bit BIT OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (
			SELECT *
			FROM WorkflowPara
			WHERE ParaName = 'SendEmail'
				AND IsSystemPara = 1
			)
	BEGIN
		SET @bit = (
				SELECT CONVERT(BIT, Value)
				FROM WorkflowPara
				WHERE ParaName = 'SendEmail'
					AND IsSystemPara = 1
				)
	END
	ELSE
	BEGIN
		SET @bit = 1;
	END
END
go

