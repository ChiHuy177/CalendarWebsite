CREATE PROCEDURE [dbo].[proc_SetListRequestAccess]
(
    @SiteId        uniqueidentifier,
    @WebId       uniqueidentifier,
    @ListId         uniqueidentifier,
    @RequestAccess  bit,
    @RequestGuid    uniqueidentifier = NULL OUTPUT  
)
AS
    SET NOCOUNT ON
    DECLARE @ReqAcc int
    IF (@RequestAccess = 0)
        SET @ReqAcc = 0x200
    ELSE
        SET @ReqAcc = 0
    UPDATE
        L
    SET
        L.tp_Flags = (L.tp_Flags & (~ CAST (0x200 AS INT))) ^ @ReqAcc
    FROM
        TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
    EXEC proc_LogChange @SiteId, @WebId, @ListId, NULL, NULL, NULL, NULL, NULL,
        8192, 2, NULL

go

