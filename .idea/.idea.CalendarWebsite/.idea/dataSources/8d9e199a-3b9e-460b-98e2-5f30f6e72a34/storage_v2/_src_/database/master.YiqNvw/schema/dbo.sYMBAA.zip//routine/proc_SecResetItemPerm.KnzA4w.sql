CREATE PROCEDURE [dbo].[proc_SecResetItemPerm](
    @SiteId     uniqueidentifier,
    @WebId      uniqueidentifier,
    @OldScopeId uniqueidentifier,
    @Url        nvarchar(260),
    @DocId      uniqueidentifier,
    @NewScopeId uniqueidentifier = NULL OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    IF NOT EXISTS (
        SELECT TOP 1
            1
        FROM
            TVF_Perms_ScopeId(@SiteId, @OldScopeId) AS P
        WHERE
            P.WebId = @WebId AND
            P.ScopeUrl = @Url)
    BEGIN
        RETURN 3
    END
    DECLARE @DirName  nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    DECLARE @ParentDirName  nvarchar(256)
    DECLARE @ParentLeafName nvarchar(128)
    DECLARE @UrlLike nvarchar(1024)
    DECLARE @ListId     uniqueidentifier
    DECLARE @ThicketFlag bit
    DECLARE @ListBaseType int
    IF (@Url IS NOT NULL)
     BEGIN
        EXEC proc_SplitUrl @Url, @DirName OUTPUT, @LeafName OUTPUT
        SELECT TOP 1
            @ThicketFlag = D.ThicketFlag
        FROM
            TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS D
    END
    ELSE
    BEGIN
        SELECT TOP 1
            @ThicketFlag = D.ThicketFlag,
            @DirName = D.DirName,
            @LeafName = D.LeafName,
            @Url = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END
        FROM
            TVF_Docs_Id(@SiteId, @DocId) AS D
    END
    EXEC proc_EscapeForLike @Url, @UrlLike OUTPUT
    EXEC proc_SplitUrl @DirName, @ParentDirName OUTPUT, @ParentLeafName OUTPUT
    SELECT TOP 1
        @NewScopeId = D.ScopeId,
        @ListId = D.ListId
    FROM
        TVF_Docs_Url(@SiteId, @ParentDirName, @ParentLeafName) AS D
    IF @@ROWCOUNT = 0 OR @ListId IS NULL 
    BEGIN
        RETURN 3
    END
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    EXEC proc_LockListAuxForDocumentUpdate @SiteId, @ListId, 0       
    SELECT TOP 1
        @ListBaseType = L.tp_BaseType 
    FROM
        TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
    UPDATE 
        W
    SET 
        W.CachedNavDirty =1 
    FROM
        TVF_Webs_SiteId(@SiteId) AS W
    DELETE
        RA
    FROM    
        TVF_RoleAssignment_SiteId_ScopeID(@SiteId, @OldScopeId) AS RA
    EXEC proc_SecUpdateDepsFromScope @SiteId, @OldScopeId
    EXEC proc_SecLogChange @SiteId, @WebId, @OldScopeId, NULL, NULL, NULL, 
            33554432, 1
    EXEC proc_SecLogChange @SiteId, @WebId, @OldScopeId, NULL, NULL, NULL, 
            41943040, 1
    EXEC proc_SecChangeSecurityScopeForFolderShared 
        @SiteId, @WebId, @ListId, @ListBaseType, @DirName, @LeafName, @Url, 
        @UrlLike, @ThicketFlag, @OldScopeId, @NewScopeId, 
        0  
    DELETE
        P
    FROM 
        TVF_Perms_ScopeId(@SiteId, @OldScopeId) AS P
    EXEC proc_SecUpdateListInternalFGP @SiteId, @WebId, @ListId, 1    
    EXEC proc_SecUpdateSiteLevelSecurityMetadata @SiteId, 1, 0
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    IF @RET <> 0
        RETURN @RET
    EXEC proc_GetAuditMaskSniffItemTypeInternal @SiteId, @DirName, @LeafName, @RequestGuid OUTPUT
    RETURN @RET

go

