CREATE PROCEDURE [dbo].[proc_DeleteDirInternal](
    @WebSiteId       uniqueidentifier,
    @WebId           uniqueidentifier,
    @Url             nvarchar(260),
    @UserId          int,
    @ListDeletedUrls bit,
    @ListDeletedAliases bit,
    @IgnoreLookupRelationshipsCheck bit,
    @DeleteOp        int,
    @DoclibId        uniqueidentifier,
    @DoclibRowId     int,
    @DocId           uniqueidentifier,
    @UrlLike         nvarchar(1024),
    @DeleteDirName   nvarchar(256),
    @DeleteLeafName  nvarchar(256),
    @ItemName        nvarchar(255),
    @DeleteDTM       datetime,
    @ScopeId         uniqueidentifier,
    @ProgId          nvarchar(255),
    @BinId           tinyint,
    @ShowUserName    bit,
    @IsCascadeDeleteOperation bit,
    @IsCascadeParent bit, 
    @DocClientId varbinary(16),
    @ChildDeleteTransactionId varbinary(16) OUTPUT,
    @DeleteTransactionId varbinary(16) OUTPUT,
    @Size            bigint OUTPUT,
    @NewDeleteTransaction bit OUTPUT,
    @ItemCountDelta  int OUTPUT,
    @FreedSpace      bigint OUTPUT,
    @RequestGuid     uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    DECLARE @ReturnStatus int
    SET @ReturnStatus = 0
    DECLARE @NumLists int
    DECLARE @Collation smallint
    DECLARE @EffectiveDeleteTransactionId varbinary(16); 
    SELECT @EffectiveDeleteTransactionId = dbo.fn_GetEffectiveDeleteTransactionId(
        @DeleteTransactionId,
        @ChildDeleteTransactionId,
        @IsCascadeDeleteOperation,
        @IsCascadeParent);
    DECLARE @ListsDeleted table (
        Id uniqueidentifier NOT NULL,
        Flags bigint NOT NULL)
    INSERT INTO @ListsDeleted(
        Id,
        Flags)
    SELECT
        Lists.tp_ID,
        Lists.tp_Flags
    FROM
        TVF_Lists_CI(@WebSiteId, @WebId, @DoclibId) AS Lists
    CROSS APPLY
        TVF_AllListsAux_XLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
    WHERE
        Lists.tp_RootFolder = @DocId
    SET @NumLists = @@ROWCOUNT
    DECLARE @ListId uniqueidentifier
    DECLARE @DeleteItemType tinyint
    IF @NumLists = 1
    BEGIN
        SELECT TOP 1
            @ListId = Id
        FROM
            @ListsDeleted
        SET @DeleteItemType = 4
    END    
    ELSE
    BEGIN
        INSERT INTO @ListsDeleted(
            Id,
            Flags)
        SELECT
            Lists.tp_ID,
            Lists.tp_Flags
        FROM
            TVF_Docs_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS Docs
        CROSS APPLY
            TVF_Lists_CI(Docs.SiteId, @WebId, Docs.ListId) AS Lists
        CROSS APPLY
            TVF_AllListsAux_XLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
        WHERE
            Lists.tp_RootFolder = Docs.Id AND
            Docs.Type = 1
        OPTION (FORCE ORDER)
        IF (@@ROWCOUNT > 0)
            SET @DeleteItemType = 6
        ELSE    
            SET @DeleteItemType = 5
    END
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
            @ListsDeleted
        WHERE
            (Flags & 0x04) <> 0)
    BEGIN
        SET @ReturnStatus = 8398
        GOTO cleanup
    END
    IF @IgnoreLookupRelationshipsCheck = 0
    BEGIN
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                @ListsDeleted AS LD
            CROSS APPLY
                TVF_AllLookupRelationships_SiteLookupList(@WebSiteId, LD.Id) AS ALR
            CROSS APPLY
                TVF_Lists_Id(ALR.SiteId, ALR.ListId) AS L
            WHERE
                ALR.ListId <> ALR.LookupListId AND ALR.DeleteBehavior <> 0)
        BEGIN
            SET @ReturnStatus = 4335;
            GOTO cleanup
        END
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                @ListsDeleted AS LD
            CROSS APPLY
                TVF_AllLookupRelationships_SiteList(@WebSiteId, LD.Id) AS ALR
            CROSS APPLY
                TVF_Lists_Id(ALR.SiteId, ALR.LookupListId) AS L
            WHERE
                ALR.ListId <> ALR.LookupListId AND ALR.DeleteBehavior <> 0)
        BEGIN
            SET @ReturnStatus = 4335
            GOTO cleanup
        END
    END
    DECLARE @SessionID smallint
    SET @SessionID = @@SPID
    IF (@SessionID IS NULL)
    BEGIN
        SET @SessionID = 0
    END
    IF @DeleteOp = 4 AND
        (@DeleteTransactionId IS NULL OR 
         @DeleteTransactionId = 0x OR
            (@IsCascadeDeleteOperation = 1 AND @ChildDeleteTransactionId IS NULL))
    BEGIN
        DECLARE @AuthorId int
        DECLARE @Title nvarchar(260)
        IF @NumLists = 1
        BEGIN
            SELECT TOP 1
                @AuthorId = tp_Author,
                @Title = tp_Title
            FROM
                TVF_Lists_CI(@WebSiteId, @WebId, @DoclibId) AS Lists
        END
        ELSE
        BEGIN
            SELECT TOP 1
                @AuthorId = UD.tp_Author
            FROM
                TVF_UserData_ListItem(@WebSiteId, @DoclibId, @DoclibRowId) AS UD
            ORDER BY
                UD.tp_Level DESC 
            SET @Title = @DeleteLeafName    
        END
        DECLARE @ListDirName nvarchar(256)
        IF @DeleteItemType = 5
        BEGIN
            SELECT TOP 1
                @ListDirName = CASE WHEN (DATALENGTH(Docs.DirName) = 0) THEN Docs.LeafName WHEN (DATALENGTH(Docs.LeafName) = 0) THEN Docs.DirName ELSE Docs.DirName + N'/' + Docs.LeafName END
            FROM
                TVF_Lists_CI(@WebSiteId, @WebId, @DoclibId) AS Lists
            CROSS APPLY
                TVF_Docs_Id_Level(Lists.tp_SiteId, Lists.tp_RootFolder, 1) AS Docs
        END
        SET @NewDeleteTransaction = 1
        IF @IsCascadeDeleteOperation = 1
        BEGIN
            IF (@DeleteTransactionId IS NULL OR @DeleteTransactionId = 0x)
            BEGIN
                SET @DeleteTransactionId = NEWID();
            END
            IF @IsCascadeParent = 1
            BEGIN
                SET @ChildDeleteTransactionId = 0x;
            END
            ELSE
            BEGIN
                SET @ChildDeleteTransactionId = NEWID();
            END
        END
        ELSE
        BEGIN
            SET @DeleteTransactionId = NEWID();
            SET @ChildDeleteTransactionId = 0x;
        END
        SELECT @EffectiveDeleteTransactionId = dbo.fn_GetEffectiveDeleteTransactionId(
            @DeleteTransactionId,
            @ChildDeleteTransactionId,
            @IsCascadeDeleteOperation,
            @IsCascadeParent);
        INSERT INTO RecycleBin (
            SiteId,
            WebId,
            BinId,
            DeleteUserId,
            DeleteTransactionId,
            ChildDeleteTransactionId, 
            DeleteDate,
            ItemType,
            OriginalItemType,
            ListId,
            DocId,
            DocVersionId,
            ListItemId,
            Title,
            DirName,
            LeafName,
            AuthorId,
            Size,
            ListDirName,
            ScopeId,
            ProgId,
            EffectiveDeleteTransactionId)
        VALUES (
            @WebSiteId,
            @WebId,
            @BinId,
            @UserId,
            @DeleteTransactionId,
            @ChildDeleteTransactionId, 
            @DeleteDTM,
            CASE 
                WHEN (@IsCascadeParent = 1) THEN 9
                ELSE @DeleteItemType
            END,
            CASE 
                WHEN (@IsCascadeParent = 1) THEN @DeleteItemType
                ELSE NULL
            END,
            @DoclibId,
            @DocId,
            NULL,
            @DoclibRowId,
            ISNULL(@Title,''),
            @DeleteDirName,
            @DeleteLeafName,
            CASE WHEN @ShowUserName = 1 THEN @AuthorId ELSE NULL END,
            0,
            @ListDirName,
            @ScopeId,
            @ProgId,
            CASE WHEN @ChildDeleteTransactionId = 0x THEN @DeleteTransactionId ELSE @ChildDeleteTransactionId END)
    END
    IF @ListDeletedUrls = 1
    BEGIN
        SELECT
            CASE WHEN (DATALENGTH(DirName) = 0) THEN LeafName WHEN (DATALENGTH(LeafName) = 0) THEN DirName ELSE DirName + N'/' + LeafName END, Type
        FROM
            TVF_Docs_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS Docs
        WHERE
            (Type = 0 OR
                Type = 1)
        UNION ALL 
        SELECT
            @Url, 1 
    END
    IF @ListDeletedAliases = 1
    BEGIN
        SELECT
            @WebSiteId,
            Lists.tp_WebId,
            Lists.tp_ID
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_Lists_Id(@WebSiteId, LD.Id) AS Lists
        WHERE
            Lists.tp_EmailAlias IS NOT NULL
        OPTION (FORCE ORDER)
    END
    EXEC proc_DirtyDependents @WebSiteId, 1, NULL, @UrlLike
    IF @DoclibRowId IS NOT NULL
    BEGIN
        DECLARE @DocLibRowsDeleted table (
            Id int NOT NULL)
        INSERT INTO @DocLibRowsDeleted(
            Id)
        VALUES(
            @DoclibRowId)
        INSERT INTO @DocLibRowsDeleted(
            Id)
        SELECT
            Docs.DoclibRowId
        FROM
            TVF_Docs_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS Docs
        WHERE
            Docs.DoclibRowId IS NOT NULL AND
            Docs.IsCurrentVersion = 1
        DECLARE @ListRootUrl nvarchar(260)
        DECLARE @AttachmentSubfolderUrl nvarchar(260)
        SELECT TOP 1
            @ListRootUrl = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END,
            @AttachmentSubfolderUrl = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END + N'/'+ N'Attachments'
        FROM
            TVF_Lists_CI(@WebSiteId, @WebId, @DoclibId) AS L
        CROSS APPLY
            TVF_Docs_NoLock_Id(@WebSiteId, L.tp_RootFolder) AS D
        DECLARE @AttachmentsFolderDeltaSize bigint
        SELECT
            @AttachmentsFolderDeltaSize = SUM(-SM.TotalSize)
        FROM
            @DocLibRowsDeleted AS DD
        CROSS APPLY
            TVF_Docs_Url(
                @WebSiteId, 
                @AttachmentSubfolderUrl, 
                CAST(DD.Id AS nvarchar(128))) AS D
        CROSS APPLY
            TVF_StorageMetrics_DocId(D.SiteId, D.Id) AS SM
        DECLARE @AttachmentsFolderDirName nvarchar(256)
        DECLARE @AttachmentsFolderLeafName nvarchar(128)
        EXEC proc_SplitUrl @AttachmentSubfolderUrl, 
                @AttachmentsFolderDirName OUTPUT, @AttachmentsFolderLeafName OUTPUT
        DECLARE @AttachmentsFolderDocId uniqueidentifier
        SELECT
            @AttachmentsFolderDocId = D.Id
        FROM
            TVF_Docs_Url(@WebSiteId, @AttachmentsFolderDirName, @AttachmentsFolderLeafName) AS D
        IF (@AttachmentsFolderDocId IS NOT NULL)
        BEGIN
            EXEC proc_AddStorageMetricsChange @WebSiteId, @AttachmentsFolderDocId, @AttachmentsFolderDeltaSize, 1
        END
        IF (@DeleteOp = 3)
        BEGIN
            DELETE
                UD
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_UserDataVersioned_ListItem(@WebSiteId, @DoclibId, DD.Id) AS UD
            OPTION (FORCE ORDER)
            INSERT INTO SiteQuota
                (SiteId, SessionId, SMOpCode, DocId, DiskUsed, UpdateTimeStamp)
            SELECT
                @WebSiteId,
                @SessionID,
                2,
                D.Id,
                0,
                0
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY 
                TVF_Docs_DirNameEqLike_Value(
                    @WebSiteId, 
                    @AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)),
                    dbo.fn_EscapeForLike(@AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)), 1)) AS D
            INSERT INTO SiteQuota
                (SiteId, SessionId, SMOpCode, DocId, DiskUsed, UpdateTimeStamp)
            SELECT
                @WebSiteId,
                @SessionID,
                2,
                D.Id,
                0,
                0
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_Docs_Url(
                    @WebSiteId, 
                    @AttachmentSubfolderUrl, 
                    CAST(DD.Id AS nvarchar(128))) AS D
            DELETE
                DocsForDelete            
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY 
                TVF_Docs_DirNameEqLike_Value(
                    @WebSiteId, 
                    @AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)),
                    dbo.fn_EscapeForLike(@AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)), 1)) AS D
            CROSS APPLY
                TVF_Docs_CI(D.SiteId, D.ParentId, D.Id, D.Level) AS DocsForDelete
            OPTION (FORCE ORDER, MAXDOP 1)
            Delete 
                D
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_Docs_Url(
                @WebSiteId, 
                @AttachmentSubfolderUrl, 
                CAST(DD.Id AS nvarchar(128))) AS D
            OPTION (FORCE ORDER, MAXDOP 1)
            EXEC proc_GetCollation @WebSiteId, @ListId, @Collation OUTPUT
    IF @Collation = 0
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 1
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 2
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 3
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 4
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 5
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 6
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 7
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 8
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 9
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 10
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 11
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 12
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 13
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 14
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 15
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 16
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 17
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 18
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 19
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 20
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 21
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 22
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 23
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 24
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 25
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 26
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 27
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 28
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 29
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 30
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 31
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 32
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 33
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 34
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 35
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 36
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 37
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 38
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 39
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 40
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 41
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 42
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 43
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 44
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 45
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 46
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 47
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 48
    BEGIN
        DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
            NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_MatchUserData)
        ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
    END
    DELETE NVP FROM @DocLibRowsDeleted AS DD INNER LOOP JOIN
        NameValuePair AS NVP WITH (INDEX=NameValuePair_MatchUserData)
    ON DD.Id = NVP.ItemId WHERE SiteId = @WebSiteId AND ListId = @DoclibId OPTION (FORCE ORDER)
            DELETE 
                I
            FROM
                @DocLibRowsDeleted AS DL
            CROSS APPLY
                TVF_ImmedSubscriptions_SiteIdListIdItemId(@WebSiteId, @DoclibId, DL.Id) AS I
            OPTION(FORCE ORDER)
            DELETE 
                S
            FROM
                @DocLibRowsDeleted AS DL
            CROSS APPLY
                TVF_SchedSubscriptions_SiteIdListIdItemId(@WebSiteId, @DoclibId, DL.Id) AS S
            OPTION(FORCE ORDER)
        END
        ELSE
        BEGIN
            SET @Size = @Size + (
                SELECT
                    (ISNULL((SUM(CAST((ISNULL(tp_Size, 0)) AS BIGINT))),0))
                FROM
                    @DocLibRowsDeleted AS DD
                CROSS APPLY
                    TVF_UserDataVersioned_ListItem(@WebSiteId, @DoclibId, DD.Id) AS UD)
            UPDATE
                UD
            SET
                tp_DeleteTransactionId = @EffectiveDeleteTransactionId
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_UserDataVersioned_ListItem(@WebSiteId, @DoclibId, DD.Id) AS UD
            OPTION (FORCE ORDER)
            SELECT
                @Size = @Size + ISNULL(
                    SUM(CAST(ISNULL(D.Size, 0) AS BIGINT) +
                        CAST(ISNULL(D.MetaInfoSize, 0) AS BIGINT) +
                        CAST(ISNULL(D.UnVersionedMetaInfoSize,0) AS BIGINT) +
                        CAST(D.FileFormatMetaInfoSize AS BIGINT) +
                        CAST(152 AS BIGINT)), 0)
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY 
                TVF_Docs_DirNameEqLike_Value(
                    @WebSiteId, 
                    @AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)),
                    dbo.fn_EscapeForLike(@AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)), 1)) AS D
            OPTION (FORCE ORDER, MAXDOP 1)
            UPDATE
                DocsForDelete            
            SET    
                DocsForDelete.DeleteTransactionId = @EffectiveDeleteTransactionId
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY 
                TVF_Docs_DirNameEqLike_Value(
                    @WebSiteId, 
                    @AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)),
                    dbo.fn_EscapeForLike(@AttachmentSubfolderUrl + '/' + CAST(DD.Id AS nvarchar(128)), 1)) AS D
            CROSS APPLY
                TVF_Docs_CI(D.SiteId, D.ParentId, D.Id, D.Level) AS DocsForDelete
            OPTION (FORCE ORDER, MAXDOP 1)
            SELECT
                @Size = @Size + ISNULL(
                    SUM(CAST(ISNULL(D.Size, 0) AS BIGINT) +
                        CAST(ISNULL(D.MetaInfoSize, 0) AS BIGINT) +
                        CAST(ISNULL(D.UnVersionedMetaInfoSize,0) AS BIGINT) +
                        CAST(D.FileFormatMetaInfoSize AS BIGINT) +
                        CAST(152 AS BIGINT)), 0)
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_Docs_Url(
                @WebSiteId, 
                @AttachmentSubfolderUrl, 
                CAST(DD.Id AS nvarchar(128))) AS D
            OPTION (FORCE ORDER, MAXDOP 1)
            UPDATE
                D 
            SET    
                D.DeleteTransactionId = @EffectiveDeleteTransactionId
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_Docs_Url(
                @WebSiteId, 
                @AttachmentSubfolderUrl, 
                CAST(DD.Id AS nvarchar(128))) AS D
            OPTION (FORCE ORDER, MAXDOP 1)
            UPDATE
                I
            SET
                I.Deleted = 1
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_ImmedSubscriptions_SiteIdListIdItemId(@WebSiteId, @DoclibId, DD.Id) AS I
            OPTION (FORCE ORDER)
            UPDATE
                S
            SET
                S.Deleted = 1
            FROM
                @DocLibRowsDeleted AS DD
            CROSS APPLY
                TVF_SchedSubscriptions_SiteIdListIdItemId(@WebSiteId, @DoclibId, DD.Id) AS S
            OPTION (FORCE ORDER)
        END
    END
    EXEC proc_NavStructDeleteNodesByUrlDir @WebSiteId, @DeleteDirName,
        @DeleteLeafName, @Url, @UrlLike
    DECLARE @DocsDeleted table (
        Id uniqueidentifier NOT NULL,
        DocType tinyint NULL,
        DoclibRowId int NULL,
        IsCurrentVersion bit NOT NULL)
    INSERT INTO @DocsDeleted(
        Id,
        DocType,
        DoclibRowId,
        IsCurrentVersion)
    SELECT
        Id,
        Type,
        DoclibRowId,
        IsCurrentVersion
    FROM
        TVF_Docs_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS Docs
    IF @DeleteItemType = 5
        SET @ItemCountDelta = 
            (SELECT
                COUNT(1)
            FROM
                @DocsDeleted
            WHERE
                DoclibRowId IS NOT NULL AND
                IsCurrentVersion = 1)
    IF (@DeleteOp = 3)
    BEGIN
        DECLARE @TransactionsDeleted table (
            DeleteTransactionId varbinary(16),
            BinId tinyint,
            Size bigint)
        IF @DeleteItemType = 4 OR
            @DeleteItemType = 6
        BEGIN
            INSERT INTO @TransactionsDeleted 
                (DeleteTransactionId, BinId, Size)
            SELECT 
                R.DeleteTransactionId, R.BinId, R.Size
            FROM 
                @ListsDeleted LD
            CROSS APPLY
                TVF_RecycleBin_List(LD.Id) AS R
            OPTION (FORCE ORDER)
            INSERT INTO @DocsDeleted 
                (Id, IsCurrentVersion)
            SELECT
                AD.Id, 
                AD.IsCurrentVersion
            FROM
                @TransactionsDeleted TD
            CROSS APPLY
                TVF_AllDocs_SiteDelTransId(@WebSiteId, TD.DeleteTransactionId) AS AD
            OPTION (FORCE ORDER)
        END
        IF @DeleteItemType = 5
        BEGIN
            INSERT INTO @TransactionsDeleted 
                (DeleteTransactionId, BinId, Size)
            SELECT 
                R.DeleteTransactionId,
                R.BinId,
                R.Size
            FROM
                @DocsDeleted AS DD
            CROSS APPLY
                TVF_AllDocVersions_SiteDocId(@WebSiteId, DD.Id) AS ADV
            CROSS APPLY
                TVF_RecycleBin_EffDelId(ADV.SiteId, ADV.DeleteTransactionId) AS R
            WHERE
                ADV.DeleteTransactionId <> 0x AND
                R.ListId = @ListId
            OPTION (FORCE ORDER)
        END
        ELSE IF @DeleteItemType = 6
        BEGIN
            INSERT INTO @TransactionsDeleted 
                (DeleteTransactionId, BinId, Size)
            SELECT 
                R.DeleteTransactionId,
                R.BinId,
                R.Size
            FROM
                @DocsDeleted AS DD
            CROSS APPLY
                TVF_AllDocVersions_SiteDocId(@WebSiteId, DD.Id) AS ADV
            CROSS APPLY
                TVF_RecycleBin_EffDelId(ADV.SiteId, ADV.DeleteTransactionId) AS R
            WHERE
                ADV.DeleteTransactionId <> 0x AND
                R.ListId IS NULL
            OPTION (FORCE ORDER)
        END
        SET @FreedSpace = @FreedSpace + ISNULL((
            SELECT
                SUM(Size)
            FROM
                @TransactionsDeleted
            WHERE
                BinId = 1), 0)
        DELETE
            AUD
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllUserData_List(@WebSiteId, LD.Id) AS AUD
        OPTION (FORCE ORDER)
        EXEC proc_GetCollation @WebSiteId, @ListId, @Collation OUTPUT
    IF @Collation = 0
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 1
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 2
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 3
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 4
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 5
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 6
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 7
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 8
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 9
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 10
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 11
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 12
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 13
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 14
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 15
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 16
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 17
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 18
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 19
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 20
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 21
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 22
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 23
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 24
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 25
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 26
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 27
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 28
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 29
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 30
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 31
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 32
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 33
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 34
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 35
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 36
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 37
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 38
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 39
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 40
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 41
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 42
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 43
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 44
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 45
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 46
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 47
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 48
    BEGIN
        DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
            NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_CI)
        ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
    END
    DELETE NVP FROM @ListsDeleted AS LD INNER LOOP JOIN
        NameValuePair AS NVP WITH (INDEX=NameValuePair_CI)
    ON LD.Id = NVP.ListId WHERE SiteId = @WebSiteId OPTION (FORCE ORDER)
        DELETE 
            WPL
        FROM
            @DocsDeleted DD
        CROSS APPLY
            TVF_WebPartLists_SitePage(@WebSiteId, DD.Id) AS WPL
        OPTION (FORCE ORDER)
        DELETE 
            WPL
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_WebPartLists_List(LD.Id) AS WPL
        OPTION (FORCE ORDER)
        DELETE 
            AWP
        FROM
            @DocsDeleted DD
        CROSS APPLY
            TVF_AllWebParts_SitePageId(@WebSiteId, DD.Id) AS AWP
        OPTION (FORCE ORDER)
        DELETE 
            AWP
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_AllWebParts_List(@WebSiteId, LD.Id) AS AWP
        OPTION (FORCE ORDER)
        DELETE
            AppPerms
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_AppPrincipalPerms_SiteId_WebId_ListId(@WebSiteId, @WebId, LD.Id) AS AppPerms
        OPTION(FORCE ORDER)
        DELETE 
            I
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_ImmedSubscriptions_SiteIdListId(@WebSiteId, LD.Id) AS I
        OPTION(FORCE ORDER)
        DELETE 
            S
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_SchedSubscriptions_SiteIdListId(@WebSiteId, LD.Id) AS S
        OPTION(FORCE ORDER)
        DELETE 
            AL
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_AllLists_CI(@WebSiteId, @WebId, LD.Id) AS AL
        OPTION (FORCE ORDER)
        DELETE 
            ALP
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_AllListsPlus_ListId(@WebSiteId, LD.Id) AS ALP
        OPTION (FORCE ORDER)
        DELETE
            ALAux
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllListsAux_ListId(@WebSiteId, LD.Id) AS ALAux
        OPTION (FORCE ORDER)
        DELETE 
            R
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_Resources_SiteWebList(@WebSiteId, @WebId, LD.Id) AS R
        OPTION (FORCE ORDER)
        DELETE 
            CA
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_CustomActions_CIAllLevels(@WebSiteId, @WebId, LD.Id) AS CA
        OPTION (FORCE ORDER)
        DELETE 
            ALR
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllLookupRelationships_SiteList(@WebSiteId, LD.Id) AS ALR
        OPTION (FORCE ORDER)
        DELETE 
            ALUF
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_AllListUniqueFields_SiteList(@WebSiteId, LD.Id) AS ALUF
        OPTION (FORCE ORDER)
        DELETE
            AUDJ
        FROM
            @DocsDeleted AS DD
        CROSS APPLY
            TVF_Docs_Id(@WebSiteId, DD.Id) AS Docs
        CROSS APPLY
            TVF_UserDataJunctionsVersioned_SiteParIdDocId(
                Docs.SiteId,
                Docs.ParentId,
                Docs.Id) AS AUDJ
        OPTION (FORCE ORDER)
        DELETE
            AUDJ
        FROM
           @TransactionsDeleted TR
        CROSS APPLY
            TVF_AllUserDataJunctions_SiteDel(
                @WebSiteId, 
                TR.DeleteTransactionId) AS AUDJ
        OPTION (FORCE ORDER)
        DELETE 
            R
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_RecycleBin_List(LD.Id) AS R
        OPTION (FORCE ORDER)
        DELETE 
            ER
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_EventReceivers_SiteWebHost(@WebSiteId, @WebId, LD.Id) AS ER
        OPTION (FORCE ORDER)
        DELETE 
            CTU
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_ContentTypeUsage_SiteIsFList(
                @WebSiteId, 
                0 , 
                LD.Id) AS CTU
        WHERE
            CTU.WebId = @WebId
        OPTION (FORCE ORDER)
        DELETE 
            CTU
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_ContentTypeUsage_SiteIsFList(
                @WebSiteId, 
                1 , 
                LD.Id) AS CTU
        WHERE
            CTU.WebId = @WebId
        OPTION (FORCE ORDER)
        UPDATE
            WFA
        SET
            WFA.Configuration = WFA.Configuration | 512
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_WorkflowAssoc_SiteWebList(@WebSiteId, @WebId, LD.Id) AS WFA
        OPTION (FORCE ORDER)
        DELETE FROM
            ScheduledWorkItems
        WHERE
            SiteId = @WebSiteId AND
            ParentId IN (SELECT LD.Id FROM @ListsDeleted LD)
        DELETE
            ADV
        FROM
            @DocsDeleted AS DD
        CROSS APPLY
            TVF_AllDocVersions_SiteDocId(@WebSiteId, DD.Id) AS ADV
        OPTION (FORCE ORDER)
        DELETE
            Links
        FROM
            TVF_Docs_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS Docs
        CROSS APPLY
            TVF_Links_PagLock_PId_DId_Lvl(Docs.SiteId, Docs.ParentId, Docs.Id, Docs.Level) AS Links
        OPTION (FORCE ORDER, MAXDOP 1)
        DELETE
            AD
        FROM
            @DocsDeleted AS DD
        CROSS APPLY
            TVF_AllDocs_Id(@WebSiteId, DD.Id) AS AD
        OPTION (FORCE ORDER)
        DECLARE @docsToDelete tvpStreamMetadata2
        INSERT INTO @docsToDelete (DocId)
        SELECT Id FROM @DocsDeleted
        EXEC proc_DeleteStreams @WebSiteId, @docsToDelete
        DELETE 
            R
        FROM
            @TransactionsDeleted TD
        CROSS APPLY
            TVF_RecycleBin_DelId(@WebSiteId, TD.DeleteTransactionId) AS R
        WHERE
            R.WebId = @WebId
        OPTION (FORCE ORDER)
        DELETE
            BDForDelete
        FROM
            TVF_BuildDependencies_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS BD
        CROSS APPLY
            TVF_BuildDependencies_Url(BD.SiteId, BD.DirName, BD.LeafName) AS BDForDelete
        OPTION (FORCE ORDER)
        INSERT INTO SiteQuota
            (SiteId, SessionId, SMOpCode, DocId, DiskUsed, UpdateTimeStamp)
        SELECT
            @WebSiteId,
            @SessionID,
            2,
            DD.Id,
            0,
            0
        FROM
            @DocsDeleted AS DD
        UNION ALL
        SELECT
            @WebSiteId,
            @SessionID,
            2,
            @DocId,
            0,
            0
    END
    ELSE
    BEGIN
        SET @Size = @Size + (
            SELECT
                (ISNULL((SUM(CAST((ISNULL(tp_Size, 0)) AS BIGINT))),0))
            FROM
                @ListsDeleted AS LD
            CROSS APPLY
                TVF_UserDataVersioned_List(@WebSiteId, LD.Id) AS UD)
        UPDATE
            UD
        SET
            tp_DeleteTransactionId = @EffectiveDeleteTransactionId
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_UserDataVersioned_List(@WebSiteId, LD.Id) AS UD
        OPTION (FORCE ORDER)
        IF EXISTS(SELECT TOP 1 1 FROM @ListsDeleted)
        BEGIN
            DECLARE @WebPartPagesAffected table (
                DocId uniqueidentifier NOT NULL,
                DeleteTransactionId varbinary(16)
                    NOT NULL,
                SizeDelta bigint NOT NULL)
            INSERT INTO @WebPartPagesAffected
                (DocId, DeleteTransactionId, SizeDelta)
            SELECT
                AD.Id,
                AD.DeleteTransactionId,
                ISNULL(WP.tp_Size, 0)
            FROM    
                @ListsDeleted LD
            CROSS APPLY
                TVF_WebParts_List(@WebSiteId, LD.Id) AS WP
            CROSS APPLY
                TVF_AllDocs_Id(@WebSiteId, WP.tp_PageUrlID) AS AD
            WHERE
                AD.DeleteTransactionId <> 0x AND
                AD.ListId NOT IN (SELECT LD2.Id FROM @ListsDeleted LD2)
            OPTION (FORCE ORDER)
            INSERT INTO 
                @WebPartPagesAffected(
                    DocId, 
                    DeleteTransactionId, 
                    SizeDelta)
            SELECT
                P.tp_PageUrlID,
                S.DeleteTransactionId,
                ISNULL(P.tp_Size, 0)
            FROM
                @WebPartPagesAffected S
            CROSS APPLY
                TVF_Personalization_SitePage(@WebSiteId, S.DocId) AS P
            OPTION (FORCE ORDER)
            UPDATE
                R
            SET
                R.Size = R.Size - ISNULL((
                    SELECT
                        SUM(SizeDelta)
                    FROM
                        @WebPartPagesAffected S
                    WHERE
                        S.DeleteTransactionId = R.EffectiveDeleteTransactionId),0)
            FROM
                @WebPartPagesAffected WPPA
            CROSS APPLY
                TVF_RecycleBin_EffDelId(@WebSiteId, WPPA.DeleteTransactionId) AS R
            OPTION (FORCE ORDER)
            SET @FreedSpace = @FreedSpace + ISNULL((
                SELECT
                    SUM(SizeDelta)
                FROM
                    @WebPartPagesAffected S
                CROSS APPLY
                    TVF_RecycleBin_EffDelId(@WebSiteId, S.DeleteTransactionId) AS R
                WHERE
                    R.BinId = 1), 0)
            DELETE 
                WPL
            FROM
                @ListsDeleted LD
            CROSS APPLY
                TVF_WebPartLists_List(LD.Id) AS WPL
            WHERE
                NOT EXISTS (
                    SELECT TOP 1
                        1
                    FROM 
                        @ListsDeleted LD2
                    CROSS APPLY
                        TVF_AllDocs_Id(@WebSiteId, WPL.tp_PageUrlID) AS AD
                    WHERE
                        AD.ListId = LD2.Id)
            OPTION (FORCE ORDER)
            DELETE 
                WP
            FROM
                @ListsDeleted LD
            CROSS APPLY
                TVF_WebParts_List(@WebSiteId, LD.Id) AS WP
            WHERE
                NOT EXISTS (
                    SELECT TOP 1
                        1
                    FROM
                        @ListsDeleted LD2
                    CROSS APPLY
                        TVF_AllDocs_Id(@WebSiteId, WP.tp_PageUrlID) AS AD
                    WHERE 
                        AD.ListId = LD2.Id)
            OPTION (FORCE ORDER)
        END
        SET @Size = @Size + (
            SELECT
                (ISNULL((SUM(CAST((ISNULL(WP.tp_Size, 0)) AS BIGINT))),0))
            FROM
                @DocsDeleted DD
            CROSS APPLY
                TVF_WebParts_SitePageId(@WebSiteId, DD.Id) AS WP)
        UPDATE
            P
        SET
            P.tp_Deleted = 1
        FROM
            @DocsDeleted DD
        CROSS APPLY
            TVF_Personalization_SitePage(@WebSiteId, DD.Id) AS P
        OPTION (FORCE ORDER)
        UPDATE
            WP
        SET
            WP.tp_Deleted = 1
        FROM
            @DocsDeleted DD
        CROSS APPLY
            TVF_WebParts_SitePageId(@WebSiteId, DD.Id) AS WP
        OPTION (FORCE ORDER)
        UPDATE
            I
        SET
            I.Deleted = 1
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_ImmedSubscriptions_SiteIdListId(@WebSiteId, LD.Id) AS I
        OPTION (FORCE ORDER)
        UPDATE
            S
        SET
            S.Deleted = 1
        FROM
            @ListsDeleted LD
        CROSS APPLY
            TVF_SchedSubscriptions_SiteIdListId(@WebSiteId, LD.Id) AS S
        OPTION (FORCE ORDER)
        UPDATE
            Lists
        SET
            tp_DeleteTransactionId = @EffectiveDeleteTransactionId,
            tp_EmailAlias = NULL
        FROM
            @ListsDeleted AS LD
        CROSS APPLY
            TVF_Lists_CI(@WebSiteId, @WebId, LD.Id) AS Lists
        OPTION (FORCE ORDER)
        SET @Size = @Size + (
            SELECT
                (ISNULL((SUM(CAST((ISNULL(Size, 0) + ISNULL(MetaInfoSize, 0)) AS BIGINT))),0))
            FROM
                @DocsDeleted AS DD
            CROSS APPLY
                TVF_DocVersions_SiteDocId(@WebSiteId, DD.Id) AS DV)
        UPDATE
            AUDJ
        SET
            AUDJ.tp_DeleteTransactionId = @EffectiveDeleteTransactionId
        FROM
            @DocsDeleted DD
        CROSS APPLY
            TVF_Docs_Id(@WebSiteId, DD.Id) AS Docs
        CROSS APPLY
            TVF_UserDataJunctionsVersioned_SiteParIdDocId(
                @WebSiteId,
                Docs.ParentId,
                Docs.Id) AS AUDJ
        OPTION (FORCE ORDER)
        UPDATE
            DV
        SET
            DeleteTransactionId = @EffectiveDeleteTransactionId
        FROM
            @DocsDeleted AS DD
        CROSS APPLY
            TVF_DocVersions_SiteDocId(@WebSiteId, DD.Id) AS DV
        OPTION (FORCE ORDER)
        SET @Size = @Size + ISNULL((
            SELECT
                SUM(CAST(ISNULL(Size, 0) AS BIGINT) +
                    CAST(ISNULL(MetaInfoSize, 0) AS BIGINT) +
                    CAST(ISNULL(UnVersionedMetaInfoSize,0) AS BIGINT) +
                    CAST(FileFormatMetaInfoSize AS BIGINT) +
                    CAST(152 AS BIGINT))
            FROM
                TVF_Docs_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS Docs), 0)
        UPDATE
            Links
        SET
            DeleteTransactionId = @EffectiveDeleteTransactionId
        FROM
            TVF_Docs_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS Docs
        CROSS APPLY
            TVF_Links_PId_DId_Lvl(Docs.SiteId, Docs.ParentId, Docs.Id, Docs.Level) AS Links
        OPTION (FORCE ORDER, MAXDOP 1)
        UPDATE
            Docs
        SET
            DeleteTransactionId = @EffectiveDeleteTransactionId,
            BuildDependencySet = NULL
        FROM
            TVF_Docs_DirNameEqLike_NotForDelete(@WebSiteId, @Url, @UrlLike) AS Docs
        DELETE
            BDForDelete
        FROM
            TVF_BuildDependencies_DirNameEqLike_Value(@WebSiteId, @Url, @UrlLike) AS BD
        CROSS APPLY
            TVF_BuildDependencies_Url(BD.SiteId, BD.DirName, BD.LeafName) AS BDForDelete
        OPTION (FORCE ORDER)
    END
    DECLARE @fileFragsQuota bigint
    SET @fileFragsQuota = ISNULL((
        SELECT
            (SUM(CAST((F.BlobSize) AS BIGINT)))
        FROM
            @DocsDeleted D
        CROSS APPLY
            TVF_AllFileFragments_XLock_DocId(@WebSiteId, D.Id) AS F),0)
    DELETE 
        F
    FROM
        @DocsDeleted D
    CROSS APPLY
        TVF_AllFileFragments_DocId(@WebSiteId, D.Id) AS F
    OPTION (FORCE ORDER)
    SET @FreedSpace = @FreedSpace + @fileFragsQuota
    IF @NumLists = 1
    BEGIN
        EXEC proc_LogChange @WebSiteId, @WebId, @ListId, NULL, NULL, NULL,
            NULL, @Url, 16384,  2,
            @DeleteDTM, NULL, NULL, NULL, @UserId, NULL, @RequestGuid OUTPUT
    END
    ELSE IF @DoclibRowId IS NOT NULL
    BEGIN
        IF @ItemName IS NULL
           SET @ItemName = @DeleteLeafName
        DECLARE @DelEventType int
        SET @DelEventType = 
            CASE WHEN (@IsCascadeDeleteOperation = 1 AND @IsCascadeParent = 0)
            THEN 16384
            ELSE 16388
            END;
        EXEC proc_AddEventToCacheForDeleteRestore
            @WebSiteId, 
            @WebId, 
            @DoclibId,
            @DoclibRowId,
            @ItemName,
            @Url,
            @DocId,
            @DelEventType,
            @UserId,
            @DeleteDTM,
            NULL,
            NULL,
            @DocClientId,
            @RequestGuid OUTPUT
    END
    ELSE IF @DeleteItemType != 4
    BEGIN
        EXEC proc_LogChange @WebSiteId, @WebId, NULL, NULL, @DocId,
            NULL, NULL, @Url, 16384,
            32, @DeleteDTM,
            NULL, NULL, @DocClientId, @UserId, NULL, @RequestGuid OUTPUT
    END
cleanup:
    RETURN @ReturnStatus

go

