CREATE PROCEDURE [dbo].[proc_RevertDocContentStreams](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @WebFullUrl nvarchar(260),
    @DocDirName nvarchar(256),
    @DocLeafName nvarchar(128),
    @UserId int,
    @AppPrincipalId int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocFullUrl nvarchar(260)
    SET @DocFullUrl = CASE WHEN (DATALENGTH(@DocDirName) = 0) THEN @DocLeafName WHEN (DATALENGTH(@DocLeafName) = 0) THEN @DocDirName ELSE @DocDirName + N'/' + @DocLeafName END
    DECLARE @DocId uniqueidentifier
    DECLARE @ListId uniqueidentifier
    DECLARE @DoclibRowId int
    DECLARE @Level tinyint
    DECLARE @ListFlags bigint
    DECLARE @DocParentId uniqueidentifier
    SELECT TOP 1
        @DocId = Docs.Id,
        @ListId = Docs.ListId,
        @DoclibRowId = Docs.DoclibRowId,
        @Level = Docs.Level,
        @ListFlags = Lists.tp_Flags,
        @DocParentId = Docs.ParentId
    FROM
        TVF_Docs_Url(@SiteId, @DocDirName, @DocLeafName) AS Docs
    OUTER APPLY
        TVF_Lists_NoLock_CI(Docs.SiteId, Docs.WebId, Docs.ListId) AS Lists
    WHERE
        Docs.SetupPath IS NOT NULL AND
        (Docs.DocFlags & 64) <> 0 AND
        Docs.IsCurrentVersion = 1
    ORDER BY
        Docs.Level DESC
    OPTION (FORCE ORDER)
    IF (@DocId IS NULL)
        RETURN 2
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    IF @Level IS NOT NULL AND @Level <> 1
    BEGIN
        DECLARE @DocFlagOut int
        DECLARE @DocVersionOut int
        DECLARE @UIVersion int
        DECLARE @Moderated bit
        DECLARE @MinorVersionEnabled bit
        DECLARE @VersionEnabled bit
        SET @Moderated = 0
        SET @MinorVersionEnabled = 0
        SET @VersionEnabled = 0
        IF @ListFlags & 0x80 = 0x80
            SET @VersionEnabled = 1
        IF @ListFlags & 0x400 = 0x400
            SET @Moderated = 1
        IF @ListFlags & 0x80000 = 0x80000
            SET @MinorVersionEnabled = 1
        EXEC proc_ChangeLevelForDoc
            @SiteId,
            @DocDirName,
            @DocLeafName,    
            @Level OUTPUT,  
            1,
            0,                
            @MinorVersionEnabled,
            @Moderated,
            @VersionEnabled,
            @UserId,
            NULL,
            0,
            @DoclibRowId OUTPUT,
            @UIVersion OUTPUT,
            @DocFlagOut OUTPUT,
            @DocVersionOut OUTPUT
    END
    EXEC proc_DeleteStream @SiteId, @DocId, 0 , @Level
    DELETE
        Links
    FROM
        TVF_Links_PId_DId(@SiteId, @DocParentId, @DocId) AS Links
    WHERE
        WebPartId IS NULL AND
        FieldId IS NULL
    DELETE
        DP
    FROM
        TVF_Deps_SiteDelIdUrl(@SiteId, 0x, @DocFullUrl) AS DP
    DECLARE @DTM datetime
    SELECT @DTM = dbo.fn_RoundDateToNearestSecond(GETUTCDATE())
    DECLARE @DiskUsedDelta bigint
    SELECT
        @DiskUsedDelta = SUM(
            - CAST((CASE WHEN Docs.Size IS NULL THEN 0 ELSE (Docs.Size - 200) END) AS BIGINT)
            - CAST(ISNULL(Docs.MetaInfoSize, 0) AS BIGINT)
            - CAST(ISNULL(Docs.UnVersionedMetaInfoSize,0) AS BIGINT))
    FROM
        TVF_Docs_Id(@SiteId, @DocId) AS Docs
    UPDATE
        Docs
    SET
        Size = CASE WHEN Size IS NULL THEN NULL ELSE 200 END,
        MetaInfoSize = NULL,        
        Docs.InternalVersion = Docs.EffectiveVersion, Docs.BumpVersion = 0,
        DocFlags = (DocFlags & ~64),
        StreamSchema = 0, 
        ThicketFlag = 0,
        CharSet = NULL,
        ProgId = NULL,
        NextToLastTimeModified = TimeLastModified,
        TimeLastModified = @DTM,
        MetaInfoTimeLastModified = @DTM,
        TimeLastWritten = @DTM,
        VirusVendorID = NULL,
        VirusStatus = NULL,
        VirusInfo = NULL,
        VirusInfoEx = NULL,
        MetaInfo = NULL,
        UnVersionedMetaInfo = NULL,
        UnVersionedMetaInfoSize = NULL,
        UnVersionedMetaInfoVersion = NULL
    FROM
        TVF_Docs_Id(@SiteId, @DocId) AS Docs
    INSERT INTO EventCache(
        EventTime,
        SiteId,
        WebId,
        ListId,
        ItemId,
        DocId,
        Guid0,
        Int0,
        ItemName,
        ItemFullUrl,
        EventType,
        ObjectType,
        ModifiedBy,
        TimeLastModified,
        EventData, 
        ACL,
        ContentTypeId)          
    VALUES(
        GETUTCDATE(),                               
        @SiteId,
        @WebId,
        @ListId,
        @DoclibRowId,                               
        @DocId,                                     
        NULL,                                       
        NULL,                                       
        @DocLeafName,                               
        @DocFullUrl,                                
        8192,                    
        CASE WHEN @DoclibRowId IS NULL THEN 16 ELSE 
            1 END,                      
        NULL,                                       
        @DTM,                                       
        NULL,                                       
        NULL,                                       
        NULL)                                       
    EXEC proc_AddAuditEntryFromSql @SiteId, @DocDirName, @DocLeafName, 
        1, @UserId, @AppPrincipalId, 5, 
        N'<RevertDocumentContentStream />', 0x00000010
    EXEC proc_QMChangeSiteDiskUsedAndContentTimestamp @SiteId, @DiskUsedDelta, 1, @DocId
cleanup:
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN 0

go

