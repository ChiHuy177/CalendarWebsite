-- Work_CheckOverInLogtime 'vuongnq@vntt.com.vn',7,8 
   CREATE   PROC [dbo].[Work_CheckOverInLogtime] 
   @email as nvarchar(250), 
   @newVal as int=0, 
   @oldVal as int=0 , 
   @dateTime as datetime 
   as 
   declare @sogio as int =0 
   set @sogio=( select SUM(ISNULL(SoGio,0)) from Dynamic.Data_VNTTSLT where ISNULL( IsDelete,'False')='False' and CONVERT(char, Ngay ,103)=CONVERT(char, @dateTime,103) and Email=@email) 
   if(select (8 - (@sogio+@newVal-@oldVal)))>=0 
   begin 
   select (8 -(@sogio+@newVal-@oldVal)) 
   end 
   else 
   begin 
   select -1 * @sogio 
   end 
go

