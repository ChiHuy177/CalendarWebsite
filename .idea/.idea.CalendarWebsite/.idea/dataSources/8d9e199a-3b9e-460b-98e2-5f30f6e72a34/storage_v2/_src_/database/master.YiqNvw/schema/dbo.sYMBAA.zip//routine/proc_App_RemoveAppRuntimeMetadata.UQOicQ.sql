CREATE Procedure [dbo].[proc_App_RemoveAppRuntimeMetadata] (
    @AppInstanceId uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
DELETE FROM TVF_AppRuntimeMetadata_AppInstanceId(@SiteId, @AppInstanceId)
DELETE FROM TVF_AppRuntimeSubstitutionDictionary_AppInstanceId(@SiteId, @AppInstanceId)
COMMIT TRANSACTION

go

