CREATE PROCEDURE [dbo].[proc_DeleteStream] (
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @HistVersion int,
    @Level tinyint)
AS
    SET NOCOUNT ON
    DECLARE @err int, @rowc int
    DELETE
        DTS
    FROM
        TVF_DocsToStreams_SiteIdDocId(@SiteId, @DocId) AS DTS
    WHERE
        @HistVersion IS NULL OR @Level IS NULL
    OPTION (FORCE ORDER)
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    DELETE
        DS
    FROM
        TVF_DocStreams_SiteIdDocId(@SiteId, @DocId) AS DS
    WHERE
        @HistVersion IS NULL OR @Level IS NULL
    OPTION (FORCE ORDER)
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    DECLARE @bsnsToGC tvpBSNMetadata
    DELETE
        DTS
    OUTPUT
        DELETED.DocId, DELETED.Partition, DELETED.BSN
    INTO
        @bsnsToGC (DocId, Partition, BSN)
    FROM
        TVF_DocsToStreams_SiteDocHistVerLvl(@SiteId, @DocId, @HistVersion, @Level) AS DTS
    WHERE
        @HistVersion IS NOT NULL AND @Level IS NOT NULL
    OPTION (FORCE ORDER)
    DELETE
        DS
    FROM
        @bsnsToGC bn
    CROSS APPLY
        TVF_DocStreams_CI(@SiteId, bn.DocId, bn.Partition, bn.BSN) AS DS
    OUTER APPLY
        TVF_DocsToStreams_SiteDocPartBSN(@SiteId, DS.DocId, DS.Partition, DS.BSN) AS DTS
    WHERE
        DTS.Partition IS NULL AND DTS.BSN IS NULL
    OPTION (FORCE ORDER, LOOP JOIN)
    SELECT @err=@@ERROR, @rowc=@@ROWCOUNT
    IF @err <> 0
        RETURN 29
    RETURN 0

go

