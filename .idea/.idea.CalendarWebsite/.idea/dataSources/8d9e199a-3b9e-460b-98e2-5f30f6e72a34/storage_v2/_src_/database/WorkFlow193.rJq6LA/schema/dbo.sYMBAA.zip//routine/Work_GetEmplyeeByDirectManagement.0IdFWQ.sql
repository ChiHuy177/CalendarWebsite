-- Work_GetEmplyeeByDirectManagement 'P:285'   
   CREATE   PROC [dbo].[Work_GetEmplyeeByDirectManagement]   
   @employeeCurrent as nvarchar(50)   
   ,@adminPage as bit
   as   
   ;   
   if(@adminPage=0)
   begin
   with tab as (   
   select 'P:'+ TRIM(STR(Id)) as Id,FullName, 1 as index1 from PersonalProfile where Id= REPLACE(@employeeCurrent,'P:','') and UserStatus<>-1   
   union   
   select 'P:'+ TRIM(STR(Id)) as Id,FullName , 2 as index1 from PersonalProfile where ManagerId= REPLACE(@employeeCurrent,'P:','') and UserStatus<>-1   
   )   
   select * from tab order by index1  
   end
   else
   begin 
   select 'P:'+ TRIM(STR(Id)) as Id,FullName ,1 as index1 from PersonalProfile where UserStatus<>-1   
   end
   --with tab as (   
   --select 'P:'+ TRIM(STR(Id)) as Id,FullName, 1 as index1 from PersonalProfile where Id= 486 and UserStatus<>-1   
   --union   
   --select 'P:'+ TRIM(STR(Id)) as Id,FullName , 2 as index1 from PersonalProfile where ManagerId=486 and UserStatus<>-1   
   --)   
   --select * from tab order by index1  
   -- select * from PersonalProfile where Email like '%nguyen%' 
go

