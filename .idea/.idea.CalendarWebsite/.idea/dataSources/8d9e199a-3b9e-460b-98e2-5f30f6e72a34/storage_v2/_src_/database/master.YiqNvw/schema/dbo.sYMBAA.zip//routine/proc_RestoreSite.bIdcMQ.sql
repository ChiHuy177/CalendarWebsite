CREATE PROCEDURE [dbo].[proc_RestoreSite](
    @SiteId uniqueidentifier)
AS
    SET NOCOUNT ON
    DECLARE @iRet int
    SET @iRet = 0
    BEGIN TRAN
    DELETE FROM
        SiteDeletion
    WHERE
        SiteId = @SiteId AND
        InDeletion = 0 AND
        Restorable = 1 AND
        (LockTime IS NULL OR DATEADD(hour, 24, LockTime) < GETUTCDATE())
    IF (@@ROWCOUNT = 0)
    BEGIN
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                SiteDeletion
            WHERE
                SiteId = @SiteId AND
                InDeletion = 0 AND
                Restorable = 1 AND
                (LockTime IS NOT NULL AND DATEADD(hour, 24, LockTime) >= GETUTCDATE()))
        BEGIN
            SET @iRet = 212
            GOTO cleanup
        END
        SET @iRet = 2
        GOTO cleanup
    END
    UPDATE
        AllSites
    SET
        Deleted = 0
    WHERE
        Id = @SiteId
    IF (@@ROWCOUNT = 0)
    BEGIN
        SET @iRet = 2
        GOTO cleanup
    END
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
        131072,  8, NULL
cleanup:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @iRet

go

