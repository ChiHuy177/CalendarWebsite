CREATE PROCEDURE [dbo].[proc_DTSetRelationship](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @ChildDocLevel tinyint,
    @ChildLeafName nvarchar(128),
    @ParentDocLevel tinyint,
    @ParentLeafName nvarchar(128),
    @TransformerId uniqueidentifier,
    @ParentVersion int,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    UPDATE 
        Docs
    SET
        TransformerId = @TransformerId,
        ParentLeafName = @ParentLeafName,
        ParentVersion = @ParentVersion
    FROM
        TVF_Docs_Url_Level(@SiteId, @DirName, @ChildLeafName, @ChildDocLevel) AS Docs
    UPDATE 
        Docs
    SET
        DocFlags = DocFlags | 1024
    FROM
        TVF_Docs_Url_Level(@SiteId, @DirName, @ParentLeafName, @ParentDocLevel) AS Docs
    DECLARE @FullChildUrl nvarchar(260)
    DECLARE @FullParentUrl nvarchar(260)
    SET @FullChildUrl = CASE WHEN (DATALENGTH(@DirName) = 0) THEN @ChildLeafName WHEN (DATALENGTH(@ChildLeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @ChildLeafName END
    SET @FullParentUrl = CASE WHEN (DATALENGTH(@DirName) = 0) THEN @ParentLeafName WHEN (DATALENGTH(@ParentLeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @ParentLeafName END
    EXEC proc_AddDependency @SiteId,
                            @FullChildUrl,
                            @ChildDocLevel,
                            8,
                            @FullParentUrl,
                            @RequestGuid OUTPUT

go

