CREATE FUNCTION [dbo].[TVF_SolutionResourceUsageDailyOrdinal_PK]
(
    @DaysAgo int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SolutionResourceUsageDailyOrdinal] WITH (INDEX=SolutionResourceUsageDailyOrdinal_PK, FORCESEEK)
    WHERE
        DaysAgo = @DaysAgo

