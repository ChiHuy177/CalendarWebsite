CREATE FUNCTION [dbo].[TVF_Docs_UpdLock_DirNameLike]
(
    @SiteId uniqueidentifier,
    @DirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (UPDLOCK, INDEX=AllDocs_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        DirName LIKE @DirNameLike

go

