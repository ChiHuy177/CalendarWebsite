CREATE Procedure [dbo].[proc_App_SetAppInstanceSourceInfoId] (
    @InstallationId uniqueidentifier,
    @SourceInfoId uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
SET NOCOUNT ON
UPDATE TVF_AppInstallations_Id(@SiteId, @InstallationId)
    SET
        SourceInfoId = @SourceInfoId,
        PreviousSourceInfoId = SourceInfoId
    WHERE PreviousSourceInfoId IS NULL
    --The where clause here isn't restricting the result set, because the TVF only
    --returns a single row. Instead, it is providing idempotency.
    --We can also use this to figure out if we're in a partially committed state.
    --todo: error case when PreviousSourceInfoId is not null and is not equal to @Fingerprint

go

