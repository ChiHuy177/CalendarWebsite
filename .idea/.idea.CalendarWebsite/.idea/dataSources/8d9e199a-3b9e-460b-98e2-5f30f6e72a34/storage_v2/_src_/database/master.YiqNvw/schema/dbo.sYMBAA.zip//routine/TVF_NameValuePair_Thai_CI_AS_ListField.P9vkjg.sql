CREATE FUNCTION [dbo].[TVF_NameValuePair_Thai_CI_AS_ListField]
(
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NameValuePair_Thai_CI_AS] WITH (INDEX=NameValuePair_Thai_CI_AS_MatchUserData, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ListId = @ListId AND
        FieldId = @FieldId

go

