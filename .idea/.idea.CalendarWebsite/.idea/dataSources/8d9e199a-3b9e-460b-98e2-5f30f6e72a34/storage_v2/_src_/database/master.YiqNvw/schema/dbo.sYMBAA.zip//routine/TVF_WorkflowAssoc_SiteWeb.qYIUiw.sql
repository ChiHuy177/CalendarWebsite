CREATE FUNCTION [dbo].[TVF_WorkflowAssoc_SiteWeb]
(
    @SiteId uniqueidentifier,
    @WebId varbinary(16)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[WorkflowAssociation] WITH (INDEX=WorkflowAssociation_Parent, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@WebId IS NULL AND WebId IS NULL) OR @WebId=WebId)

go

