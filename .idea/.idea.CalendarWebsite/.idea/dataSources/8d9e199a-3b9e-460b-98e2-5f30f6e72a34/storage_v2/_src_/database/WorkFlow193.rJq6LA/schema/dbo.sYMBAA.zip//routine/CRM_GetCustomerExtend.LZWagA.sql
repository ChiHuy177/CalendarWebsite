CREATE   PROC [dbo].[CRM_GetCustomerExtend]      
 @code as nvarchar(50)      
 as      
       
 select a.ID, CustomerCode      
 , a.ID_DefineCustomerColumn  as IDDefineCustomerColumn    
 ,b.Name as DefineCustomerColumnName      
 ,b.Description as DefineCustomerColumnDescription       
 ,a.Contents as customerExtendContents      
 ,ISNULL(a.IsDelete,0) as IsDelete  
 from Dynamic.Data_CRMCustomerExtend a      
 inner join Dynamic.Data_CRMDefineCustomerColumn b on a.ID_DefineCustomerColumn= b.ID      
 where a.CustomerCode=@code and ISNULL(a.IsDelete,0)=0  
go

