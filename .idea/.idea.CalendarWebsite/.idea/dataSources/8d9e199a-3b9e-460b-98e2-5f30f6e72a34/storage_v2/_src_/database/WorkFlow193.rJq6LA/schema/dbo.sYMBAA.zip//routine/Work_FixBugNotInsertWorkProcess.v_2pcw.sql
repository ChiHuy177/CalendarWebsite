-- Work_FixBugNotInsertWorkProcess 235187,241776 
   CREATE   PROC [dbo].[Work_FixBugNotInsertWorkProcess] 
   @workProcessId as nvarchar(50) 
   ,@workId as nvarchar(50) 
   as 
   select * into #c from Dynamic.Data_FOLLOWCHART where QuyTrinhDinhKem=@workProcessId 
   select * into #d from Dynamic.Data_FOLLOWCHART where IsUseForWork=@workId 
   select a.Id into #e from #c a 
   left join #d b on a.Nodeid=b.Nodeid 
   where b.Nodeid is null 
   DECLARE @NodeTrue TABLE(id INT,nodeid VARCHAR(150)) 
   -- lấy ra node s,au node bắt đầu 
   select * into #a from Dynamic.Data_LSQTCV where Step in  
   ( 
   select b.value from Dynamic.Data_LSQTCV a 
   CROSS APPLY STRING_SPLIT(ISNULL(a.NextStep,''),',') AS b 
   where CategoryWorkProcessId=@workProcessId and Step = 0 
   ) and CategoryWorkProcessId=@workProcessId 
   -- kiểm tra xem sau node bắt đầu có node chỉ chạy 1 quy trình hay không nếu có thêm vào table @NodeTrue 
   select a.*, b.value as StepValue into #b from #a a 
   cross apply string_split(a.NextStep,',') b 
   where Title=N'Chỉ chạy 1 quy trình' 
   -- thêm tất cả các node vào bảng NodeTrue để active node khi thêm mới CV 
   insert into @NodeTrue 
   select * from ( 
   select a.Id,a.Nodeid from #a a 
   union 
   select a.Id,a.Nodeid from Dynamic.Data_LSQTCV a 
   inner join #b b on a.Step=b.StepValue 
   where a.CategoryWorkProcessId= @workProcessId 
   ) a 
   select a.[Id] 
   ,a.[UserWorkflowId] 
   ,[Nguoixuly] 
   ,[Nguoiphoihop] 
   ,[Nguoitheodoi] 
   ,[Mota] 
   ,[Tieude] 
   ,[Loaicv] 
   ,[Douutien] 
   ,[Thoigian] 
   ,a.[nodeid] as Nodeid 
   ,[Mota] as Noidung 
   ,case when ISNULL(c.Id,0) =0 then 'False' else 'True' end as IsActive 
   ,case when CAST(ISNULL( a.Thoigian,0) as int)=0 then null else trim(CONVERT(CHAR, GETDATE(), 120)) end as Ngaybatdau 
   ,case when CAST(ISNULL( a.Thoigian,0) as int)=0 then null else TRIM( CONVERT(char, DATEADD(DAY,CAST(ISNULL( a.Thoigian,0) as int) ,GETDATE()),120)) end as Ngayketthuc 
   ,a.Quytrinh 
   ,a.TudonghoanthanhCV 
   ,case when ISNULL(c.Id,0)> 0 and ISNULL([Nguoixuly],'') <>'' then ISNULL([Nguoixuly],'') else '' end as NguoiXuLyDauTien 
   ,case when ISNULL(c.Id,0)> 0 and ISNULL([Nguoixuly],'') <>'' then trim(CONVERT(CHAR, GETDATE(), 120)) else null end as Ngaygiaoviec 
   ,a.IsCompeleteWhenAllChildDone 
   from Dynamic.Data_FOLLOWCHART a 
   inner join Dynamic.Data_TMDSQTCV b on a.QuyTrinhDinhKem=b.UserWorkflowId 
   left join  
   ( 
   select * from @NodeTrue 
   ) c on a.nodeid=c.Nodeid and a.QuyTrinhDinhKem=@workProcessId 
   where a.Id in ( select * from #e ) 
   order by a.Id desc 
   ; 
   drop table #a 
   drop table #b 
   drop table #c 
   drop table #d 
go

