-- Work_GetWorkInForm 'P:287' 
   CREATE   PROC [dbo].[Work_GetWorkInForm] 
   @userId as char(10) 
   as 
   select UserWorkflowId as Value, Tieude as Label,Duan 
   ,ISNULL( Nguoixuly,'')+';'+ISNULL(Nguoixulydautien,'')+';'+ISNULL(Nguoiphoihop,'')+';'+ISNULL(Nguoigiao,'')+';'+ISNULL(Nguoitheodoi,'') as Nguoithamgia 
   into #a 
   from Dynamic.Data_WORK 
   where ISNULL(Isactive,'True')='True' 
   select a.Value,Label,Duan from #a a 
   cross apply string_split(a.Nguoithamgia,';') b 
   where b.value= @userId 
   group by a.Value,Label,Duan 
   drop table #a
go

