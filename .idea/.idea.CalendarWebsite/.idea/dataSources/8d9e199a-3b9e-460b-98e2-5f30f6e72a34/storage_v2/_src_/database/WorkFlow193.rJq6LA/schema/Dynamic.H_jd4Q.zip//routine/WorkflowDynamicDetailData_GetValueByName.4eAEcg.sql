CREATE 
    PROCEDURE [Dynamic].[WorkflowDynamicDetailData_GetValueByName] 
	@WorkflowId BIGINT,
	@UserWorkflowId BIGINT,
	@ColumnName nvarchar(max) 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX), @TableCode NVARCHAR(MAX), @TableNameResult NVARCHAR(MAX);
		DECLARE @SqlScript NVARCHAR(MAX) = '';


		SET @TableName =(
			SELECT Title
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
		SET @TableCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)

		set @TableNameResult = CONCAT (
			'Dynamic.Detail_'
			,dbo.fn_StripCharacters(@TableCode, '^a-z0-9')
			);		
		SET @SqlScript =  'SELECT [' + @ColumnName + '] FROM ' +  @TableNameResult + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';';
		print @SqlScript
		EXEC sp_ExecuteSql @SqlScript;
END
go

