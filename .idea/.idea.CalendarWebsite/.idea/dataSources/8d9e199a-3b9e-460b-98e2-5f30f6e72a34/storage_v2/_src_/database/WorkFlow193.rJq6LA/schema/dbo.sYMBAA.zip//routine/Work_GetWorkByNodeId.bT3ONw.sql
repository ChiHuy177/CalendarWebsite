CREATE   PROC [dbo].[Work_GetWorkByNodeId] 
   @workProcessId as nvarchar(250) 
   ,@nodeId as nvarchar(250) 
   ,@isActice as char(20)
   as 
   select c.* from Dynamic.Data_WORK a 
   inner join Dynamic.Data_WORK b on a.CongViecCha=b.UserWorkflowId 
   inner join Dynamic.Workflow_WORK c on a.UserWorkflowId=c.UserWorkflowId
   where a.Nodeid=@nodeId 
   and b.QuyTrinhDinhKem=@workProcessId and ISNULL(a.IsActive,'True')=@isActice 
go

