CREATE FUNCTION [dbo].[TVF_AppPackages_CrossSiteProductId]
(
    @ProductId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppPackages] WITH (INDEX=AppPackages_ProductId, FORCESEEK)
    WHERE
        ProductId = @ProductId

go

