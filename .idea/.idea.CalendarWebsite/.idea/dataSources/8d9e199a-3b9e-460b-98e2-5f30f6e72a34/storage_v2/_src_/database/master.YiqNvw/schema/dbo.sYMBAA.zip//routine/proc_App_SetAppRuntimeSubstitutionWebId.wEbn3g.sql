CREATE Procedure [dbo].[proc_App_SetAppRuntimeSubstitutionWebId] (
    @AppInstanceId uniqueidentifier,
    @ValueKey nvarchar(50),
    @ValueWebId uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
UPDATE TVF_AppRuntimeSubstitutionDictionary_AppInstanceId(@SiteId, @AppInstanceId)
    SET ValueString = NULL,
    ValueWebId = @ValueWebId
    WHERE ValueKey = @ValueKey
IF(@@ROWCOUNT = 0) --then we're inserting rather than updating
BEGIN
    INSERT INTO AppRuntimeSubstitutionDictionary
        (AppInstanceId, ValueKey, ValueString, ValueWebId, SiteId)
    VALUES
        (@AppInstanceId, @ValueKey, NULL, @ValueWebId, @SiteId)
END
COMMIT TRANSACTION

go

