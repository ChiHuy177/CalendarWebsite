-- Work_GeneralBvpReport '','','','228181','P:287','P:287','',''
   CREATE   PROC [dbo].[Work_GeneralBvpReport] 
   @fromDateBegin AS NVARCHAR(50) = ''  
   ,@toDateBegin AS NVARCHAR(50) = ''  
   ,@title as nvarchar(150)='' 
   ,@projectId as nvarchar(150)='' 
   ,@employeeCurrent as nvarchar(150)='' 
   ,@employee as nvarchar(150)=''  
   ,@fromDateEnd AS NVARCHAR(50) = ''  
   ,@toDateEnd AS NVARCHAR(50) = '' 
   as 
   declare @sql as nvarchar(max)=N'' ,@sql1 as nvarchar(max)=N'',@sql2 as nvarchar(max)=N'' ,@dateWhereBegin as nvarchar(300)=N'',@dateWhereEnd as nvarchar(300)=N'',@projectWhere as nvarchar(350)=N'',@Where as nvarchar(300)=N''  
   if(@fromDateBegin<>'' and @toDateBegin='')  
   begin  
   set @dateWhereBegin=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''9999-12-12''),23) )>=0 ' 
   end 
   else if(@fromDateBegin<>'' and @toDateBegin<>'') 
   begin 
   set @dateWhereBegin=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''9999-12-12''),23) )>=0 and '+ 
   ' DATEDIFF(day, CONVERT(varchar,'''+@toDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''9999-12-12''),23) )<=0 ' 
   end 
   if(@fromDateEnd<>'' and @toDateEnd='') 
   begin  
   set @dateWhereEnd=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )<=0 '  
   end 
   else if(@fromDateEnd<>'' and @toDateEnd<>'') 
   begin  
   set @dateWhereEnd=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )>=0 and '+ 
   ' DATEDIFF(day, CONVERT(varchar,'''+@toDateEnd+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )<=0 '  
   end 
   if(@projectId<>'') 
   begin  
   set @projectWhere=' and b.UserWorkflowId = '''+@projectId+'''' 
   end 
   if(@employee <>'') 
   begin  
   set @Where=' where ISNULL( a.IsActive,''True'')=''True'' and a.Tieude like N''%'+@title+'%'''+' and e.Id = '''+@employee+''''+@dateWhereBegin+' '+@dateWhereEnd +' '+@projectWhere 
   end 
   else 
   begin 
   set @Where=' where ISNULL( a.IsActive,''True'')=''True'' and a.Tieude like N''%'+@title+'%'''+' '+@dateWhereBegin+' '+@dateWhereEnd +' '+@projectWhere 
   end 
   set @sql =N'
   select ''P:''+ TRIM(STR(Id)) as Id,FullName into #user from PersonalProfile where (ManagerId= REPLACE('''+@employeeCurrent+''',''P:'','''') or Id= REPLACE('''+@employeeCurrent+''',''P:'','''') ) and UserStatus<>-1  
   select 
   a.Id 
   ,a.UserWorkflowId as WorkId 
   ,a.UserWorkflowId 
   ,b.Ten as ProjectName 
   ,a.Tieude as Title 
   ,a.Ngaybatdau as [Start] 
   ,a.NgayKetThuc as [End] 
   ,a.Tiendo as Progress 
   ,DATEDIFF(DAY,a.Ngaybatdau, a.Ngayketthuc ) as TotalDateExec 
   , ISNULL(a.CongViecCha,'''') as CongViecCha 
   ,d.Ten as StatusName 
   from Dynamic.Data_WORK a 
   inner join Dynamic.Data_RESOURCEDA b on a.Duan=b.UserWorkflowId 
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId 
   cross apply string_split(ISNULL( Nguoigiao,'''')+'';''+ISNULL( Nguoixuly,'''')+'';''+ISNULL(Nguoixulydautien,''''),'';'') c 
   inner join #user e on c.value=e.Id
   '+@Where+'
   group by a.Id 
   ,a.UserWorkflowId 
   ,b.Ten 
   ,a.Tieude 
   ,a.Ngaybatdau 
   ,a.NgayKetThuc 
   ,a.Tiendo 
   , ISNULL(a.CongViecCha,'''') 
   ,d.Ten
   order by UserWorkflowId desc'
   exec(@sql)
   print(@sql)
go

