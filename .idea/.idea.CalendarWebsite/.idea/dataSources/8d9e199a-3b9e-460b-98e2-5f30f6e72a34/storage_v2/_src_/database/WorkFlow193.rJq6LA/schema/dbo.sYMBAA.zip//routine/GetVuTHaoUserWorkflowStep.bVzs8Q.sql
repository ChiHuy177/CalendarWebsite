-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [dbo].[GetVuTHaoUserWorkflowStep]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   
	SELECT us.*
	FROM UserWorkflowStep us
	inner join UserWorkflow u on u.Id = us.UserWorkflowId
	where (us.IsReplace = 1 OR (us.IsReplace = 0 and us.Action = N'Chuyển xử lý'))
	and u.IsConverted = 1
	and u.CreatedTime >= '2022-06-01'
	and us.StartTime < us.CreatedTime
END
go

