CREATE   PROC [dbo].[Work_GetAllStatusCompelete] 
   @projectId as nvarchar(50) 
   as 
   select 
   b.Id 
   , b.Ten as Name 
   , b.Duan as ProjectId 
   , b.TrangThaiCongViec 
   ,isnull(b.NguoiChinhSua,'') as [user] 
   ,b.UserWorkflowId 
   ,c.Step 
   ,'' as WorkflowId 
   ,c.NextStep 
   ,ISNULL(a.QuanLy,'') as Manager 
   from [Dynamic].Data_RESOURCEDA a 
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan 
   inner join Dynamic.Data_LSQTCV c on a.UserWorkflowId=c.ProjectId
   where a.UserWorkflowId= @projectId and TrangThaiCongViec =N'Hoàn thành' 
   order by c.Step 
go

