CREATE PROCEDURE [dbo].[proc_EnumDoclibsFileDlg](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @Collation nvarchar(48),
    @GetTemplate bit,
    @OnlyLibsWithTemplates bit,
    @IncludeSubWebs bit,
    @LCID int,
    @Scopes varbinary(max) = NULL,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @strTemplateField nvarchar(1024)
    DECLARE @strTemplateJoin nvarchar(1024)
    DECLARE @strWebTemplateField nvarchar(1024)
    DECLARE @strWebTemplateJoin nvarchar(1024)
    DECLARE @strQuery nvarchar(2000)
    SET @strTemplateField = N''
    SET @strTemplateJoin = N''
    SET @strWebTemplateField = N''
    SET @strQuery = 
        'DECLARE @_scopeTbl TABLE(_id uniqueidentifier NOT NULL PRIMARY KEY);' +
        'DECLARE @_count INT;' +
        'SET @_count = 0;' +
        'WHILE @_count < DATALENGTH(@Scopes)/16 ' +
        'BEGIN  ' +
        '   INSERT INTO @_scopeTbl VALUES (CAST(SUBSTRING(@Scopes ,@_count*16 + 1, 16) AS uniqueidentifier))' +
        '   SET @_count = @_count + 1 ' +
        'END '
    IF @GetTemplate = 1
    BEGIN
        IF (@IncludeSubWebs = 0)
        BEGIN
            SET @strTemplateField =
                ' CASE WHEN LEN(Docs2.DirName) = 0 THEN N''/'' + Docs2.LeafName ' +
                ' ELSE N''/'' + Docs2.DirName + N''/'' + Docs2.LeafName END ' +
                ' AS Docs#Template#FullUrl, '
            SET @strTemplateJoin =
                ' OUTER APPLY TVF_Docs_Id_Level(@SiteId, tp_Template, ' + CONVERT(NVARCHAR, 1) + ') AS Docs2 '
        END
        ELSE
        BEGIN
            SET @strTemplateField = ' NULL AS Docs#Template#FullUrl, '
        END
    END
    IF (@IncludeSubWebs = 0)
    BEGIN
        SET @strQuery = @strQuery + 
            ' SELECT CASE WHEN LEN(Docs1.DirName) = 0 THEN N''/'' + Docs1.LeafName ' +
            ' ELSE N''/'' + Docs1.DirName + N''/'' + Docs1.LeafName END ' +
            ' AS tp_RootFolder, ' + @strTemplateField +
            ' tp_Title, tp_Description, tp_ImageUrl, ' + 
            ' CASE WHEN RLT.NvarcharVal IS NULL THEN ALP.TitleResource ELSE RLT.NvarcharVal END AS TitleResource, ' +
            ' CASE WHEN RLD.NtextVal IS NULL THEN ALP.DescriptionResource ELSE RLD.NtextVal END AS DescriptionResource ' +
            ' FROM @_scopeTbl AS Scopes ' +
            ' CROSS APPLY TVF_Lists_WebId(@SiteId, @WebId) AS Lists ' +
            ' OUTER APPLY TVF_AllListsPlus_ListId(@SiteId, Lists.tp_ID) AS ALP ' +
            ' OUTER APPLY TVF_Resources_PK(@SiteId, @WebId, Lists.tp_ID, N''_ListTitle'', @LCID) AS RLT ' +
            ' OUTER APPLY TVF_Resources_PK(@SiteId, @WebId, Lists.tp_ID, N''_ListDescription'', @LCID) AS RLD ' +
            ' CROSS APPLY TVF_Docs_Id_Level(@SiteId, tp_RootFolder, ' + CONVERT(NVARCHAR, 1) + ') AS Docs1 ' +
            @strTemplateJoin +
            ' WHERE tp_BaseType=1 AND (tp_Flags & ' + CONVERT(NVARCHAR, 256) +')=0 ' + 
            ' AND tp_ScopeId=Scopes._id '
        IF @OnlyLibsWithTemplates = 1
            SET @strQuery = @strQuery + ' AND tp_Template IS NOT NULL '
        SET @strQuery = @strQuery + ' ORDER BY tp_Title COLLATE ' + @Collation + ' OPTION (FORCE ORDER)'
    END
    ELSE 
    BEGIN
        SET @strQuery = @strQuery + 
        ' SELECT N''/'' + FullUrl as tp_RootFolder, ' +  @strTemplateField +
        ' Title as tp_Title, Description as tp_Description, ' +
        ' CASE WHEN WebTemplate = 2 THEN  N''/_layouts/images/mtgicon.gif'' ' +
        ' ELSE N''/_layouts/images/SharePointFoundation16.png'' END as tp_ImageUrl, ' +
        ' CASE WHEN RWT.NvarcharVal IS NULL THEN WP.TitleResource ELSE RWT.NvarcharVal END AS TitleResource, ' +
        ' CASE WHEN RWD.NtextVal IS NULL THEN WP.DescriptionResource ELSE RWD.NtextVal END AS DescriptionResource ' +
        ' FROM @_scopeTbl AS Scopes ' +
        ' CROSS APPLY TVF_Webs_SiteIdParent(@SiteId, @WebId) AS Webs ' +
        ' OUTER APPLY TVF_WebsPlus_WebId(@SiteId, Webs.Id) AS WP ' +
        ' OUTER APPLY TVF_Resources_PK(@SiteId, Webs.Id, N''00000000-0000-0000-0000-000000000000'', N''_WebTitle'', @LCID) AS RWT ' +
        ' OUTER APPLY TVF_Resources_PK(@SiteId, Webs.Id, N''00000000-0000-0000-0000-000000000000'', N''_WebDescription'', @LCID) AS RWD ' +
        ' WHERE Scopes._id=Webs.ScopeId AND Webs.AppWebDomainId IS NULL'
        SET @strQuery = @strQuery + ' ORDER BY Title COLLATE ' + @Collation + ' OPTION (FORCE ORDER)'
    END
    EXEC sp_executesql 
        @strQuery, 
        N'@SiteId uniqueidentifier, @WebId uniqueidentifier, @LCID int, @Scopes varbinary(max)', 
        @SiteId, @WebId, @LCID, @Scopes

go

