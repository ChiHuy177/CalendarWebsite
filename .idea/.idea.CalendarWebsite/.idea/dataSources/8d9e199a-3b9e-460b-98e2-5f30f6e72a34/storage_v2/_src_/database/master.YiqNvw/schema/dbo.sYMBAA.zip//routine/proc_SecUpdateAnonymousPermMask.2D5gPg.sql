CREATE PROCEDURE [dbo].[proc_SecUpdateAnonymousPermMask](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ScopeId uniqueidentifier,
    @AnonymousPermMask tPermMask,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    UPDATE
        P
    SET
        P.AnonymousPermMask = @AnonymousPermMask
    FROM
        TVF_Perms_ScopeId(@SiteId, @ScopeId) AS P
    WHERE
        P.WebId = @WebId
    EXEC proc_SecLogChange @SiteId, @WebId, @ScopeId, NULL, NULL, -1, 524288, NULL
    EXEC proc_SecUpdateSiteLevelSecurityMetadata @SiteId, 1, 0
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @RET

go

