CREATE FUNCTION [dbo].[TVF_EventSubsMatches_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[EventSubsMatches] WITH (INDEX=EventSubsMatches_EventIdSubId, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

