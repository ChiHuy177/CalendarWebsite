CREATE FUNCTION [dbo].[TVF_SchedSubscriptions_SiteIdWebId]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SchedSubscriptions] WITH (INDEX=SchedSubscriptions_SiteIdWebId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId

go

