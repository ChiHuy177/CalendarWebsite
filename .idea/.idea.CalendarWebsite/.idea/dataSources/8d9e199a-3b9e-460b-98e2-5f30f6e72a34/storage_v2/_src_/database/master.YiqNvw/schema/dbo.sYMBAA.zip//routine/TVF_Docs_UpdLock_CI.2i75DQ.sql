CREATE FUNCTION [dbo].[TVF_Docs_UpdLock_CI]
(
    @SiteId uniqueidentifier,
    @ParentId uniqueidentifier,
    @Id uniqueidentifier,
    @Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (UPDLOCK, INDEX=AllDocs_ParentId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x AND
        ParentId = @ParentId AND
        Id = @Id AND
        Level = @Level

go

