CREATE PROCEDURE [dbo].[proc_DropListUniqueField](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier)
AS
    SET NOCOUNT ON;
    DELETE
        ALR
    FROM
        TVF_AllListUniqueFields_SiteListField(@SiteId, @ListId, @FieldId) AS ALR
    RETURN 0;

go

