-- Work_GetProjectLinkCoupon 265245 ,2     
   CREATE   PROC [dbo].[Work_GetProjectLinkCoupon]     
   @projectId as nvarchar(50)     
   ,@type as nvarchar(50)     
   as     
   if(@type='1')     
   begin     
   select a.*,b.Title as WorkFlowName,c.WorkflowCode +' - '+ c.ShortContent as CoponName     
   ,a.Note     
   ,case when c.UserWorkflowStatus =0 then N'Chờ phê duyệt'  
   when c.UserWorkflowStatus =1 then N'Phê duyệt' else N'Từ chối' end as Status  
   , d.FullName as CreateBy  
   ,a.WorkId
   from Dynamic.Data_ProjectLinkCoupon a     
   inner join Workflow b on a.WorkFlowId=b.Id     
   inner join UserWorkflow c on a.CouponId=c.Id    
   inner join PersonalProfile d on d.Id=c.UserId  
   where ProjectId=@projectId and ISNULL( a.IsDelete,'False')='False'    
   end     
   else     
   begin     
   select a.*,b.Title as WorkFlowName,c.WorkflowCode +' - '+ c.ShortContent as CoponName     
   ,a.Note     
   ,case when c.UserWorkflowStatus =0 then N'Chờ phê duyệt'  
   when c.UserWorkflowStatus =1 then N'Phê duyệt' else N'Từ chối' end as Status  
   , d.FullName as CreateBy  
   ,a.WorkId
   from Dynamic.Data_ProjectLinkCoupon a     
   inner join Workflow b on a.WorkFlowId=b.Id     
   inner join UserWorkflow c on a.CouponId=c.Id     
   inner join PersonalProfile d on d.Id=c.UserId  
   where a.WorkId=@projectId and [Type]=@type and ISNULL( a.IsDelete,'False')='False'    
   end     
   --insert Dynamic.Data_ProjectLinkCoupon values(null,215712,6,247817)     
   --select * from UserWorkflow where WorkflowId=6 
go

