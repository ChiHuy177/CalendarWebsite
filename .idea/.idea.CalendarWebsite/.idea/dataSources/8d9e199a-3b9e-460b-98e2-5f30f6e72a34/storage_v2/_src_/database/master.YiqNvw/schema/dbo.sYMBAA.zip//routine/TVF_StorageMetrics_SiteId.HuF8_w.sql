CREATE FUNCTION [dbo].[TVF_StorageMetrics_SiteId]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[StorageMetrics] WITH (INDEX=StorageMetrics_DocId, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

