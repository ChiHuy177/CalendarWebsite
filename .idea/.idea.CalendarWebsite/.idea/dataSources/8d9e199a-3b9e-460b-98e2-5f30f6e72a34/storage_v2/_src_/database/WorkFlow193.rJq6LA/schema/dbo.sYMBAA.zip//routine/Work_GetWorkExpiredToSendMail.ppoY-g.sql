CREATE   PROC Work_GetWorkExpiredToSendMail  
   as  
   select c.Email as  EmailUserAssign, a.* from Dynamic.Data_WORK a  
   cross apply string_split(a.nguoixuly,';') b  
   inner join PersonalProfile c on b.value= 'P:'+ TRIM(str(c.Id))  
   where DATEDIFF(day,CONVERT(date, Ngayketthuc,21),CONVERT(date, GETDATE(),21)) =0  
   and c.EnableEmail=1
go

