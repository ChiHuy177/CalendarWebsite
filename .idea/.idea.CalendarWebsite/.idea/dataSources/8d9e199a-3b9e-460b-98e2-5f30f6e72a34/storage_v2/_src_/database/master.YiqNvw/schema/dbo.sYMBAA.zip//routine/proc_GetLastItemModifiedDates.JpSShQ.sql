CREATE PROC [dbo].[proc_GetLastItemModifiedDates](
    @LastItemModifiedTable tvpLastItemModified READONLY,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT
        LIM.ArrayIndex,
        D.WebId,
        D.ListId,
        ALA.Modified,
        ALA.LastDeleted
    FROM
        @LastItemModifiedTable AS LIM
    OUTER APPLY
        TVF_Docs_Url_Level(LIM.SiteId, LIM.DirName, LIM.LeafName, 1) AS D        
    OUTER APPLY
        TVF_AllListsAux_NoLock_ListId(
            LIM.SiteId, 
            D.ListId) AS ALA

go

