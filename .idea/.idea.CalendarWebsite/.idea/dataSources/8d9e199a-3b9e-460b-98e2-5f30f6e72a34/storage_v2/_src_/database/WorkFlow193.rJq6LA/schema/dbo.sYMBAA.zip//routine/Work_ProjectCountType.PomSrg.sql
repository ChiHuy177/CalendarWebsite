-- Work_GetProjectByUser 'P:287', 
   -- Work_ProjectCountType 'P:287' 
   CREATE   PROC [dbo].[Work_ProjectCountType] 
   @id as nvarchar(50) 
   as 
   declare @tbUser table ( UserId nvarchar(50), UserWorkflowId bigint) 
   insert into @tbUser 
   select * from 
   ( 
   SELECT 
   'P:'+ trim(str(c.PersonalProfilesId)) AS userId 
   ,a.UserWorkflowId 
   -- into #da 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b 
   inner join GroupPersonalProfile c on 'G:'+ trim(str(GroupsId))=b.value 
   where left(trim(b.value),2)='G:' 
   union 
   SELECT 
   b.value AS userId 
   ,a.UserWorkflowId 
   -- into #da 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b 
   where left(trim(b.value),2)='P:' 
   union 
   SELECT 
   b.value AS userId 
   ,a.UserWorkflowId 
   -- into #da 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   where left(trim(b.value),2)='P:' 
   ) a group by userId,UserWorkflowId 
   select  
   COUNT(*) as [Total] 
   ,ISNULL(Loai,'None') as Loai 
   ,0 as [All] 
   into #a 
   from Dynamic.Data_RESOURCEDA a 
   inner join @tbUser b on a.UserWorkflowId=b.UserWorkflowId 
   where b.UserId=@id 
   and ISNULL(IsDeleted,'False')='False' and ISNULL(a.TrangThai,'')=N'Đang thực hiện'
   group by Loai 
   update #a set [All]=(select SUM(Total) from #a) 
   select * from #a 
go

