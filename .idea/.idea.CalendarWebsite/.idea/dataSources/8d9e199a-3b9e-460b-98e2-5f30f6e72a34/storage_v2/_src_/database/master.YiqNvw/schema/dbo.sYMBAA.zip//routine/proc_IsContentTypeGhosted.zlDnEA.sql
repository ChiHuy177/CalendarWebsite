CREATE PROC [dbo].[proc_IsContentTypeGhosted](
    @SiteId uniqueidentifier,
    @Class tinyint,
    @ContentTypeId tContentTypeId,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT
        CASE
            WHEN CT.Definition IS NULL THEN 1
            ELSE 0
        END
    FROM
        TVF_ContentTypes_SiteClassCTId(
            @SiteId, 
            @Class, 
            @ContentTypeId) AS CT

go

