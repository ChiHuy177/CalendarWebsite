CREATE FUNCTION [dbo].[TVF_AllListsAux_SiteId]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllListsAux] WITH (INDEX=AllListsAux_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

