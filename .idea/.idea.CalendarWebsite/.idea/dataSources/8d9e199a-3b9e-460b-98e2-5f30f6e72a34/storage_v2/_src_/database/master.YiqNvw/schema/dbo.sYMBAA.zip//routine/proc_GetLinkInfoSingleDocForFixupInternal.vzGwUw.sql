CREATE PROCEDURE [dbo].[proc_GetLinkInfoSingleDocForFixupInternal](
    @DocSiteId uniqueidentifier,
    @DocParentId uniqueidentifier,
    @DocId uniqueidentifier,
    @Level tinyint)
AS
    SET NOCOUNT ON
    DECLARE @LinksList table( DirName nvarchar(256) COLLATE Latin1_General_CI_AS_KS_WS NULL, LeafName nvarchar(128) COLLATE Latin1_General_CI_AS_KS_WS NULL, ParentId uniqueidentifier NOT NULL, DocId uniqueidentifier NOT NULL, WebPartId uniqueidentifier NULL, FieldId uniqueidentifier NULL, LinkNumber int NOT NULL, TargetDirName nvarchar(256) COLLATE Latin1_General_CI_AS_KS_WS NOT NULL, TargetLeafName nvarchar(128) COLLATE Latin1_General_CI_AS_KS_WS NOT NULL, Type tinyint NOT NULL, Security tinyint NOT NULL, Dynamic tinyint NOT NULL, ServerRel bit NOT NULL, PointsToDir bit NOT NULL, Level tinyint DEFAULT 1 NOT NULL)
    INSERT INTO 
        @LinksList 
    SELECT
        NULL,
        NULL,
        ParentId, 
        DocId,
        WebPartId,
        FieldId,
        LinkNumber,
        TargetDirName,
        TargetLeafName,
        Type,
        Security,
        Dynamic,
        ServerRel,
        PointsToDir,
        Level
    FROM
        TVF_Links_PId_DId_Lvl(@DocSiteId, @DocParentId, @DocId, @Level) AS Links
    SELECT DISTINCT
        Links.TargetDirName AS LinkDirName,
        Links.TargetLeafName AS LinkLeafName, Links.Type AS LinkType,
        Links.Security AS LinkSecurity, Links.Dynamic AS LinkDynamic,
        Links.ServerRel AS LinkServerRel, Docs.Type AS LinkStatus,
        Links.PointsToDir AS PointsToDir, Links.WebPartId AS WebPartId,
        Links.LinkNumber AS LinkNumber, NULL AS WebId, NULL AS Search,
        FieldId AS FieldId
    FROM
        @LinksList AS Links
    OUTER APPLY
        TVF_Docs_Url(@DocSiteId, Links.TargetDirName, Links.TargetLeafName) AS Docs
    ORDER BY
        WebPartId, LinkNumber
    OPTION (FORCE ORDER, LOOP JOIN, MAXDOP 1)

go

