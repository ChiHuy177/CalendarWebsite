-- [Work_RecursiveMaxRoot] '272757',100,0   
   CREATE   PROC [dbo].[Work_RecursiveMaxRoot]   
   @workId as nvarchar(max)  
   ,@rootIndex as int =1   
   ,@isGetAllTheSameLevel as bit =1   
   as   
   declare @tbId table(UserWorkflowId bigint, RowIndex int,IsMyWork int)  
   insert into @tbId select Item,0,0 from Split(@workId,',')  
   ;   
   -- ***************** đệ quy trong sql lấy ra tất cả cha **************************   
   WITH Managers AS    
   (    
   --initialization    
   SELECT a.UserWorkflowId,a.Tieude,a.CongViecCha, a.Duan, 0 as RowIndex,1 as IsMyWork   
   ,a.Ngayketthuc   
   FROM [Dynamic].[Data_WORK] AS a    
   inner join @tbId b on a.UserWorkflowId=b.UserWorkflowId   
   --where a.UserWorkflowId in (218184,218207,218930,217302,217404,218720,218722)   
   UNION ALL    
   --recursive execution    
   SELECT   
   a.UserWorkflowId,a.Tieude,a.CongViecCha,b.Duan, b.RowIndex +1 as RowIndex,0 as IsMyWork   
   ,a.Ngayketthuc   
   FROM Dynamic.Data_WORK a    
   inner join Managers b on ISNULL(b.CongViecCha,'') = ISNULL(a.UserWorkflowId,'')   
   where ISNULL( a.IsActive,'True')='True'   
   )   
   --bảng #tbTemp thêm vào bang tạm #tbTemp workId   
   SELECT a.UserWorkflowId,RowIndex,IsMyWork,Tieude,CongViecCha,case when ISNULL(a.Ngayketthuc,'') ='' then 9999 else ISNULL(DATEDIFF(DAY, a.Ngayketthuc, GETDATE()),0) end as TimeExpired   
   into #tbTemp    
   FROM Managers a where a.RowIndex<=@rootIndex   
   ;   
   -- ***************** đệ quy trong sql lấy ra tất cả con **************************   
   WITH Managers1 AS    
   (    
   --initialization    
   SELECT a.UserWorkflowId,a.Tieude,a.CongViecCha, a.Duan, 0 as RowIndex,1 as IsMyWork   
   ,a.Ngayketthuc   
   FROM [Dynamic].[Data_WORK] AS a    
   inner join @tbId b on a.UserWorkflowId=b.UserWorkflowId   
   --where a.UserWorkflowId in (218184,218207,218930,217302,217404,218720,218722)   
   UNION ALL    
   --recursive execution    
   SELECT   
   a.UserWorkflowId,a.Tieude,a.CongViecCha,b.Duan, b.RowIndex -1 as RowIndex,0 as IsMyWork   
   ,a.Ngayketthuc   
   FROM Dynamic.Data_WORK a    
   inner join Managers1 b on ISNULL(b.UserWorkflowId,'') = ISNULL(a.CongViecCha,'')   
   where ISNULL( a.IsActive,'True')='True'   
   )   
   SELECT a.UserWorkflowId,a.RowIndex,a.IsMyWork,a.Tieude,a.CongViecCha , case when ISNULL(a.Ngayketthuc,'') ='' then 9999 else ISNULL(DATEDIFF(DAY, a.Ngayketthuc, GETDATE()),0) end as TimeExpired   
   into #tbAll  
   FROM Managers1 a   
   -- left join #tbTemp b on a.UserWorkflowId=b.UserWorkflowId where b.UserWorkflowId is null   
   SELECT a.UserWorkflowId,a.RowIndex,a.IsMyWork,a.Tieude,a.CongViecCha , a.TimeExpired   
   into #tbExist  
   FROM #tbAll a   
   inner join #tbTemp b on a.UserWorkflowId=b.UserWorkflowId   
   insert into #tbTemp  
   SELECT a.UserWorkflowId,a.RowIndex,a.IsMyWork,a.Tieude,a.CongViecCha , a.TimeExpired   
   FROM #tbAll a   
   left join #tbTemp b on a.UserWorkflowId=b.UserWorkflowId where b.UserWorkflowId is null   
   -- lấy ra node cùng cấp hay không   
   if(@isGetAllTheSameLevel=1)   
   begin   
   insert into #tbTemp   
   SELECT a.UserWorkflowId,9999 as RowIndex,0 IsMyWork,a.Tieude,a.CongViecCha ,case when ISNULL(a.Ngayketthuc,'') ='' then 9999 else ISNULL(DATEDIFF(DAY, a.Ngayketthuc, GETDATE()),0) end as TimeExpired   
   FROM Dynamic.Data_WORK a   
   inner join Dynamic.Data_WORK b on a.CongViecCha=b.CongViecCha   
   inner join @tbId c on c.UserWorkflowId=b.UserWorkflowId   
   where ISNULL(a.IsActive,'True')='True'   
   end   
   --bảng #b lấy ra distinct workId để xuống dưới join không bị trùng   
   select UserWorkflowId,TimeExpired into #b from #tbTemp group by UserWorkflowId,TimeExpired   
   -- bảng #c lấy ra gốc cha (gốc cha là 0)  
   -- left join với bảng #tbExist để không gán rowindex nếu đã có trong cha   
   select a.UserWorkflowId ,0 as RowIndex, 0 as TimeExpired into #c   
   from #tbTemp a   
   left join #tbExist b on a.UserWorkflowId=b.UserWorkflowId --   
   where   
   (a.RowIndex=@rootIndex and b.UserWorkflowId is null) or ISNULL(a.CongViecCha,'')=''   
   group by a.UserWorkflowId   
   update a set a.TimeExpired = b.TimeExpired from #c a   
   inner join (select max(TimeExpired) as TimeExpired,CongViecCha from #tbTemp group by CongViecCha ) b on a.UserWorkflowId=b.CongViecCha   
   CREATE TABLE #duan (UserWorkflowId char(50), Ten nvarchar(500), Loai nvarchar(500))   
   insert into #duan select UserWorkflowId,Ten,Loai from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False'    
   insert into #duan select '','',''   
   SELECT   
   a.UserWorkflowId   
   ,case when ISNULL(h.RowIndex,9999)=0 then 0 else 9999 end as RowIndex   
   ,a.Duan  
   ,a.Id    
   ,a.tieude AS title   
   ,ISNULL(a.noidung, '') AS description    
   ,a.TrangThaiCongViec AS STATUS    
   ,a.tieude   
   ,a.noidung    
   ,ISNULL(a.Nguoiphoihop, '') AS Nguoiphoihop    
   ,isnull(a.Nguoixuly, '') AS Nguoixuly   
   ,ISNULL(a.Nguoigiao, '') AS Nguoigiao   
   ,ISNULL(a.Nguoitheodoi, '') AS Nguoitheodoi    
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, null), 120)) AS [start]    
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS [end]   
   ,trim(CONVERT(CHAR, ISNULL(e.CreatedTime, getdate()), 120)) AS CreatedTime   
   ,ISNULL(a.Loaicv, '') AS Loaicv   
   ,ISNULL(a.CongViecCha,'') as CongViecCha    
   ,a.Tiendo as Progress    
   ,b.Ten as projectName    
   ,b.UserWorkflowId as ProjectId   
   ,d.Ten as statusName   
   ,a.Douutien Priority    
   ,c.TenCV as CategoryName    
   ,d.TrangThaiCongViec as StatusType    
   ,e.Id as Id1   
   ,e.CreatedBy          
   ,d.TrangThaiCongViec as StatusType    
   ,case when ISNULL(g.UserWorkflowId,0)>0 then 1 else 0 end as IsMyWork   
   ,case when d.TrangThaiCongViec=N'Hoàn thành' then trim(CONVERT(CHAR, ISNULL(e.LastModified, null), 120)) else null end as DateComplete    
   ,CONVERT(CHAR, ISNULL(e.LastModified, e.CreatedTime), 120) as LastModified    
   --,case when exists ( select UserWorkflowId as abc from [Dynamic].[Data_WORK] where CongViecCha=a.UserWorkflowId) then 'True' else 'False' end as Haschildren    
   ,ISNULL(a.CongViecCha,'') as Parent    
   ,'' as IsShowInGanttChart   
   ,case when d.TrangThaiCongViec<>N'Hoàn thành' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) >0 then N'Trễ '+ trim(str( DATEDIFF(DAY, Ngayketthuc, GETDATE()))) +N' ngày'   
   when d.TrangThaiCongViec<>N'Hoàn thành' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) <0 then N'Còn '+ trim(str( ABS( DATEDIFF(DAY, Ngayketthuc, GETDATE())))) +N' ngày'   
   when d.TrangThaiCongViec<>N'Hoàn thành' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) =0 then N'Hôm nay ( '+ trim(str( DATEDIFF(HOUR, GETDATE(),Ngayketthuc )))+'h )'   
   else '' end as RemainTime  
   ,case when ISNULL(h.UserWorkflowId,'')='' then f.TimeExpired  
   else h.TimeExpired end as TimeExpired  
   FROM [Dynamic].[Data_WORK] AS a  
   inner join #duan b on ISNULL(a.Duan,'')=b.UserWorkflowId  
   left join DYNAMIC.Data_NHOMCV c on a.Loaicv=c.UserWorkflowId  
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId  
   inner join Dynamic.Workflow_WORK e on a.UserWorkflowId=e.UserWorkflowId  
   inner join #b f on a.UserWorkflowId=f.UserWorkflowId  
   left join @tbId g on a.UserWorkflowId=g.UserWorkflowId  
   left join #c h on a.UserWorkflowId=h.UserWorkflowId  
   order by f.TimeExpired desc , d.TrangThaiCongViec ,a.UserWorkflowId desc  
   drop table #duan   
   drop table #tbTemp   
   drop table #b   
   drop table #c   
   drop table #tbAll  
   drop table #tbExist
go

