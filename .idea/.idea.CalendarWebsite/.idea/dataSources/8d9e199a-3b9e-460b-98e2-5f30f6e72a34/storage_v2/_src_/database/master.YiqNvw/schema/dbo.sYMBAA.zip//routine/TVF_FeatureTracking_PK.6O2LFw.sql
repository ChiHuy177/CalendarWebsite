CREATE FUNCTION [dbo].[TVF_FeatureTracking_PK]
(
    @SiteId uniqueidentifier,
    @FeatureId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[FeatureTracking] WITH (INDEX=FeatureTracking_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        FeatureId = @FeatureId

go

