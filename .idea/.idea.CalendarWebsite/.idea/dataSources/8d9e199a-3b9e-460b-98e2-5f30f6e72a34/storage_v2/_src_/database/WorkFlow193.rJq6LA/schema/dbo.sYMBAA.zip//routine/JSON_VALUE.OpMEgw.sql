CREATE FUNCTION [dbo].[JSON_VALUE]
(
    @JSON NVARCHAR(max),
    @column NVARCHAR(max)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
set @column = SUBSTRING(@column,3,len(@column))

DECLARE @value NVARCHAR(MAX);
DECLARE @trimmedJSON NVARCHAR(MAX);

DECLARE @start INT;
DECLARE @end INT;

set @start = PATINDEX('%' + @column + '":%',@JSON) + LEN(@column) + 2;

SET @trimmedJSON = SUBSTRING(@JSON, @start, LEN(@JSON));
Set @end = CHARINDEX(',',@trimmedJSON);
IF @end = 0  
	set @end = LEN(@trimmedJSON)
SET @value = REPLACE(SUBSTRING(@trimmedJSON, 0, @end),'"','');

RETURN @value
END
go

