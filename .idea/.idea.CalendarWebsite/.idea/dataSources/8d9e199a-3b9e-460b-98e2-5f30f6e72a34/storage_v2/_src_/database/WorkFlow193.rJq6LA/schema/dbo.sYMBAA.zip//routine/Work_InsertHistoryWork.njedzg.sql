CREATE   PROC [dbo].[Work_InsertHistoryWork] 
   @UpdateUser as nvarchar(50) 
   ,@Date as datetime2(7) 
   ,@OldValue as nvarchar(1000) 
   ,@NewValue as nvarchar(1000) 
   ,@WorkId as nvarchar(50) 
   ,@ColumnName as nvarchar(100) 
   ,@Note as nvarchar(1000)=''
   as 
   INSERT INTO [Dynamic].[Data_LSCNTTCV] 
   ( 
   [UpdateUser] 
   ,[Date] 
   ,[OldValue] 
   ,[NewValue] 
   ,[WorkId] 
   ,[ColumnName] 
   ,[Note]
   ) 
   VALUES 
   ( 
   @UpdateUser 
   ,@Date 
   ,@OldValue 
   ,@NewValue 
   ,@WorkId 
   ,@ColumnName 
   ,@Note
   ) 
go

