CREATE FUNCTION [dbo].[TVF_DocStreams_ExpireLT]
(
    @LTExpirationUTC datetime
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[DocStreams] WITH (INDEX=DocStreams_Expiration, FORCESEEK)
    WHERE
        ExpirationUTC < @LTExpirationUTC

go

