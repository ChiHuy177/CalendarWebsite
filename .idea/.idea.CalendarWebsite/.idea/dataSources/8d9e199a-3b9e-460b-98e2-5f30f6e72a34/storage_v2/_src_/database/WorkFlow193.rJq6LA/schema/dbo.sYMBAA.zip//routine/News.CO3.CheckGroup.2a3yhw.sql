-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.CheckGroup] @userId NVARCHAR(MAX),
@userWorkflowId NVARCHAR(MAX),
@WorkflowId bigint
AS
BEGIN
	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @QueryString NVARCHAR(MAX);
	DECLARE @DataTableName NVARCHAR(MAX);
	SET NOCOUNT ON;
		SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
			SET @QueryString = '
SELECT dw.Id
FROM '+ @DataTableName+' [dw]
INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
WHERE u.IsDeleted = 0
  AND (
  dw.UserWorkflowId='+@userWorkflowId+'
  and
     ((
	 (
      ISNULL([dw].Admin, '''') <> ''''
      AND ([dw].Admin) LIKE (''%'' + CAST('+@userId+' AS VARCHAR) + ''%''))
      )
	  or
	  (  ISNULL([dw].Member, '''') <> ''''
      AND ([dw].Member) LIKE (''%'' + CAST('+@userId+' AS VARCHAR) + ''%''))
	  )
	  
	     
    )'
		PRINT @QueryString;

	EXEC sp_ExecuteSql @QueryString;
END
go

