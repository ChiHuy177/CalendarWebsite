CREATE Procedure [dbo].[proc_App_SetOAuthAppIdOnAppInstance] (
    @InstallationId uniqueidentifier,
    @OAuthAppId nvarchar(256),
    @SiteId uniqueidentifier    
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
UPDATE TVF_AppInstallations_Id(@SiteId, @InstallationId)
    SET OAuthAppId = @OAuthAppId
COMMIT TRANSACTION

go

