-- [Work_GetHistoryChangedStatus] 3139     
   CREATE   PROC [dbo].[Work_GetHistoryChangedStatus]     
   @id as bigint     
   as     
   select a.Id     
   ,a.UserWorkflowId     
   ,b.FullName as UpdateUser     
   ,Date     
   ,Workid     
   ,case when a.ColumnName='TrangThaiCongViec' then trangthaiTu.Ten 
   when a.ColumnName='Nguoixuly' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.OldValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   when a.ColumnName='Nguoitheodoi' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.OldValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   when a.ColumnName='Nguoiphoihop' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.OldValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   when a.ColumnName='Nguoigiao' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.OldValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   else a.OldValue end OldValue     
   ,case when a.ColumnName='TrangThaiCongViec' then trangthaiDen.Ten
   when a.ColumnName='Nguoixuly' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.NewValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   when a.ColumnName='Nguoitheodoi' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.NewValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   when a.ColumnName='Nguoiphoihop' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.NewValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   when a.ColumnName='Nguoigiao' then (select STUFF((SELECT ', ' + FullName FROM PersonalProfile t2 where t2.Id in (select [dbo].fn_GetNumeric(value) from string_split(a.NewValue,';')) FOR XML PATH ('')), 1, 1, '') )     
   else a.NewValue end NewValue     
   ,c.Label as ColumnName     
   ,a.Note     
   into #a
   from Dynamic.Data_LSCNTTCV a     
   left join PersonalProfile b on a.UpdateUser ='P:'+ TRIM(str( b.Id))     
   inner join ( select a.Name,a.Label from Property a inner join Workflow b on a.WorkflowId=b.Id where b.Code='WORK' and a.Name not in ('IndexWork') )as c on a.ColumnName=c.Name     
   left join ( select * from Dynamic.Data_RESOURCETTFC ) as trangthaiTu on a.OldValue= TRIM(str(trangthaiTu.UserWorkflowId))     
   left join ( select * from Dynamic.Data_RESOURCETTFC ) as trangthaiDen on a.NewValue=trim( str( trangthaiDen.UserWorkflowId))  
   where a.WorkId=@id     
   -- order by a.Date desc 
   select * from #a a
   group by id,UserWorkflowId,UpdateUser,date,WorkId,OldValue,NewValue,ColumnName,Note
   order by a.Date desc 
go

