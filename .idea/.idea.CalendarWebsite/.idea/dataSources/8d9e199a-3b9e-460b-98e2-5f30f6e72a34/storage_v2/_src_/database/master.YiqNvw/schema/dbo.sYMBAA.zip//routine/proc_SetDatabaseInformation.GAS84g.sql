CREATE PROCEDURE [dbo].[proc_SetDatabaseInformation]
(
    @Name nvarchar(128),
    @Value nvarchar(max),
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    DECLARE @Escaped nvarchar(1024)
    SELECT @Escaped = dbo.fn_EscapeForLike(@Name, 0)
    SET @Escaped = @Escaped + '_%'
    BEGIN TRAN
    DELETE FROM
        TVF_DatabaseInformation_Name(@Name)
    DELETE FROM
        TVF_DatabaseInformation_NameLike(@Escaped)
    IF (@Value IS NOT NULL)
    BEGIN
        INSERT INTO DatabaseInformation(
            Name,
            Value)
        VALUES (
            @Name,
            @Value)
    END
    COMMIT TRAN

go

