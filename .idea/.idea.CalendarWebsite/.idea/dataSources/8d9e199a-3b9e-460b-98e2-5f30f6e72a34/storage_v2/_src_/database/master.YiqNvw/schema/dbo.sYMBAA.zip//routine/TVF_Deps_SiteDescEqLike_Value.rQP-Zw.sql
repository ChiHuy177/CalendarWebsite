CREATE FUNCTION [dbo].[TVF_Deps_SiteDescEqLike_Value]
(
    @SiteId uniqueidentifier,
    @DepDesc nvarchar(270),
    @DepDescLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        Deps WITH (INDEX=Deps_DepToDoc, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DepDesc = @DepDesc
    UNION ALL
    SELECT
        *
    FROM
        Deps WITH (INDEX=Deps_DepToDoc, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DepDesc LIKE @DepDescLike

go

