CREATE PROC [dbo].[proc_DeleteItemJunctionsVersion](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier, 
    @ItemId int,
    @ItemVersion int,
    @DeleteOp int,
    @DeleteTransactionId varbinary(16)
    )
AS
    SET NOCOUNT ON
    DECLARE @ParentId AS uniqueidentifier
    DECLARE @DocId AS uniqueidentifier
    EXEC proc_ListItemIdToSiteParentDocId 
        @SiteId, @ListId, @ItemId, @ParentId OUTPUT, @DocId OUTPUT
    IF @DeleteOp = 3
    BEGIN
        DELETE
            UDJV
        FROM
            TVF_UserDataJunctionsVersioned_SiteParIdDocIdCalcVer(
                @SiteId,
                @ParentId,
                @DocId,
                @ItemVersion) AS UDJV
    END
    ELSE
    BEGIN
        UPDATE
            UDJV
        SET
            UDJV.tp_DeleteTransactionId = @DeleteTransactionId
        FROM
            TVF_UserDataJunctionsVersioned_SiteIsCurParIdDocIdCalcVer(
                @SiteId,
                CAST(0 AS bit), 
                @ParentId,
                @DocId,
                @ItemVersion) AS UDJV
    END

go

