CREATE PROCEDURE [dbo].[proc_InsertContextEventReceiver](
    @Id uniqueidentifier,
    @Name nvarchar(256),
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ParentHostId uniqueidentifier,
    @ParentHostType int,
    @Synchronization int,
    @Type int,
    @SequenceNumber int,
    @Assembly nvarchar(256),
    @Class nvarchar(256),
    @Data nvarchar(256),
    @Filter nvarchar(256),
    @Credential int,
    @ContextHostType int,
    @ContextObjectItemId int,
    @ContextObjectUrl nvarchar(260),
    @ContextType uniqueidentifier,
    @ContextEventType uniqueidentifier,
    @ContextId uniqueidentifier,
    @ContextObjectId uniqueidentifier,
    @ContextCollectionId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @ERR int, @ROWC int
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    IF @ContextCollectionId IS NULL
    BEGIN
        SET @iRet = 87
        GOTO CLEANUP
    END
    IF @ContextObjectId IS NOT NULL
    BEGIN
        DECLARE @ParentId uniqueidentifier;
        SET @ParentId = NEWID();
        DECLARE @ContextObjectDirName nvarchar(256)
        DECLARE @ContextObjectLeafName nvarchar(128)
        IF @ContextObjectUrl IS NOT NULL
            EXEC proc_SplitUrl 
                @ContextObjectUrl, 
                @ContextObjectDirName OUTPUT, 
                @ContextObjectLeafName OUTPUT
        ELSE
        BEGIN
            SET @ContextObjectDirName = NULL
            SET @ContextObjectLeafName = NULL
        END
        SELECT @ROWC = COUNT(1)
        FROM
            TVF_EventReceivers_UpdLock_SiteWebHostHostTypeTypeItemId(@SiteId, @WebId, @ParentHostId, @ParentHostType, 32767, @ContextObjectItemId) AS ER    
        IF (@ROWC = 0) OR (NOT EXISTS (
            SELECT TOP 1
                1 
            FROM 
                TVF_EventReceivers_NoLock_SiteWebHostHostTypeTypeItemId(@SiteId, @WebId, @ParentHostId, @ParentHostType, 32767, @ContextObjectItemId) AS ER
            WHERE
                ER.ContextCollectionId = @ContextObjectId AND
                ER.ContextObjectId IS NULL AND
                ER.ContextId IS NULL AND
                ER.ContextType IS NULL AND
                ER.ContextEventType IS NULL AND
                ER.SourceId IS NULL AND
                ER.SourceType = 0 AND
                ER.Assembly = N'' AND
                ER.Class = N'' AND
                ER.SequenceNumber = @SequenceNumber AND
                ER.SolutionId IS NULL
            ))
        BEGIN
            INSERT INTO
                EventReceivers (EventReceivers.Id, EventReceivers.Name, EventReceivers.SiteId, EventReceivers.WebId, EventReceivers.HostId, EventReceivers.HostType, EventReceivers.ItemId, EventReceivers.DirName, EventReceivers.LeafName, EventReceivers.Synchronization, EventReceivers.Type, EventReceivers.SequenceNumber, EventReceivers.RemoteUrl, EventReceivers.Assembly, EventReceivers.Class, EventReceivers.SolutionId, EventReceivers.Data, EventReceivers.Filter, EventReceivers.SourceId, EventReceivers.SourceType, EventReceivers.Credential, EventReceivers.ContextType, EventReceivers.ContextEventType, EventReceivers.ContextId, EventReceivers.ContextObjectId, EventReceivers.ContextCollectionId)
            VALUES (
                @ParentId, 
                N'' ,
                @SiteId, 
                @WebId, 
                @ParentHostId, 
                @ParentHostType,
                @ContextObjectItemId, 
                @ContextObjectDirName, 
                @ContextObjectLeafName,
                @Synchronization, 
                32767,
                @SequenceNumber, 
                NULL,
                N'' , 
                N'' , 
                NULL ,
                N'' , 
                N'' ,
                NULL , 
                0 , 
                0 ,
                NULL , 
                NULL ,
                NULL , 
                NULL , 
                @ContextObjectId )
        END
    END
    INSERT INTO
        EventReceivers (EventReceivers.Id, EventReceivers.Name, EventReceivers.SiteId, EventReceivers.WebId, EventReceivers.HostId, EventReceivers.HostType, EventReceivers.ItemId, EventReceivers.DirName, EventReceivers.LeafName, EventReceivers.Synchronization, EventReceivers.Type, EventReceivers.SequenceNumber, EventReceivers.RemoteUrl, EventReceivers.Assembly, EventReceivers.Class, EventReceivers.SolutionId, EventReceivers.Data, EventReceivers.Filter, EventReceivers.SourceId, EventReceivers.SourceType, EventReceivers.Credential, EventReceivers.ContextType, EventReceivers.ContextEventType, EventReceivers.ContextId, EventReceivers.ContextObjectId, EventReceivers.ContextCollectionId)
    VALUES (
        @Id, 
        @Name,
        @SiteId, 
        @WebId, 
        @ParentHostId, 
        @ContextHostType,
        @ContextObjectItemId, 
        NULL , 
        NULL ,
        @Synchronization, 
        @Type, 
        @SequenceNumber,
        NULL,
        @Assembly, 
        @Class, 
        NULL ,
        @Data, 
        @Filter,
        NULL , 
        0 , 
        @Credential,
        @ContextType, 
        @ContextEventType,
        @ContextId, 
        @ContextObjectId, 
        @ContextCollectionId )
     SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
     IF @ERR <> 0
        SET @iRet = 30
     ELSE IF @ROWC <> 1
        SET @iRet = 87                       
 CLEANUP:
     IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
     RETURN @iRet

go

