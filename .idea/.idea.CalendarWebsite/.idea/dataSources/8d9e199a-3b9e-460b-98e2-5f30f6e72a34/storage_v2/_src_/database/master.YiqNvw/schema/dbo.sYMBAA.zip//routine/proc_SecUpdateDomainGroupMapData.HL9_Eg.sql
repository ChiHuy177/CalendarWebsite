CREATE PROCEDURE [dbo].[proc_SecUpdateDomainGroupMapData](
    @SiteId uniqueidentifier,
    @CacheVersion bigint,
    @DomainGroupMapCache varbinary(max),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        S
    SET
        S.DomainGroupMapCacheVersion = @CacheVersion,
        S.DomainGroupMapCache = @DomainGroupMapCache
    FROM
        TVF_Sites_Id(@SiteId) AS S
    RETURN 0

go

