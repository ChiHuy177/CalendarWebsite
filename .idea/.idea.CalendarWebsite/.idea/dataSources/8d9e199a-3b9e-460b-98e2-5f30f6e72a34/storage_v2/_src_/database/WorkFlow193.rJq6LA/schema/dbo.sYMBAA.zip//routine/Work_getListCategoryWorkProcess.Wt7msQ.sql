CREATE   PROC [dbo].[Work_getListCategoryWorkProcess]       
   @UserWorkFlowId as nvarchar(250)='',        
   @userId as nvarchar(500)='',       
   @title as nvarchar(500)='',       
   @adminPage as nvarchar(500)=''       
   as        
   declare @user as nvarchar(250) = (select 'P:'+ TRIM(str(Id)) from PersonalProfile where 'P:'+ TRIM(str(Id))=@userId)        
   if(@UserWorkFlowId='')        
   begin        
   SELECT a.Id        
   ,a.UserWorkflowId        
   ,a.Title        
   ,a.WorkflowId                  
   ,'' as FlowChartData        
   ,ISNULL(a.Version,1) as Version        
   ,c.CreatedTime        
   ,PermissionEdit        
   ,c.CreatedBy       
   ,PermissionUser       
   ,a.Duan       
   ,a.CreateType       
   ,d.Title as WorkFlowName       
   ,a.Quytrinh as WorkFlowId      
   ,a.AddDefaultUserAssign   
   ,a.ActiveManual  
   ,a.AllowShowAllDataInWorkProcess
   FROM Dynamic.Data_TMDSQTCV a       
   inner join (        
   select WorkflowId,max(ISNULL(Version,1)) as Version from Dynamic.Data_TMDSQTCV group by WorkflowId        
   ) b on ISNULL(a.WorkflowId,'') = ISNULL(b.WorkflowId,'') and ISNULL(a.Version,1)=b.Version        
   left join Dynamic.Workflow_TMDSQTCV c on c.UserWorkflowId = a.UserWorkflowId       
   left join Workflow d on a.Quytrinh=d.Id       
   where ISNULL(a.IsUseForWork,'')='' and ( @userId in (select * from string_split(a.PermissionEdit,';')) or @user=@adminPage)        
   and ISNULL(a.IsDelete ,'False')= 'False' and (a.Title like N'%'+trim(@title)+'%' or d.Title like N'%'+trim(@title)+'%')       
   order by a.UserWorkflowId desc        
   end        
   else        
   begin        
   SELECT a.Id        
   ,a.UserWorkflowId        
   ,a.Title        
   ,a.WorkflowId        
   ,CONVERT(date, GETDATE(),203) as CreatedTime       
   ,'' as CreatedBy       
   ,REPLACE(FlowChartData,'"strokeDasharray": "5 5"','"strokeDasharray": ""') as FlowChartData       
   ,ISNULL(a.Version,1) as Version        
   ,PermissionEdit       
   ,PermissionUser       
   ,a.QuyTrinh       
   ,a.Duan       
   ,a.CreateType       
   ,d.Title as WorkFlowName       
   ,a.Quytrinh as WorkFlowId       
   ,a.AddDefaultUserAssign  
   ,a.ActiveManual  
   ,a.AllowShowAllDataInWorkProcess
   FROM Dynamic.Data_TMDSQTCV a       
   left join Workflow d on a.Quytrinh=d.Id       
   where a.UserWorkflowId=@UserWorkFlowId and ISNULL(a.IsDelete ,'False')= 'False'        
   order by a.UserWorkflowId desc        
   end
go

