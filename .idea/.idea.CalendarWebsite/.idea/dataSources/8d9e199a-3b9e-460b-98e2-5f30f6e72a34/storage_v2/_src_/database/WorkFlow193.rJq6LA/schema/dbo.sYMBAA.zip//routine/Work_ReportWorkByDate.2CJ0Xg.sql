-- [Work_ReportWorkByDate] '2024-01-01','','','','P:481','','','2024-03-31',''      
   CREATE   PROC  [dbo].[Work_ReportWorkByDate]                                                               
   @fromDateBegin AS NVARCHAR(50) = ''                                                                                                                                      
   ,@toDateBegin AS NVARCHAR(50) = ''                                                                      
   ,@title as nvarchar(150)=''                                                        
   ,@projectId as nvarchar(150)=''                                                                                    
   ,@employee as nvarchar(150)=''                                                        
   ,@dateCompleteFrom as NVARCHAR(50)=''                                                        
   ,@dateCompleteTo as NVARCHAR(50)=''                                                        
   ,@fromDateEnd AS NVARCHAR(50) = ''                                                                                                                                      
   ,@toDateEnd AS NVARCHAR(50) = ''                                                                   
   as                                                         
   declare @sql as nvarchar(max)=N'' ,@sql0  as nvarchar(max)=N''                      
   , @sql1 as nvarchar(max)=N'',@sql2 as nvarchar(max)=N'',@dateWhereBegin as nvarchar(max)=N'',@dateWhereEnd as nvarchar(max)=N'',@projectWhere as nvarchar(max)=N'',@Where as nvarchar(max)=N'',                         
   @dateCompWhere as nvarchar(300)=N''          
   if(@fromDateBegin<>'' and @toDateBegin='')                                                       
   begin                                                       
   set @dateWhereBegin=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''0001-12-12''),23) )>=0 '                                      
   end                                          
   else if(@fromDateBegin<>'' and @toDateBegin<>'')                                        
   begin                                       
   set @dateWhereBegin=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''0001-12-12''),23) )>=0 and '+                                    
   ' DATEDIFF(day, CONVERT(varchar,'''+@toDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''9999-12-12''),23) )<=0 '                                      
   end                                      
   if(@fromDateEnd<>'' and @toDateEnd='')                                                      
   begin                                                       
   set @dateWhereEnd=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )<=0 '                                                            
   end            
   else if(@fromDateEnd<>'' and @toDateEnd<>'')                    
   begin                                           
   set @dateWhereEnd=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )>=0 and '+                     
   ' DATEDIFF(day, CONVERT(varchar,'''+@toDateEnd+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )<=0 '                                                       
   end                             
   if(@dateCompleteFrom<>'' and @dateCompleteTo='')                         
   begin                         
   set @dateCompWhere=' and DATEDIFF(day, CONVERT(varchar,'''+@dateCompleteFrom+''',23) , CONVERT(varchar,ISNULL(d.Date,''9999-12-12''),23) )>=0 '                                       
   end                                       
   else if(@dateCompleteFrom<>''  and @dateCompleteTo<>'' )                                                      
   begin                                                 
   set @dateCompWhere=' and DATEDIFF(day, CONVERT(varchar,'''+@dateCompleteFrom+''',23) , CONVERT(varchar,ISNULL(d.Date,''9999-12-12''),23) )>=0 and '+       
   ' DATEDIFF(day, CONVERT(varchar,'''+@dateCompleteFrom+''',23) , CONVERT(varchar,ISNULL(d.Date,''9999-12-12''),23) )<=0 '                                    
   end                                      
   if(@projectId<>'')                                                      
   begin                                                       
   set @projectWhere=' and b.UserWorkflowId in (select * from Split('''+@projectId+''','',''))'                                                     
   end                
   set @Where =N' where ( ISNULL(b.IsDeleted,''False'')=''False'' and b.TrangThai  <>'''+N'Hủy'+''' and ISNULL(a.IsActive,''True'')=''True''                 
   and a.Tieude like N''%'+@title+'%'''+' '+@projectWhere+''+' '+@dateWhereBegin+''              
   if(@employee <>'')                                                      
   begin                                          
   set @Where= @Where + ' and isnull(d.TrangThaiCongViec,'''')<>N'''+N'Hủy' +''' and '''+ @employee+ ''' in  ( select * from string_split(a.NguoiXuLyDauTien ,'';''))            
   '+@dateWhereBegin+' '+@dateWhereEnd+' '+@dateCompWhere+')            
   or (            
   ISNULL(b.IsDeleted,''False'')=''False'' and b.TrangThai  <>'''+N'Hủy'+''' and ISNULL(a.IsActive,''True'')=''True''                 
   and a.Tieude like N''%'+@title+'%'''+' '+@projectWhere+' and isnull(d.TrangThaiCongViec,'''') in (N'''+N'Hoàn thành'+''',N'''+N'Người xử lý hoàn thành'+''')             
   and '''+@employee+''' in  ( select * from string_split(a.NguoiXuLyDauTien ,'';'')) '+@dateWhereBegin+'        
   and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(d.Date,''0001-12-12''),23))<=0        
   )'                                                      
   end                                 
   else                                          
   begin                                           
   set @Where=@Where + ' and isnull(d.TrangThaiCongViec,'''')<>N'''+N'Hủy' +''' and 1=1  '+@dateWhereBegin+' '+@dateWhereEnd+' '+@dateCompWhere+')            
   or (            
   ISNULL(b.IsDeleted,''False'')=''False'' and b.TrangThai  <>'''+N'Hủy'+''' and ISNULL(a.IsActive,''True'')=''True''                 
   and a.Tieude like N''%'+@title+'%'''+' '+@projectWhere+' and isnull(d.TrangThaiCongViec,'''') in (N'''+N'Hoàn thành'+''',N'''+N'Người xử lý hoàn thành'+''') '+@dateWhereBegin+'           
   and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(d.Date,''0001-12-12''),23))<=0        
   )'            
   end                            
   set @sql0=N'                            
   select max(c.Id) as Id,c.WorkId,b.TrangThaiCongViec,MAX(c.Date ) as Date                             
   into #b from  Dynamic.Data_LSCNTTCV c                                                                            
   inner join Dynamic.data_RESOURCETTFC b on c.NewValue=trim(str( b.UserWorkflowId))                               
   where  ColumnName=''TrangThaiCongViec'' and b.TrangThaiCongViec = (N'''+N'Người xử lý hoàn thành'+''') and b.TrangThaiCongViec<>N'''+N'Hủy'+'''                                   
   group by WorkId , b.TrangThaiCongViec                         
   insert into #b                      
   select max(c.Id) as Id,c.WorkId,b.TrangThaiCongViec,MAX(c.Date ) as Date                      
   from  Dynamic.Data_LSCNTTCV c                                      
   inner join Dynamic.data_RESOURCETTFC b on c.NewValue=trim(str( b.UserWorkflowId))                         
   left join #b d on c.WorkId=d.WorkId                      
   where  ColumnName=''TrangThaiCongViec'' and b.TrangThaiCongViec = N'''+N'Hoàn thành'+''' and b.TrangThaiCongViec<>N'''+N'Hủy'+'''                                   
   and d.WorkId is null                      
   group by  c.WorkId , b.TrangThaiCongViec '      
   set @sql=N'            
   select                                                                     
   a.UserWorkflowId                                                                    
   ,b.Ten                              
   ,a.Tieude                                                               
   ,i.FullName as CreatedBy       
   ,trim(CONVERT(CHAR, ISNULL(c.CreatedTime, null), 120))  as CreatedTime                                                                   
   ,trim(CONVERT(CHAR, ISNULL(a.NgayBatDau, null), 120))  as NgayBatDau                                                                   
   ,trim(CONVERT(CHAR, ISNULL(a.NgayKetThuc, null), 120))  as NgayKetThuc                                                                      
   ,a.NguoiXuLyDauTien                                                                      
   ,DATEDIFF(HOUR,a.Ngaygiaoviec, d.Date ) as TimeExec                                                                      
   , case when d.TrangThaiCongViec in (N'''+N'Hoàn thành'+''',N'''+N'Người xử lý hoàn thành'+''') and (isnull(a.Ngayketthuc,'''')='''' or DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0)                                                              
   then N'''+N'Hoàn thành đúng tiến độ'+'''                    
   when d.TrangThaiCongViec in (N'''+N'Hoàn thành'+''',N'''+N'Người xử lý hoàn thành'+''') and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0                                                               
   then N'''+N'Hoàn thành trễ tiến độ'+'''                             
   when (isnull(d.TrangThaiCongViec,'''')='''' or d.TrangThaiCongViec not in (N''Hoàn thành'',N'''+N'Người xử lý hoàn thành'+''')) and ((isnull(a.Ngayketthuc,'''')='''' ) or DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )<0)                            
   then N'''+N'Chưa hoàn thành'+'''                            
   when (isnull(d.TrangThaiCongViec,'''')='''' or d.TrangThaiCongViec not in (N''Hoàn thành'',N'''+N'Người xử lý hoàn thành'+'''))  and DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )>0                            
   then N'''+N'Quá hạn'+'''                              
   else  N'''' end as Status                                                                      
   ,  case when d.TrangThaiCongViec in (N'''+N'Hoàn thành'+''',N'''+N'Người xử lý hoàn thành'+''') and (isnull(a.Ngayketthuc,'''')='''' or DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0)                                                      
   then 1                            
   when d.TrangThaiCongViec in (N'''+N'Hoàn thành'+''',N'''+N'Người xử lý hoàn thành'+''') and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0                               
   then 2                      
   when (isnull(d.TrangThaiCongViec,'''')='''' or d.TrangThaiCongViec not in (N''Hoàn thành'',N'''+N'Người xử lý hoàn thành'+''')) and ((isnull(a.Ngayketthuc,'''')='''' ) or DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )<0)                            
   then 3                            
   when (isnull(d.TrangThaiCongViec,'''')='''' or d.TrangThaiCongViec not in (N''Hoàn thành'',N'''+N'Người xử lý hoàn thành'+'''))  and DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )>0                    
   then 4                            
   else  0 end as StatusInt              
   , '''' as userId                                                              
   ,d.TrangThaiCongViec                                                     
   ,d.Date as DateCompelete                                                      
   ,DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) as abc                   
   ,ISNULL( Nguoixuly,'''')+'';''+ISNULL(Nguoixulydautien,'''') as Nguoithamgia           
   , b.UserWorkflowId as ProjectId                     
   ,a.TrangThaiCongViec as TrangThaiCongViec1                  
   into #a '            
   set @sql1=N'                                                    
   from Dynamic.Data_WORK a                                                                      
   inner join Dynamic.Data_RESOURCEDA b on a.Duan=b.UserWorkflowId                                                    
   inner join UserWorkflow c on a.UserWorkflowId=c.Id                                                                      
   left join       
   (                                      
   select * from #b                                                 
   ) d on a.UserWorkflowId=d.WorkId                                                        
   inner join PersonalProfile i on i.Id=c.UserId                   
   ' +' ' + trim( @where)              
   set @sql2=N'                                                      
   select                                                                     
   b.UserWorkflowId as WorkId                                                                  
   ,b.Ten as ProjectName                                                                  
   ,b.Tieude   as Title                          
   ,b.CreatedBy                                                                     
   ,b.CreatedTime                                                            
   ,ISNULL( g.OldValue, b.NgayBatDau)  as BeginDate                            
   ,ISNULL( h.OldValue,b.NgayKetThuc)    as EndDate                               
   ,trim(CONVERT(CHAR, ISNULL(DateCompelete, null), 120))  as DateCompelete                                
   ,b.TrangThaiCongViec                            
   ,b.NguoiXuLyDauTien   as UserExec                                                                  
   ,abs(b.TimeExec) as TimeExec                                                               
   ,b.Status                                                                    
   ,b.StatusInt                                                                    
   , e.NewValue as ChangDateBegin                                                                    
   , f.NewValue as ChangDateEnd                                                                    
   ,UserExecFullName = STUFF((                                                                    
   SELECT '', '' + h.FullName                                                                   
   FROM #a a                                                       
   cross apply string_split(ISNULL(a.NguoiXuLyDauTien,''''),'';'') g                                                                  
   inner join PersonalProfile h on ''P:''+trim( str(h.Id))=g.value                                                        
   where a.UserWorkflowId=b.UserWorkflowId                                                                    
   FOR XML PATH('''')), 1, 2, '''')                                                             
   ,Nguoithamgia                      
   ,ProjectId                                 
   from #a b                            
   left join (                                                                     
   select a.* from Dynamic.Data_LSCNTTCV a                               
   inner join #a b on a.WorkId=b.UserWorkflowId                          
   inner join ( select MAX(Id) as Id,WorkId from  Dynamic.Data_LSCNTTCV where ColumnName=''Ngaybatdau'' group by WorkId )  c on c.Id=a.Id                                                                      
   where ColumnName=''Ngaybatdau''                                                      
   ) e on e.WorkId=b.UserWorkflowId                                    
   left join (                                                                     
   select a.* from Dynamic.Data_LSCNTTCV a                           
   inner join #a b on a.WorkId=b.UserWorkflowId                          
   inner join ( select MAX(Id) as Id,WorkId from  Dynamic.Data_LSCNTTCV where ColumnName=''Ngayketthuc'' group by WorkId )  c on c.Id=a.Id                                                                      
   where ColumnName=''Ngayketthuc''                                                                     
   ) f on f.WorkId=b.UserWorkflowId                               left join (                                                         
   select a.* from Dynamic.Data_LSCNTTCV a                                                                  
   inner join #a b on a.WorkId=b.UserWorkflowId                          
   inner join ( select min(Id) as Id,WorkId from  Dynamic.Data_LSCNTTCV where ColumnName=''Ngaybatdau'' group by WorkId )  c on c.Id=a.Id                              
   where ColumnName=''Ngaybatdau''                                                    
   ) g on g.WorkId=b.UserWorkflowId                     
   left join (                      
   select a.* from Dynamic.Data_LSCNTTCV a                           
   inner join #a b on a.WorkId=b.UserWorkflowId                          
   inner join ( select min(Id) as Id,WorkId from  Dynamic.Data_LSCNTTCV where ColumnName=''Ngayketthuc'' group by WorkId )  c on c.Id=a.Id                            
   where ColumnName=''Ngayketthuc''                          
   ) h on h.WorkId=b.UserWorkflowId                     
   inner join Dynamic.Data_RESOURCETTFC i on i.Duan= b.ProjectId and b.TrangThaiCongViec1=i.UserWorkflowId  
   where  i.TrangThaiCongViec<>N'''+N'Hủy'+''' 
   group by                                     
   b.UserWorkflowId                                                      
   ,b.Ten                                                            
   ,b.Tieude                                                              
   ,b.CreatedBy                                                                     
   ,b.CreatedTime                                                  
   ,b.NgayBatDau                                                         
   ,b.NgayKetThuc                                                             
   ,b.NguoiXuLyDauTien                                                         
   ,b.TimeExec                                                               
   ,b.Status                                  
   ,b.StatusInt                                                                    
   , e.NewValue                                                                      
   , f.NewValue                                                         
   ,Nguoithamgia                                                       
   ,b.DateCompelete                                                       
   ,ProjectId                            
   ,b.TrangThaiCongViec                            
   ,g.OldValue                          
   ,h.OldValue                          
   order by b.UserWorkflowId  desc                                        
   drop table #a                                    
   drop table #b                        
   '                          
   declare @sqlExec  as nvarchar(max)= (trim( @sql0)+' ' + trim( @sql)+' ' + trim( @sql1)+' '+trim( @sql2))                      
   exec(@sqlExec)              
   PRINT CAST(@sqlExec AS NTEXT)
go

