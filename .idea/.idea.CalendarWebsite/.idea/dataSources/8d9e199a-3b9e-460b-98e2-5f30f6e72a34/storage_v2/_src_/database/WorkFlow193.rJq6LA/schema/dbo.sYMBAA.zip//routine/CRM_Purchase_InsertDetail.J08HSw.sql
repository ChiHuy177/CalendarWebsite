CREATE   PROC [dbo].[CRM_Purchase_InsertDetail]  
  @UserWorkflowId as bigint  
 ,@PurchaseOrderID as bigint
 ,@DueDate as datetime2(7)  
 ,@OrderQty as decimal(18, 4)
 ,@ProductID as bigint
 ,@UnitPrice as  decimal(18, 4)
 ,@LineTotal	as decimal(18, 4)
 ,@Discount	as  decimal(18, 4)
 ,@ReceivedQty as decimal(18, 4)	
 ,@StockedQty as decimal(18, 4)	
 ,@Note	as nvarchar(max)
 ,@ModifiedDate	as  datetime2(7) 
 ,@IsDelete as bit
 as  
 	 
 insert into Dynamic.Data_CRMPurchaseOrderDetail 
 (
 	 UserWorkflowId
 	,PurchaseOrderID
 	,PurchaseOrderDetailID	
 	,DueDate	
 	,OrderQty	
 	,ProductID	
 	,UnitPrice	
 	,LineTotal	
 	,Discount	
 	,ReceivedQty		
 	,StockedQty	
 	,Note	
 	,ModifiedDate	
 	,IsDelete
 )
 
 values (
 
 	@UserWorkflowId,
 	@PurchaseOrderID,
 	null,
 	@DueDate,
 	@OrderQty,
 	@ProductID,
 	@UnitPrice,
 	@LineTotal,
 	@Discount,	
     @ReceivedQty,
     @StockedQty, 
 	@Note,	
 	@ModifiedDate,	
 	@IsDelete
 )
go

