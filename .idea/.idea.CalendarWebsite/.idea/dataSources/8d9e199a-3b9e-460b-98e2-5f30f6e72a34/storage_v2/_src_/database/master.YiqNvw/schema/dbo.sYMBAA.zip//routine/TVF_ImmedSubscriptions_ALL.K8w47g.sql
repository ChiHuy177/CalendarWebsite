CREATE FUNCTION [dbo].[TVF_ImmedSubscriptions_ALL]
(
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[ImmedSubscriptions] WITH (INDEX=ImmedSubscriptions_SiteIdListIdItemId)
    WHERE
        1 = 1

go

