

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [Dynamic].[CreateUserWorkflowCode]
	@Id BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@CurrentYear NVARCHAR(MAX)
		,@CurrentMonth NVARCHAR(MAX)
		,@NeedToUpdateCodeCount BIT = 0
		,@Count BIGINT = 1
		,@WorkflowId BIGINT;

	SET @WorkflowId = (
			SELECT WorkflowId
			FROM UserWorkflow
			WHERE Id = @Id
			);
	SET @CurrentYear = [dbo].[fn_GetThe2digitYear]();
	SET @CurrentMonth = [dbo].[fn_GetThe2digitMonth]();
	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);

	/* Generate basic para for workflow*/
	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE [WorkflowId] = @WorkflowId
					AND ParaName = 'Year'
				)
			)
	BEGIN
		INSERT INTO [dbo].[WorkflowPara] (
			ParaName
			,WorkflowId
			,Value
			)
		VALUES (
			'Year'
			,@WorkflowId
			,[dbo].[fn_GetThe2digitYear]()
			);
	END

	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE [WorkflowId] = @WorkflowId
					AND ParaName = 'Month'
				)
			)
	BEGIN
		INSERT INTO [dbo].[WorkflowPara] (
			ParaName
			,WorkflowId
			,Value
			)
		VALUES (
			'Month'
			,@WorkflowId
			,[dbo].[fn_GetThe2digitMonth]()
			);
	END

	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE [WorkflowId] = @WorkflowId
					AND ParaName = 'CodeCount'
				)
			)
	BEGIN
		INSERT INTO [dbo].[WorkflowPara] (
			ParaName
			,WorkflowId
			,Value
			)
		VALUES (
			'CodeCount'
			,@WorkflowId
			,'1'
			);
	END

	/*----------------------------------------*/
	/* Update Wofklow Para*/
	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE WorkflowId = @WorkflowId
					AND ParaName = 'Year'
					AND Value = @CurrentYear
				)
			)
	BEGIN
		UPDATE [dbo].[WorkflowPara]
		SET Value = @CurrentYear
		WHERE WorkflowId = @WorkflowId
			AND ParaName = 'Year';

		SET @NeedToUpdateCodeCount = 1;
	END

	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE WorkflowId = @WorkflowId
					AND ParaName = 'Month'
					AND Value = @CurrentMonth
				)
			)
	BEGIN
		UPDATE [dbo].[WorkflowPara]
		SET Value = @CurrentMonth
		WHERE WorkflowId = @WorkflowId
			AND ParaName = 'Month';

		SET @NeedToUpdateCodeCount = 1;
	END


	IF (@NeedToUpdateCodeCount = 1)
	BEGIN
		UPDATE [dbo].[WorkflowPara]
		SET Value = 1
		WHERE WorkflowId = @WorkflowId
			AND ParaName = 'CodeCount';
	END

	/* Set WorkflowCode depend on Year and Month*/
	SET @Count = (
			SELECT MAX(CAST(Value AS BIGINT))
			FROM [dbo].[WorkflowPara]
			WHERE WorkflowId = @WorkflowId
				AND ParaName = 'CodeCount'
			);
	SET @WorkflowCode = CONCAT (
			@WorkflowCode
			,@CurrentYear
			,@CurrentMonth
			,FORMAT(@Count, '0000')
			);

	UPDATE [dbo].[UserWorkflow]
	SET WorkflowCode = @WorkflowCode
	WHERE Id = @Id

	UPDATE [dbo].[WorkflowPara]
	SET Value = (@Count + 1)
	WHERE WorkflowId = @WorkflowId
		AND ParaName = 'CodeCount';
END
go

