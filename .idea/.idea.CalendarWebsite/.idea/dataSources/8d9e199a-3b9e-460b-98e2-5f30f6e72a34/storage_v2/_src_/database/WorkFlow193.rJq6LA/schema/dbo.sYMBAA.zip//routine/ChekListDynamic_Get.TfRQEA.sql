
-- =============================================
-- Author:		DuyDam
-- Create date: 04/10/2021
-- Description:	Get data in dynamic checklist
-- =============================================
CREATE   PROCEDURE [dbo].[ChekListDynamic_Get] @Id BIGINT
	,@WorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	SET @Sql = 'SELECT * FROM ' + @TableName + ' WHERE Id = ' + CAST(@Id AS VARCHAR);

	EXEC sp_executesql @Sql;
END
go

