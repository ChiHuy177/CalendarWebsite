CREATE   PROC [dbo].[Work_GetWorkRepeat]
   as
   select a.* from Dynamic.Data_WorkRepeat a 
   inner join Dynamic.Data_WORK b on a.WorkId=b.UserWorkflowId
   where ISNULL(b.IsActive,'True')='True'
   --select id,UserWorkflowId,Type,WorkId,ResultRepeat,TypeFinishRepeat,NumberOfRepeat,ValueFinishRepeat from Dynamic.Data_WorkRepeat a 
go

