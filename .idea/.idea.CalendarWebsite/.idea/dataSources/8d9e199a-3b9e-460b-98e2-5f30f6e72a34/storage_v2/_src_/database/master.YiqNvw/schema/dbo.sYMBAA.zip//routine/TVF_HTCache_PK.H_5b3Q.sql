CREATE FUNCTION [dbo].[TVF_HTCache_PK]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @TransName nvarchar(128)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[HT_Cache] WITH (INDEX=HT_Cache_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DirName = @DirName AND
        LeafName = @LeafName AND
        TransName = @TransName

go

