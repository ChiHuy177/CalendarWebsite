CREATE PROCEDURE [dbo].[proc_UpdateWebCustomActionFlag](
                                        @SiteId uniqueidentifier,
                                        @WebId uniqueidentifier)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @webCustomActionExists int
    SET @webCustomActionExists = 0
    DECLARE @webListCustomActionExists int
    SET @webListCustomActionExists = 0
    DECLARE @returnCode int SET @returnCode = 0 BEGIN TRAN
    IF ((NOT ((@SiteId IS NULL) OR (@SiteId = '00000000-0000-0000-0000-000000000000'))) AND
        (NOT ((@WebId IS NULL) OR (@WebId = '00000000-0000-0000-0000-000000000000'))))
    BEGIN
        SET @webCustomActionExists = 
        (
            SELECT TOP 1
                1
            FROM
                TVF_CustomActions_CIAllLevels(@SiteId, @WebId, @WebId) AS CA
            WHERE
                CA.ScopeType = 3
        )
        UPDATE 
            W
        SET 
            W.Flags = 
            (
                CASE
                    WHEN ((0 = @webCustomActionExists) OR (@webCustomActionExists IS NULL)) THEN (W.Flags & ~65536)
                    ELSE (W.Flags | 65536)
                END
            )
        FROM
            TVF_Webs_Id(@SiteId, @WebId) AS W
        SELECT @returnCode = @@ERROR
        IF (0 <> @returnCode)
        BEGIN
            GOTO cleanup
        END
        SET @webListCustomActionExists = 
        (
            SELECT TOP 1
                1
            FROM
                TVF_CustomActions_WebAllLevels(@SiteId, @WebId)
            WHERE
                ScopeType = 4
        )
        UPDATE
            W
        SET
            W.Flags = 
            (
                CASE
                    WHEN ((0 = @webListCustomActionExists) OR (@webListCustomActionExists IS NULL)) THEN (W.Flags & ~131072)
                    ELSE (W.Flags | 131072)
                END
            )
        FROM
            TVF_Webs_Id(@SiteId, @WebId) AS W
        SELECT @returnCode = @@ERROR
        IF (0 <> @returnCode)
        BEGIN
            GOTO cleanup
        END
    END
cleanup:
    IF (@returnCode <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN   
    RETURN @returnCode
END

go

