CREATE PROCEDURE [dbo].[proc_GetListItemsTreeToDeleteCore]
(
    @ISiteId uniqueidentifier,
    @IWebId uniqueidentifier,
    @IListId uniqueidentifier,
    @IItemId int,
    @MaxLimit int,
    @CompareResults bit,
    @CsvListItemString nvarchar(MAX))
AS
    SET NOCOUNT ON;
    DECLARE @RowCount int;
    DECLARE @TotalRowCount int;
    DECLARE @iRet int;
    DECLARE @Error_ListId uniqueidentifier;
    DECLARE @Error_LookupListId uniqueidentifier;
    DECLARE @Error_ItemId int;
    SET @iRet = 0;
    SET @Error_ListId = NULL;
    SET @Error_LookupListId = NULL;
    SET @Error_ItemId = NULL;
    DECLARE @CurrResultSet TABLE
    (
        ListId uniqueidentifier,
        ItemId int,
        DirName nvarchar(256),
        LeafName nvarchar(128),
        DocId uniqueidentifier,
        DocType tinyint,
        BFSLevel int,
        DeleteBehavior tinyint,
        LookupListId uniqueidentifier,
        Follow tinyint
    );
    DECLARE @NextResultSet TABLE
    (
        ListId uniqueidentifier,
        ItemId int,
        DirName nvarchar(256),
        LeafName nvarchar(128),
        DocId uniqueidentifier,
        DocType tinyint,
        BFSLevel int,
        DeleteBehavior tinyint,
        LookupListId uniqueidentifier,
        Follow tinyint
    );
    INSERT INTO @CurrResultSet
    SELECT 
        U.tp_ListId, 
        U.tp_ID, 
        D.DirName, 
        D.LeafName, 
        D.Id, 
        D.Type, 
        0, 
        1, 
        '00000000-0000-0000-0000-000000000000', 
        0
    FROM 
        TVF_UserData_ListItem(@ISiteId, @IListId, @IItemId) AS U
    CROSS APPLY 
        TVF_Docs_CI(U.tp_SiteId, U.tp_ParentId, U.tp_DocId, U.tp_Level) AS D
    WHERE 
        U.tp_RowOrdinal = 0
        AND U.tp_IsCurrent = 1
    DECLARE @DeclTableForRelatedItems TABLE
    (
        ListId uniqueidentifier NOT NULL,
        ItemId int NOT NULL,
        DirName nvarchar(256) NULL, 
        LeafName nvarchar(128) NULL, 
        DocType tinyint, 
        BFSLevel int,
        Follow tinyint
    );
    INSERT INTO @DeclTableForRelatedItems
    SELECT 
        R.ListId, 
        R.ItemId, 
        R.DirName, 
        R.LeafName, 
        R.DocType,
        R.BFSLevel,
        R.Follow
    FROM 
        @CurrResultSet AS R;
    SET @RowCount = @@ROWCOUNT;
    SET @TotalRowCount = @RowCount;
    WHILE (@RowCount > 0)
    BEGIN
        INSERT INTO @NextResultSet
        SELECT 
            U.tp_ListId, 
            U.tp_ID, 
            D.DirName, 
            D.LeafName, 
            D.Id,
            D.Type, 
            PrevResult.BFSLevel + 1,
            ALR.DeleteBehavior, 
            ALR.LookupListId,
            0
        FROM 
            (
                SELECT 
                    U2.tp_ListId as ListId, 
                    U2.tp_ID as ItemId, 
                    D2.DirName as DirName, 
                    D2.LeafName as LeafName,
                    D2.Id as DocId, 
                    D2.Type as DocType, 
                    NonExpandedResult.BFSLevel as BFSLevel,  
                    2 as Follow 
                FROM 
                    @CurrResultSet as NonExpandedResult
                CROSS APPLY
                    TVF_UserData_PId(@ISiteId, NonExpandedResult.DocId) AS U2
                CROSS APPLY
                    TVF_Docs_CI(U2.tp_SiteId, U2.tp_ParentId, U2.tp_DocId, U2.tp_Level) AS D2
                WHERE 
                    NonExpandedResult.DocType = 1 
                    AND D2.Type = 0 
                    AND U2.tp_RowOrdinal = 0 
                    AND U2.tp_CalculatedVersion = 0
                    AND U2.tp_IsCurrent = 1 
                    AND NOT EXISTS 
                      (SELECT 
                            T2.ItemId
                       FROM 
                            @DeclTableForRelatedItems AS T2
                       WHERE 
                            T2.ListId = U2.tp_ListId AND 
                            T2.ItemId = U2.tp_ID AND 
                            T2.Follow = 0) 
             ) AS PrevResult
        CROSS APPLY 
            TVF_AllLookupRelationships_SiteLookupList(@ISiteId, PrevResult.ListId) AS ALR
        CROSS APPLY
            TVF_NameValuePair_UDItem(ALR.ListId, PrevResult.ItemId) AS nvp
        CROSS APPLY 
            TVF_UserData_ListItemLevelRow(nvp.SiteId, nvp.ListId, nvp.ItemId, nvp.Level, 0) AS U 
        CROSS APPLY
            TVF_Docs_CI(U.tp_SiteId, U.tp_ParentId, U.tp_DocId, U.tp_Level) AS D
        WHERE 
            nvp.SiteId = ALR.SiteId AND
            nvp.FieldId = ALR.FieldId AND
            ALR.DeleteBehavior <> 0
            AND ((U.tp_Level = 1 AND U.tp_DraftOwnerId IS NULL) OR U.tp_Level = 2)
            AND NOT EXISTS 
              (SELECT 
                    T.ItemId 
               FROM 
                    @DeclTableForRelatedItems AS T
               WHERE 
                    T.ListId = U.tp_ListId AND 
                    T.ItemId = U.tp_ID AND 
                    T.Follow = 0) 
        UNION
        SELECT 
            U.tp_ListId, 
            U.tp_ID, 
            D.DirName, 
            D.LeafName,
            D.Id, 
            D.Type, 
            CurrResult.BFSLevel,  
            CurrResult.DeleteBehavior,  
            CurrResult.LookupListId, 
            1 
        FROM 
            @CurrResultSet AS CurrResult
        CROSS APPLY
            TVF_Docs_Pid(@ISiteId, CurrResult.DocId) AS D
        CROSS APPLY 
            TVF_UserData_PId_DId_Level_Row(D.SiteId, D.ParentId, D.Id, D.Level, 0) AS U
        WHERE 
            CurrResult.DocType = 1
            AND D.Type = 1 
            AND U.tp_IsCurrent = 1 
            AND NOT EXISTS 
              (SELECT 
                    T.ItemId
               FROM 
                    @DeclTableForRelatedItems AS T
               WHERE 
                    T.ListId = U.tp_ListId AND 
                    T.ItemId = U.tp_ID AND 
                    T.Follow = 1) 
        UNION    
        SELECT 
            U.tp_ListId, 
            U.tp_ID, 
            D.DirName, 
            D.LeafName, 
            D.Id,
            D.Type, 
            PrevResult.BFSLevel + 1,
            ALR.DeleteBehavior, 
            ALR.LookupListId,
            0
        FROM 
            @CurrResultSet AS PrevResult 
        CROSS APPLY
            TVF_AllLookupRelationships_SiteLookupList(@ISiteId, PrevResult.ListId) AS ALR
        CROSS APPLY
            TVF_NameValuePair_ListFieldValue(ALR.SiteId, ALR.ListId, ALR.FieldId, PrevResult.ItemId) AS nvp
        CROSS APPLY 
            TVF_UserData_ListItemLevelRow(nvp.SiteId, nvp.ListId, nvp.ItemId, nvp.Level, 0) AS U 
        CROSS APPLY
            TVF_Docs_CI(@ISiteId, U.tp_ParentId, U.tp_DocId, U.tp_Level) AS D
        WHERE 
            ALR.DeleteBehavior <> 0
            AND ((U.tp_Level = 1 AND U.tp_DraftOwnerId IS NULL) OR U.tp_Level = 2)
            AND NOT EXISTS 
              (SELECT 
                    T.ItemId 
               FROM 
                    @DeclTableForRelatedItems AS T
               WHERE 
                    T.ListId = U.tp_ListId AND 
                    T.ItemId = U.tp_ID AND 
                    T.Follow = 0) 
        OPTION (FORCE ORDER)
        SELECT TOP 1 
            @Error_ListId = ListId, 
            @Error_ItemId = ItemId,
            @Error_LookupListId = LookupListId
        FROM 
            @NextResultSet 
        WHERE 
            DeleteBehavior = 2;
        SET @RowCount = @@ROWCOUNT;
        IF @RowCount = 1
        BEGIN
           SET @iRet = 8239;
           GOTO DONE;
        END
        DELETE FROM @CurrResultSet;
        INSERT INTO @CurrResultSet
        SELECT 
            * 
        FROM 
            @NextResultSet 
        WHERE 
            Follow = 0
        SET @RowCount = @@ROWCOUNT;
        SET @TotalRowCount = @TotalRowCount + @RowCount;
        IF @TotalRowCount > @MaxLimit
        BEGIN
            SET @iRet = 1142;
            GOTO DONE;
        END
        INSERT INTO @CurrResultSet
        SELECT 
            * 
        FROM 
            @NextResultSet 
        WHERE 
            Follow = 1
        INSERT INTO @DeclTableForRelatedItems
        SELECT 
            R.ListId, 
            R.ItemId, 
            R.DirName, 
            R.LeafName, 
            R.DocType,
            R.BFSLevel,
            R.Follow
        FROM 
            @CurrResultSet AS R;
        DELETE FROM @NextResultSet;
    END
DONE:
    IF (@CompareResults = 1)
    BEGIN
        IF @iRet = 0
        BEGIN
            IF (EXISTS(
                    SELECT 
                        T.ListId, 
                        T.ItemId
                    FROM 
                        @DeclTableForRelatedItems AS T
                    WHERE 
                        Follow = 0
                    EXCEPT
                    SELECT 
                        T.ListId, 
                        T.ItemId
                    FROM 
                        dbo.fn_UnpackCsvListItemString(@CsvListItemString) AS T
                    EXCEPT
                    SELECT
                        @IListId,
                        @IItemId)
                OR
                EXISTS(
                    SELECT 
                        T.ListId, 
                        T.ItemId
                    FROM 
                        dbo.fn_UnpackCsvListItemString(@CsvListItemString) AS T
                    UNION
                    SELECT
                        @IListId,
                        @IItemId
                    EXCEPT
                    SELECT 
                        T.ListId, 
                        T.ItemId
                    FROM 
                        @DeclTableForRelatedItems AS T
                    WHERE 
                        Follow = 0)
                )
            BEGIN
                SET @iRet = 255; 
            END
        END
    END
    ELSE
    BEGIN
        IF @iRet = 0
        BEGIN
            SELECT 
                T.ListId, 
                T.ItemId, 
                T.DirName, 
                T.LeafName
            FROM 
                @DeclTableForRelatedItems AS T
            WHERE 
                Follow = 0
        END
        ELSE IF @iRet = 8239
        BEGIN
            SELECT 
                @Error_ListId, 
                @Error_LookupListId
        END
    END
    RETURN @iRet;

go

