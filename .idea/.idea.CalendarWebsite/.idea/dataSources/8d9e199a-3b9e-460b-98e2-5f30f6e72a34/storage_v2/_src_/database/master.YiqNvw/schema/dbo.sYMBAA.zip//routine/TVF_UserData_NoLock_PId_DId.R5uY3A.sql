CREATE FUNCTION [dbo].[TVF_UserData_NoLock_PId_DId]
(
    @tp_SiteId uniqueidentifier,
    @tp_ParentId uniqueidentifier,
    @tp_DocId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserData] WITH (NOLOCK, INDEX=AllUserData_ParentId, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_DeleteTransactionId = 0x AND
        tp_IsCurrentVersion = CONVERT(bit, 1) AND
        tp_ParentId = @tp_ParentId AND
        tp_DocId = @tp_DocId AND
        tp_CalculatedVersion = 0

go

