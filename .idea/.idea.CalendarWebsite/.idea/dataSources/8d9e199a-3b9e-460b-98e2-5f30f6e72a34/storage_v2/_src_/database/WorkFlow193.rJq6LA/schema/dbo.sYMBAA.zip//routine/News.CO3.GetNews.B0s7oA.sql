
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,> 
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.GetNews] @department Nvarchar(max),
@WorkflowId  BIGINT
AS
BEGIN
	SET NOCOUNT ON;
		DECLARE @TableName NVARCHAR(MAX);
	DECLARE @QueryString NVARCHAR(MAX);
	DECLARE @DataTableName NVARCHAR(MAX);

	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	DECLARE @sql AS NVARCHAR(max)
	Set @QueryString='
	SELECT dw.*,u.CreatedTime
	FROM '+@DataTableName+' dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE u.IsDeleted = 0
	and u.UserWorkflowStatus=1
	 AND ([dw].department) =''' +@department+ '''
	 order by CreatedTime desc
		'
			PRINT @QueryString;

	EXEC sp_ExecuteSql @QueryString;
END
go

