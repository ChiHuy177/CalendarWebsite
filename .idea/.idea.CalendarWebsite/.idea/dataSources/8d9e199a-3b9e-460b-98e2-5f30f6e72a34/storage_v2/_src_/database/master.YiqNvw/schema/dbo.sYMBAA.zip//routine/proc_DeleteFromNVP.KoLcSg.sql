CREATE PROCEDURE [dbo].[proc_DeleteFromNVP](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier = NULL,
    @ItemId int = NULL,
    @Level tinyint = NULL)
AS
    SET NOCOUNT ON
    IF @ListId IS NULL
    BEGIN
        DELETE
            NVP
        FROM
            NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_CI)
        WHERE
            SiteId = @SiteId
        DELETE
            NVP
        FROM
            NameValuePair AS NVP WITH (INDEX=NameValuePair_CI)
        WHERE
            SiteId = @SiteId
    END
    ELSE
    BEGIN
        DECLARE @Collation smallint
        EXEC proc_GetCollation @SiteId, @ListId, @Collation OUTPUT
        IF @ItemId IS NULL
        BEGIN
            DELETE
                NVP
            FROM
                TVF_NameValuePair_List(@SiteId, @ListId) AS NVP
            IF @Collation = 0
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 1
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 2
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 3
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 4
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 5
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 6
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 7
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 8
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 9
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 10
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 11
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 12
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 13
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 14
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 15
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 16
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 17
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 18
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 19
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 20
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 21
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 22
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 23
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 24
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 25
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 26
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 27
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 28
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 29
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 30
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 31
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 32
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 33
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 34
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 35
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 36
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 37
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 38
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 39
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 40
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 41
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 42
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 43
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 44
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 45
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 46
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 47
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
            ELSE
            IF @Collation = 48
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_CI)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId
            END
        END
        ELSE
        BEGIN
            IF @Level IS NULL
            BEGIN
                DELETE
                    NVP
                FROM
                    NameValuePair AS NVP WITH (INDEX=NameValuePair_MatchUserData)
                WHERE
                    SiteId = @SiteId AND
                    ListId = @ListId AND
                    ItemId = @ItemId
                IF @Collation = 0
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 1
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 2
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 3
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 4
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 5
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 6
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 7
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 8
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 9
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 10
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 11
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 12
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 13
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 14
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 15
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 16
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 17
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 18
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 19
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 20
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 21
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 22
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 23
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 24
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 25
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 26
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 27
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 28
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 29
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 30
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 31
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 32
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 33
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 34
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 35
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 36
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 37
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 38
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 39
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 40
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 41
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 42
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 43
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 44
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 45
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 46
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 47
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
                ELSE
                IF @Collation = 48
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId
                END
            END
            ELSE
            BEGIN
                DELETE
                    NVP
                FROM
                    TVF_NameValuePair_UserData(@ListId, @ItemId, @Level) AS NVP
                WHERE
                    NVP.SiteId = @SiteId
                IF @Collation = 0
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 1
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 2
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 3
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 4
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 5
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 6
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 7
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 8
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 9
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 10
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 11
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 12
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 13
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 14
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 15
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 16
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 17
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 18
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 19
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 20
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 21
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 22
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 23
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 24
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 25
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 26
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 27
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 28
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 29
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 30
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 31
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 32
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 33
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 34
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 35
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 36
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 37
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 38
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 39
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 40
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 41
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 42
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 43
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 44
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 45
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 46
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 47
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
                ELSE
                IF @Collation = 48
                BEGIN
                    DELETE
                        NVP
                    FROM
                        NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_MatchUserData)
                    WHERE
                        SiteId = @SiteId AND
                        ListId = @ListId AND
                        ItemId = @ItemId AND
                        Level = @Level
                END
            END
        END
    END
    RETURN 0

go

