CREATE FUNCTION [dbo].[Split] (
      @InputString                  NVARCHAR(MAX),
      @Delimiter                    NVARCHAR(50)
)

RETURNS @Items TABLE (
      Item                          NVARCHAR(4000)
)

AS
BEGIN
      IF @Delimiter = ' '
      BEGIN
            SET @Delimiter = ','
            SET @InputString = REPLACE(@InputString, ' ', @Delimiter)
      END

      IF (@Delimiter IS NULL OR @Delimiter = '')
            SET @Delimiter = ','

--INSERT INTO @Items VALUES (@Delimiter) -- Diagnostic
--INSERT INTO @Items VALUES (@InputString) -- Diagnostic

      DECLARE @Item                 NVARCHAR(4000)
      DECLARE @ItemList       NVARCHAR(MAX)
      DECLARE @DelimIndex     INT
	  DECLARE @LengthDelimIndex     INT

      SET @ItemList = @InputString
      SET @DelimIndex = CHARINDEX(@Delimiter, @ItemList, 0)
	  SET @LengthDelimIndex = LEN(@Delimiter)

      WHILE (@DelimIndex != 0)
      BEGIN
            SET @Item = SUBSTRING(@ItemList, 1, @DelimIndex - 1)
            INSERT INTO @Items VALUES (@Item)

            -- Set @ItemList = @ItemList minus one less item
            SET @ItemList = SUBSTRING(@ItemList, @DelimIndex+@LengthDelimIndex, LEN(@ItemList)-( @DelimIndex - 1 + @LengthDelimIndex))
            SET @DelimIndex = CHARINDEX(@Delimiter, @ItemList, 0)
      END -- End WHILE

      IF @Item IS NOT NULL -- At least one delimiter was encountered in @InputString
      BEGIN
            SET @Item = @ItemList
            INSERT INTO @Items VALUES (@Item)
      END

      -- No delimiters were encountered in @InputString, so just return @InputString
      ELSE INSERT INTO @Items VALUES (@InputString)

      RETURN

END
go

