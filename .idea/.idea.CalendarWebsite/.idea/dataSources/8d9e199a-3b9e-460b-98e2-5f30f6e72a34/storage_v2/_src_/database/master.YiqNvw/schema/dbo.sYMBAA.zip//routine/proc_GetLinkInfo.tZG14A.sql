CREATE PROCEDURE [dbo].[proc_GetLinkInfo](
    @DirSiteId uniqueidentifier,
    @DirFullUrl nvarchar(260),
    @ClientTimeStamp datetime,
    @IncludeListItems bit,
    @UserId int)
AS
    SET NOCOUNT ON
    DECLARE @DirId              uniqueidentifier
    DECLARE @DirDirName         nvarchar(256)
    DECLARE @DirLeafName        nvarchar(128)
    EXEC proc_SplitUrl  @DirFullUrl, @DirDirName OUTPUT,
        @DirLeafName OUTPUT
    SELECT TOP 1
        @DirId = Docs.Id
    FROM
        TVF_Docs_Url(@DirSiteId, @DirDirName, @DirLeafName) AS Docs   
    SELECT
        Docs.Id AS DocId, Links.TargetDirName AS LinkDirName,
        Links.TargetLeafName AS LinkLeafName, Links.Type AS LinkType,
        Links.Security AS LinkSecurity, Links.Dynamic AS LinkDynamic,
        Links.ServerRel AS LinkServerRel, Docs2.Type AS LinkStatus,
        PointsToDir AS PointsToDir, NULL AS WebPartId, NULL AS LinkNumber,
        NULL AS WebId, NULL AS Search, NULL AS FieldId
    FROM
        TVF_Docs_PId(@DirSiteId, @DirId) AS Docs
    CROSS APPLY
        TVF_Links_PId_DId(Docs.SiteId, Docs.ParentId, Docs.Id) AS Links
    LEFT OUTER JOIN 
        AllDocs AS Docs2 WITH (INDEX=AllDocs_Url)
    ON
        Links.ServerRel = 1 AND
        Docs2.SiteId = Links.SiteId AND
        Docs2.DeleteTransactionId = 0x AND
        Docs2.DirName = Links.TargetDirName AND
        Docs2.LeafName = Links.TargetLeafName
    WHERE
        Docs.MetaInfoTimeLastModified > @ClientTimeStamp AND
        (Docs.Type <> 0 OR
         @IncludeListItems = 1 OR
         Docs.DocFlags & 2048 = 0 OR
         Docs.DocFlags & 256 <> 0) AND
        (Docs.Level = 255 AND 
            Docs.LTCheckoutUserId = @UserId OR
         ((Docs.Level = 1 AND 
          Docs.DraftOwnerId IS NULL OR 
          Docs.Level = 2)  AND
        (Docs.LTCheckoutUserId IS NULL OR 
            Docs.LTCheckoutUserId <> @UserId)))
    UNION ALL
    SELECT DISTINCT
        Docs.Id AS DocId, Docs2.DirName AS LinkDirName,
        Docs2.LeafName AS LinkLeafName, Links.Type AS LinkType, 
        NULL AS LinkSecurity, NULL AS LinkDynamic, NULL AS LinkServerRel,
        CAST(128 AS tinyint) AS LinkStatus,
        NULL AS PointsToDir,
        NULL AS WebPartId, NULL AS LinkNumber, NULL As WebId,
        NULL AS Search, NULL AS FieldId
    FROM
        TVF_Docs_PId(@DirSiteId, @DirId) AS Docs
    CROSS APPLY
        TVF_Links_TargetUrlPointsToDir(Docs.SiteId, Docs.DirName, Docs.LeafName) AS Links
    CROSS APPLY
        TVF_Docs_CI(Links.SiteId, Links.ParentId, Links.DocId, Links.Level) AS Docs2
    WHERE
        Docs.MetaInfoTimeLastModified > @ClientTimeStamp AND
        (Docs.Type <> 0 OR
         @IncludeListItems = 1 OR
         Docs.DocFlags & 2048 = 0 OR
         Docs.DocFlags & 256 <> 0)
    UNION ALL
    SELECT DISTINCT
        Docs.Id AS DocId, Docs2.DirName AS LinkDirName,
        Docs2.LeafName AS LinkLeafName, Links.Type AS LinkType, 
        NULL AS LinkSecurity, NULL AS LinkDynamic, NULL AS LinkServerRel,
        CAST(128 AS tinyint) AS LinkStatus,
        NULL AS PointsToDir,
        NULL AS WebPartId, NULL AS LinkNumber, NULL As WebId,
        NULL AS Search, NULL AS FieldId
    FROM
        TVF_Docs_PId(@DirSiteId, @DirId) AS Docs
    CROSS APPLY
        TVF_Links_TargetUrlNotPointsToDir(Docs.SiteId, Docs.DirName, Docs.LeafName) AS Links
    CROSS APPLY
        TVF_Docs_CI(Links.SiteId, Links.ParentId, Links.DocId, Links.Level) AS Docs2
    WHERE
        Docs.MetaInfoTimeLastModified > @ClientTimeStamp AND
        (Docs.Type <> 0 OR
         @IncludeListItems = 1 OR
         Docs.DocFlags & 2048 = 0 OR
         Docs.DocFlags & 256 <> 0)
    ORDER BY
        DocId
    OPTION (FORCE ORDER, LOOP JOIN, MAXDOP 1)
    RETURN 0

go

