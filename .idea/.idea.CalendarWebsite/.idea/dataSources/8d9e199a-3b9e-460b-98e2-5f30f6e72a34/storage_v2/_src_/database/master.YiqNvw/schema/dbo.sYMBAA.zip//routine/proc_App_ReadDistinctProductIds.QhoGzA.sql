CREATE PROCEDURE [dbo].[proc_App_ReadDistinctProductIds] (
    @ProductId uniqueidentifier,
    @SubscriptionId varbinary(16),
    @RowLimit int)
AS
BEGIN
    -- Reads specified number of product IDs order by first subscription ID and then by product ID
    -- whose subscription ID is greater than the specified one or whose subscription ID equals to
    -- the specified one and product ID is greater than the specified one
    SET NOCOUNT ON;
    IF (@SubscriptionId IS NULL)
        SELECT TOP (@RowLimit) PartitionedSourceInfo.SubscriptionId, PartitionedSourceInfo.ProductId
        FROM (
            SELECT
                Sites.SubscriptionId, 
                Packages.ProductId,
                ROW_NUMBER() OVER (PARTITION BY Sites.SubscriptionId, Packages.ProductId ORDER BY Sites.SubscriptionId, Packages.ProductId) AS RowNumber
            FROM
                TVF_Sites_SubscriptionIdNotNull() AS Sites
                CROSS APPLY TVF_AppSourceInfo_AppSource(Sites.Id, 2) AS SourceInfo
                CROSS APPLY TVF_AppPackages_PackageFingerprint(SourceInfo.SiteId, SourceInfo.PackageFingerprint) AS Packages
            UNION
            SELECT
                Sites.SubscriptionId, 
                Packages.ProductId,
                ROW_NUMBER() OVER (PARTITION BY Sites.SubscriptionId, Packages.ProductId ORDER BY Sites.SubscriptionId, Packages.ProductId) AS RowNumber
            FROM
                dbo.AllSites AS Sites
                CROSS APPLY TVF_AppSourceInfo_AppSource(Sites.Id, 2) AS SourceInfo
                CROSS APPLY TVF_AppPackages_PackageFingerprint_ProductIdGT(SourceInfo.SiteId, SourceInfo.PackageFingerprint, @ProductId) AS Packages
            ) as PartitionedSourceInfo
        WHERE RowNumber = 1
        ORDER BY PartitionedSourceInfo.SubscriptionId, PartitionedSourceInfo.ProductId
        OPTION (FORCE ORDER)
    ELSE
        SELECT TOP (@RowLimit) PartitionedSourceInfo.SubscriptionId, PartitionedSourceInfo.ProductId 
        FROM (
            SELECT
                Sites.SubscriptionId, 
                Packages.ProductId,
                ROW_NUMBER() OVER (PARTITION BY Sites.SubscriptionId, Packages.ProductId ORDER BY Sites.SubscriptionId, Packages.ProductId) AS RowNumber
            FROM
                TVF_Sites_SubscriptionIdGT (@SubscriptionId) AS Sites
                CROSS APPLY TVF_AppSourceInfo_AppSource(Sites.Id, 2) AS SourceInfo
                CROSS APPLY TVF_AppPackages_PackageFingerprint(SourceInfo.SiteId, SourceInfo.PackageFingerprint) AS Packages
            UNION
            SELECT
                Sites.SubscriptionId, 
                Packages.ProductId,
                ROW_NUMBER() OVER (PARTITION BY Sites.SubscriptionId, Packages.ProductId ORDER BY Sites.SubscriptionId, Packages.ProductId) AS RowNumber
            FROM
                TVF_Sites_SubscriptionId (@SubscriptionId) AS Sites
                CROSS APPLY TVF_AppSourceInfo_AppSource(Sites.Id, 2) AS SourceInfo
                CROSS APPLY TVF_AppPackages_PackageFingerprint_ProductIdGT(SourceInfo.SiteId, SourceInfo.PackageFingerprint, @ProductId) AS Packages
            ) AS PartitionedSourceInfo
        WHERE 
            PartitionedSourceInfo.RowNumber = 1
        ORDER BY PartitionedSourceInfo.SubscriptionId, PartitionedSourceInfo.ProductId
        OPTION (FORCE ORDER)
END

go

