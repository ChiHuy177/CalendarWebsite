CREATE FUNCTION [dbo].[TVF_UserInfo_SIDDel]
(
    @tp_SiteID uniqueidentifier,
    @tp_SystemID tSystemID,
    @tp_Deleted int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[UserInfo] WITH (INDEX=UserInfo_SID, FORCESEEK)
    WHERE
        tp_SiteID = @tp_SiteID AND
        tp_SystemID = @tp_SystemID AND
        tp_Deleted = @tp_Deleted

go

