CREATE Procedure [dbo].[proc_App_SetAppRuntimeMetadataIsKilled] (
    @AppInstanceId uniqueidentifier,
    @IsKilled bit,
    @SiteId uniqueidentifier
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
UPDATE TVF_AppRuntimeMetadata_AppInstanceId(@SiteId, @AppInstanceId)
    SET IsKilled = @IsKilled
COMMIT TRANSACTION

go

