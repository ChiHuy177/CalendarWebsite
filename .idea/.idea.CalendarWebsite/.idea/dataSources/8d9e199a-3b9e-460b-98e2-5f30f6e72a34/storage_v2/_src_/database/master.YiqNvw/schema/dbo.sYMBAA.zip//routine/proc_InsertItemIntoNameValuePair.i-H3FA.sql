CREATE PROCEDURE [dbo].[proc_InsertItemIntoNameValuePair](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ItemId int,
    @Level tinyint = 1,
    @FieldId1 uniqueidentifier = NULL,
    @FieldValue1 sql_variant = NULL,
    @FieldId2 uniqueidentifier = NULL,
    @FieldValue2 sql_variant = NULL,
    @FieldId3 uniqueidentifier = NULL,
    @FieldValue3 sql_variant = NULL,
    @FieldId4 uniqueidentifier = NULL,
    @FieldValue4 sql_variant = NULL,
    @FieldId5 uniqueidentifier = NULL,
    @FieldValue5 sql_variant = NULL,
    @FieldId6 uniqueidentifier = NULL,
    @FieldValue6 sql_variant = NULL,
    @FieldId7 uniqueidentifier = NULL,
    @FieldValue7 sql_variant = NULL,
    @FieldId8 uniqueidentifier = NULL,
    @FieldValue8 sql_variant = NULL,
    @FieldId9 uniqueidentifier = NULL,
    @FieldValue9 sql_variant = NULL,
    @FieldId10 uniqueidentifier = NULL,
    @FieldValue10 sql_variant = NULL,
    @SelectFromUserData bit = 0,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @ReturnCode int
    SET @ReturnCode = 0
    DECLARE @Author int
    DECLARE @Editor int
    DECLARE @Created datetime
    DECLARE @Modified datetime
    DECLARE @HasCopyDestinations bit
    DECLARE @UIVersion int
    DECLARE @ContentTypeId tContentTypeId
    DECLARE @CheckoutUser int
    IF @FieldId1 IS NULL AND @FieldId2 IS NULL AND @FieldId3 IS NULL AND @FieldId4 IS NULL AND
       @FieldId5 IS NULL AND @FieldId6 IS NULL AND @FieldId7 IS NULL AND @FieldId8 IS NULL AND
       @FieldId9 IS NULL AND @FieldId10 IS NULL
    BEGIN
        RETURN @ReturnCode
    END
    IF @SelectFromUserData = 1
    BEGIN
        SELECT TOP 1
            @Author = tp_Author,
            @Editor = tp_Editor,
            @Created = tp_Created,
            @Modified = tp_Modified,
            @HasCopyDestinations = tp_HasCopyDestinations,
            @UIVersion = tp_UIVersion,
            @ContentTypeId = tp_ContentTypeId,
            @CheckoutUser = tp_CheckoutUserId
        FROM
            TVF_UserData_ListItemLevelRow(@SiteId, @ListId, @ItemId, @Level, 0) AS UD
    END
    DECLARE @RowsAffected int
    SET @RowsAffected = 0
    IF @FieldId1 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, @FieldValue1) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId1, CASE @FieldId1 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue1 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId2 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, @FieldValue2) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId2, CASE @FieldId2 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue2 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId3 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, @FieldValue3) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId3, CASE @FieldId3 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue3 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId4 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, @FieldValue4) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId4, CASE @FieldId4 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue4 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId5 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, @FieldValue5) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId5, CASE @FieldId5 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue5 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId6 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, @FieldValue6) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId6, CASE @FieldId6 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue6 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId7 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, @FieldValue7) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId7, CASE @FieldId7 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue7 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId8 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, @FieldValue8) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId8, CASE @FieldId8 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue8 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId9 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, @FieldValue9) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId9, CASE @FieldId9 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue9 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @FieldId10 IS NOT NULL BEGIN IF @SelectFromUserData = 0 BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, @FieldValue10) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END ELSE BEGIN INSERT INTO NameValuePair ( SiteId, WebId, ListId, ItemId, Level, FieldId, Value) VALUES ( @SiteId, @WebId, @ListId, @ItemId, @Level, @FieldId10, CASE @FieldId10 WHEN '{1df5e554-ec7e-46a6-901d-d85a3881cb18}' THEN @Author WHEN '{d31655d1-1d5b-4511-95a1-7a09e9b75bf2}' THEN @Editor WHEN '{8c06beca-0777-48f7-91c7-6da68bc07b69}' THEN @Created WHEN '{28cf69c5-fa48-462a-b5cd-27b6f9d2bd5f}' THEN @Modified WHEN '{26d0756c-986a-48a7-af35-bf18ab85ff4a}' THEN @HasCopyDestinations WHEN '{7841bf41-43d0-4434-9f50-a673baef7631}' THEN @UIVersion WHEN '{03e45e84-1992-4d42-9116-26f756012634}' THEN @ContentTypeId WHEN '{3881510a-4e4a-4ee8-b102-8ee8e2d0dd4b}' THEN @CheckoutUser ELSE @FieldValue10 END) SET @RowsAffected = @RowsAffected + @@ROWCOUNT END END
    IF @RowsAffected = 0
    BEGIN
        SET @ReturnCode = 87
        GOTO CLEANUP
    END
CLEANUP:
    RETURN @ReturnCode

go

