CREATE PROCEDURE [dbo].[proc_GetLastFileFragmentId]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @Partition tinyint,
    @LastId bigint OUTPUT
)
AS
    SET NOCOUNT ON
    DECLARE @CurrentId bigint
    SET @CurrentId = IDENT_CURRENT('AllFileFragments')
    SELECT TOP 1
        @LastId = AFF.Id
    FROM
        TVF_AllFileFragments_ReadPast_DocIdPartBeforeId(
            @SiteId, 
            @DocId, 
            @Partition, 
            @CurrentId) AS AFF
    ORDER BY
        AFF.Id DESC
    OPTION (MAXDOP 1)
    IF @LastId IS NULL
        SET @LastId = @CurrentId

go

