CREATE PROCEDURE [dbo].[proc_UpdateViewWhileSaving](
    @SiteId uniqueidentifier,
    @ListWebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ViewId uniqueidentifier,
    @View tCompressedString,
    @DisplayName nvarchar(255),
    @ContentTypeId tContentTypeId,
    @Type tinyint,
    @Flags int,
    @BaseViewID tinyint,
    @PageUrlID uniqueidentifier,
    @Level tinyint,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @ViewSize int
    DECLARE @NewSize int
    DECLARE @Ret int
    DECLARE @SqlError int
    DECLARE @Result int
    DECLARE @OldContentTypeId tContentTypeId
    SET @SqlError = 0
    SET @Ret = 0
    SET @ViewSize = DATALENGTH(@View)
    IF (@Type = 1)
    BEGIN
        IF NOT EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_WebParts_ListUser(@SiteId, @ListId, NULL ) AS WP
            WHERE
                WP.tp_Type = 0 AND
                WP.tp_ID <> @ViewId)
            BEGIN
                SET @Type = 0
            END
    END
    IF EXISTS (
        SELECT TOP 1
            1
        FROM
            TVF_WebParts_SitePartIdLvl(@SiteId, @ViewId, @Level) AS WP                
        WHERE
            WP.tp_ListId = @ListId)
    BEGIN
        IF @View IS NOT NULL
        BEGIN
            EXEC @Ret = proc_OnUpdateWebParts
                @SiteId,
                @ViewId,
                @Level,
                @ViewSize,
                NULL,  
                NULL,  
                NULL,  
                NULL,  
                NULL,  
                NULL,
                @NewSize OUTPUT
            END
            IF (0 <> @Ret)
                GOTO cleanup
            IF (@ContentTypeId IS NULL)
            BEGIN
                SELECT TOP 1
                    @OldContentTypeId = WP.tp_ContentTypeId
                FROM
                    TVF_WebParts_SitePartIdLvl(@SiteId, @ViewId, @Level) AS WP
                WHERE
                    WP.tp_ListId = @ListId
            END
            UPDATE
                WP
            SET
                WP.tp_View =
                    CASE
                        WHEN @View IS NULL THEN
                            WP.tp_View
                        WHEN @ViewSize = 0 THEN
                            NULL
                        ELSE
                            @View
                    END,
                WP.tp_DisplayName = CASE WHEN @DisplayName IS NULL THEN
                    WP.tp_DisplayName ELSE @DisplayName END,
                WP.tp_Type = CASE WHEN @Type IS NULL THEN
                    WP.tp_Type ELSE @Type END,
                WP.tp_BaseViewID = CASE WHEN @BaseViewID IS NULL THEN
                    WP.tp_BaseViewID ELSE @BaseViewID END,
                WP.tp_ContentTypeId = ISNULL(@ContentTypeId, WP.tp_ContentTypeId),
                WP.tp_Size = CASE WHEN @View IS NULL THEN
                    WP.tp_Size ELSE ISNULL(@NewSize, 0) END,
                WP.tp_Flags = CASE WHEN @Flags IS NULL THEN
                    WP.tp_Flags ELSE @Flags END
            FROM
                TVF_WebParts_SitePartIdLvl(@SiteId, @ViewId, @Level) AS WP
            WHERE
                WP.tp_ListId = @ListId
            SET @SqlError = @@ERROR
            IF (0 <> @SqlError)
                GOTO cleanup
            IF (@PageUrlID IS NOT NULL)
            BEGIN
                UPDATE
                    WPL
                SET
                    WPL.tp_PageUrlID = @PageUrlID
                FROM
                    TVF_WebParts_NoLock_SitePartIdLvl(@SiteId, @ViewId, @Level) AS WP
                CROSS APPLY
                    TVF_WebPartLists_SitePageLvlUser(
                        WP.tp_SiteId, 
                        WP.tp_PageUrlID, 
                        WP.tp_Level, 
                        WP.tp_UserID) AS WPL
                WHERE
                    WP.tp_ListId = @ListId
                UPDATE
                    WP
                SET
                    WP.tp_PageUrlID = @PageUrlID
                FROM
                    TVF_WebParts_SitePartIdLvl(@SiteId, @ViewId, @Level) AS WP
                WHERE
                    WP.tp_ListId = @ListId
            END
    END
    ELSE
    BEGIN
        DECLARE @quotaOrLockStatus int SELECT @quotaOrLockStatus = dbo.fn_IsOverQuotaOrWriteLocked(@SiteId) IF (@quotaOrLockStatus = 1) BEGIN RETURN 1816 END ELSE IF (@quotaOrLockStatus > 1) BEGIN RETURN 212 END
        DECLARE @cbDelta bigint
        SET @cbDelta = 116 + ISNULL(DATALENGTH(@View), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(NULL), 0)
        EXEC proc_AppendSiteQuota
            @SiteId, @cbDelta, 0, @PageUrlID
        SET @SqlError = @@ERROR
        IF (0 <> @SqlError)
            GOTO cleanup
        SET @ContentTypeId = ISNULL(@ContentTypeId, 0x)
        INSERT INTO WebPartLists(
            tp_SiteId,
            tp_WebPartID,
            tp_ListId,
            tp_WebId,
            tp_PageUrlID,
            tp_Level)
        VALUES (
            @SiteId,
            @ViewId,
            @ListId,
            @ListWebId,
            @PageUrlID,
            @Level)
        INSERT INTO AllWebParts(
            tp_SiteId,
            tp_ID,
            tp_ListId,
            tp_Type,
            tp_Flags,
            tp_BaseViewID,
            tp_DisplayName,
            tp_ContentTypeId,
            tp_PageUrlID,
            tp_View,
            tp_Size,
            tp_Level)
        VALUES (
            @SiteId,
            @ViewId,
            @ListId,
            @Type,
            @Flags,
            @BaseViewID,
            @DisplayName,
            @ContentTypeId,
            @PageUrlID,
            CASE
                WHEN @ViewSize = 0 THEN
                    NULL
                ELSE
                    @View
            END,
            @cbDelta,
            @Level)
    END
    IF (@Type = 0)
    BEGIN
        EXEC @Result = proc_MakeViewDefaultForList 
            @SiteId, 
            @ListId, 
            @ViewId, 
            @RequestGuid OUTPUT
        IF @Result <> 0
            GOTO cleanup
    END
    IF ((@Flags & 16777216) <> 0)
    BEGIN
        EXEC @Result = proc_MakeViewMobileDefaultForList 
            @SiteId,
            @ListId, 
            @ViewId, 
            @RequestGuid OUTPUT
        IF @Result <> 0
            GOTO cleanup
    END
    ELSE
    BEGIN
        EXEC @Result = proc_EnsureMobileDefaultViewForList @SiteId, @ListId
        IF @Result <> 0
            GOTO cleanup
    END
    IF ((@Flags & 268435456) <> 0)
    BEGIN
        SET @ContentTypeId = ISNULL(@ContentTypeId, @OldContentTypeId)
        EXEC @Ret = proc_MakeViewDefaultForContentType 
            @SiteId,
            @ListId, 
            @ViewId, 
            @ContentTypeId, 
            @RequestGuid OUTPUT
        IF (0 <> @Ret)
            GOTO cleanup
    END
cleanup:
    IF (0 <> @SqlError OR 0 <> @Ret)
    BEGIN
        RETURN CASE WHEN (0 = @Ret) THEN 1 ELSE @Ret END
    END
    RETURN 0

go

