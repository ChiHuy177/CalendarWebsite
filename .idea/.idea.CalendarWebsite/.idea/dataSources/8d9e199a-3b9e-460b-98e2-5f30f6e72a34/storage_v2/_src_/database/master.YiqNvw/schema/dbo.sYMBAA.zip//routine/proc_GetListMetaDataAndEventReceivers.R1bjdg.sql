CREATE PROCEDURE [dbo].[proc_GetListMetaDataAndEventReceivers](
    @SiteId uniqueidentifier,
    @WebId  uniqueidentifier,
    @ListId uniqueidentifier,
    @PrefetchListScope bit = 0,       
    @ThresholdScopeCount int = 0,
    @PrefetchRelatedFields bit = 0,
    @PrefetchWebParts bit = 0,
    @UserId int = -1, 
    @CurrentFolderUrl nvarchar(260) = NULL,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON    
    EXEC proc_GetListMetaData 
        @SiteId,
        @WebId, 
        @ListId, 
        @PrefetchListScope,
        @ThresholdScopeCount, 
        @PrefetchRelatedFields,
        @CurrentFolderUrl
    EXEC proc_GetEventReceivers 
        @SiteId, 
        @WebId, 
        @ListId, 
        2
    IF (@PrefetchWebParts = 1)
    BEGIN
        EXEC proc_GetListWebParts 
            @ListId, 
            NULL,
            @UserId, 
            0, 
            0, 
            0, 
            0, 
            @SiteId, 
            @RequestGuid OUTPUT
    END

go

