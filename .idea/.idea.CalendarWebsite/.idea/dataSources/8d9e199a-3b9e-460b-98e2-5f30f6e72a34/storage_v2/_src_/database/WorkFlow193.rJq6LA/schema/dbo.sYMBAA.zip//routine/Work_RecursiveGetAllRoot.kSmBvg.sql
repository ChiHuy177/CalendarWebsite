-- [Work_RecursiveGetAllRoot] '' 
   CREATE   PROC [dbo].[Work_RecursiveGetAllRoot] 
   @workId as nvarchar(max)='' 
   -- declare @workId as nvarchar(max)='261088,261091,261092,261094' 
   ,@rootIndex as int =1 
   ,@isGetAllTheSameLevel as bit =0 
   as 
   declare @tbId table(UserWorkflowId bigint NOT NULL PRIMARY KEY, RowIndex int,IsMyWork int) 
   insert into @tbId select Item,0,0 from Split(@workId,',') 
   ; 
   -- ***************** đệ quy trong sql lấy ra tất cả cha ************************** 
   WITH Managers AS  
   (  
   --initialization  
   SELECT a.UserWorkflowId,a.Tieude,a.CongViecCha, a.Duan, 0 as RowIndex,1 as IsMyWork 
   ,a.Ngayketthuc 
   FROM [Dynamic].[Data_WORK] AS a  
   inner join @tbId b on a.UserWorkflowId=b.UserWorkflowId  
   where ISNULL( a.IsActive,'True')='True' 
   --where a.UserWorkflowId in (218184,218207,218930,217302,217404,218720,218722)  
   UNION ALL  
   --recursive execution  
   SELECT  
   a.UserWorkflowId,a.Tieude,a.CongViecCha,b.Duan, b.RowIndex +1 as RowIndex,0 as IsMyWork 
   ,a.Ngayketthuc 
   FROM Dynamic.Data_WORK a  
   inner join Managers b on ISNULL(b.CongViecCha,'') = ISNULL(a.UserWorkflowId,'')  
   where ISNULL( a.IsActive,'True')='True' 
   ) 
   --bảng #tbTemp thêm vào bang tạm #tbTemp workId  
   SELECT a.UserWorkflowId,RowIndex,IsMyWork,Tieude,CongViecCha,case when ISNULL(a.Ngayketthuc,'') ='' then 9999 else ISNULL(DATEDIFF(DAY, a.Ngayketthuc, GETDATE()),0) end as TimeExpired 
   into #tbTemp  
   FROM Managers a where a.RowIndex<=@rootIndex 
   ; 
   ---- ***************** đệ quy trong sql lấy ra tất cả con ************************** 
   --WITH Managers1 AS  
   --(  
   ----initialization  
   --SELECT a.UserWorkflowId,a.Tieude,a.CongViecCha, a.Duan, 0 as RowIndex,1 as IsMyWork 
   --,a.Ngayketthuc 
   --FROM [Dynamic].[Data_WORK] AS a  
   --inner join 
   --( 
   -- select UserWorkflowId from #tbTemp a -- where ISNULL(a.CongViecCha,'')='' and a.RowIndex=@rootIndex 
   -- group by UserWorkflowId 
   --) b on a.UserWorkflowId=b.UserWorkflowId 
   ----where a.UserWorkflowId in (218184,218207,218930,217302,217404,218720,218722) 
   --where ISNULL( a.IsActive,'True')='True' 
   --UNION ALL  
   ----recursive execution 
   --SELECT 
   --a.UserWorkflowId,a.Tieude,a.CongViecCha,b.Duan, b.RowIndex -1 as RowIndex,0 as IsMyWork 
   --,a.Ngayketthuc 
   --FROM Dynamic.Data_WORK a 
   --inner join @tbId c on a.UserWorkflowId=c.UserWorkflowId 
   --inner join Managers1 b on ISNULL(b.UserWorkflowId,'') = ISNULL(a.CongViecCha,'') 
   --where ISNULL( a.IsActive,'True')='True' --and c.UserWorkflowId is null 
   --) 
   --SELECT a.UserWorkflowId,a.RowIndex,a.IsMyWork,a.Tieude,a.CongViecCha , case when ISNULL(a.Ngayketthuc,'') ='' then 9999 else ISNULL(DATEDIFF(DAY, a.Ngayketthuc, GETDATE()),0) end as TimeExpired 
   --into #tbAll 
   --FROM Managers1 a 
   --SELECT a.UserWorkflowId,a.RowIndex,a.IsMyWork,a.Tieude,a.CongViecCha , a.TimeExpired 
   --into #tbExist 
   --FROM #tbAll a 
   --inner join #tbTemp b on a.UserWorkflowId=b.UserWorkflowId 
   select a.UserWorkflowId ,0 as RowIndex, 0 as TimeExpired 
   from #tbTemp a 
   --left join #tbExist b on a.UserWorkflowId=b.UserWorkflowId -- 
   where (a.RowIndex=@rootIndex --and b.UserWorkflowId is null
   ) or ISNULL(a.CongViecCha,'')='' 
   group by a.UserWorkflowId 
   -- insert into abc 
   drop table #tbTemp 
   --drop table #tbAll 
   --drop table #tbExist 
   --delete abc 
go

