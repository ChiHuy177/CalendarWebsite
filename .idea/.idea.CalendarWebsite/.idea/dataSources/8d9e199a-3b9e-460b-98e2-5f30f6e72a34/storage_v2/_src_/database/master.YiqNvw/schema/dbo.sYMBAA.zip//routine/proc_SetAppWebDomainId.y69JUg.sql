CREATE PROCEDURE [dbo].[proc_SetAppWebDomainId](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @AppWebDomainId varchar(8),
    @CreateNew bit,
    @RequestGuid uniqueidentifier = NULL OUTPUT
)
AS
    SET NOCOUNT ON
    DECLARE @returnCode int SET @returnCode = 0 BEGIN TRAN
    DECLARE @currentAppWebDomainId varchar(8)
    DECLARE @appSiteDomainId varchar(6)
    DECLARE @rowCount int
    DECLARE @appWebDomainIdToAssign binary(4)
    DECLARE @nextAppWebDomainId binary(4)
    SET @rowCount = 0
    SELECT
        @currentAppWebDomainId = AppWebDomainId
    FROM
        [dbo].[AllWebs] WITH (XLOCK, INDEX=Webs_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Id = @WebId
    SELECT @returnCode=@@ERROR, @rowCount=@@ROWCOUNT
    IF (@returnCode <> 0)
    BEGIN
        GOTO Cleanup
    END
    IF (@rowCount = 0)
    BEGIN
        SET @returnCode = 2
        GOTO Cleanup
    END
    IF (('' <> (ISNULL(@currentAppWebDomainId, ''))) AND (1 = @CreateNew))
    BEGIN
        SET @returnCode = 183
        GOTO Cleanup
    END
    SELECT
        @appSiteDomainId = AppSiteDomainId
    FROM
        [dbo].[AllSites] WITH (XLOCK, INDEX=Sites_Id, FORCESEEK)
    WHERE
        Id = @SiteId AND
        Deleted = CONVERT(bit, 0)
    SELECT @returnCode=@@ERROR, @rowCount=@@ROWCOUNT
    IF (@returnCode <> 0)
    BEGIN
        GOTO Cleanup
    END
    IF (@rowCount = 0)
    BEGIN
        SET @returnCode = 2
        GOTO Cleanup
    END
    IF (@appSiteDomainId IS NULL)
    BEGIN
        SET @returnCode = 21
        GOTO Cleanup    
    END
    IF (1 = @CreateNew)
    BEGIN
        SELECT
            @appWebDomainIdToAssign = NextAppWebDomainId
        FROM
            TVF_Sites_Id(@SiteId)
        SELECT @returnCode=@@ERROR, @rowCount=@@ROWCOUNT
        IF (@returnCode <> 0)
        BEGIN
            GOTO Cleanup
        END
        IF (@rowCount = 0)
        BEGIN
            SET @returnCode = 2
            GOTO Cleanup
        END
        IF (@appWebDomainIdToAssign IS NULL)
        BEGIN
            SET @appWebDomainIdToAssign = CONVERT(binary(4), RAND())
        END
        SET @nextAppWebDomainId = @appWebDomainIdToAssign + 1
        SET @currentAppWebDomainId = dbo.fn_BinaryToVarChar(@appWebDomainIdToAssign)
        UPDATE 
            S
        SET
            S.NextAppWebDomainId = @nextAppWebDomainId
        FROM
            TVF_Sites_Id(@SiteId) AS S
    END
    ELSE
    BEGIN
        SET @currentAppWebDomainId = @AppWebDomainId
    END
    UPDATE
        W
    SET 
        W.AppWebDomainId = @currentAppWebDomainId
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
Cleanup:
    IF (@returnCode <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @returnCode

go

