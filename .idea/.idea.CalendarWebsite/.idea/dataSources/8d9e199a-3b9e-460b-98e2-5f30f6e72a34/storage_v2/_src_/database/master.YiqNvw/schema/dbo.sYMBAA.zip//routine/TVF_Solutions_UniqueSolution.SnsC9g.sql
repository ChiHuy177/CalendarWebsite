CREATE FUNCTION [dbo].[TVF_Solutions_UniqueSolution]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @SolutionId uniqueidentifier,
    @SolutionLevel int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Solutions] WITH (INDEX=Solutions_BySiteAndWebAndSolutionId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@WebId IS NULL AND WebId IS NULL) OR @WebId=WebId) AND
        SolutionId = @SolutionId AND
        SolutionLevel = @SolutionLevel

go

