-- [Work_GetDataFlowChartProject] 342093
   CREATE   PROC [dbo].[Work_GetDataFlowChartProject]  
   @UserWorkflowId as nvarchar(50)  
   as
   if(@UserWorkflowId=-99) -- -99 lưu Cài đặt mặc định trạng thái cho dự án
   begin 
   if (select COUNT(*)  from Dynamic.Data_RESOURCEDA where Ten='TrangThai' and UserWorkflowId=-99)<=0
   begin 
   insert into Dynamic.Data_RESOURCEDA(UserWorkflowId,Ten,MoTa) 
   values (-99,N'TrangThai',N'Cài đặt mặc định trạng thái cho dự án')
   end 
   end 
   select REPLACE(FlowChartData,'"strokeDasharray": "5 5"','"strokeDasharray": ""') as FlowChartData into #a from Dynamic.Data_RESOURCEDA where UserWorkflowId=@UserWorkflowId  
   if(select COUNT(*) from #a)<=0
   begin 
   select REPLACE(FlowChartData,'"strokeDasharray": "5 5"','"strokeDasharray": ""') as FlowChartData from Dynamic.Data_RESOURCEDA where UserWorkflowId=-99  
   end
   else
   begin 
   select * from #a
   end
go

