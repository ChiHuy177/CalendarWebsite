CREATE PROCEDURE [dbo].[proc_HTTotalFileSize]
AS
    SET NOCOUNT ON
    SELECT (SUM(CAST(([FileSize]) AS BIGINT)))
    FROM HT_Cache

go

