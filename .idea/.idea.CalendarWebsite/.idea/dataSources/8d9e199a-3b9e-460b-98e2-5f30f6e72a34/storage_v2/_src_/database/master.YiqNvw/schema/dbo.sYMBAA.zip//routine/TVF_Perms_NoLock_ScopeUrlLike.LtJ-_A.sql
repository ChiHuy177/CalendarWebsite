CREATE FUNCTION [dbo].[TVF_Perms_NoLock_ScopeUrlLike]
(
    @SiteId uniqueidentifier,
    @ScopeUrlLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Perms] WITH (NOLOCK, INDEX=Perms_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DelTransId = 0x AND
        ScopeUrl LIKE @ScopeUrlLike

go

