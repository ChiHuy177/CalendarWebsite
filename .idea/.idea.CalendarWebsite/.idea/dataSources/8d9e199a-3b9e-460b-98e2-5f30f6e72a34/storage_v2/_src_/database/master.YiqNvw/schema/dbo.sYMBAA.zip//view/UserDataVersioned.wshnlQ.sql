
        CREATE VIEW [dbo].[UserDataVersioned]
        AS
            SELECT
                *
            FROM
                AllUserData
            WHERE
                tp_DeleteTransactionId = 0x AND
                (tp_IsCurrentVersion = CONVERT(bit, 1) OR tp_IsCurrentVersion = CONVERT(bit, 0))
    
go

