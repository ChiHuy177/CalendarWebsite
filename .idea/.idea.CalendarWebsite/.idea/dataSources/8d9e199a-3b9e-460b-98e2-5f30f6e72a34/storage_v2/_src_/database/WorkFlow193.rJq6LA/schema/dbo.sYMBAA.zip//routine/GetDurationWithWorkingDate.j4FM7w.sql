-- =============================================
-- Author:		DuyDam
-- Create date: 10/10/2022
-- Description:	Get duration between two times without calculate the off date and hours 
--				not in the working times and print the text
-- =============================================
CREATE   FUNCTION [dbo].[GetDurationWithWorkingDate] (
	@StartDate DATETIME
	,@ToDate DATETIME
	,@WorkingTimesTable [UT_WorkingTimes] READONLY
	,@WorkweekTable [UT_Workweek] READONLY
	)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @So INT = 0;
	DECLARE @DateCursor DATETIME = @StartDate;
	DECLARE @Weekday NVARCHAR(20) = NULL;
	DECLARE @MorningStart INT = 0;
	DECLARE @MorningEnd INT = 0;
	DECLARE @AfternoonStart INT = 0;
	DECLARE @AfternoonEnd INT = 0;
	DECLARE @MorningStartTime DATETIME;
	DECLARE @MorningEndTime DATETIME;
	DECLARE @AfternoonStartTime DATETIME;
	DECLARE @AfternoonEndTime DATETIME;
	DECLARE @LargerThanOneDate bit = 0;
	DECLARE @days int = -1;
	DECLARE @hourAndMin nvarchar(max) = '';

	--DECLARE @WorkingTimesTable table (Title NVARCHAR(MAX) ,MorningStart float, MorningEnd float, AfternoonStart float, AfternoonEnd float)
	--DECLARE @WorkweekTable table (Title NVARCHAR(MAX) ,IsFullTime bit)
	
	--INSERT @WorkingTimesTable
	--SELECT Title, MorningStart, MorningEnd, AfternoonStart, AfternoonEnd
	--FROM WorkingTimes

	--INSERT @WorkweekTable
	--SELECT Title, IsFullTime
	--FROM Workweek

	WHILE (@DateCursor < @ToDate)
	BEGIN
		SET @Weekday = DATENAME(WEEKDAY, @DateCursor);
		SET @MorningStart = (
				SELECT TOP 1 MorningStart
				FROM @WorkingTimesTable
				WHERE Title = @Weekday
				);
		SET @MorningEnd = (
				SELECT TOP 1 MorningEnd
				FROM @WorkingTimesTable
				WHERE Title = @Weekday
				);
		SET @AfternoonStart = (
				SELECT TOP 1 AfternoonStart
				FROM @WorkingTimesTable
				WHERE Title = @Weekday
				);
		SET @AfternoonEnd = (
				SELECT TOP 1 AfternoonEnd
				FROM @WorkingTimesTable
				WHERE Title = @Weekday
				);

		IF EXISTS (
				SELECT TOP 1 ww.Title
				FROM @WorkweekTable ww
				INNER JOIN @WorkingTimesTable wt ON wt.Title = ww.Title
				WHERE LTRIM(RTRIM(ww.Title)) = LTRIM(RTRIM(@Weekday))
					AND ww.IsFullTime = 0
					AND wt.MorningStart IS NULL
					AND wt.MorningEnd IS NULL
					AND wt.AfternoonStart IS NULL
					AND wt.AfternoonEnd IS NULL
				)
		BEGIN
			SET @So = 0
		END
		ELSE IF EXISTS (
				SELECT TOP 1 ww.Title
				FROM @WorkweekTable ww
				INNER JOIN @WorkingTimesTable wt ON wt.Title = ww.Title
				WHERE LTRIM(RTRIM(ww.Title)) = LTRIM(RTRIM(@Weekday))
					AND ww.IsFullTime = 0
					AND (
						wt.MorningStart IS NOT NULL
						OR wt.MorningEnd IS NOT NULL
						OR wt.AfternoonStart IS NOT NULL
						OR wt.AfternoonEnd IS NOT NULL
						)
				)
		BEGIN
			SET @days = @days + 1;
			IF @MorningStart IS NOT NULL
			BEGIN
				SET @MorningStartTime = DATEADD(HOUR, @MorningStart, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
				SET @MorningEndTime = DATEADD(HOUR, @MorningEnd, CAST(CAST(@DateCursor AS DATE) AS DATETIME))

				IF @DateCursor < @MorningStartTime
				BEGIN
					SET @DateCursor = DATEADD(HOUR, @MorningStart, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
				END

				IF DATEDIFF(DAY, @DateCursor, @ToDate) = 0
				BEGIN
					IF (
							@DateCursor <= @MorningEndTime
							AND @ToDate >= @MorningEndTime
							)
						SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @MorningEndTime))
					ELSE IF (
							@DateCursor > @MorningEndTime
							AND @ToDate > @MorningEndTime
							)
						SET @So = 0
					ELSE
						SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @ToDate))
				END
				ELSE
				BEGIN
					IF @DateCursor <= @MorningEndTime
						SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @MorningEndTime))
					ELSE
						SET @So = 0
				END
			END
			ELSE IF @AfternoonStart IS NOT NULL
			BEGIN
				SET @AfternoonStartTime = DATEADD(HOUR, @AfternoonStart, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
				SET @AfternoonEndTime = DATEADD(HOUR, @AfternoonEnd, CAST(CAST(@DateCursor AS DATE) AS DATETIME))

				IF @DateCursor < @AfternoonStartTime
				BEGIN
					SET @DateCursor = DATEADD(HOUR, @AfternoonStart, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
				END

				IF DATEDIFF(DAY, @DateCursor, @ToDate) = 0
				BEGIN
					IF @ToDate < @AfternoonStartTime
						SET @So = 0
					ELSE
						SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @ToDate))
				END
				ELSE
				BEGIN
					SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @AfternoonEndTime))
				END
			END
		END
		ELSE
		BEGIN
			SET @days = @days + 1;
			SET @MorningStartTime = DATEADD(HOUR, @MorningStart, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
			SET @MorningEndTime = DATEADD(HOUR, @MorningEnd, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
			SET @AfternoonStartTime = DATEADD(HOUR, @AfternoonStart, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
			SET @AfternoonEndTime = DATEADD(HOUR, @AfternoonEnd, CAST(CAST(@DateCursor AS DATE) AS DATETIME))

			IF @DateCursor < @MorningStartTime
			BEGIN
				SET @DateCursor = DATEADD(HOUR, @MorningStart, CAST(CAST(@DateCursor AS DATE) AS DATETIME))
			END

			IF DATEDIFF(DAY, @DateCursor, @ToDate) = 0
			BEGIN
				IF (
						@DateCursor <= @MorningEndTime
						AND @ToDate >= @AfternoonStartTime
						AND @ToDate <= @AfternoonEndTime
						)
					SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @ToDate)) - ABS(DATEDIFF(MINUTE, @AfternoonStartTime, @MorningEndTime));
				ELSE IF (
						@DateCursor < @MorningEndTime
						AND @ToDate <= @AfternoonStartTime
						AND @ToDate >= @MorningEndTime
						)
					SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @MorningEndTime))
				ELSE IF (
						@DateCursor >= @MorningEndTime
						AND @DateCursor <= @AfternoonStartTime
						AND @ToDate >= @AfternoonStartTime
						)
					SET @So = ABS(DATEDIFF(MINUTE, @AfternoonStartTime, @ToDate))
				ELSE IF (
						@DateCursor >= @MorningEndTime
						AND @ToDate <= @AfternoonStartTime
						)
					SET @So = 0
				ELSE IF (
							@DateCursor >= @AfternoonEndTime
							AND @ToDate >= @AfternoonEndTime
						)
					SET @So = 0
				ELSE
					SET @So = ABS(DATEDIFF(MINUTE, @DateCursor, @ToDate))
			END
			ELSE
			BEGIN
				IF @DateCursor < @MorningEndTime
					SET @So = ABS(DATEDIFF(MINUTE, @AfternoonEndTime, @DateCursor)) - ABS(DATEDIFF(MINUTE, @AfternoonStartTime, @MorningEndTime))
				ELSE IF @DateCursor > @AfternoonStartTime AND @DateCursor <= @AfternoonEndTime
					SET @So = ABS(DATEDIFF(MINUTE, @AfternoonEndTime, @DateCursor))
				ELSE IF @DateCursor >= @AfternoonEndTime
					SET @So = 0
				ELSE 
					SET @So = ABS(DATEDIFF(MINUTE, @AfternoonEndTime, @AfternoonStartTime))
			END
		END
		
		SET @DateCursor = CAST(CAST(DATEADD(DAY, 1, @DateCursor) AS DATE) AS DATETIME)
		IF @DateCursor >= @ToDate
		BEGIN
			SET @hourAndMin = dbo.ConvertMinutesToText(@So, default)
		END
	END

	
	RETURN CONCAT(CASE WHEN @days >= 1 THEN CONCAT(CAST(@days as varchar(max)), N' ngày') ELSE '' END, ' ' , @hourAndMin)		
END
go

