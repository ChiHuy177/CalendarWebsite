CREATE FUNCTION [dbo].[TVF_AppTasks_JobIdRetriesGT]
(
    @SiteId uniqueidentifier,
    @JobId uniqueidentifier,
    @GTRetries int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppTasks] WITH (INDEX=AppTasks_Retries, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        JobId = @JobId AND
        Retries > @GTRetries

go

