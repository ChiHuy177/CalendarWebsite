CREATE   FUNCTION [dbo].[Work_ReplaceInvalidChars] (@string NVARCHAR(MAX))  
                    RETURNS NVARCHAR(MAX)  
                    BEGIN  
                        DECLARE @str NVARCHAR(MAX) = @string;  
                        DECLARE @Pattern NVARCHAR (MAX) = '%[^a-zA-Z0-9]%';  
                        WHILE PATINDEX(@Pattern,@str) > 0  
                        BEGIN  
                            SELECT @str = STUFF(@str, PATINDEX(@Pattern,@str),1,'');   
                        END       
                        RETURN @str  
                    END
go

