CREATE PROCEDURE [dbo].[proc_SetEvalSiteRequestStatus]
(
    @SiteId uniqueidentifier,
    @LastProcessDate datetime,
    @Status tinyint,
    @RetryCount int,
    @NewSiteId uniqueidentifier,
    @DestinationDbId uniqueidentifier
)
AS
    SET NOCOUNT ON
    UPDATE TVF_PreviewSiteRequests_SiteId(@SiteId)
    SET
        LastProcessDate = @LastProcessDate,
        Status = @Status,
        RetryCount = @RetryCount,
        NewSiteId = @NewSiteId,
        DestinationDbId = @DestinationDbId

go

