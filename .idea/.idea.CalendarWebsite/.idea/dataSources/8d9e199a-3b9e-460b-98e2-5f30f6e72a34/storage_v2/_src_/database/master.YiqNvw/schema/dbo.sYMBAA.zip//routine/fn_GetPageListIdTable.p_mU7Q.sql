CREATE FUNCTION [dbo].[fn_GetPageListIdTable](
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @RootWebId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @UserInfoListId uniqueidentifier,
    @UserId int,
    @Level tinyint)
RETURNS TABLE
AS
RETURN
(
    SELECT
        AllLists.tp_ID AS tp_ListId,
        AllLists.tp_WebId AS tp_WebId,
        AllLists.tp_HasFGP AS tp_HasFGP,
        AllLists.tp_HasInternalFGP AS tp_HasInternalFGP,
        AllLists.tp_ScopeId AS tp_ScopeId,
        AllLists.tp_RootFolder AS tp_RootFolder
    FROM
        fn_GetPageListIdTableNoListInfo(
            @SiteId, @DocId, @RootWebId, @WebId, @ListId,
            @UserInfoListId, @UserId, @Level) AS PageLists
    CROSS APPLY
        TVF_AllLists_NoLock_CI(@SiteId, PageLists.tp_WebId, PageLists.tp_ListId) AS AllLists
)

go

