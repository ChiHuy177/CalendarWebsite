CREATE FUNCTION [dbo].[TVF_BuildDependencies_DirNameLike]
(
    @SiteId uniqueidentifier,
    @DirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[BuildDependencies] WITH (INDEX=BuildDependencies_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DirName LIKE @DirNameLike

go

