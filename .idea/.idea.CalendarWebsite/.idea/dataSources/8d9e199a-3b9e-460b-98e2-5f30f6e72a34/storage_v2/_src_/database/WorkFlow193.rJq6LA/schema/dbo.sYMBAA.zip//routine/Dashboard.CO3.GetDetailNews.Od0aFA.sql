
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Dashboard.CO3.GetDetailNews] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @sql AS NVARCHAR(max)

	SELECT dw.*
	FROM [Dynamic].[Workflow_NEWS] dw
	WHERE dw.IsDeleted = 0
		AND dw.UserWorkflowId = @UserWorkflowId
		AND dbo.JSON_VALUE(dw.Data, '$.trueorfall') = 'false'
END
go

