-- Work_getStatusByProject 115796     
   -- Work_getStatusByProject null     
   CREATE   PROC [dbo].[Work_getStatusByProject]     
   @projectId as nvarchar(250)='0'     
   as     
   select b.Id , b.Ten as Name, b.Duan as ProjectId, b.TrangThaiCongViec     
   ,b.NguoiChinhSua as [user],b.UserWorkflowId     
   ,b.UseForChild    
   from [Dynamic].Data_RESOURCEDA a     
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan     
   inner join Dynamic.Data_LSQTCV c on a.UserWorkflowId = c.ProjectId and b.nodeid=c.Nodeid and c.Title<>''      
   where a.UserWorkflowId=@projectId     
   and ISNULL(b.IsSetting,0)=0  
   order by c.Step
go

