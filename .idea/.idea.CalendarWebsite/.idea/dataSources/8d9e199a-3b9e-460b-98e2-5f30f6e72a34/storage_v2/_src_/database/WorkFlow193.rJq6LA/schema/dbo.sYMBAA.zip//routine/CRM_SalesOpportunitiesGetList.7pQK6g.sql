CREATE   PROC [dbo].[CRM_SalesOpportunitiesGetList]          
 @userName as nvarchar(50)='',                             
 @str as nvarchar(250)='',            
 @menuId as bigint=0                   
 as            
             
 declare @sql as nvarchar(max), @where as nvarchar(max)='',@join as nvarchar(max)            
 --set @join ='inner join (select * from FnGetUserPermission('''+@userName+''','+STR(@menuId)+')) f on a.UserCreate=f.UserName'            
 set @join =''            
 if(@str !='')            
 begin             
  set @where = ' and (a.Code like N''%'+@str+'%'' or a.Name  like N''%'+@str+'%'')'             
 end            
 set @sql ='                             
 SELECT a.[ID]                            
       ,a.[Code]                            
       ,a.[Name]                            
       ,a.[Description]                            
       ,a.[Note]                            
       ,a.[CustomerID]                            
    ,b.Code as CustomerCode                         
    ,b.Name as CustomerName                               
    ,b.PhoneNumber as CustomerPhone     
    ,b.Address as CustomerAddress                            
       ,a.[UserExec]                            
       ,a.[SourceID]                            
       ,a.[CampaignID]                            
       ,a.[DescriptionSource]         
                              
    , SuccessRate                  
    ,'''' as SuccessRate1                 
     ,a.IsLead            
    ,a.LeadContent            
    ,a.Revenue        
      ,c.CreatedTime as CreatedDate  
    ,c.ModifiedBy as UserModified  
    ,c.LastModified as modifiedDate  
    ,a.UserWorkflowId
   FROM Dynamic.Data_CRMSalesOpportunitiesHeader a                            
   left join Dynamic.Data_CRMCustormer b on a.CustomerID=b.UserWorkflowId  
   inner join Dynamic.Workflow_CRMSalesOpportunitiesHeader c on c.UserWorkflowId=a.UserWorkflowId 
   left join UserWorkflow u on u.id= a.userWorkflowId
     
   '+ @join+ '              
   where ISNULL(u.IsDeleted,0)=0'+@where+'                       
  order by a.ID desc                    
  '            
  print(@sql)            
  exec(@sql)
go

