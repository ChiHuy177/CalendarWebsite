
-- =============================================
-- Author:		DuyDam
-- Create date: 14/3/2023
-- Description:	Check user is existed in Groups
-- =============================================
CREATE   PROCEDURE [dbo].[CheckUserExistedInGroup]
	-- Add the parameters for the stored procedure here
	@UserId BIGINT = NULL
	,@GroupsTitle NVARCHAR(max) = NULL
	,@IsExisted BIT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF EXISTS (
			SELECT top 1 gp.GroupsId
			FROM GroupPersonalProfile gp
			INNER JOIN [dbo].[PersonalProfile] p ON p.Id = gp.PersonalProfilesId
			INNER JOIN [dbo].[Group] g ON g.Id = gp.GroupsId
			WHERE p.Id = @UserId
				AND g.Title IN (
					SELECT Item
					FROM [dbo].[Split](@GroupsTitle, ',')
					)
			)
	BEGIN
		SET @IsExisted = 1;
	END
	ELSE
	BEGIN
		SET @IsExisted = 0;
	END
END
go

