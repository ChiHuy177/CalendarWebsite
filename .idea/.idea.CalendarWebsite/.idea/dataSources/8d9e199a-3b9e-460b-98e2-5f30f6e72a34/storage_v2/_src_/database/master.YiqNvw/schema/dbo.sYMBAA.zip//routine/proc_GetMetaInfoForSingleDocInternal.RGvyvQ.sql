CREATE PROCEDURE [dbo].[proc_GetMetaInfoForSingleDocInternal](
    @DocSiteId uniqueidentifier,
    @DocParentId uniqueidentifier,
    @DocId uniqueidentifier,
    @UserId int,
    @Level tinyint,
    @DocWebId uniqueidentifier = NULL)
AS
    SET NOCOUNT ON
    SELECT
        Docs.Id, CASE WHEN (DATALENGTH(Docs.DirName) = 0) THEN Docs.LeafName WHEN (DATALENGTH(Docs.LeafName) = 0) THEN Docs.DirName ELSE Docs.DirName + N'/' + Docs.LeafName END, Docs.Type, Docs.MetaInfoTimeLastModified, Docs.MetaInfo, Size, Docs.TimeCreated, TimeLastModified, Docs.ETagVersion, Docs.DocFlags, NULL, NULL, NULL, Docs.TimeLastWritten, NULL, NULL, UI.tp_Login, Docs.CheckoutDate, Docs.CheckoutExpires, Docs.VirusStatus, Docs.VirusInfo, Docs.VirusInfoEx, Docs.VirusVendorID, SetupPathVersion, SetupPath, SetupPathUser, Docs.NextToLastTimeModified, Docs.UIVersion, Docs.CheckinComment, Docs.WelcomePageUrl, Docs.WelcomePageParameters, NULL, Perms.Acl, Perms.AnonymousPermMask, Docs.DraftOwnerId, Docs.Level, Docs.ParentVersion, Docs.TransformerId, Docs.ParentLeafName, Docs.ProgId, Docs.DoclibRowId, NULL, Docs.ListId, Docs.ItemChildCount, Docs.FolderChildCount, Docs.MetaInfoVersion, NULL, Docs.ContentVersion, (CASE WHEN Docs.ListSchemaVersion IS NOT NULL AND L.tp_ListSchemaVersion IS NOT NULL AND Docs.ListSchemaVersion <> L.tp_ListSchemaVersion THEN CAST(1 AS bit) WHEN Docs.Dirty = CAST(1 AS bit) THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END), Docs.NextBSN, Docs.MetadataNextBSN, Docs.StreamSchema, Docs.InternalVersion, Docs.ParentId
    FROM
        TVF_Docs_CI(@DocSiteId, @DocParentId, @DocId, @Level) AS Docs
    CROSS APPLY
        TVF_Perms_ScopeId(Docs.SiteId, Docs.ScopeId) AS Perms
    OUTER APPLY
        TVF_UserInfo_PK(Docs.SiteId, Docs.CheckoutUserId) AS UI
    OUTER APPLY
        TVF_Lists_NoLock_CI(Docs.SiteId, Docs.WebId, Docs.ListId) AS L
    WHERE
        (@DocWebId IS NULL OR Docs.WebId = @DocWebId)
    OPTION (FORCE ORDER)
    IF @@ROWCOUNT > 0
    BEGIN
        IF (@DocWebId IS NULL)
        BEGIN
            SELECT
                NULL
            WHERE
                1 = 0
        END
        ELSE
        BEGIN
            EXEC proc_GetEventReceivers @DocSiteId, @DocWebId, @DocId, 3
        END
    END

go

