
        CREATE VIEW [dbo].[Webs]
        AS
            SELECT
                *
            FROM
                AllWebs
            WHERE
                DeleteTransactionId = 0x
    
go

