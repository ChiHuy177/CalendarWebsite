CREATE FUNCTION [dbo].[TVF_RoleAssignment_NCI]
(
    @SiteId uniqueidentifier,
    @PrincipalId int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[RoleAssignment] WITH (INDEX=RoleAssignment_NCI, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        PrincipalId = @PrincipalId

go

