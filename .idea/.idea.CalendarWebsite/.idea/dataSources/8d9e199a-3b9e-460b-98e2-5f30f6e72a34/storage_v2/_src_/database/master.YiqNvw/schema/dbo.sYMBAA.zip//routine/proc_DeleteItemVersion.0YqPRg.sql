CREATE PROCEDURE [dbo].[proc_DeleteItemVersion](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ItemId int,
    @ItemVersion int,
    @UserId int,
    @AppPrincipalId int,
    @UseNvarchar1ItemName bit = 1,
    @DeleteOp int = 3,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DeleteTransactionId varbinary(16)
    SET @DeleteTransactionId = 0x
    DECLARE @ReturnStatus int SET @ReturnStatus = 0 BEGIN TRAN
    SET @ReturnStatus = 1359
    DECLARE @DirName nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    DECLARE @Size bigint
    DECLARE @ItemName nvarchar(255)
    DECLARE @AuthorId int
    DECLARE @AuditEventData nvarchar(4000)
    DECLARE @DocId uniqueidentifier
    SELECT TOP 1
        @DirName = D.DirName,
        @LeafName = D.LeafName,
        @DocId = D.Id,
        @Size = CAST(ISNULL(tp_Size, 0) AS BIGINT),
        @ItemName = 
            CASE 
                WHEN @UseNvarchar1ItemName = 1 AND nvarchar1 IS NOT NULL THEN nvarchar1 
                ELSE CAST(tp_ID AS NVARCHAR(10)) 
            END,
        @AuthorId = tp_Editor
    FROM
        TVF_UserDataVersioned_ListVerItemCal_Nvarchar1(@SiteId, @ListId, CONVERT(bit,0), @ItemId, @ItemVersion) AS UD
    CROSS APPLY
        TVF_Docs_PId_DId(UD.tp_SiteId, UD.tp_ParentId, UD.tp_DocId) AS D
    WHERE
        D.IsCurrentVersion = 1
    ORDER BY
        UD.tp_Level DESC 
    OPTION (FORCE ORDER)
    SET @AuditEventData = STUFF(STUFF('</>', 3, 0, 'Version'), 1, 0, STUFF(STUFF(STUFF('</>', 3, 0, 'Major'), 1, 0, STUFF(@ItemVersion/512, 1, 0, STUFF('<>', 2, 0, 'Major'))) + STUFF(STUFF('</>', 3, 0, 'Minor'), 1, 0, STUFF(@ItemVersion%512, 1, 0, STUFF('<>', 2, 0, 'Minor'))), 1, 0, STUFF('<>', 2, 0, 'Version')))
    IF (@DeleteOp = 3) 
        SET @AuditEventData = @AuditEventData + STUFF(STUFF('</>', 3, 0, 'Recycle'), 1, 0, STUFF('0', 1, 0, STUFF('<>', 2, 0, 'Recycle')))
    ELSE IF (@DeleteOp = 4) 
        SET @AuditEventData = @AuditEventData + STUFF(STUFF('</>', 3, 0, 'Recycle'), 1, 0, STUFF('1', 1, 0, STUFF('<>', 2, 0, 'Recycle')))
    EXEC @ReturnStatus = proc_AddAuditEntryFromSql
        @SiteId,
        @DirName,
        @LeafName,
        3,
        @UserId,                
        @AppPrincipalId,
        4,
        @AuditEventData,
        0x00000008
    IF @ReturnStatus <> 0 
        GOTO cleanup
    IF (@DeleteOp = 3)
    BEGIN
        DECLARE @docsToDelete tvpStreamMetadata2
        INSERT INTO @docsToDelete (
            DocId, HistVersion, Level)
        SELECT 
            DV.Id, DV.UIVersion, DV.Level
        FROM
            TVF_DocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @ItemVersion) AS DV
        EXEC proc_DeleteStreams @SiteId, @docsToDelete
        DELETE
            DV
        FROM
            TVF_DocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @ItemVersion) AS DV
        DELETE
            UD
        FROM
            TVF_UserDataVersioned_ListVerItemCal(@SiteId, @ListId, CONVERT(bit,0), @ItemId, @ItemVersion) AS UD
        IF @@ROWCOUNT = 0
        BEGIN
            SET @ReturnStatus = 2
            GOTO cleanup
        END
        EXEC proc_UpdateDiskUsed @SiteId
        SET @ReturnStatus = 0
    END
    ELSE IF (@DeleteOp = 4)
    BEGIN
        SET @DeleteTransactionId = NEWID()    
        DECLARE @ListDirName nvarchar(256)
        SELECT TOP 1
            @ListDirName = CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END
        FROM
            TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L
        CROSS APPLY
            TVF_Docs_Id(L.tp_SiteId, L.tp_RootFolder) AS D
        INSERT INTO RecycleBin (
            SiteId,
            WebId,
            BinId,
            DeleteUserId,
            DeleteTransactionId,
            ChildDeleteTransactionId,
            DeleteDate,
            ItemType,
            ListId,
            DocId,
            DocVersionId,
            ListItemId,
            Title,
            DirName,
            LeafName,
            AuthorId,
            Size,
            ListDirName,
            EffectiveDeleteTransactionId,
            ScopeId)
        VALUES (
            @SiteId,
            @WebId,
            1,
            @UserId,
            @DeleteTransactionId,
            0x,
            dbo.fn_RoundDateToNearestSecond(GETUTCDATE()),
            8,
            @ListId,
            @DocId,
            @ItemVersion,
            @ItemId,
            @ItemName + ' (' + CAST(@ItemVersion/512 AS nvarchar(10)) + 
                         '.' + CAST(@ItemVersion%512 AS nvarchar(10)) + ')',
            @DirName,
            @LeafName,
            @AuthorId,
            @Size,
            @ListDirName,
            CASE WHEN 0x = 0x THEN @DeleteTransactionId ELSE 0x END,
            NULL)   
        UPDATE
            DV
        SET
            DeleteTransactionId = @DeleteTransactionId
        FROM
            TVF_DocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @ItemVersion) AS DV
        UPDATE 
            UD
        SET
            tp_DeleteTransactionId = @DeleteTransactionId
        FROM
            TVF_UserDataVersioned_ListVerItemCal(@SiteId, @ListId, CONVERT(bit,0), @ItemId, @ItemVersion) AS UD
        DECLARE @DeltaSize bigint
        SET @DeltaSize = -ISNULL(@Size, 0)
        EXEC proc_AddStorageMetricsChange @SiteId, @DocId, @DeltaSize, 1, 1
        SET @ReturnStatus = 0            
    END
    EXEC proc_DeleteItemJunctionsVersion 
        @SiteId,
        @ListId, 
        @ItemId, 
        @ItemVersion, 
        @DeleteOp, 
        @DeleteTransactionId
cleanup:
    IF (@ReturnStatus <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @ReturnStatus

go

