CREATE FUNCTION [dbo].[TVF_AllDocs_NoLock_Id]
(
    @SiteId uniqueidentifier,
    @Id uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (NOLOCK, INDEX=Docs_IdLevelUnique, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Id = @Id

go

