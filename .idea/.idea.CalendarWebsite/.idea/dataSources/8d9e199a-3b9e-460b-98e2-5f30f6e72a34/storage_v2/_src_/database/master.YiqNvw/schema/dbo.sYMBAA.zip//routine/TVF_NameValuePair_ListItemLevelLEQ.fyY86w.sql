CREATE FUNCTION [dbo].[TVF_NameValuePair_ListItemLevelLEQ]
(
    @ListId uniqueidentifier,
    @ItemId int,
    @LEQLevel tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NameValuePair] WITH (INDEX=NameValuePair_MatchUserData, FORCESEEK)
    WHERE
        ListId = @ListId AND
        ItemId = @ItemId AND
        Level <= @LEQLevel

go

