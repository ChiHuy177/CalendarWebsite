-- Work_GetAllByProject 'Co1.Work' 
   -- select * FROM [Dynamic].[Workflow_WORK] 
   -- select * FROM Dynamic.Workflow_RESOURCEDA 
   -- select dbo.Work_Fn_GetProgressProject('RESOURCEDA22090001') 
   -- Work_GetProjectViewByUser 'P:10518' 
   CREATE   PROC [dbo].[Work_GetProjectViewByUser] 
   @UserId AS NVARCHAR(50) = '' 
   ,@type as nvarchar(150)='' 
   AS 
   DECLARE @a TABLE(totalWork INT,Duan VARCHAR(40)) 
   insert into @a 
   SELECT DISTINCT count(a.Id) AS totalWork 
   ,a.Duan 
   FROM [Dynamic].[Data_WORK] AS a 
   where ISNULL(a.IsActive,'True')='True' 
   GROUP BY a.Duan 
   declare @tbUser table ( UserId nvarchar(50), UserWorkflowId bigint) 
   insert into @tbUser 
   select * from 
   ( 
   SELECT  
   'P:'+ trim(str(c.PersonalProfilesId)) AS userId 
   ,a.UserWorkflowId 
   -- into #da 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b 
   inner join GroupPersonalProfile c on 'G:'+ trim(str(GroupsId))=b.value 
   where left(trim(b.value),2)='G:' and ISNULL(a.IsDeleted,'False')='False' 
   union 
   SELECT  
   b.value AS userId 
   ,a.UserWorkflowId 
   -- into #da 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b 
   where left(trim(b.value),2)='P:' and ISNULL(a.IsDeleted,'False')='False' 
   union 
   SELECT  
   b.value AS userId 
   ,a.UserWorkflowId 
   -- into #da 
   FROM DYNAMIC.Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   where left(trim(b.value),2)='P:' and ISNULL(a.IsDeleted,'False')='False' 
   ) a group by userId,UserWorkflowId 
   SELECT
   b.UserWorkflowId as Duan
   ,a.Ten as projectName 
   ,@UserId AS UserId 
   ,[NgayBatDau] as [Start]  
   ,[NgayKetThuc] as [End] 
   ,a.ThanhPhanThamGia as UserPartner 
   ,isnull( dbo.Work_Fn_GetProgressProject(a.UserWorkflowId),0) AS progress 
   ,a.QuanLy 
   ,a.UserWorkflowId as ProjectId 
   ,isnull(a.MoTa,'') as description 
   ,a.TrangThai as status 
   , ISNULL( c.totalWork,0) as TotalWork 
   FROM Dynamic.Data_RESOURCEDA a
   inner join @tbUser b ON b.UserWorkflowId = a.UserWorkflowId
   left join @a c on b.UserWorkflowId=c.Duan
   where ISNULL(a.Loai,'') like N'%'+ @type+'%' and b.UserId=@UserId
   group by 
   b.UserWorkflowId
   ,a.Ten 
   ,[NgayBatDau]  
   ,[NgayKetThuc] 
   ,a.ThanhPhanThamGia 
   ,a.QuanLy 
   ,a.UserWorkflowId 
   ,isnull(a.MoTa,'') 
   ,a.TrangThai 
   , ISNULL( c.totalWork,0)
go

