CREATE PROCEDURE [dbo].[proc_GetListItemWorkflows] (
        @SiteId                uniqueidentifier,
        @WebId                 uniqueidentifier,
        @ListId                uniqueidentifier,
        @ItemId                int,
        @WorkflowInstanceId    uniqueidentifier,
        @TemplateId            uniqueidentifier,
        @InclusiveFilterState  int = 0xFFFFFFFF,
        @ExclusiveFilterState  int = 0,
        @Limit int = 0,
        @LimitFlags int = 0,
        @RequestGuid uniqueidentifier = NULL OUTPUT     
        )
AS
    SET NOCOUNT ON
    IF (@WorkflowInstanceId IS NOT NULL)
    BEGIN
        SELECT TOP 1
            Id, TemplateId, ListId, SiteId, WebId, ItemId, ItemGUID, TaskListId, AdminTaskListId, Author, Modified, Created, StatusVersion, Status1, Status2, Status3, Status4, Status5, Status6, Status7, Status8, Status9, Status10, TextStatus1, TextStatus2, TextStatus3, TextStatus4, TextStatus5, Modifications, ActivityDetails, CorrelationId,
            NULL as InstanceData,     
            0 as InstanceDataSize,     
            InternalState,
            LockMachineId as ProcessingId       
        FROM
            TVF_Workflow_Id(@SiteId, @WorkflowInstanceId) AS WF
        WHERE
            WF.WebId = @WebId AND
            (WF.InternalState & @InclusiveFilterState) != 0 AND
            (WF.InternalState & @ExclusiveFilterState) = 0
    END
    ELSE
        BEGIN
        SET ROWCOUNT @Limit
        IF (@LimitFlags & 1) <> 0 
        BEGIN
            IF (@ItemId IS NOT NULL)
            BEGIN
                SELECT ALL
                    Id, TemplateId, ListId, SiteId, WebId, ItemId, ItemGUID, TaskListId, AdminTaskListId, Author, Modified, Created, StatusVersion, Status1, Status2, Status3, Status4, Status5, Status6, Status7, Status8, Status9, Status10, TextStatus1, TextStatus2, TextStatus3, TextStatus4, TextStatus5, Modifications, ActivityDetails, CorrelationId,            
                    NULL as InstanceData,     
                    0 as InstanceDataSize,     
                    InternalState,
                    NULL as ProcessingId                
                FROM
                    TVF_Workflow_CI(@SiteId, @WebId, @ListId, @ItemId) AS WF
                WHERE
                    (@TemplateId IS NULL OR
                        WF.TemplateId = @TemplateId) AND
                    (WF.InternalState & @InclusiveFilterState) != 0 AND
                    (WF.InternalState & @ExclusiveFilterState) = 0
                ORDER BY
                    Created ASC
            END
            ELSE 
            BEGIN
                SELECT ALL
                    Id, TemplateId, ListId, SiteId, WebId, ItemId, ItemGUID, TaskListId, AdminTaskListId, Author, Modified, Created, StatusVersion, Status1, Status2, Status3, Status4, Status5, Status6, Status7, Status8, Status9, Status10, TextStatus1, TextStatus2, TextStatus3, TextStatus4, TextStatus5, Modifications, ActivityDetails, CorrelationId,            
                    NULL as InstanceData,     
                    0 as InstanceDataSize,     
                    InternalState,
                    NULL as ProcessingId                
                FROM
                    TVF_Workflow_SiteWeb(@SiteId, @WebId) AS WF
                WHERE
                    (@ListId IS NULL OR
                        WF.ListId = @ListId) AND
                    (@TemplateId IS NULL OR
                        WF.TemplateId = @TemplateId) AND
                    (WF.InternalState & @InclusiveFilterState) != 0 AND
                    (WF.InternalState & @ExclusiveFilterState) = 0
                ORDER BY
                    Created ASC
            END
        END
        ELSE 
	BEGIN
            IF (@ItemId IS NOT NULL)
            BEGIN
                SELECT ALL
                    Id, TemplateId, ListId, SiteId, WebId, ItemId, ItemGUID, TaskListId, AdminTaskListId, Author, Modified, Created, StatusVersion, Status1, Status2, Status3, Status4, Status5, Status6, Status7, Status8, Status9, Status10, TextStatus1, TextStatus2, TextStatus3, TextStatus4, TextStatus5, Modifications, ActivityDetails, CorrelationId,            
                    null as InstanceData,     
                    0 as InstanceDataSize,     
                    InternalState,
                    null as ProcessingId                
                FROM
                    TVF_Workflow_CI(@SiteId, @WebId, @ListId, @ItemId) AS WF
                WHERE
                    (@TemplateId IS NULL OR
                        WF.TemplateId = @TemplateId) AND
                    (WF.InternalState & @InclusiveFilterState) != 0 AND
                    (WF.InternalState & @ExclusiveFilterState) = 0
                ORDER BY
                    Created DESC
            END
            ELSE 
            BEGIN
                SELECT ALL
                    Id, TemplateId, ListId, SiteId, WebId, ItemId, ItemGUID, TaskListId, AdminTaskListId, Author, Modified, Created, StatusVersion, Status1, Status2, Status3, Status4, Status5, Status6, Status7, Status8, Status9, Status10, TextStatus1, TextStatus2, TextStatus3, TextStatus4, TextStatus5, Modifications, ActivityDetails, CorrelationId,            
                    null as InstanceData,     
                    0 as InstanceDataSize,     
                    InternalState,
                    NULL as ProcessingId                
                FROM
                    TVF_Workflow_SiteWeb(@SiteId, @WebId) AS WF
                WHERE
                    (@ListId IS NULL OR
                        WF.ListId = @ListId) AND
                    (@TemplateId IS NULL OR
                        WF.TemplateId = @TemplateId) AND
                    (WF.InternalState & @InclusiveFilterState) != 0 AND
                    (WF.InternalState & @ExclusiveFilterState) = 0
                ORDER BY
                    Created DESC
            END
        END
    END

go

