CREATE   PROC [dbo].[Work_InsertUserWorkFlow]  
   @UserId as bigint  
   ,@WorkflowId as bigint  
   ,@WorkflowStepId as bigint  
   ,@WorkflowCode as nvarchar(max)='WORKChatTien'  
   ,@ShortContent as nvarchar(max)  
   ,@Status as nvarchar(max)  
   ,@CreatedBy as nvarchar(max)  
   ,@CreatedTime as datetime2(7)  
   ,@LastModified as datetime2(7)  
   ,@ModifiedBy as nvarchar(max)  
   ,@IsDeleted as bit=0  
   ,@IsDraft as bit  
   ,@UserWorkflowStatus as int = 1  
   ,@Content as nvarchar(max)  
   ,@Note as nvarchar(max)  
   ,@Approver as nvarchar(max)  
   ,@IsWaitingForAppoved as bit=0  
   ,@MeetingRoom as bigint  
   ,@IsConverted as bit  
   ,@MainUserWorkflowId as bigint  
   ,@WorkId as bigint  
   as  
   declare @UserWorkflowIdNew table([Id] bigint)
   INSERT INTO [dbo].[UserWorkflow]  
   ([UserId]  
   ,[WorkflowId]  
   ,[WorkflowStepId]  
   ,[WorkflowCode]  
   ,[ShortContent]  
   ,[Status]  
   ,[CreatedBy]  
   ,[CreatedTime]  
   ,[LastModified]  
   ,[ModifiedBy]  
   ,[IsDeleted]  
   ,[IsDraft]  
   ,[UserWorkflowStatus]  
   ,[Content]  
   ,[Note]  
   ,[Approver]  
   ,[IsWaitingForAppoved]  
   ,[MeetingRoom]  
   ,[IsConverted]  
   ,[MainUserWorkflowId]  
   ,[WorkId])  
   OUTPUT Inserted.ID into @UserWorkflowIdNew
   VALUES  
   (@UserId  
   ,@WorkflowId  
   ,(SELECT TOP 1 Id from [dbo].[WorkflowStep] where WorkflowID = @WorkflowId AND IsDeleted = 0 AND Step = 1 ORDER BY Step)  
   ,@WorkflowCode  
   ,@ShortContent  
   ,@Status  
   ,@CreatedBy  
   ,@CreatedTime  
   ,@LastModified  
   ,@ModifiedBy  
   ,@IsDeleted  
   ,@IsDraft  
   ,@UserWorkflowStatus  
   ,@Content  
   ,@Note  
   ,@Approver  
   ,@IsWaitingForAppoved  
   ,@MeetingRoom  
   ,@IsConverted  
   ,@MainUserWorkflowId  
   ,@WorkId)  
   select * from @UserWorkflowIdNew
go

