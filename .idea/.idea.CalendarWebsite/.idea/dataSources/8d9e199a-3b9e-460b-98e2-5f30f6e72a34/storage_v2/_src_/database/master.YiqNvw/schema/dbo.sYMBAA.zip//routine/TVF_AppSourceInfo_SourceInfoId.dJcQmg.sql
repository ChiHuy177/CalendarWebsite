CREATE FUNCTION [dbo].[TVF_AppSourceInfo_SourceInfoId]
(
    @SiteId uniqueidentifier,
    @SourceInfoId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppSourceInfo] WITH (INDEX=AppSourceInfo_SourceInfoId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SourceInfoId = @SourceInfoId

go

