-- Work_ReportTimeSheetTotal '2023-11-01','5',''  
   CREATE   PROC Work_ReportTimeSheetTotal  
   @date as nvarchar(50)  
   ,@department AS NVARCHAR(50) = '5'      
   ,@typeDate as nvarchar(50)='Week'  
   as  
   declare @tb table (ProjectName nvarchar(500),TypeDate nvarchar(500), TotalHour int, GroupName nvarchar(500), ProjectId nvarchar(500))
   select c.Ten as ProjectName  
   ,trim(str(year(a.Ngay))) +'-'+  trim(str(datepart(WEEK, a.Ngay))) as TypeDate  
   , (ISNULL(a.SoGio,0))  as TotalHour  
   ,ISNULL(f.Ten,'') as GroupName  
   ,c.UserWorkflowId as  ProjectId  
   into #a  
   from Dynamic.data_VNTTSLT a  
   inner join Dynamic.Data_WORK b on a.Congviec=b.UserWorkflowId   
   inner join Dynamic.Data_RESOURCEDA c on c.UserWorkflowId=b.Duan  
   INNER JOIN [dbo].[PersonalProfile] d ON a.Email = d.Email and ISNULL(d.IsDeleted,0) = 0     
   inner join Department e on d.DepartmentId=e.Id and isnull(e.IsDeleted,0)=0    
   left join Dynamic.Data_ProjectGroup f on b.GroupProject=f.UserWorkflowId  
   where LEFT( trim(CONVERT(CHAR, a.Ngay, 23)),7) =  LEFT( trim(CONVERT(CHAR, @date, 23)),7)      
   and ISNULL(a.IsDelete,'False')='False'     
   and e.Id=@department     
   group by c.Ten   
   , a.Ngay   
   ,f.Ten   
   ,c.UserWorkflowId  
   ,a.SoGio
   insert into @tb
   select ProjectName,TypeDate,sum(TotalHour) as TotalHour,
   N'' as GroupName, ProjectId   
   from #a  group by ProjectName,TypeDate,ProjectId   
   insert into @tb
   select a.ProjectName,a.TypeDate,sum(a.TotalHour) as TotalHour,
   case when a.GroupName ='' then N'[none]' else a.GroupName end as GroupName ,a.ProjectId  
   from #a  a 
   inner join @tb b on a.ProjectId=b.ProjectId and a.TypeDate=b.TypeDate 
   group by a.ProjectName,a.TypeDate,a.ProjectId ,a.GroupName 
   select * from @tb -- where ProjectId=332666 and TypeDate='2023-44'
   drop table #a
go

