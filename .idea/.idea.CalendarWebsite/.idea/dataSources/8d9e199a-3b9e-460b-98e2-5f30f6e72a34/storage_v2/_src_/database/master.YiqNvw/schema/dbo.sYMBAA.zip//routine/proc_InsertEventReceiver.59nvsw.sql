CREATE PROCEDURE [dbo].[proc_InsertEventReceiver](
    @Id uniqueidentifier,
    @Name nvarchar(256),
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @HostId uniqueidentifier,
    @HostType int,
    @ItemId int,                                
    @DirName nvarchar(256),     
    @LeafName nvarchar(128),   
    @Synchronization int,
    @Type int,
    @SequenceNumber int,
    @RemoteUrl nvarchar(4000),
    @Assembly nvarchar(256),
    @Class nvarchar(256),
    @SolutionId uniqueidentifier,
    @Data nvarchar(256),
    @Filter nvarchar(256),
    @SourceId tContentTypeId,
    @SourceType int,
    @Credential int,
    @ContextType uniqueidentifier,
    @ContextEventType uniqueidentifier,
    @ContextId uniqueidentifier,
    @ContextObjectId uniqueidentifier,
    @ContextCollectionId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @ERR int, @ROWC int
    DECLARE @RC int SET @RC = 0 BEGIN TRAN
    SELECT @ROWC = COUNT(1)
    FROM
        TVF_EventReceivers_UpdLock_SiteWebHostHostTypeType(@SiteId, @WebId, @HostId, @HostType, @Type) AS ER
    IF NOT EXISTS (
        SELECT TOP 1
            1 
        FROM 
            TVF_EventReceivers_NoLock_SiteWebHostHostTypeType(@SiteId, @WebId, @HostId, @HostType, @Type) AS ER
        WHERE
            ER.HostType = @HostType AND
            ((ER.ContextCollectionId IS NULL AND @ContextCollectionId IS NULL) OR ER.ContextCollectionId = @ContextCollectionId) AND
            ((ER.ContextObjectId IS NULL AND @ContextObjectId IS NULL) OR ER.ContextObjectId = @ContextObjectId) AND
            ((ER.ContextId IS NULL AND @ContextId IS NULL) OR ER.ContextId = @ContextId) AND
            ((ER.ContextType IS NULL AND @ContextType IS NULL) OR ER.ContextType = @ContextType) AND
            ((ER.ContextEventType IS NULL AND @ContextEventType IS NULL) OR ER.ContextEventType = @ContextEventType) AND
            ((ER.SourceId IS NULL AND @SourceId IS NULL) OR ER.SourceId = @SourceId) AND
            (ER.SourceType = @SourceType) AND
            ((ER.RemoteUrl IS NULL AND @RemoteUrl IS NULL) OR ER.RemoteUrl = @RemoteUrl) AND
            ((ER.Assembly IS NULL AND @Assembly IS NULL) OR ER.Assembly = @Assembly) AND
            ((ER.Class IS NULL AND @Class IS NULL) OR ER.Class = @Class) AND
            ER.SequenceNumber = @SequenceNumber AND
            ((ER.SolutionId IS NULL AND @SolutionId IS NULL) OR ER.SolutionId = @SolutionId))
    BEGIN
        INSERT INTO
            EventReceivers (EventReceivers.Id, EventReceivers.Name, EventReceivers.SiteId, EventReceivers.WebId, EventReceivers.HostId, EventReceivers.HostType, EventReceivers.ItemId, EventReceivers.DirName, EventReceivers.LeafName, EventReceivers.Synchronization, EventReceivers.Type, EventReceivers.SequenceNumber, EventReceivers.RemoteUrl, EventReceivers.Assembly, EventReceivers.Class, EventReceivers.SolutionId, EventReceivers.Data, EventReceivers.Filter, EventReceivers.SourceId, EventReceivers.SourceType, EventReceivers.Credential, EventReceivers.ContextType, EventReceivers.ContextEventType, EventReceivers.ContextId, EventReceivers.ContextObjectId, EventReceivers.ContextCollectionId)
        VALUES (
            @Id,
            @Name,
            @SiteId,
            @WebId,
            @HostId,
            @HostType,
            @ItemId,
            @DirName,
            @LeafName,
            @Synchronization,
            @Type,
            @SequenceNumber,
            @RemoteUrl,
            @Assembly,
            @Class,
            @SolutionId,
            @Data,
            @Filter,
            @SourceId,
            @SourceType,
            @Credential,
            @ContextType,
            @ContextEventType,
            @ContextId,
            @ContextObjectId,
            @ContextCollectionId)
        SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
        IF @ERR <> 0
            SET @RC = 30
        ELSE IF @ROWC <> 1
            SET @RC = 87                       
    END
cleanup:
    IF (@RC <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN        
    RETURN @RC

go

