CREATE PROC [dbo].[proc_RenameListItemContentType](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @ContentTypeId tContentTypeId,
    @ContentTypeName nvarchar(255),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @Collation smallint
    EXEC proc_GetCollation @SiteId, @ListId, @Collation OUTPUT, @RequestGuid OUTPUT
    IF @Collation = 0
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 1
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 2
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 3
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 4
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 5
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 6
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 7
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 8
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 9
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 10
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 11
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 12
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 13
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 14
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 15
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 16
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 17
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 18
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 19
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 20
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 21
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 22
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 23
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 24
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 25
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 26
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 27
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 28
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 29
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 30
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 31
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 32
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 33
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 34
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 35
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 36
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 37
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 38
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 39
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 40
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 41
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 42
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 43
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 44
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 45
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 46
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 47
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    ELSE
    IF @Collation = 48
    BEGIN
        UPDATE NVP SET Value = @ContentTypeName FROM
            NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_CI)
        CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId
    END
    UPDATE NVP SET Value = @ContentTypeName FROM
        NameValuePair AS NVP WITH (INDEX=NameValuePair_CI)
    CROSS APPLY TVF_AllUserData_List(NVP.SiteId, NVP.ListId) AS AUD WHERE NVP.ItemId = AUD.tp_ID AND NVP.SiteId = @SiteId AND NVP.ListId = @ListId AND NVP.FieldId = '{c042a256-787d-4a6f-8a8a-cf6ab767f12d}' AND AUD.tp_ContentTypeId = @ContentTypeId

go

