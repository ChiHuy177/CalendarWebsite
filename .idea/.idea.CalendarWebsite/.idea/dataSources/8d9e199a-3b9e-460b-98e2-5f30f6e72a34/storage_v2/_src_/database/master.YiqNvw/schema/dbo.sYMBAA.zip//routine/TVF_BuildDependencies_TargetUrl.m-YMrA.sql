CREATE FUNCTION [dbo].[TVF_BuildDependencies_TargetUrl]
(
    @SiteId uniqueidentifier,
    @TargetDirName nvarchar(256),
    @TargetLeafName nvarchar(128)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[BuildDependencies] WITH (INDEX=BuildDependencies_Backward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        TargetDirName = @TargetDirName AND
        TargetLeafName = @TargetLeafName

go

