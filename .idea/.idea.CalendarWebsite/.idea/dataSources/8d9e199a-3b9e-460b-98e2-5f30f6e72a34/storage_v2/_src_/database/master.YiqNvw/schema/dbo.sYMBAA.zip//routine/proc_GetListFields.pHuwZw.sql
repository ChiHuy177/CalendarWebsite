CREATE PROC [dbo].[proc_GetListFields](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT
        tp_Fields
    FROM
        TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L

go

