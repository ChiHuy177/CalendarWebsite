-- [Work_GetWorkByTypeInput] '','333572','','','P:287',N'Việc cần đánh giá',1,'',''         
   CREATE   PROC [dbo].[Work_GetWorkByTypeInput]         
   @title AS NVARCHAR(500) = ''         
   ,@projectName AS NVARCHAR(500) = ''         
   ,@group AS NVARCHAR(500) = ''         
   ,@status AS NVARCHAR(500) = ''         
   ,@employee AS NVARCHAR(500) = 'P:287'         
   ,@type as nvarchar(50)=N'XỬ LÝ'         
   ,@isComplete as int =0         
   ,@defaulUser as nvarchar(250)=''         
   ,@projectType as nvarchar(150)=''         
   ,@maxRoot as nvarchar(150)='False'         
   as          
   ;          
   declare @sql as nvarchar(max)=N'',@where as nvarchar(max)=N'', @join as nvarchar(max)=N''    
   ,@where1 as nvarchar(max)=N' and isnull(d.TrangThaiCongViec,'''') <> N''Hoàn thành'' and isnull(d.TrangThaiCongViec,'''') <> N''Hủy'''          
   ,@from as nvarchar(max) =' ,case when N'''+@type+'''=N'''+N'Xử lý'+''' and '''+@maxRoot+'''<>''True'' then isnull( a.RootNguoiXuLy ,a.UserWorkflowId)         
   when N'''+@type+'''=N'''+N'Việc phối hợp'+''' and '''+@maxRoot+'''<>''True'' then isnull( a.RootNguoiPhoiHop ,a.UserWorkflowId)         
   when N'''+@type+'''=N'''+N'Theo dõi'+''' and '''+@maxRoot+'''<>''True'' then isnull( a.RootNguoiTheoDoi ,a.UserWorkflowId)         
   when N'''+@type+'''=N'''+N'Việc giao'+''' and '''+@maxRoot+'''<>''True'' then isnull( a.RootNguoiGiao ,a.UserWorkflowId)         
   when N'''+@type+'''=N'''+N'Việc đã xử lý'+''' and '''+@maxRoot+'''<>''True'' then isnull( a.RootViecDaXuly ,a.UserWorkflowId)         
   when N'''+@type+'''=N'''+N'Việc cần đánh giá'+''' and '''+@maxRoot+'''<>''True'' then isnull( a.RootNguoiGiao ,a.UserWorkflowId)         
   else isnull(a.MaxRoot,a.UserWorkflowId) end as RootWork         
   FROM [Dynamic].[Data_WORK] AS a          
   inner join #duan b on isnull(a.Duan, '''') = b.UserWorkflowId          
   left join DYNAMIC.Data_NHOMCV c on a.Loaicv=c.UserWorkflowId          
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId          
   inner join Dynamic.Workflow_WORK e on a.UserWorkflowId=e.UserWorkflowId '         
   ,@RemainTime as nvarchar(max)= N',case when d.TrangThaiCongViec<> N''Hoàn thành'' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) >0 then N''Trễ ''+ trim(str( DATEDIFF(DAY, Ngayketthuc, GETDATE()))) +N'' ngày''         
   when d.TrangThaiCongViec<> N''Hoàn thành'' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) <0 then N''Còn ''+ trim(str( ABS( DATEDIFF(DAY, Ngayketthuc, GETDATE())))) +N'' ngày''         
   when d.TrangThaiCongViec<>N''Hoàn thành'' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) =0 then N''Hôm nay ( ''+ trim(str( DATEDIFF(HOUR, GETDATE(),Ngayketthuc )))+''h )''         
   else '''' end as RemainTime         
   ,case when d.TrangThaiCongViec<> N''Hoàn thành'' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) >0 then trim(str( DATEDIFF(DAY, Ngayketthuc, GETDATE())))         
   when d.TrangThaiCongViec<> N''Hoàn thành'' and DATEDIFF(DAY, Ngayketthuc, GETDATE()) <0 then trim(str(( DATEDIFF(DAY, Ngayketthuc, GETDATE())))) else 0 end as RemainTimeInt         
   '      
   if(@group<>'')    
   begin     
   set @where1 = @where1 +' ' + ' AND isnull(a.Loaicv, '''') in (select * from Split('''+@group+''','',''))'    
   end    
   if(@status<>'')    
   begin     
   set @where1 = @where1 +' ' + ' AND isnull(a.TrangThaiCongViec, '''') in (select * from Split('''+@status+''','',''))'    
   end    
   CREATE TABLE #duan (UserWorkflowId bigint , Ten nvarchar(500), Loai nvarchar(500),RemindReviewsWork char(10))         
   insert into #duan select 1,'','',''         
   if(@projectName='')         
   begin         
   if(@defaulUser<>'')         
   begin         
   insert into #duan select UserWorkflowId,Ten,Loai,RemindReviewsWork from Dynamic.Data_RESOURCEDA         
   where (@defaulUser in (select * from string_split(ThanhPhanThamGia,';'))          
   or @defaulUser in ( select * from string_split(QuanLy,';'))) and ISNULL(IsDeleted,'False')='False' and TrangThai<>N'Hủy'         
   insert into #duan select '','','',''          
   end         
   else          
   begin         
   if(@employee<>'')         
   begin         
   insert into #duan select UserWorkflowId,Ten,Loai,RemindReviewsWork from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False' and TrangThai<>N'Hủy' and ISNULL(Loai,'') like N'%'+ @projectType+'%'         
   insert into #duan select '','','',''         
   end         
   end         
   end         
   else          
   begin          
   insert into #duan select UserWorkflowId,Ten,Loai,RemindReviewsWork from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False' and UserWorkflowId=@projectName  
   end          
   if(@title<>'')         
   begin         
   set @where1 = N' '         
   end         
   if(@type=N'XỬ LÝ')          
   begin          
   set @join= N' CROSS APPLY STRING_SPLIT(a.Nguoixuly, '';'') as NguoixulyCross '          
   end          
   else if(@type=N'VIỆC GIAO')         
   begin         
   set @join= N' CROSS APPLY STRING_SPLIT(a.Nguoigiao, '';'') as NguoixulyCross '          
   end          
   else if(@type=N'THEO DÕI')          
   begin          
   set @join= N' CROSS APPLY STRING_SPLIT(a.Nguoitheodoi, '';'') as NguoixulyCross '          
   end          
   else if(@type=N'VIỆC PHỐI HỢP' or @type=N'PHỐI HỢP')          
   begin         
   set @join= N' CROSS APPLY STRING_SPLIT(a.Nguoiphoihop, '';'') as NguoixulyCross '          
   end          
   else if(@type=N'Việc đã xử lý')          
   begin         
   set @join= N' CROSS APPLY (select value         
   from STRING_SPLIT(ISNULL(a.NguoiXuLyDauTien,'''')+'';''+ISNULL(a.Nguoiphoihop,'''')+'';''+ISNULL(a.Nguoigiao,'''')+'';''+ISNULL(a.Nguoitheodoi,''''), '';'') AS newID          
   group by value ) as NguoixulyCross '          
   set @where1=N' and (isnull(d.TrangThaiCongViec,'''') = N''Hoàn thành'' or isnull(d.TrangThaiCongViec,'''') = N''Hủy'')'         
   end         
   else if(@type=N'Việc cần đánh giá')         
   begin         
   set @join= N' left join Dynamic.Data_ReviewsWork f on f.WorkId=a.UserWorkflowId CROSS APPLY (select value from STRING_SPLIT(ISNULL(a.Nguoigiao,''''),'';'') AS c group by value ) as NguoixulyCross '         
   set @where1=N' and isnull(d.TrangThaiCongViec,'''') =N''Hoàn thành'' and b.RemindReviewsWork=''1'' and f.WorkId is null '         
   end         
   set @sql=N'          
   SELECT a.Duan          
   ,a.Id          
   ,a.tieude AS title          
   ,ISNULL(a.noidung, '''') AS description          
   ,a.TrangThaiCongViec AS STATUS          
   ,a.tieude          
   ,a.noidung          
   ,ISNULL(a.Nguoiphoihop, '''') AS Nguoiphoihop          
   ,isnull(a.Nguoixuly, '''') AS Nguoixuly          
   ,ISNULL(a.Nguoigiao, '''') AS Nguoigiao          
   ,ISNULL(a.Nguoitheodoi, '''') AS Nguoitheodoi          
   ,a.UserWorkflowId          
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, null), 120)) AS [start]          
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS [end]          
   ,trim(CONVERT(CHAR, ISNULL(e.CreatedTime, getdate()), 120)) AS CreatedTime         
   ,ISNULL(a.Loaicv, '''') AS Loaicv          
   ,ISNULL(CongViecCha,'''') as CongViecCha          
   ,a.Tiendo as Progress          
   ,b.Ten as projectName          
   ,b.UserWorkflowId as ProjectId          
   ,d.Ten as statusName         
   ,a.Douutien Priority         
   ,c.TenCV as CategoryName         
   ,d.TrangThaiCongViec as StatusType          
   ,e.Id as Id1         
   ,a.IndexWork         
   ,e.CreatedBy         
   ,case when '+trim(str(@isComplete))+'=1 then 1 else 0 end as IsMyWork         
   ,case when d.TrangThaiCongViec=N''Hoàn thành'' then trim(CONVERT(CHAR, ISNULL(e.LastModified, null), 120)) else null end as DateComplete 
   ,case when ISNULL(a.WorkRepeatId,'''')<> '''' then N'''+N'Việc lặp'+'''      
   when ISNULL(a.Nodeid,'''')<> '''' then N'''+N'Quy trình'+'''      
   when ISNULL(a.RequestChangeUser,0)=1 then N'''+N'Chuyển xử lý'+'''
   else N'''+N'Công việc'+''' end as WorkType      
   '         
   --,case when exists ( select UserWorkflowId as abc from [Dynamic].[Data_WORK] where CongViecCha=a.UserWorkflowId) then ''True'' else ''False'' end as Haschildren '       
   set @where= N'          
   where ISNULL(a.WorkRepeat,''False'')=''False'' and          
   ISNULL(a.IsActive,''True'')=''True''          
   and ISNULL(a.tieude, '''') LIKE N''%'+ @title + '%''                    
   and NguoixulyCross.value ='''+@employee+'''         
   '      
   exec( @sql +' ' + @RemainTime +' '+ @from+ ' '+@join +' '+ @where+' '+@where1 +' '+ N' order by ISNULL(DATEDIFF(DAY, Ngayketthuc, GETDATE()),999999) desc ' )          
   print cast (@sql +' ' + @RemainTime +' '+ @from+ ' '+@join +' '+ @where+' '+@where1 +' '+ N' order by ISNULL(DATEDIFF(DAY, Ngayketthuc, GETDATE()),999999) desc ' as Ntext)         
   --print (@RemainTime )         
   -- [Work_GetWorkByTypeInput] '','','','','P:287',N'Xử lý',1,'',''         
   -- [Work_GetWorkByTypeInput] '','','','','P:344',N'Việc giao',1,'','' 
go

