CREATE   PROC [dbo].[CRM_Product_GetListProduct]    
 @userName as nvarchar(50)='',    
 @str as nvarchar(250)='',    
 @menuId as bigint                
 as                
 SELECT a.ID            
       ,a.Code            
       ,a.Name            
       ,a.Description            
       ,a.ProductNumber            
       ,a.MakeFlag            
       ,a.FinishedGoodsFlag            
       ,a.Color            
       ,a.SafetyStockLevel            
       ,a.ReorderPoint            
       ,a.UnitCode      
       ,a.StandardCost            
       ,a.ListPrice            
       ,a.Size            
       ,a.SizeUnitMeasureCode            
       ,a.WeightUnitMeasureCode            
       ,a.Weight            
       ,a.DaysToManufacture            
       ,a.ProductLine            
       ,a.Class            
       ,a.Style            
       ,a.ProductCategoryID                     
       ,a.ProductModelID            
       ,a.SellStartDate            
       ,a.SellEndDate            
       ,a.DiscontinuedDate                  
       ,a.CreateDate            
       ,a.CreateBy            
       ,a.ModifiedBy            
       ,a.ModifiedDate     
 	  ,a.UserWorkflowId
       ,ISNULL(b.Qty,0) as StockQty                   
      ,e.Price as PurchasePrice          
    ,f.Price as SalePrice      
     
   FROM Dynamic.Data_CRMProduct a            
   left join Dynamic.Data_CRMProductionInventory b on a.Code=b.ProductCode                  
          
   left join Dynamic.Data_CRMPurchasePrice e on a.ID=e.ProductID and isnull( e.IsDelete,0)=0 and ISNULL(e.Active,0) =1          
   left join Dynamic.Data_CRMSalePrice f on a.ID=f.ProductID and isnull( f.IsDelete,0)=0 and ISNULL(f.Active,0) =1     
   where ISNULL(a.IsDelete,0)=0  and (a.Code like N'%'+@str+'%' or a.Name like N'%'+@str+'%' or len(''+ISNULL(@str,'')+'')=0)    
   order by ID desc
go

