-- Work_RecentActivity 'P:287',''                  
   CREATE   PROC Work_RecentActivity                  
   @UserId as nvarchar(50) ,              
   @projectId as nvarchar(50) =''             
   as                  
   declare @workflowId as nvarchar(50) = (select top 1  Id from Workflow where code='work')          
   select 0 as UserId, a.Tieude as FullName, a.Tieude as ColumnName , Ngaybatdau as Date              
   ,a.Tieude as WorkName,a.UserWorkflowId as WorkId, '0' as [Type], a.Duan        
   into  #work from Dynamic.Data_WORK a where Id=0            
   select *,N'day la kha bao do dai cua cot time' as Time,N'qweqweqwe qweqw eqw qw qweqwe q eqweqwe' as TimeOrder into #tbFinish from #work  
   -- lịch sử cập nhật                  
   select d.Id as UserId,d.FullName, N' đã thay đổi '+ c.Label as ColumnName , b.Date                  
   ,a.Tieude as WorkName,a.UserWorkflowId as WorkId, '0' as [Type]     
   ,(ISNULL(a.Nguoigiao,'')+';'+ISNULL(a.Nguoixuly,'')+';'+ISNULL(a.Nguoitheodoi,'')          
   +';'+ISNULL(a.Nguoiphoihop,'')+';'+ISNULL(a.NguoiGiaoDauTien,'')+';'+ISNULL(a.NguoiXuLyDauTien,'')) as UserRelationship    
   ,a.Duan    
   into #workHis    
   from Dynamic.Data_WORK a                  
   inner join Dynamic.Data_LSCNTTCV b on a.UserWorkflowId=b.WorkId                  
   inner join Property c on b.ColumnName=c.Name and c.WorkflowId=@workflowId                  
   inner join PersonalProfile d on  'P:'+trim(str( d.Id)  )=b.UpdateUser                  
   where  ISNULL(a.IsActive,'True') = 'True'                   
   and DATEDIFF(day,b.Date,getdate()) <=15                   
   and c.Name not in ('IsActive','IsDelete','IndexWork')       
   insert into #work          
   select UserId,FullName,ColumnName,Date,WorkName,WorkId,[Type],Duan    
   from #workHis where @UserId = (select top 1  Item from Split(UserRelationship,';') where Item =@UserId )     
   -- Bình luận                  
   insert into #work                  
   select c.Id as UserId,c.FullName,N' đã bình luận ' as ColumnName, b.CreatedTime                   
   ,d.Tieude ,d.UserWorkflowId  , '1' as [Type],d.Duan                
   from  [Chat].[Info] a                   
   inner join [Chat].[Message] b on a.Id=b.ChatId                  
   inner join PersonalProfile c on c.Id=b.UserId                  
   inner join Dynamic.Data_WORK d on d.UserWorkflowId=a.UserWorkflowId                  
   where @UserId = (select top 1 Item from Split(ISNULL(d.Nguoigiao,'')+';'+ISNULL(d.Nguoixuly,'')+';'+ISNULL(d.Nguoitheodoi,'')          
   +';'+ISNULL(d.Nguoiphoihop,'')+';'+ISNULL(d.NguoiGiaoDauTien,'')+';'+ISNULL(d.NguoiXuLyDauTien,''),';') where Item =@UserId)               
   and DATEDIFF(day,b.CreatedTime,getdate()) <=15                   
   and ISNULL(d.IsActive,'True') = 'True'                  
   -- thêm mới cv                   
   insert into #work                  
   select d.Id as UserId,d.FullName, N' đã giao bạn xử lý ' as ColumnName, a.CreateDate                  
   ,a.Tieude ,a.UserWorkflowId   , '2' as [Type],a.Duan     
   from Dynamic.Data_WORK a                  
   left join Dynamic.Data_LSCNTTCV b on a.UserWorkflowId=b.WorkId                  
   --inner join Property c on b.ColumnName=c.Name and c.WorkflowId=@workflowId                  
   inner join PersonalProfile d on  'P:'+trim(str( d.Id)  )=a.Nguoigiao    
   where @UserId = (select top 1 Item from Split(ISNULL(a.Nguoixuly,''),';') where Item =@UserId)                  
   and ISNULL(a.IsActive,'True') = 'True'                   
   and DATEDIFF(day,a.CreateDate,getdate()) <=15 and b.WorkId is null        
   insert into #work      
   select d.Id as UserId,d.FullName, N' đã thêm bạn vào người theo dõi' as ColumnName, a.CreateDate                  
   ,a.Tieude ,a.UserWorkflowId   , '2' as [Type],a.Duan     
   from Dynamic.Data_WORK a                  
   left join Dynamic.Data_LSCNTTCV b on a.UserWorkflowId=b.WorkId                  
   --inner join Property c on b.ColumnName=c.Name and c.WorkflowId=@workflowId                
   inner join PersonalProfile d on  'P:'+trim(str( d.Id)  )=a.Nguoigiao     
   where @UserId = (select top 1 Item from Split(ISNULL(a.Nguoitheodoi,''),';') where Item =@UserId)          
   and ISNULL(a.IsActive,'True') = 'True'                   
   and DATEDIFF(day,a.CreateDate,getdate()) <=15 and b.WorkId is null             
   insert into #work      
   select d.Id as UserId,d.FullName, N' đã thêm bạn vào người phối hợp' as ColumnName, a.CreateDate                  
   ,a.Tieude ,a.UserWorkflowId   , '2' as [Type] ,a.Duan     
   from Dynamic.Data_WORK a                  
   left join Dynamic.Data_LSCNTTCV b on a.UserWorkflowId=b.WorkId                  
   --inner join Property c on b.ColumnName=c.Name and c.WorkflowId=@workflowId                  
   inner join PersonalProfile d on  'P:'+trim(str( d.Id)  )=a.Nguoigiao      
   where @UserId = (select top 1 Item from Split(ISNULL(a.Nguoiphoihop,''),';') where Item =@UserId)                  
   and ISNULL(a.IsActive,'True') = 'True'                   
   and DATEDIFF(day,a.CreateDate,getdate()) <=15 and b.WorkId is null           
   -- table finish          
   if(@projectId='')              
   begin     
   insert into #tbFinish  
   select  *,                  
   case  when DATEDIFF(MINUTE,b.Date,getdate())<=2 then N'Vừa xong'                  
   when DATEDIFF(MINUTE,b.Date,getdate())<60 then trim( str( DATEDIFF(MINUTE,b.Date,getdate()))) + N' Phút trước.'                   
   when DATEDIFF(HOUR,b.Date,getdate())>=1 and  DATEDIFF(HOUR,b.Date,getdate())<=24 then trim(str( DATEDIFF(HOUR,b.Date,getdate()))) + N' giờ trước.'                    
   when DATEDIFF(DAY,b.Date,getdate())>=1 then trim( str( DATEDIFF(DAY,b.Date,getdate()))) + N' ngày trước.'                    
   else '' end  as Time  
   , case  when DATEDIFF(MINUTE,b.Date,getdate())<=2 then N'1.'
   when DATEDIFF(MINUTE,b.Date,getdate())<60 then '2.'+ trim( str( DATEDIFF(MINUTE,b.Date,getdate())))
   when DATEDIFF(HOUR,b.Date,getdate())>=1 and  DATEDIFF(HOUR,b.Date,getdate())<=24 
   then N'3.'+ trim(str( DATEDIFF(HOUR,b.Date,getdate()))) 
   when DATEDIFF(DAY,b.Date,getdate())>=1 then  N'4.'+ trim( str( DATEDIFF(DAY,b.Date,getdate()))) 
   else '' end as TimeOrder  
   from #work b                   
   order by DATEDIFF(MINUTE,b.Date,getdate()),b.WorkId              
   end      
   else    
   begin     
   insert into #tbFinish  
   select  *,                  
   case  when DATEDIFF(MINUTE,b.Date,getdate())<=2 then N'Vừa xong'                  
   when DATEDIFF(MINUTE,b.Date,getdate())<60 then trim( str( DATEDIFF(MINUTE,b.Date,getdate()))) + N' Phút trước.'                   
   when DATEDIFF(HOUR,b.Date,getdate())>=1 and  DATEDIFF(HOUR,b.Date,getdate())<=24 then trim(str( DATEDIFF(HOUR,b.Date,getdate()))) + N' giờ trước.'                    
   when DATEDIFF(DAY,b.Date,getdate())>=1 then trim( str( DATEDIFF(DAY,b.Date,getdate()))) + N' ngày trước.'                    
   else '' end  as Time   
   , case  when DATEDIFF(MINUTE,b.Date,getdate())<=2 then N'1.'
   when DATEDIFF(MINUTE,b.Date,getdate())<60 then '2.'+ trim( str( DATEDIFF(MINUTE,b.Date,getdate())))
   when DATEDIFF(HOUR,b.Date,getdate())>=1 and  DATEDIFF(HOUR,b.Date,getdate())<=24 
   then N'3.'+ trim(str( DATEDIFF(HOUR,b.Date,getdate()))) 
   when DATEDIFF(DAY,b.Date,getdate())>=1 then  N'4.'+ trim( str( DATEDIFF(DAY,b.Date,getdate()))) 
   else '' end as TimeOrder  
   from #work b      where    Duan=@projectId          
   order by DATEDIFF(MINUTE,b.Date,getdate()),b.WorkId     
   end    
   select UserId,FullName,ColumnName,WorkName,WorkId,[Type],Duan,Time,TimeOrder   
   from #tbFinish  
   group by UserId,FullName,ColumnName,WorkName,WorkId,[Type],Duan,Time ,TimeOrder    
   order by TimeOrder  
   drop table #tbFinish  
   drop table #work     
   drop table #workHis
go

