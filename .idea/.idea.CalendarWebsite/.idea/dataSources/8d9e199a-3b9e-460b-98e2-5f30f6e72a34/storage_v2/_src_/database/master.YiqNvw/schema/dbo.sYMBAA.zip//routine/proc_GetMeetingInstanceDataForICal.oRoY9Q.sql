CREATE PROCEDURE [dbo].[proc_GetMeetingInstanceDataForICal]
(
    @SiteId             uniqueidentifier,
    @WebId              uniqueidentifier,
    @InstanceID         int,
    @OrganizerID       int OUTPUT,
    @UID               nvarchar(255) OUTPUT,
    @DTStartUTC        datetime OUTPUT,
    @DTEndUTC          datetime OUTPUT,
    @DTStampUTC        datetime OUTPUT,
    @Sequence          int OUTPUT,
    @RequestGuid        uniqueidentifier = NULL OUTPUT  
)
AS
    SET NOCOUNT ON
    DECLARE @MeetingsListID uniqueidentifier
    EXEC proc_GetUniqueList @SiteId, @WebId, 200, @MeetingsListID OUTPUT
    IF @MeetingsListID IS NULL
        RETURN 13
    SELECT TOP 1
        @OrganizerID   = UD.int6,
        @UID           = UD.nvarchar1,
        @DTStartUTC    = UD.datetime1,
        @DTEndUTC      = UD.datetime2,
        @DTStampUTC    = UD.datetime4,
        @Sequence      = UD.int5
    FROM
        TVF_UserData_List_Mtg(@SiteId, @MeetingsListID) AS UD
    WHERE
        UD.tp_InstanceID = @InstanceID AND
        UD.tp_RowOrdinal = 0
    IF @@ROWCOUNT = 0
        RETURN 2
    IF @OrganizerID IS NULL OR @UID IS NULL
    BEGIN
        SELECT TOP 1
            @OrganizerID   = UD.int6,
            @UID           = UD.nvarchar1
        FROM
            TVF_UserData_List_Mtg(@SiteId, @MeetingsListID) AS UD
        WHERE
            UD.int1 = 1 AND
            UD.tp_RowOrdinal = 0
        IF @OrganizerID IS NULL OR @UID IS NULL
            RETURN 13
    END
    RETURN 0

go

