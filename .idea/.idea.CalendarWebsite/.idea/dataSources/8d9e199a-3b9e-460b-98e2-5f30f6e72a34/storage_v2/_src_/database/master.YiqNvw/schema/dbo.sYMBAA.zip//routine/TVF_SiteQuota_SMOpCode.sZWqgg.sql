CREATE FUNCTION [dbo].[TVF_SiteQuota_SMOpCode]
(
    @SiteId uniqueidentifier,
    @SessionId smallint,
    @SMOpCode tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SiteQuota] WITH (INDEX=SiteQuota_SiteId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SessionId = @SessionId AND
        SMOpCode = @SMOpCode

go

