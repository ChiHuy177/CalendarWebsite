CREATE FUNCTION [dbo].[TVF_Lists_NoLock_CI]
(
    @tp_SiteId uniqueidentifier,
    @tp_WebId uniqueidentifier,
    @tp_ID uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllLists] WITH (NOLOCK, INDEX=AllLists_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_WebId = @tp_WebId AND
        tp_ID = @tp_ID AND
        tp_DeleteTransactionId = 0x

go

