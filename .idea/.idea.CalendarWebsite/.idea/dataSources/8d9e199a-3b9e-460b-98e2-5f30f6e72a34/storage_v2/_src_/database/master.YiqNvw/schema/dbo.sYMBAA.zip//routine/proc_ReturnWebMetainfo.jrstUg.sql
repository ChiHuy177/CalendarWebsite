CREATE PROCEDURE [dbo].[proc_ReturnWebMetainfo](
    @SiteId uniqueidentifier, 
    @WebId uniqueidentifier)
AS
    SET NOCOUNT ON
    SELECT TOP 1
        Webs.MetaInfo
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS Webs
    IF @@ROWCOUNT <> 1 
    BEGIN
        RETURN 3
    END
    RETURN 0

go

