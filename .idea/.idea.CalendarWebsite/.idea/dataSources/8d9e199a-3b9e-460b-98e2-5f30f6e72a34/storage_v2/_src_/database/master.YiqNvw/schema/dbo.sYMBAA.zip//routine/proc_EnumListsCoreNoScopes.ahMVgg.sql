CREATE PROCEDURE [dbo].[proc_EnumListsCoreNoScopes](
       @SiteId uniqueidentifier,                                                
       @WebId uniqueidentifier,
       @WebFullUrl nvarchar(256),
       @Collation nvarchar(48),
       @BaseType int,
       @BaseType2 int,
       @BaseType3 int,
       @BaseType4 int,
       @ServerTemplate int,
       @FMobileDefaultViewUrl bit,
       @FRootFolder bit,
       @ListFlags int,
       @FAclInfo int,
       @Scopes varbinary(max) = NULL,
       @FGP bit = NULL,
       @AllowMUI bit = 0)
AS
    SET NOCOUNT ON
        IF (@Collation = N'Latin1_General_CI_AS')
            BEGIN
            IF (@AllowMUI = 0)
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    NULL AS TitleResource,
    NULL AS DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  Latin1_General_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
            ELSE 
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    ALPlus.TitleResource,
    ALPlus.DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
OUTER APPLY
    TVF_AllListsPlus_ListId(Lists.tp_SiteId, Lists.tp_Id) AS ALPlus
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  Latin1_General_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
        END
        ELSE IF (@Collation = N'Japanese_CI_AS')
            BEGIN
            IF (@AllowMUI = 0)
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    NULL AS TitleResource,
    NULL AS DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  Japanese_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
            ELSE 
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    ALPlus.TitleResource,
    ALPlus.DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
OUTER APPLY
    TVF_AllListsPlus_ListId(Lists.tp_SiteId, Lists.tp_Id) AS ALPlus
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  Japanese_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
        END
        ELSE IF (@Collation = N'Modern_Spanish_CI_AS')
            BEGIN
            IF (@AllowMUI = 0)
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    NULL AS TitleResource,
    NULL AS DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  Modern_Spanish_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
            ELSE 
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    ALPlus.TitleResource,
    ALPlus.DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
OUTER APPLY
    TVF_AllListsPlus_ListId(Lists.tp_SiteId, Lists.tp_Id) AS ALPlus
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  Modern_Spanish_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
        END
        ELSE IF (@Collation = N'French_CI_AS')
            BEGIN
            IF (@AllowMUI = 0)
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    NULL AS TitleResource,
    NULL AS DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  French_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
            ELSE 
            BEGIN 
SELECT
    CASE WHEN AllDocs1.DirName = N'' THEN
        N'/' + AllDocs1.LeafName
    ELSE
        N'/' + AllDocs1.DirName + N'/' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'' THEN
        N'/' + AllDocs2.LeafName
    ELSE
        N'/' + AllDocs2.DirName + N'/' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N'{' + CAST(Lists.tp_ID AS nvarchar(36)) + N'}' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    ALPlus.TitleResource,
    ALPlus.DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
OUTER APPLY
    TVF_AllListsPlus_ListId(Lists.tp_SiteId, Lists.tp_Id) AS ALPlus
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  French_CI_AS OPTION (FORCE ORDER, LOOP JOIN)
            END
        END 
        ELSE
        BEGIN
        DECLARE @strQuery nvarchar(max)
        IF (@AllowMUI = 0)
        BEGIN
        SET @strQuery = N'
DECLARE @_scopeTbl TABLE(_id uniqueidentifier NOT NULL PRIMARY KEY)
DECLARE @_count INT
SET @_count = 0
WHILE @_count < DATALENGTH(@Scopes)/16
BEGIN 
    INSERT INTO @_scopeTbl VALUES (CAST(SUBSTRING(@Scopes ,@_count*16 + 1, 16) AS uniqueidentifier))
    SET @_count = @_count + 1
END
        ' + CAST(N'
SELECT
    CASE WHEN AllDocs1.DirName = N'''' THEN
        N''/'' + AllDocs1.LeafName
    ELSE
        N''/'' + AllDocs1.DirName + N''/'' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'''' THEN
        N''/'' + AllDocs2.LeafName
    ELSE
        N''/'' + AllDocs2.DirName + N''/'' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N''{'' + CAST(Lists.tp_ID AS nvarchar(36)) + N''}'' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    NULL AS TitleResource,
    NULL AS DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  ' as nvarchar(max)) + @Collation + N' OPTION (FORCE ORDER, LOOP JOIN)'
        EXEC sp_executesql @strQuery, N'
            @WebId uniqueidentifier,
            @BaseType int,
            @BaseType2 int,
            @BaseType3 int,
            @BaseType4 int,
            @ServerTemplate int,
            @FmobileDefaultViewUrl bit,
            @FRootFolder bit,
            @ListFlags int,
            @FAclInfo bit,
            @WebFullUrl nvarchar(256),
            @SiteId uniqueidentifier,
            @FGP bit,
            @Scopes varbinary(max)
            ', @WebId,
            @BaseType,
            @BaseType2,
            @BaseType3,
            @BaseType4,
            @ServerTemplate,
            @FmobileDefaultViewUrl,
            @FRootFolder,
            @ListFlags,
            @FAclInfo,
            @WebFullUrl,
            @SiteId,
            @FGP,
            @Scopes
        END
        ELSE 
        BEGIN
        SET @strQuery = N'
DECLARE @_scopeTbl TABLE(_id uniqueidentifier NOT NULL PRIMARY KEY)
DECLARE @_count INT
SET @_count = 0
WHILE @_count < DATALENGTH(@Scopes)/16
BEGIN 
    INSERT INTO @_scopeTbl VALUES (CAST(SUBSTRING(@Scopes ,@_count*16 + 1, 16) AS uniqueidentifier))
    SET @_count = @_count + 1
END
        ' + CAST(N'
SELECT
    CASE WHEN AllDocs1.DirName = N'''' THEN
        N''/'' + AllDocs1.LeafName
    ELSE
        N''/'' + AllDocs1.DirName + N''/'' + AllDocs1.LeafName END
    AS
        tp_DocTemplateUrl,
    CASE WHEN AllDocs2.DirName = N'''' THEN
        N''/'' + AllDocs2.LeafName
    ELSE
        N''/'' + AllDocs2.DirName + N''/'' + AllDocs2.LeafName END
     AS
        tp_DefaultViewUrl,
    CASE WHEN @FMobileDefaultViewUrl = 1 THEN
        dbo.fn_GetMobileDefaultViewUrl(@SiteId, Lists.tp_ID)
    ELSE
        NULL END
    AS
        tp_MobileDefaultViewUrl,
    Lists.tp_ID AS tp_ID,
    Lists.tp_Title AS tp_Title,
    Lists.tp_Description AS tp_Description,
    Lists.tp_ImageUrl AS tp_ImageUrl,
    N''{'' + CAST(Lists.tp_ID AS nvarchar(36)) + N''}'' AS tp_Name,
    Lists.tp_BaseType AS tp_BaseType,
    Lists.tp_FeatureId AS tp_FeatureId,
    Lists.tp_ServerTemplate AS tp_ServerTemplate,
    Lists.tp_Created AS tp_Created,
    ALAux.Modified AS tp_Modified,
    ALAux.LastDeleted AS tp_LastDeleted,
    Lists.tp_Version AS tp_Version,
    Lists.tp_Direction AS tp_Direction,
    Lists.tp_ThumbnailSize AS tp_ThumbnailSize,
    Lists.tp_WebImageWidth AS tp_WebImageWidth,
    Lists.tp_WebImageHeight AS tp_WebImageHeight,
    Lists.tp_Flags AS tp_Flags,
    ALAux.ItemCount AS tp_ItemCount,     
    Perms.AnonymousPermMask AS tp_AnonymousPermMask,
    CASE WHEN @FRootFolder = 1 THEN
        dbo.fn_GetRootFolder(Lists.tp_SiteId, Lists.tp_RootFolder)
    ELSE
        NULL END
    AS
        tp_RootFolder,
    Lists.tp_ReadSecurity,
    Lists.tp_WriteSecurity,
    Lists.tp_Author,
    Lists.tp_EventSinkAssembly,
    Lists.tp_EventSinkClass,
    Lists.tp_EventSinkData,
    Lists.tp_EmailAlias,
    @WebFullUrl AS tp_WebFullUrl,
    @WebId AS tp_WebId,
    Lists.tp_SendToLocation,
    Lists.tp_ScopeId,
    ISNULL(Lists.tp_MaxMajorVersionCount, 0),
    ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),	  
    Lists.tp_DefaultWorkflowId,
    Lists.tp_HasInternalFGP,
    Lists.tp_NoThrottleListOperations,
    NULL AS HasRelatedLists,
    ALAux.Followable,
    NULL AS tp_ValidationFormula,
    NULL AS tp_ValidationMessage,
    ALPlus.TitleResource,
    ALPlus.DescriptionResource,
    CASE WHEN @FAclInfo = 1 THEN
        Perms.Acl
    ELSE
        NULL END
    AS
        tp_ACL
FROM 
    TVF_Lists_NoLock_WebId(@SiteId, @WebId) AS Lists
CROSS APPLY
    TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
CROSS APPLY
    TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
OUTER APPLY
    TVF_WebParts_ListUserLvlType(
        @SiteId,
        Lists.tp_ID, 
        NULL, 
        1,
        0) AS WebParts
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(WebParts.tp_SiteId, WebParts.tp_PageUrlID, WebParts.tp_Level) AS AllDocs2
OUTER APPLY
    TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs1
OUTER APPLY
    TVF_AllListsPlus_ListId(Lists.tp_SiteId, Lists.tp_Id) AS ALPlus
WHERE
    (@BaseType = -1
     OR
     Lists.tp_BaseType = @BaseType
     OR
     Lists.tp_BaseType = @BaseType2
     OR
     Lists.tp_BaseType = @BaseType3
     OR
     Lists.tp_BaseType = @BaseType4) AND
    (@ServerTemplate = -1
     OR
     Lists.tp_ServerTemplate = @ServerTemplate) AND
    (@ListFlags = -1
     OR
     Lists.tp_Flags & @ListFlags = @ListFlags) AND  
    (@FGP IS NULL 
    OR Lists.tp_HasFGP = 1 )
ORDER BY 
    Lists.tp_Title 
COLLATE  ' as nvarchar(max)) + @Collation + N' OPTION (FORCE ORDER, LOOP JOIN)'
        EXEC sp_executesql @strQuery, N'
            @WebId uniqueidentifier,
            @BaseType int,
            @BaseType2 int,
            @BaseType3 int,
            @BaseType4 int,
            @ServerTemplate int,
            @FmobileDefaultViewUrl bit,
            @FRootFolder bit,
            @ListFlags int,
            @FAclInfo bit,
            @WebFullUrl nvarchar(256),
            @SiteId uniqueidentifier,
            @FGP bit,
            @Scopes varbinary(max)
            ', @WebId,
            @BaseType,
            @BaseType2,
            @BaseType3,
            @BaseType4,
            @ServerTemplate,
            @FmobileDefaultViewUrl,
            @FRootFolder,
            @ListFlags,
            @FAclInfo,
            @WebFullUrl,
            @SiteId,
            @FGP,
            @Scopes
        END
    END

go

