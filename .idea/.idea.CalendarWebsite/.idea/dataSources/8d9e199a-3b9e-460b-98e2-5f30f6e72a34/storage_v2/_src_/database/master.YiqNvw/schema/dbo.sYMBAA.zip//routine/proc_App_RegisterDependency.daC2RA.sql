CREATE Procedure [dbo].[proc_App_RegisterDependency] (
    @TaskId uniqueidentifier,
    @DependsOnTaskId uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
SET NOCOUNT ON
--Shouldn't need an applock for this. These won't do anything until the job is finalized.
--These should always be in the same Job. Enforce in the future?
INSERT INTO
    AppTaskDependencies(
        TaskId,
        DependsOnTaskId,
        SiteId
    )
VALUES 
    (
        @TaskId,
        @DependsOnTaskId,
        @SiteId
    )

go

