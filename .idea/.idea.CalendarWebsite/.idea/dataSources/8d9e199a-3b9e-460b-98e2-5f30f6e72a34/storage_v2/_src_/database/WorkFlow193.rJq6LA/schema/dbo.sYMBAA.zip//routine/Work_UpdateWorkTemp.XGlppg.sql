-- Work_UpdateWorkTemp -51726863 
   CREATE   PROC  [dbo].[Work_UpdateWorkTemp]  
   @IsUseForWork as bigint  ,
   @workId as bigint
   as  
   update [Dynamic].[Data_TMDSQTCV] set IsUseForWork= TRIM(STR( @workId  )) where IsUseForWork= TRIM(STR( @IsUseForWork  ))
   update [Dynamic].[Data_LSQTCV] set IsUseForWork= TRIM(STR( @workId  )) where  IsUseForWork= TRIM(STR( @IsUseForWork  ))  
   update [Dynamic].[Data_FOLLOWCHART] set IsUseForWork= TRIM(STR( @workId  )) where  IsUseForWork= TRIM(STR( @IsUseForWork  ))
go

