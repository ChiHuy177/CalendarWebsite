-- [Work_WorkFlowChartCheckIsActive] 4058, 342211
   CREATE   PROC  [dbo].[Work_WorkFlowChartCheckIsActive]  
   @workProcessId as nvarchar(150)='86776'  
   ,@parentId as nvarchar(500)='86843'         
   as           
   select   
   a.UserWorkflowId, ISNULL(a.IsActive,'True') as IsActive,  
   case when c.TrangThaiCongViec=N'Hủy' then N'Từ chối' else c.TrangThaiCongViec end as TrangThaiCongViec  
   ,a.Nodeid  
   ,a.Tieude
   from Dynamic.Data_WORK a   
   inner join Dynamic.Data_WORK b on a.CongViecCha=b.UserWorkflowId  
   inner join Dynamic.Data_RESOURCETTFC c on a.TrangThaiCongViec=c.UserWorkflowId        
   where a.CongViecCha =@parentId and b.QuyTrinhDinhKem=@workProcessId  
   and ISNULL(a.IsActive,'True') ='True'  
   --select a.Title              
   --into #b              
   --from Dynamic.Data_LSQTCV a               
   --inner join         
   --(              
   -- select a.CategoryWorkProcessId, b.value from #a a              
   -- CROSS APPLY STRING_SPLIT(ISNULL(a.NextStep,''),',') AS b        
   --) as b        
   --on a.Step=b.value and a.CategoryWorkProcessId=b.CategoryWorkProcessId              
   --select case when a.TrangThaiCongViec=b.Title then 1 else 0 end as checkDone              
   --from #a a              
   --left join #b b on a.TrangThaiCongViec=b.Title              
go

