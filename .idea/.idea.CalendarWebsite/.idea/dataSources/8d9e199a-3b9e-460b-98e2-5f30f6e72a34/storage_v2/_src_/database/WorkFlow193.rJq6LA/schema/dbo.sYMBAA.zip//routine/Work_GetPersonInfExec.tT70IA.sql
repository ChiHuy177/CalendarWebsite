-- Work_GetPersonInf   
   -- [Work_GetPersonInfExec] 'dang chay hoya '   
   CREATE   PROC [dbo].[Work_GetPersonInfExec]   
   @id AS NVARCHAR(max)   
   as   
   declare @tab table(id bigint, UserId nvarchar(50))   
   ;   
   insert into @tab   
   SELECT a.UserWorkflowId, b.Item  as UserId
   FROM [Dynamic].Data_WORK AS a   
   cross apply Split(a.Nguoigiao,';') b 
   where a.Id in (select * from STRING_SPLIT(@id,','))   
   SELECT b.id as WorkId, b.UserId as Id   
   ,AccountName   
   ,Name   
   ,FullName   
   ,a.Email   
   FROM [dbo].[PersonalProfile] a   
   INNER JOIN @tab b ON 'P:'+ trim(str(a.id)) =b.UserId   
go

