CREATE FUNCTION [dbo].[TVF_AllUserData_ListDelItem]
(
    @tp_SiteId uniqueidentifier,
    @tp_ListId uniqueidentifier,
    @tp_DeleteTransactionId varbinary(16),
    @tp_Id int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserData] WITH (INDEX=AllUserData_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_ListId = @tp_ListId AND
        tp_DeleteTransactionId = @tp_DeleteTransactionId AND
        (tp_IsCurrentVersion = CONVERT(bit, 0) OR tp_IsCurrentVersion = CONVERT(bit, 1)) AND
        tp_ID = @tp_Id

go

