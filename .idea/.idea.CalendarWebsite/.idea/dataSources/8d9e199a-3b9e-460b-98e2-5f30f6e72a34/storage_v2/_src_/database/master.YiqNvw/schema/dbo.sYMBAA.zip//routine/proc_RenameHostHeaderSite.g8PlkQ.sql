CREATE PROCEDURE [dbo].[proc_RenameHostHeaderSite](
    @SiteId uniqueidentifier,
    @HostHeader nvarchar(128))
AS
    SET NOCOUNT ON
    BEGIN TRAN
    UPDATE
        S
    SET
        S.HostHeader = @HostHeader
    FROM
        TVF_Sites_Id(@SiteId) AS S
    EXEC proc_DirtyDocWithForwardLinksInSite @SiteId
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
        32768,  8, NULL
    COMMIT TRAN

go

