CREATE PROCEDURE [dbo].[proc_ResolveWikiLinkFile](
    @SiteId uniqueidentifier,
    @LinkId int,
    @FileUrl nvarchar(260),
    @FolderUrl nvarchar(260),
    @FileUrl2 nvarchar(260),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DirName nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    EXEC proc_SplitUrl
        @FileUrl,
        @DirName OUTPUT,
        @LeafName OUTPUT
    IF EXISTS 
        (
            SELECT TOP 1
                1 
            FROM 
                TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS Docs
            WHERE
                Docs.Type = 0
        )
    BEGIN
        SELECT @LinkId AS LinkId, CASE WHEN (DATALENGTH(@DirName) = 0) THEN @LeafName WHEN (DATALENGTH(@LeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @LeafName END AS ResolvedUrl
        RETURN 0
    END
    EXEC proc_SplitUrl
        @FolderUrl,
        @DirName OUTPUT,
        @LeafName OUTPUT
    IF EXISTS 
        (
            SELECT TOP 1
                1 
            FROM 
                TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS Docs
            WHERE
                Docs.Type = 1
        )
    BEGIN
        SELECT @LinkId AS LinkId, CASE WHEN (DATALENGTH(@DirName) = 0) THEN @LeafName WHEN (DATALENGTH(@LeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @LeafName END AS ResolvedUrl
        RETURN 0
    END
    IF (@FileUrl2 IS NOT NULL)
    BEGIN
        EXEC proc_SplitUrl
            @FileUrl2,
            @DirName OUTPUT,
            @LeafName OUTPUT
        IF EXISTS 
            (
                SELECT TOP 1
                    1 
                FROM 
                    TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS Docs
                WHERE
                    Docs.Type = 0
            )
        BEGIN
            SELECT @LinkId AS LinkId, CASE WHEN (DATALENGTH(@DirName) = 0) THEN @LeafName WHEN (DATALENGTH(@LeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @LeafName END AS ResolvedUrl
            RETURN 0
        END
    END
    SELECT @LinkId AS LinkId, NULL AS ResolvedUrl
    RETURN 0

go

