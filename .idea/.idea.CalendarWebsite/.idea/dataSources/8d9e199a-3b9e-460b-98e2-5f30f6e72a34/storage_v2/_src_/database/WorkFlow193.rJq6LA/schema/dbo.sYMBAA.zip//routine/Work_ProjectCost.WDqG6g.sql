-- Work_ProjectCost 224903        
   CREATE   PROC [dbo].[Work_ProjectCost]        
   @projectId as nvarchar(50)        
   as        
   CREATE table #tb (Code nvarchar(250), Name nvarchar(250), Value float, ShortContent nvarchar(1000)      
   , CreatedTime nvarchar(150), GroupId nvarchar(100), CouponId bigint, Status nvarchar(150), RowIndex int)        
   select          
   b.Id        
   ,b.UserWorkflowId        
   ,b.ParentId        
   ,a.DisplayText        
   ,b.CouponId as WorkFlowId        
   ,b.CoulumnCoupon        
   ,a.ProjectId        
   ,c.WorkId        
   ,c.CouponId        
   , 'Dynamic.Data_'+[dbo].[Work_ReplaceInvalidChars](trim(d.Code)) as TableName      
   ,ISNULL(a.RowIndex,0) as RowIndex    
   into #a        
   from Dynamic.Data_WorkProjectCost a        
   inner join Dynamic.Data_WorkProjectCost b on a.ProjectId=b.ProjectId and a.UserWorkflowId=b.ParentId         
   inner join (        
   select a.UserWorkflowId as WorkId, a.Duan, b.CouponId, b.WorkFlowId     
   from Dynamic.Data_WORK a         
   inner join Dynamic.Data_ProjectLinkCoupon b on a.UserWorkflowId=b.WorkId and b.Type=4         
   where a.Duan=@projectId        
   union    
   select a.UserWorkflowId as WorkId, a.UserWorkflowId, b.CouponId, b.WorkFlowId     
   from Dynamic.Data_RESOURCEDA a         
   inner join Dynamic.Data_ProjectLinkCoupon b on a.UserWorkflowId=b.ProjectId and b.Type=2         
   where a.UserWorkflowId=@projectId      
   ) c on c.Duan=a.ProjectId and cast(b.CouponId as bigint)= cast(c.WorkFlowId as bigint)        
   inner join Workflow d on d.Id=c.WorkFlowId        
   where a.ProjectId=@projectId        
   Declare @Id int,@workId as bigint , @sql as nvarchar(max), @table as nvarchar(500)        
   ,@column as nvarchar(250), @userWorkflowId as nvarchar(50), @display as nvarchar(500),@groupId as nvarchar(100), @rowIndex as nvarchar(50)       
   While (Select Count(*) From #a) > 0        
   Begin        
   Select Top 1 @Id = Id, @workId =WorkId From #a        
   set @column=(Select CoulumnCoupon from #a where id =@id  and WorkId=@workId)        
   set @table=(Select TableName from #a where id =@id  and WorkId=@workId)        
   set @userWorkflowId=(Select CouponId from #a where id =@id  and WorkId=@workId)         
   set @display=(Select DisplayText from #a where id =@id  and WorkId=@workId)        
   set @groupId=(Select ParentId from #a where id =@id  and WorkId=@workId)        
   set @rowIndex=(Select RowIndex from #a where id =@id  and WorkId=@workId)        
   set @column=( select  STUFF((  
   SELECT ' sum(isnull(' +  a.Item+',0)) +'  
   FROM (select * from Split(@column,';')) a  
   FOR XML PATH('')  
   ),1, 1, ''))  
   set @sql=N'insert into #tb (Name,Value,Code,ShortContent,CreatedTime,GroupId,CouponId,Status,RowIndex)       
   select N'''+@display+''', '+left(@column,len(@column)-1)+'        
   ,b.WorkflowCode,b.ShortContent,CONVERT(char, b.CreatedTime,103) as CreatedTime,'''+@groupId+'''      
   ,b.Id  ,case when b.UserWorkflowStatus =0 then N'''+N'Chờ phê duyệt'+'''      
   when b.UserWorkflowStatus =1 then N'''+N'Phê duyệt'+''' else N'''+N'Từ chối'+''' end as Status,'+@rowIndex+'    
   from '+@table+' a         
   inner join UserWorkflow b on a.UserWorkflowId=b.Id where UserWorkflowId='''+@userWorkflowId+'''  
   group by b.WorkflowCode,b.ShortContent,b.CreatedTime,b.Id,b.UserWorkflowStatus'        
   exec(@sql)        
   print(@sql)        
   --Do some PROCessing here         
   Delete #a Where Id = @Id and WorkId=@workId        
   End        
   select Code,Name,SUM(Value) as Value, ShortContent,CreatedTime,GroupId,CouponId,Status ,RowIndex    
   ,ROW_NUMBER() OVER(ORDER BY name ASC) AS [Key]      
   from #tb group by Code,Name, ShortContent,CreatedTime,GroupId,CouponId ,Status   ,RowIndex    
   drop table #a         
   drop table #tb        
   -- Work_ProjectCost 333572 
go

