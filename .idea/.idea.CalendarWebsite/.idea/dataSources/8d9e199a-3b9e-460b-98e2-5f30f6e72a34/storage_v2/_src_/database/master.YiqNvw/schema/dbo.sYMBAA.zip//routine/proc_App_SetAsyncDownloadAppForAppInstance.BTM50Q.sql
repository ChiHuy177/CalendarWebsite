CREATE Procedure [dbo].[proc_App_SetAsyncDownloadAppForAppInstance] (
    @InstallationId uniqueidentifier,
    @AsyncDownloadAppSourceInfoId uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
SET NOCOUNT ON
UPDATE TVF_AppInstallations_Id(@SiteId, @InstallationId)
    SET
        AsyncDownloadAppSourceInfoId = @AsyncDownloadAppSourceInfoId

go

