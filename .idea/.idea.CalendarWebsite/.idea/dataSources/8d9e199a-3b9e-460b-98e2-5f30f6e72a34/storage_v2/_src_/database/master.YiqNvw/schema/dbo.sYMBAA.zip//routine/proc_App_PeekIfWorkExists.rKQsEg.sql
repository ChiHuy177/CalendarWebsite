CREATE Procedure [dbo].[proc_App_PeekIfWorkExists]
AS
SET NOCOUNT ON
DECLARE @task uniqueidentifier
DECLARE @siteId uniqueidentifier
EXEC sub_SelectTaskForPull @task OUTPUT, @siteId OUTPUT
IF(@task IS NOT NULL) --assert that @siteId follows suit
BEGIN
    RETURN 1
END
ELSE
BEGIN
    RETURN 0
END

go

