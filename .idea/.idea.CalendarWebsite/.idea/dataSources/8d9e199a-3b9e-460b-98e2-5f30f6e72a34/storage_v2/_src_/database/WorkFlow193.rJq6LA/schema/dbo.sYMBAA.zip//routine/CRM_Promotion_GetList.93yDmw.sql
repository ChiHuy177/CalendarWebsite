create   PROC [dbo].[CRM_Promotion_GetList]    
 @userName as nvarchar(50)='',    
 @str as nvarchar(250)='',    
 @menuId as bigint         
 as          
 select a.ID,a.UserWorkflowId, a.Name,           
 FromDate, ToDate, a.Description,ISNULL(a.Active,1) as Active          
 ,b.ContractAmount, b.Discount, a.IsDelete, a.ModifiedDate, a.ModifiedBy         
 from Dynamic.Data_CRMPromotion a          
 left join Dynamic.Data_CRMPromotionContractDetail  b on a.ID=b.PromotionID    
   
 where ISNULL(a.IsDelete,0)=0 and (a.Name like N'%'+@str+'%' or len(''+ISNULL(@str,'')+'')=0)     
 group by  a.ID, a.Name,           
 FromDate, ToDate, a.Description,a.Active    
 ,b.ContractAmount, b.Discount, a.IsDelete    
 , a.ModifiedDate, a.ModifiedBy ,a.UserWorkflowId       
 order by a.ID desc
go

