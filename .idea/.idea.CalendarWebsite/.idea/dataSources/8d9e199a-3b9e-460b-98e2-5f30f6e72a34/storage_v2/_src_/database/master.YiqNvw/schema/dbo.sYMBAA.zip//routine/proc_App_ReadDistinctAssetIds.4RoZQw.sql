CREATE Procedure [dbo].[proc_App_ReadDistinctAssetIds] (
    @AssetId nvarchar(100),
    @RowLimit int)
AS
SET NOCOUNT ON
SELECT TOP (@RowLimit) AssetId, ContentMarket
    FROM (SELECT AssetId, ROW_NUMBER() OVER (PARTITION BY AssetId ORDER BY AssetId) AS RowNumber, ContentMarket
        FROM TVF_AppSourceInfo_AssetIdGTAllSites_AppSource(@AssetId, 1)) AS PartitionedSourceInfo
    WHERE RowNumber = 1
    ORDER BY AssetId

go

