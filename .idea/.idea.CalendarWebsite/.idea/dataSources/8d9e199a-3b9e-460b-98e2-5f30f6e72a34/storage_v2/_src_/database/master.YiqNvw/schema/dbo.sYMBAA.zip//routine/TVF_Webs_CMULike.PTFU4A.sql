CREATE FUNCTION [dbo].[TVF_Webs_CMULike]
(
    @SiteId uniqueidentifier,
    @CustomMasterUrlLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebs] WITH (INDEX=Webs_CMU, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        CustomMasterUrl LIKE @CustomMasterUrlLike AND
        DeleteTransactionId = 0x

go

