-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.News_delete] @userWorkflowId NVARCHAR(max)
AS
BEGIN
	SET NOCOUNT ON;

	
	
	UPDATE UserWorkflow
	SET IsDeleted = 1
	WHERE Id = @userWorkFlowId
	or (Id in (SELECT dw.UserWorkflowId
	FROM [Dynamic].[Workflow_COMMENT] dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE u.IsDeleted = 0
	and u.UserWorkflowStatus=1
		AND
		(
		(
		NullIf( dbo.JSON_VALUE(dw.Data, '$.PostId'), 'NULL')= @userWorkflowId
		)
		OR
		(
		NullIf( dbo.JSON_VALUE(dw.Data, '$.CommentId'), 'NULL')= @userWorkflowId
		
		)
		))
		)
END
go

