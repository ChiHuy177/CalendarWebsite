CREATE FUNCTION [dbo].[TVF_AllSites_Id]
(
    @Id uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllSites] WITH (INDEX=Sites_Id, FORCESEEK)
    WHERE
        Id = @Id

go

