CREATE PROCEDURE [dbo].[proc_RestoreFixupThumbnailInternal](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @DeleteTransactionId uniqueidentifier,
    @DirName nvarchar(256),
    @ThumbnailDirName nvarchar(256),
    @SubImageLeafName nvarchar(128),
    @ThumbnailFolderScopeId uniqueidentifier
    )
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    SET @Ret = 1359
    DECLARE @OldParentId uniqueidentifier
    SELECT TOP 1
        @OldParentId = ParentId
    FROM
        TVF_AllDocs_DelIdUrl(
                @SiteId, 
                @DeleteTransactionId, 
                @ThumbnailDirName, 
                @SubImageLeafName) AS AD   
    IF @@ROWCOUNT = 0
    BEGIN
        SET @Ret = 0
        GOTO cleanup
    END    
    DECLARE @ThumbnailDirLeafName nvarchar(128)
    EXEC proc_SplitUrl
        @ThumbnailDirName,
        NULL,
        @ThumbnailDirLeafName OUTPUT
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
             TVF_AllDocs_DelIdUrl(
                @SiteId, 
                @DeleteTransactionId, 
                @DirName, 
                @ThumbnailDirLeafName) AS AD)
    BEGIN
        SET @Ret = 0
        GOTO cleanup
    END
    DECLARE @ThumbnailFolderDocId uniqueidentifier
    SELECT TOP 1
        @ThumbnailFolderDocId = Id
    FROM
        TVF_Docs_Url(@SiteId, @DirName, @ThumbnailDirLeafName) AS Docs
    IF @ThumbnailFolderDocId IS NULL
    BEGIN
        EXEC @Ret = proc_CreateDir
            @SiteId,
            @WebId,
            @DirName,
            @ThumbnailDirLeafName,
            1, 
            0,       
            0, 
            0,       
            NULL,    
            NULL,    
            NULL,    
            NULL,    
            0,       
            NULL,    
            @ThumbnailFolderDocId OUTPUT,
            @ThumbnailFolderScopeId,
            NULL
        IF @Ret <> 0 
            GOTO cleanup
    END
    IF @OldParentId <> @ThumbnailFolderDocId
    BEGIN
        UPDATE
            AD
        SET
            ParentId = @ThumbnailFolderDocId    
        FROM
            TVF_AllDocs_DelIdPId(
                @SiteId, 
                @DeleteTransactionId, 
                @OldParentId) AS AD
    END
    SET @Ret = 0
cleanup:
    RETURN @Ret

go

