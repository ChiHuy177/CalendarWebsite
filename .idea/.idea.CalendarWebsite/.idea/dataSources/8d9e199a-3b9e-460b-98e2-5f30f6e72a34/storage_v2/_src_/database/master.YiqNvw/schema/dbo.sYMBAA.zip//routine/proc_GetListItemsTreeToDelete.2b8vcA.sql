CREATE PROCEDURE [dbo].[proc_GetListItemsTreeToDelete]
(
    @ISiteId uniqueidentifier,
    @IWebId uniqueidentifier,
    @IListId uniqueidentifier,
    @IItemId int,
    @MaxLimit int
)
AS
    SET NOCOUNT ON;
    DECLARE @iRet int;
    SET @iRet = 0;
    EXEC @iRet = proc_GetListItemsTreeToDeleteCore
        @ISiteId,
        @IWebId,
        @IListId,
        @IItemId,
        @MaxLimit,
        0,
        NULL;
    RETURN @iRet;

go

