CREATE PROCEDURE [dbo].[proc_SecUpdateUser](
    @SiteId uniqueidentifier,
    @CurrentUserId int,
    @AppPrincipalId int,
    @UserIdToUpdate int,
    @Title nvarchar(255),
    @Email nvarchar(255),
    @Notes nvarchar(1023),
    @SiteAdmin bit, 
    @Flags int,     
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @SiteOwnerId        int
    DECLARE @SecondaryContactId int
    DECLARE @OtherAdminId       int
    DECLARE @RootWebId  uniqueidentifier
    DECLARE @UserInfoListId     uniqueidentifier
    SELECT TOP 1
        @SiteOwnerId = S.OwnerID,
        @SecondaryContactId = S.SecondaryContactID,
        @RootWebId = S.RootWebId,
        @UserInfoListId = S.UserInfoListId
    FROM
        TVF_Sites_Id(@SiteId) AS S
    IF @UserInfoListId IS NOT NULL
    BEGIN
        EXEC proc_LockListAuxForDocumentUpdate @SiteId, @UserInfoListId, 0
        SELECT
            @UserIdToUpdate = UD.tp_ID
        FROM
            TVF_UserData_XLock_ListItem(@SiteId, @UserInfoListId, @UserIdToUpdate) AS UD
    END
    IF @SiteAdmin = 0
    BEGIN        
        SELECT TOP 1
            @OtherAdminId = UI.tp_ID
        FROM
            TVF_UserInfo_SiteDelIsAdmin(@SiteId, 0, 1) AS UI
        WHERE    
            UI.tp_ID <> @UserIdToUpdate
        IF @OtherAdminId IS NULL
            RETURN 4335
        IF @UserIdToUpdate = @SiteOwnerId OR 
            @UserIdToUpdate = @SecondaryContactId
        BEGIN        
            DECLARE @IsCurrentUserSiteAdmin bit
            DECLARE @NomineeId int
            SELECT TOP 1
                @IsCurrentUserSiteAdmin = UI.tp_SiteAdmin
            FROM
                TVF_UserInfo_PK(@SiteId, @CurrentUserId) AS UI
            WHERE
                UI.tp_Deleted = 0
            IF @IsCurrentUserSiteAdmin = 1 AND @CurrentUserId <> @UserIdToUpdate
            BEGIN
                SET @NomineeId = @CurrentUserId
            END
            ELSE
            BEGIN
                SET @NomineeId = @OtherAdminId
            END
            IF @SiteOwnerId = @UserIdToUpdate
            BEGIN
                SET @SiteOwnerId = @NomineeId
            END
            IF @SecondaryContactId = @UserIdToUpdate
            BEGIN
                SET @SecondaryContactId = @NomineeId
            END
            IF @SecondaryContactId = @SiteOwnerId
            BEGIN
               SET @SecondaryContactId = NULL 
            END
            UPDATE
                S
            SET
                S.OwnerID = @SiteOwnerId,
                S.SecondaryContactID = @SecondaryContactId
            FROM
                TVF_Sites_Id(@SiteId) AS S
        END
    END
    DECLARE @WasUserToUpdateSiteAdmin bit
    DECLARE @IsDomainGroup bit
    SELECT TOP 1
        @WasUserToUpdateSiteAdmin = UI.tp_SiteAdmin,
        @IsDomainGroup = UI.tp_DomainGroup
    FROM
        TVF_UserInfo_PK(@SiteId, @UserIdToUpdate) AS UI
    UPDATE
        UI
    SET
        UI.tp_Title = ISNULL(@Title, N''),
        UI.tp_Email = ISNULL(@Email, N''),
        UI.tp_Notes = ISNULL(@Notes, N''),
        UI.tp_SiteAdmin = COALESCE(@SiteAdmin, tp_SiteAdmin),
        UI.tp_Flags = COALESCE(@Flags, tp_Flags)
    FROM
        TVF_UserInfo_PK(@SiteId, @UserIdToUpdate) AS UI
    DECLARE @data nvarchar(255)
    DECLARE @FlagsChangeUser int
    IF @SiteAdmin <> @WasUserToUpdateSiteAdmin 
    BEGIN
        DECLARE @auditEvent int
        IF @SiteAdmin = 1
        BEGIN
            SET @auditEvent = 32
        END
        ELSE
        BEGIN
            SET @auditEvent = 33
        END
        SET @data = '<siteadmin />' + STUFF(STUFF('</>', 3, 0, 'user'), 1, 0, STUFF(CONVERT(nvarchar(64), @UserIdToUpdate), 1, 0, STUFF('<>', 2, 0, 'user')))
        EXEC proc_AddSiteAuditEntryFromSql 
            @SiteId, 
            @CurrentUserId, 
            @AppPrincipalId,
            @auditEvent,
            @data,
            0x00000100    
        SET @FlagsChangeUser = 1
    END
    ELSE
    BEGIN
        SET @FlagsChangeUser = 0
    END
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, @UserIdToUpdate,
        NULL, 8192, 128, NULL, NULL, @FlagsChangeUser
    IF @SiteAdmin IS NOT NULL
    BEGIN
        EXEC proc_SecUpdateSiteLevelSecurityMetadata @SiteId, 0, @IsDomainGroup
    END
    UPDATE
        I
    SET
        I.UserEmail = @Email
    FROM
        TVF_ImmedSubscriptions_SiteIdUserId(@SiteId, @UserIdToUpdate) AS I
    UPDATE
        S
    SET
        S.UserEmail = @Email
    FROM
        TVF_SchedSubscriptions_SiteIdUserId(@SiteId, @UserIdToUpdate) AS S
    RETURN 0

go

