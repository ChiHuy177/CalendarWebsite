
-- =============================================
-- Author:		Duy Dam
-- Create date: 27/0/2021
-- Description:	Remove PersonalPrifole from Gropup
-- =============================================
CREATE   PROCEDURE [dbo].[GroupPersonalProfile_Remove] @GroupsId BIGINT
	,@PersonalProfilesId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DELETE [dbo].[GroupPersonalProfile]
	WHERE [GroupsId] = @GroupsId
		AND [PersonalProfilesId] = @PersonalProfilesId
END
go

