CREATE FUNCTION [dbo].[TVF_SolutionResourceUsageDaily_NoLock_SiteDaysSolIdResId]
(
    @SiteId uniqueidentifier,
    @DaysAgo int,
    @SolutionId uniqueidentifier,
    @ResourceId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SolutionResourceUsageDaily] WITH (NOLOCK, INDEX=SolutionResourceUsageDaily_Report, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DaysAgo = @DaysAgo AND
        SolutionId = @SolutionId AND
        ResourceId = @ResourceId

go

