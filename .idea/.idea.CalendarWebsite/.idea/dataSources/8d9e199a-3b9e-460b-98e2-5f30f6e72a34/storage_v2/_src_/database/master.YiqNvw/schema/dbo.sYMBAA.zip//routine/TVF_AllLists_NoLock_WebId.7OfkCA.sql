CREATE FUNCTION [dbo].[TVF_AllLists_NoLock_WebId]
(
    @tp_SiteId uniqueidentifier,
    @tp_WebId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllLists] WITH (NOLOCK, INDEX=AllLists_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_WebId = @tp_WebId

go

