--  [Work_ReportWorkChangeStatusProcess] '2023-04-01','2023-04-08','','','P:287','P:287','','','',''                
   CREATE   PROC  [dbo].[Work_ReportWorkChangeStatusProcess]              
   @fromDateBegin AS NVARCHAR(50) = ''                                                                                                                
   ,@toDateBegin AS NVARCHAR(50) = ''                                                
   ,@title as nvarchar(150)=''                                  
   ,@projectId as nvarchar(150)=''                                  
   ,@employeeCurrent as nvarchar(150)=''                                  
   ,@employee as nvarchar(150)=''                                  
   ,@dateCompleteFrom as NVARCHAR(50)=''                                  
   ,@dateCompleteTo as NVARCHAR(50)=''                                  
   ,@fromDateEnd AS NVARCHAR(50) = ''        
   ,@toDateEnd AS NVARCHAR(50) = ''                                             
   as                                   
   declare @sql as nvarchar(max)=N'' ,@sql1 as nvarchar(max)=N'',@sql2 as nvarchar(max)=N'',@sql3 as nvarchar(max)=N''   
   ,@dateWhereBegin as nvarchar(300)=N'',@dateWhereEnd as nvarchar(300)=N'',@projectWhere as nvarchar(350)=N'',@Where as nvarchar(300)=N' ' ,                              
   @dateCompWhere as nvarchar(300)=N'', @chuahoanthanh as nvarchar(50)= N'',  @hoanthanhdungtiendo as nvarchar(50)=N'Hoàn thành đúng tiến độ'                              
   ,@tretiendo as nvarchar(50)=N'Trễ tiến độ',@httretiendo as nvarchar(50)=N'Hoàn thành trễ tiến độ',@chuagiaocv as nvarchar(50)=N'Chưa giao công việc'                              
   if(@fromDateBegin<>'' and @toDateBegin='')                                 
   begin                                 
   set @dateWhereBegin=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(b.Ngaybatdau,''9999-12-12''),23) )>=0 '                
   end                    
   else if(@fromDateBegin<>'' and @toDateBegin<>'')                  
   begin                 
   set @dateWhereBegin=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(b.Ngaybatdau,''9999-12-12''),23) )>=0 and '+              
   ' DATEDIFF(day, CONVERT(varchar,'''+@toDateBegin+''',23) , CONVERT(varchar,ISNULL(b.Ngaybatdau,''9999-12-12''),23) )<=0 '                
   end                
   if(@fromDateEnd<>'' and @toDateEnd='')                                
   begin                                 
   set @dateWhereEnd=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(b.Ngayketthuc,''9999-12-12''),23) )<=0 '                                      
   end                                
   else if(@fromDateEnd<>'' and @toDateEnd<>'')                                
   begin                                 
   set @dateWhereEnd=' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(b.Ngayketthuc,''9999-12-12''),23) )>=0 and '+              
   ' DATEDIFF(day, CONVERT(varchar,'''+@toDateEnd+''',23) , CONVERT(varchar,ISNULL(b.Ngayketthuc,''9999-12-12''),23) )<=0 '                                 
   end                           
   if(@dateCompleteFrom<>'' and @dateCompleteTo='')                                
   begin                                 
   set @dateCompWhere=' and DATEDIFF(day, CONVERT(varchar,'''+@dateCompleteFrom+''',23) , CONVERT(varchar,ISNULL(b.Date,''9999-12-12''),23) )>=0 '                 
   end                 
   else if(@dateCompleteFrom<>''  and @dateCompleteTo<>'' )                                
   begin                                 
   set @dateCompWhere=' and DATEDIFF(day, CONVERT(varchar,'''+@dateCompleteFrom+''',23) , CONVERT(varchar,ISNULL(b.Date,''9999-12-12''),23) )>=0 and '+              
   ' DATEDIFF(day, CONVERT(varchar,'''+@dateCompleteFrom+''',23) , CONVERT(varchar,ISNULL(b.Date,''9999-12-12''),23) )<=0 '                 
   end                
   if(@projectId<>'')                                
   begin                           
   set @projectWhere=' and b.UserWorkflowId = '''+@projectId+''''                      
   end                      
   if(@employee <>'')                                
   begin                        
   set @Where=' where d.Id = '''+@employee+''''+@dateWhereBegin+' '+@dateWhereEnd+' '+@dateCompWhere+''                                
   end                                
   else                    
   begin                     
   set @Where=' where 1=1  '+@dateWhereBegin+' '+@dateWhereEnd+' '+@dateCompWhere+''                    
   end                 
   set @sql=N'                                
   select ''P:''+ TRIM(STR(Id)) as Id,FullName into #user from PersonalProfile where (ManagerId= REPLACE('''+@employeeCurrent+''',''P:'','''')   
   or Id= REPLACE('''+@employeeCurrent+''',''P:'','''') ) and UserStatus<>-1                                
   select                                               
   a.UserWorkflowId                                              
   ,b.Ten                                            
   ,a.Tieude                                                
   ,e.FullName as CreatedBy                                                            
   ,trim(CONVERT(CHAR, ISNULL(c.CreatedTime, null), 120))  as CreatedTime                                             
   ,trim(CONVERT(CHAR, ISNULL(a.NgayBatDau, null), 120))  as NgayBatDau                                             
   ,trim(CONVERT(CHAR, ISNULL(a.NgayKetThuc, null), 120))  as NgayKetThuc                                                
   ,a.NguoiXuLyDauTien                                                
   ,DATEDIFF(HOUR,a.Ngaygiaoviec, d.Date ) as TimeExec                                                
   , case when d.TrangThaiCongViec=N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0                                                  
   then N'''+@hoanthanhdungtiendo+'''                                                 
   when d.TrangThaiCongViec<>N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0                                                
   then  N'''+@tretiendo+'''                                                
   when d.TrangThaiCongViec <>N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0                                                
   then N'''+@chuahoanthanh+'''                                             
   when ISNULL(a.NguoiXuLyDauTien,'''')= ''''                                                
   then N'''+@chuagiaocv+'''                            
   when d.TrangThaiCongViec=N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0                                                  
   then N'''+@httretiendo+'''                         
   else  N'''' end as Status                                                
   , case when d.TrangThaiCongViec=N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0                                                  
   then 1       
   when d.TrangThaiCongViec<>N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0             
   then 2                                                
   when d.TrangThaiCongViec <>N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0                                                
   then 3                       
   when ISNULL(a.NguoiXuLyDauTien,'''')= ''''                              
   then 4                                           
   when d.TrangThaiCongViec=N''Hoàn thành'' and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0                                    
   then 5                                   
   else 6 end as StatusInt                
   , '''' as userId                                        
   ,d.TrangThaiCongViec                                  
   ,d.Date as DateCompelete                    
   ,DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) as abc                                  
   ,ISNULL( Nguoixuly,'''')+'';''+ISNULL(Nguoixulydautien,'''') as Nguoithamgia                                
   , b.UserWorkflowId as ProjectId                        
   , d.OldValue                    
   ,d.NewValue                    
   ,d.Date              
   ,d.FullName as UpdateUser           
   into #a '                              
   set @sql2=N'                        
   from Dynamic.Data_WORK a                                                
   inner join Dynamic.Data_RESOURCEDA b on a.Duan=b.UserWorkflowId                                                
   inner join UserWorkflow c on a.UserWorkflowId=c.id                        
   inner join PersonalProfile e on e.Id=c.UserId        
   left join                   
   (                                                
   select  a.WorkId, b.TrangThaiCongViec, a.Date,b.Ten as OldValue              
   ,c.Ten as NewValue,h.FullName               
   from Dynamic.Data_LSCNTTCV a                      
   inner join Dynamic.data_RESOURCETTFC b on a.OldValue=trim(str( b.UserWorkflowId))          
   inner join Dynamic.data_RESOURCETTFC c on a.NewValue=trim(str( c.UserWorkflowId))          
   inner join PersonalProfile h on ''P:''+trim( str(h.Id))= a.UpdateUser                   
   where a.ColumnName=''TrangThaiCongViec''                                         
   ) d on a.UserWorkflowId=d.WorkId                                                
   inner join PersonalProfile i on i.Email=c.CreatedBy'                                
   set @sql1=N'                                
   where ISNULL(b.IsDeleted,''False'')=''False'' and b.TrangThai  not in (N''hủy'',N''huỷ'') and ISNULL(a.IsActive,''True'')=''True'' and a.Tieude like N''%'+@title+'%'''+' '+@projectWhere+'                                
   select                                               
   b.UserWorkflowId as WorkId                                            
   ,b.Ten as ProjectName                                            
   ,b.Tieude   as Title                                            
   ,b.CreatedBy                                               
   ,b.CreatedTime                                        
   ,b.NgayBatDau  as BeginDate                                              
   ,b.NgayKetThuc    as EndDate                                            
   ,b.NguoiXuLyDauTien   as UserExec                                            
   ,Abs(isnull( b.TimeExec,0)) as TimeExec  
   ,b.Status                                              
   ,b.StatusInt                                              
   , e.NewValue as ChangDateBegin                                              
   , f.NewValue as ChangDateEnd                  
   ,UserExecFullName = STUFF((                                              
   SELECT '', '' + h.FullName                                             
   FROM #a a                                 
   cross apply string_split(ISNULL(a.NguoiXuLyDauTien,''''),'';'') g                                            
   inner join PersonalProfile h on ''P:''+trim( str(h.Id))=g.value                                  
   where a.UserWorkflowId=b.UserWorkflowId    group by  UserWorkflowId,a.NguoiXuLyDauTien,h.FullName                                               
   FOR XML PATH('''')                 
   ), 1, 2, '''')                                       
   ,Nguoithamgia                                 
   , trim(CONVERT(CHAR, ISNULL(DateCompelete, null), 120)) as DateCompelete                                
   ,ProjectId              
   ,b.UpdateUser          
   , b.OldValue                    
   ,b.NewValue           
   from #a b                                 
   cross apply string_split(b.Nguoithamgia,'';'') c                
   inner join #user d on c.value=d.Id      
   left join (                  
   select a.* from Dynamic.Data_LSCNTTCV a                                              
   inner join ( select MAX(Id) as Id,WorkId from  Dynamic.Data_LSCNTTCV where ColumnName=''Ngaybatdau'' group by WorkId )  c on c.Id=a.Id                                                
   where ColumnName=''Ngaybatdau''                                
   ) e on e.WorkId=b.UserWorkflowId                                              
   left join (                                               
   select a.* from Dynamic.Data_LSCNTTCV a                                              
   inner join ( select MAX(Id) as Id,WorkId from  Dynamic.Data_LSCNTTCV where ColumnName=''Ngayketthuc'' group by WorkId )  c on c.Id=a.Id                                                
   where ColumnName=''Ngayketthuc''                                               
   ) f on f.WorkId=b.UserWorkflowId '    
   set @sql3= ''+@Where+'     
   group by                                 
   b.UserWorkflowId                                
   ,b.Ten                                    
   ,b.Tieude                                        
   ,b.CreatedBy                                               
   ,b.CreatedTime                                        
   ,b.NgayBatDau                                   
   ,b.NgayKetThuc                                       
   ,b.NguoiXuLyDauTien                                   
   ,b.TimeExec        
   ,b.Status                                              
   ,b.StatusInt                                              
   , e.NewValue                                               
   , f.NewValue                              
   ,Nguoithamgia                                 
   ,b.DateCompelete                                 
   ,b.ProjectId                                
   ,b.OldValue                    
   ,b.NewValue                    
   ,b.Date           
   ,b.UpdateUser    
   order by b.UserWorkflowId  desc  
   '                                
   exec(@sql+' ' +@sql2+' '+@sql1 +''+@sql3)                                
   PRINT CAST(@sql+' ' +@sql2+' '+@sql1+''+@sql3  AS NTEXT)
go

