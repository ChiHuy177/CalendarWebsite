CREATE PROCEDURE [dbo].[proc_DeleteDocEventReceiver](
    @DocUrl nvarchar(260),
    @Id uniqueidentifier,
    @Name nvarchar(256),
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ItemId int,
    @Synchronization int,
    @Type int,
    @SequenceNumber int,
    @Assembly nvarchar(256),
    @Class nvarchar(256),
    @Data nvarchar(256),
    @Filter nvarchar(256),
    @Credential int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocDirName nvarchar(256)
    DECLARE @DocLeafName nvarchar(128)
    DECLARE @DocId uniqueidentifier
    EXEC proc_SplitUrl @DocUrl, @DocDirName OUTPUT, @DocLeafName OUTPUT
    SELECT TOP 1
        @DocId = Id
    FROM
        TVF_Docs_Url(@SiteId, @DocDirName, @DocLeafName) AS Docs
    WHERE
        WebId = @WebId
    IF (@DocId IS NULL)
        RETURN 3
    DELETE 
        ER
    FROM
        TVF_EventReceivers_PK(@SiteId, @Id) AS ER
    WHERE
        ER.Type != 32767
    IF @@ROWCOUNT <> 1
        RETURN 87
    RETURN 0

go

