CREATE FUNCTION [dbo].[TVF_Deps_SiteDescEqLike_NotForDelete]
(
    @SiteId uniqueidentifier,
    @DepDesc nvarchar(270),
    @DepDescLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        T1.*
    FROM
    (SELECT
        *
    FROM
        Deps WITH (INDEX=Deps_DepToDoc, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DepDesc = @DepDesc
    UNION ALL
    SELECT
        *
    FROM
        Deps WITH (INDEX=Deps_DepToDoc, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DepDesc LIKE @DepDescLike) AS T2
    INNER LOOP JOIN
        Deps AS T1 WITH (INDEX=Deps_DocToDep, FORCESEEK)
    ON
                    T1.SiteId = T2.SiteId AND
                    T1.DeleteTransactionId = T2.DeleteTransactionId AND
                    T1.FullUrl = T2.FullUrl AND
                    T1.Level = T2.Level

go

