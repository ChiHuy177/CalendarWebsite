CREATE PROCEDURE [dbo].[proc_EnumRecycleBinToFreeSecondStageQuota](
    @SiteId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT
        CAST(R.DeleteTransactionId AS uniqueidentifier),
        (SELECT SUM(R2.Size)
            FROM TVF_RecycleBin_DelId(R.SiteId, R.DeleteTransactionId) AS R2)
    FROM
        TVF_RecycleBin_SiteBin(
            @SiteId,
            2) AS R
    WHERE
        R.ChildDeleteTransactionId = 0x
    ORDER BY
        R.DeleteDate
    RETURN 0

go

