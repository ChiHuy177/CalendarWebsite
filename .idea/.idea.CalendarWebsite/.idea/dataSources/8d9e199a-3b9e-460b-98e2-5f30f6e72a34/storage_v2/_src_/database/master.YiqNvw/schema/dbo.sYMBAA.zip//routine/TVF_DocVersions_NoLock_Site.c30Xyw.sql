CREATE FUNCTION [dbo].[TVF_DocVersions_NoLock_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocVersions] WITH (NOLOCK, INDEX=AllDocVersions_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = 0x

go

