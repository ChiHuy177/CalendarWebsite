CREATE PROCEDURE [dbo].[proc_UpdateVersionVirusInfo](
    @DocSiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @Version int,
    @VirusVendorID int,
    @VirusStatus tinyint,
    @VirusInfo nvarchar(255),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        DV
    SET
        VirusVendorID = @VirusVendorID,
        VirusStatus = @VirusStatus,
        VirusInfo = @VirusInfo
    FROM
        TVF_DocVersions_SiteDocIdUIVersion(@DocSiteId, @DocId, @Version) AS DV
    RETURN 0

go

