CREATE PROCEDURE [dbo].[proc_SetEventReceiverToSynchronous](
    @SiteId uniqueidentifier,
    @Assembly nvarchar(256),
    @Class nvarchar(256),
    @Type int)
AS
    SET NOCOUNT ON
    UPDATE
        EventReceivers
    SET
        Synchronization = 1
    WHERE
        SiteId = @SiteId AND
        Assembly = @Assembly AND
        Class = @Class AND
        Type = @Type

go

