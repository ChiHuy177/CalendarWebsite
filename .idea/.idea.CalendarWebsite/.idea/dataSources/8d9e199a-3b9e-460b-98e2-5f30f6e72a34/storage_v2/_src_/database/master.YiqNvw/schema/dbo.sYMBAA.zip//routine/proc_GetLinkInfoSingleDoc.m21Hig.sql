CREATE PROCEDURE [dbo].[proc_GetLinkInfoSingleDoc](
    @DocSiteId   uniqueidentifier,
    @DocDirName  nvarchar(256),
    @DocLeafName nvarchar(128),
    @Level tinyint,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocParentId uniqueidentifier
    DECLARE @DocId uniqueidentifier
    EXEC proc_GetParentIdAndDocIdForUrl 
        @DocSiteId, 
        @DocDirName, 
        @DocLeafName, 
        @DocParentId OUTPUT, 
        @DocId OUTPUT
    EXEC proc_GetLinkInfoSingleDocInternal
        @DocSiteId,
        @DocDirName,
        @DocLeafName,
        @DocParentId,
        @DocId,
        @Level,
        @RequestGuid OUTPUT

go

