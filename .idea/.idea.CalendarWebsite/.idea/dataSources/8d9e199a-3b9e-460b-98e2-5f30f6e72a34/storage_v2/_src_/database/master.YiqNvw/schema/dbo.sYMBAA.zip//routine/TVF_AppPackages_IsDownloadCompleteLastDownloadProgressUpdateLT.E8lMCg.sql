CREATE FUNCTION [dbo].[TVF_AppPackages_IsDownloadCompleteLastDownloadProgressUpdateLT]
(
    @IsDownloadComplete bit,
    @LTLastDownloadProgressUpdate datetime
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppPackages] WITH (INDEX=AppPackages_IsDownloadCompleteLastDownloadProgressUpdate, FORCESEEK)
    WHERE
        IsDownloadComplete = @IsDownloadComplete AND
        LastDownloadProgressUpdate < @LTLastDownloadProgressUpdate

go

