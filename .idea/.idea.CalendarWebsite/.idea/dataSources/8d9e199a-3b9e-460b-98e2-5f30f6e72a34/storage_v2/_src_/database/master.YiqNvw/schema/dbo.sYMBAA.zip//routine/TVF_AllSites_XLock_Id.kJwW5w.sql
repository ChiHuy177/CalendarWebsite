CREATE FUNCTION [dbo].[TVF_AllSites_XLock_Id]
(
    @Id uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllSites] WITH (XLOCK, INDEX=Sites_Id, FORCESEEK)
    WHERE
        Id = @Id

go

