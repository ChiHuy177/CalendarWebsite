CREATE FUNCTION [dbo].[TVF_UserDataVersioned_NoLock_Site]
(
    @tp_SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserData] WITH (NOLOCK, INDEX=AllUserData_ParentId, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_DeleteTransactionId = 0x AND
        (tp_IsCurrentVersion = CONVERT(bit, 0) OR tp_IsCurrentVersion = CONVERT(bit, 1))

go

