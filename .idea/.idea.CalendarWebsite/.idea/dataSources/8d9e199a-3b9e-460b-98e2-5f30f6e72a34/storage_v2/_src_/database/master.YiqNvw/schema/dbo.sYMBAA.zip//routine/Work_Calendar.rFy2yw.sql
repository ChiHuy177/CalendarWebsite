CREATE PROC [dbo].[Work_Calendar]     
@date AS CHAR(10) ='2022-11-22'         
 ,@userId AS NVARCHAR(25) = 'P:287'          
 ,@title AS NVARCHAR(500) = ''          
 ,@projectName AS NVARCHAR(500) = '69451'          
 ,@status AS NVARCHAR(500) = ''   
 --,@currentUser AS NVARCHAR(25) = 'P:287'       
AS          
  
-- cho xem tat ca  
  
--declare @tbUser table ( UserId nvarchar(50), UserWorkflowId bigint)             
--insert into @tbUser                
--select * from                 
--(                
                
--SELECT                                 
-- 'P:'+ trim(str(c.PersonalProfilesId)) AS userId                  
-- ,a.UserWorkflowId                
-- -- into #da                
--FROM DYNAMIC.Data_RESOURCEDA AS a                
--CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b                
--inner join GroupPersonalProfile c on  'G:'+ trim(str(GroupsId))=b.value                
--where left(trim(b.value),2)='G:'  and ISNULL(a.IsDeleted,'False')='False'                
                
--union                 
                
--SELECT                                 
-- b.value  AS userId                  
-- ,a.UserWorkflowId                
-- -- into #da                
--FROM DYNAMIC.Data_RESOURCEDA AS a                
--CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b                
--where left(trim(b.value),2)='P:'        and ISNULL(a.IsDeleted,'False')='False'          
                
--union                 
                
--SELECT                                 
-- b.value  AS userId                  
-- ,a.UserWorkflowId                
-- -- into #da                
--FROM DYNAMIC.Data_RESOURCEDA AS a                
--CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b                
--where left(trim(b.value),2)='P:'          and ISNULL(a.IsDeleted,'False')='False'        
                
--) a group by userId,UserWorkflowId                
  
--select * into #project from (       
--select                                     
--      a.[UserWorkflowId] as Id                                    
--      ,[Ten] as Name                                    
--      ,[MoTa] as Description                                                      
--      ,[ThanhPhanThamGia] as UserPartner                                    
--      ,[NgayBatDau] as [Start]                                    
--      ,[NgayKetThuc] as [End]                                    
--      ,[TrangThai] as StatusProject                                    
--      ,[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                                    
--      ,[Quanly] as Manager                                    
--      ,a.UserWorkflowId                                
--      ,AddAllUserWhenAddWork               
--   ,RuleViewWork              
--from Dynamic.Data_RESOURCEDA a                
--inner join @tbUser b on b.UserWorkflowId=a.UserWorkflowId                
--where                 
--b.UserId=@currentUser and ISNULL(IsDeleted,'False')='False'   and TrangThai = N'Đang thực hiện'                   
--  union   
  
--select                                     
--      a.[UserWorkflowId] as Id                                    
--      ,[Ten] as Name                                    
--      ,[MoTa] as Description                                                      
--      ,[ThanhPhanThamGia] as UserPartner                                    
--      ,[NgayBatDau] as [Start]                                    
--      ,[NgayKetThuc] as [End]                                    
--      ,[TrangThai] as StatusProject                                    
--      ,[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow                                    
--      ,[Quanly] as Manager                                    
--      ,a.UserWorkflowId                                
--      ,AddAllUserWhenAddWork               
--   ,RuleViewWork              
--from Dynamic.Data_RESOURCEDA a where a.UserWorkflowId=@projectName  
--)a  
  
  
SELECT a.Id          
 ,a.UserWorkflowId          
 ,a.Duan as projectName          
 ,a.Tieude as title          
 ,ISNULL(a.Noidung, '') AS description          
 ,a.TrangThaiCongViec as TrangThai          
 , ISNULL(a.Ngaybatdau,GETDATE()) as start          
 ,ISNULL( a.Ngayketthuc,GETDATE())  as [end]          
 ,a.Nguoiphoihop      
 ,a.Nguoigiao      
 ,a.Nguoitheodoi      
 ,a.Nguoixuly
 ,t.TrangThaiCongViec 
INTO #a          
FROM [Dynamic].[Data_WORK] AS a   
left join Dynamic.data_RESOURCETTFC t on a.TrangThaiCongViec = t.UserWorkflowId  
WHERE CONVERT(DATE, ISNULL(a.Ngaybatdau, GETDATE()), 23) = CONVERT(DATE, @date, 23)          
and ISNULL(a.IsActive,'True')='True'    
    
SELECT a.Id          
 ,a.UserWorkflowId          
 ,a.projectName          
 ,a.title          
 ,a.description          
 ,a.TrangThai          
 ,ISNULL(a.start, a.[end]) AS start          
 ,ISNULL(a.[end], GETDATE()) AS [end] 
 ,a.TrangThaiCongViec  as StatusType
FROM #a a  
  
WHERE ISNULL(a.title, '') LIKE N'%' + @title + '%'     
and a.projectName=@projectName  
 AND isnull(a.TrangThai, '') LIKE N'%' + @status + '%'          
     AND  
    ( @userId IN (SELECT *  FROM STRING_SPLIT(a.Nguoiphoihop, ';'))  
 OR @userId IN (  SELECT *  FROM STRING_SPLIT(a.Nguoixuly, ';'))  
 OR @userId IN (SELECT *  FROM STRING_SPLIT(a.Nguoitheodoi, ';'))  
 OR @userId IN (SELECT *  FROM STRING_SPLIT(a.Nguoigiao, ';'))  
 or @userId=''  
 )                           
          
DROP TABLE #a       
go

