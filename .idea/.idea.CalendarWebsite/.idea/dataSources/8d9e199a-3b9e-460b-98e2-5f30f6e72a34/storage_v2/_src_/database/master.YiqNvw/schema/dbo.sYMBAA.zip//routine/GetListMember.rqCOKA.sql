create procedure [dbo].[GetListMember] @key varchar(50)
as
begin
	select us.AccountName,cus.CustomerName, cus.CustomerCode,cus.AccountantCode, cus.PhoneBilling,us.Address
	 from UserDetails us join CustomerDB.dbo.Customers cus on us.CustomerID = cus.ID
	 where cus.CustomerCode = @key or cus.AccountantCode = @key or 
	 cus.PhoneBilling = @key or cus.CustomerName like '%' +  @key + '%'
end

go

