CREATE FUNCTION [dbo].[TVF_Webs_AWDI]
(
    @SiteId uniqueidentifier,
    @AppWebDomainId varchar(8)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebs] WITH (INDEX=Webs_AWDI, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@AppWebDomainId IS NULL AND AppWebDomainId IS NULL) OR @AppWebDomainId=AppWebDomainId) AND
        DeleteTransactionId = 0x

go

