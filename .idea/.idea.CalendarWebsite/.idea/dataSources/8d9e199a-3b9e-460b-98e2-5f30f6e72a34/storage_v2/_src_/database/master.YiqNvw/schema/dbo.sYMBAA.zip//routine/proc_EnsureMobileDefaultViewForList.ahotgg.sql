CREATE PROCEDURE [dbo].[proc_EnsureMobileDefaultViewForList](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier)
AS
    SET NOCOUNT ON
    DECLARE @ViewId uniqueidentifier
    SELECT TOP 1
        @ViewId = WP.tp_ID
    FROM 
        TVF_WebParts_ListUser(@SiteId, @ListId, NULL ) AS WP
    WHERE
        (WP.tp_Flags & 8388608) = 8388608
    IF @ViewId IS NOT NULL
    BEGIN
        IF NOT EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_WebParts_ListUser(@SiteId, @ListId, NULL ) AS WP
            WHERE
                (WP.tp_Flags & 16777216) = 16777216)
        BEGIN
            UPDATE 
                WP
            SET
                WP.tp_Flags = WP.tp_Flags | 16777216
            FROM
                TVF_WebParts_SitePartId(@SiteId, @ViewId) AS WP
        END
    END
    RETURN 0

go

