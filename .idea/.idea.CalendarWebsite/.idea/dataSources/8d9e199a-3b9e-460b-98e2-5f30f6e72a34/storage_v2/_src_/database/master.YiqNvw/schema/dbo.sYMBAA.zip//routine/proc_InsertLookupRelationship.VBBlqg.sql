CREATE PROCEDURE [dbo].[proc_InsertLookupRelationship](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier,
    @LookupListId uniqueidentifier,
    @DeleteBehavior tinyint,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON;
    DECLARE @ReturnCode int,
            @RowCount int;
    SET @ReturnCode = 0;
    IF @DeleteBehavior < 0 OR
        @DeleteBehavior > 2
    BEGIN
        SET @ReturnCode = 87;
        GOTO DONE
    END
    IF EXISTS(
        SELECT TOP 1
            1
        FROM 
            TVF_AllLookupRelationships_SiteListField(@SiteId, @ListId, @FieldId))
    BEGIN
        SET @ReturnCode = 1359;
        GOTO DONE;
    END
    DECLARE @OldWebFlagValue int;
    SELECT TOP 1
        @OldWebFlagValue = W.Flags
    FROM 
        TVF_Webs_UpdLock_Id(@SiteId, @WebId) AS W
    DECLARE @NewWebFlagValue int;
    SET @NewWebFlagValue = @OldWebFlagValue;
    IF (@DeleteBehavior <> 0)
    BEGIN
        SET @NewWebFlagValue = @OldWebFlagValue | 16384;
    END 
    IF (@DeleteBehavior <> 0)
    BEGIN
        DECLARE @SourceListServerTemplate int;
        SELECT TOP 1
            @SourceListServerTemplate = L.tp_ServerTemplate
        FROM
            TVF_Lists_Id(@SiteId, @ListId) AS L
        IF (@SourceListServerTemplate = 202)
        BEGIN
            SET @ReturnCode = 155;
            GOTO DONE;
        END
        DECLARE @TargetListServerTemplate int;
        SELECT TOP 1
            @TargetListServerTemplate = L.tp_ServerTemplate
        FROM
            TVF_Lists_Id(@SiteId, @LookupListId) AS L
        IF (@TargetListServerTemplate = 202)
        BEGIN
            SET @ReturnCode = 155;
            GOTO DONE;
        END
        DECLARE @XLookupListId uniqueidentifier;
        SELECT TOP 1
            @XLookupListId = L.tp_ID
        FROM 
            TVF_Lists_XLock_Id(@SiteId, @LookupListId) AS L
        IF (@@ROWCOUNT = 0)
        BEGIN
            SET @ReturnCode = 19;
            GOTO DONE;
        END
    END
    INSERT INTO AllLookupRelationships
    (
        SiteId,
        ListId,
        FieldId,
        LookupListId,
        DeleteBehavior
    )
    VALUES
    (
        @SiteId,
        @ListId,
        @FieldId,
        @LookupListId,
        @DeleteBehavior
    )
    IF (@OldWebFlagValue <> @NewWebFlagValue)
    BEGIN
        UPDATE 
            W
        SET
            W.Flags  = @NewWebFlagValue
        FROM
            TVF_Webs_Id(@SiteId, @WebId) AS W
    END
DONE:
    RETURN @ReturnCode

go

