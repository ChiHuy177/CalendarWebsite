CREATE PROCEDURE [dbo].[proc_DropLookupRelationship](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier,
    @TranLockStatus tinyint)
AS
    SET NOCOUNT ON;
    IF (@TranLockStatus = 3 AND 
        EXISTS(
            SELECT 
                1
            FROM
                TVF_AllLookupRelationships_SiteListField(@SiteId, @ListId, @FieldId) AS ALR
            WHERE
                ALR.DeleteBehavior <> 0))
    BEGIN
        RETURN 301;
    END
    DELETE 
        ALR
    FROM
        TVF_AllLookupRelationships_SiteListField(@SiteId, @ListId, @FieldId) AS ALR
    IF (EXISTS(
            SELECT TOP 1
                1 
            FROM 
                TVF_Lists_WebId(@SiteId, @WebId) AS L
            CROSS APPLY
                TVF_AllLookupRelationships_SiteList(L.tp_SiteId, L.tp_ID) AS ALR
            CROSS APPLY
                TVF_Lists_Id(ALR.SiteId, ALR.LookupListId) AS L2
            WHERE
                ALR.DeleteBehavior <> 0))
    BEGIN
        UPDATE 
            W
        SET
            W.Flags  = W.Flags | 16384
        FROM
            TVF_Webs_Id(@SiteId, @WebId) AS W
    END
    ELSE
    BEGIN
        UPDATE 
            W
        SET
            W.Flags  = W.Flags & ~16384
        FROM
            TVF_Webs_Id(@SiteId, @WebId) AS W
    END
    RETURN 0;

go

