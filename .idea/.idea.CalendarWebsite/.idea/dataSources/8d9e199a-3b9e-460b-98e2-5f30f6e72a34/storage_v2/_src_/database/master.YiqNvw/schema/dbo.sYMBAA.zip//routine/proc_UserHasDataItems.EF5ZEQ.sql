CREATE PROCEDURE [dbo].[proc_UserHasDataItems](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @UserId int,
    @InstanceID int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_UserData_List(@SiteId, @ListId) AS UD
        WHERE
            tp_Author = @UserId AND
            (@InstanceID IS NULL OR tp_InstanceID IS NULL OR tp_InstanceID = @InstanceID))
    BEGIN
        RETURN 1
    END
    ELSE
    BEGIN
        RETURN 0
    END

go

