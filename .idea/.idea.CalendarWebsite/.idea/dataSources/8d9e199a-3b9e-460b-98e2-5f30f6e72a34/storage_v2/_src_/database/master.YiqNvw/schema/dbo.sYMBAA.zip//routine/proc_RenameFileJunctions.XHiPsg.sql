CREATE PROC [dbo].[proc_RenameFileJunctions](
    @SiteId uniqueidentifier,
    @OldDocParentId uniqueidentifier,
    @DocId uniqueidentifier,
    @NewDocParentId uniqueidentifier
    )
AS
    SET NOCOUNT ON
    UPDATE
        UDJV
    SET
        UDJV.tp_ParentId = @NewDocParentId
    FROM
        TVF_UserDataJunctionsVersioned_SiteParIdDocId(
            @SiteId,
            @OldDocParentId,
            @DocId) AS UDJV

go

