CREATE PROCEDURE [dbo].[proc_ResyncWelcomeLinks](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @FormerLeafName nvarchar(128))
AS
    SET NOCOUNT ON
    DECLARE @CurrentLeafNameIsWelcomePage bit
    DECLARE @FormerLeafNameWasWelcomePage bit
    SET @CurrentLeafNameIsWelcomePage = 0
    SET @FormerLeafNameWasWelcomePage = 0
    IF @FormerLeafName IS NOT NULL AND EXISTS (
        SELECT TOP 1
            1
        FROM
            TVF_WelcomeNames_PK(@FormerLeafName))
    BEGIN
        SET @FormerLeafNameWasWelcomePage = 1
    END
    IF @LeafName IS NOT NULL
    BEGIN
        IF EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_WelcomeNames_PK(@LeafName))
        BEGIN
            SET @CurrentLeafNameIsWelcomePage = 1
        END
    END
    IF @FormerLeafNameWasWelcomePage = 0 AND @CurrentLeafNameIsWelcomePage = 0
        AND @LeafName IS NOT NULL
    BEGIN
        RETURN
    END
    DECLARE @NewWelcome nvarchar(128)
    DECLARE @DirDirName nvarchar(256)
    DECLARE @DirLeafName nvarchar(128)
    EXEC proc_SplitUrl @DirName, @DirDirName OUTPUT, @DirLeafName OUTPUT
    SELECT TOP 1
        @NewWelcome = WelcomeName
    FROM
        fn_GetWelcomeName(@SiteId, @DirName)
    OPTION (FORCE ORDER)
    IF @LeafName IS NOT NULL
    BEGIN
        EXEC proc_UpdateHomeNavNode @SiteId, @DirName, @LeafName, @NewWelcome
    END
    IF @NewWelcome IS NULL
    BEGIN
        UPDATE
            Links
        SET
            TargetDirName = @DirDirName,
            TargetLeafName = @DirLeafName,
            PointsToDir = 0
        FROM
            TVF_Links_TargetDirNamePointsToDir(@SiteId, @DirName) AS Links
    END
    ELSE
    BEGIN
        UPDATE 
            Links
        SET
            TargetDirName = @DirName,
            TargetLeafName = @NewWelcome,
            PointsToDir = 1
        FROM
            TVF_Links_TargetUrlNotPointsToDir(@SiteId, @DirDirName, @DirLeafName) AS Links
        UPDATE 
            Links
        SET
            TargetDirName = @DirName,
            TargetLeafName = @NewWelcome,
            PointsToDir = 1
        FROM
            TVF_Links_TargetDirNamePointsToDir(@SiteId, @DirName) AS Links
    END
    IF @NewWelcome IS NOT NULL
    BEGIN
        UPDATE
            D
        SET
            D.MetaInfoTimeLastModified =
                dbo.fn_RoundDateToNearestSecond(GETUTCDATE())
        FROM
            WelcomeNames WN
        CROSS APPLY
            TVF_Docs_Url(@SiteId, @DirName, WN.LeafName) AS D
        OPTION (FORCE ORDER) 
    END

go

