-- Work_StatusReportChartByUserLogin 'vuongnq@vntt.com.vn'              
   CREATE   PROC  [dbo].[Work_StatusReportChartByUserLogin]         
   @email AS NVARCHAR(50) = ''            
   AS            
   DECLARE @userId AS NVARCHAR(20)            
   SET @userId = (            
   SELECT 'P:' + TRIM(str(Id))            
   FROM PersonalProfile            
   WHERE Email = @email and ISNULL(IsDeleted,0)=0 and UserStatus <>-1      
   )            
   DECLARE @tab2 TABLE(Name  nvarchar(150), Quantity INT,UserID nVARCHAR(50), type int)          
   insert into @tab2          
   select N'Chờ phê duyệt' AS Name , 0 as Quantity, @userId as UserID , 1 as type          
   insert into @tab2          
   select N'Đã phê duyệt' AS Name , 0 as Quantity, @userId as UserID, 2 as type          
   insert into @tab2        
   select N'Không phê duyệt' AS Name , 0 as Quantity, @userId as UserID, 3 as type          
   insert into @tab2         
   select N'Bị hủy' AS Name , 0 as Quantity, @userId as UserID, 4 as type          
   --SELECT a.Id            
   --,c.UserWorkflowStatus            
   --INTO #a            
   --FROM [Dynamic].Data_WORK AS a            
   --INNER JOIN UserWorkflow c ON a.UserWorkflowId = c.Id            
   --WHERE @userId = (select top 1 value                
   --from STRING_SPLIT(ISNULL(a.Nguoixuly,'')+';'+ISNULL(a.Nguoiphoihop,'')+';'+ISNULL(a.Nguoigiao,'')+';'+ISNULL(a.Nguoitheodoi,''), ';')   
   --where value=@userId  
   --group by value ) and  ISNULL(a.IsActive,'True')='True'      
   --;        
   --update @tab2 set Quantity=( select COUNT(*) AS Quantity            
   --FROM #a a            
   --WHERE UserWorkflowStatus = 0 )where type=1        
   --update @tab2 set Quantity=( select COUNT(*) AS Quantity            
   --FROM #a a            
   --WHERE UserWorkflowStatus = 1 )where type=2        
   --update @tab2 set Quantity=( select COUNT(*) AS Quantity            
   --FROM #a a            
   --WHERE UserWorkflowStatus = 2 )where type=3        
   --update @tab2 set Quantity=( select COUNT(*) AS Quantity            
   --FROM #a a            
   --WHERE UserWorkflowStatus = 3)where type=4        
   select * from @tab2        
   --DROP TABLE #a 
go

