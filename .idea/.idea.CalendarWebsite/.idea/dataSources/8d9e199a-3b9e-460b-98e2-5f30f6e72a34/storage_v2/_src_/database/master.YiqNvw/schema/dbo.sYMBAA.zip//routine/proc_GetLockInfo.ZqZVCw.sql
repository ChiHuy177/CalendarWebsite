CREATE PROCEDURE [dbo].[proc_GetLockInfo](
    @SiteId uniqueidentifier,
    @DocParentId uniqueidentifier,
    @DocId uniqueidentifier,
    @Level tinyint)
AS
    SET NOCOUNT ON
    SELECT 
        UI.tp_Login,
        Docs.CheckoutDate,
        Docs.CheckoutExpires
    FROM
        TVF_Docs_CI(@SiteId, @DocParentId, @DocId, @Level) AS Docs
    OUTER APPLY
        TVF_UserInfo_PK(Docs.SiteId, Docs.CheckoutUserId) AS UI

go

