CREATE PROCEDURE [dbo].[proc_UpdateWebPartLinks](
    @SiteId uniqueidentifier,
    @WebPartId uniqueidentifier,
    @Level tinyint,
    @AllUsersProperties varbinary(max),
    @Source nvarchar(max),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    DECLARE @AllUsersSize int
    DECLARE @SourceSize int
    DECLARE @NewSize bigint
    SET @Ret = 0
    SET @AllUsersSize = ISNULL(DATALENGTH(@AllUsersProperties), 0)
    SET @SourceSize = ISNULL(DATALENGTH(@Source), 0)
    EXEC @Ret = proc_OnUpdateWebParts
        @SiteId,
        @WebPartId,
        @Level,
        NULL,    
        @AllUsersSize,
        NULL,    
        NULL,    
        0,    
        @SourceSize,
        NULL,
        @NewSize OUTPUT
    IF (@@ERROR <> 0)
    BEGIN
        SET @Ret = -2147467259
        GOTO cleanup
    END
    UPDATE
        WP
    SET
        WP.tp_Version = (CASE WHEN WP.tp_Version IS NULL THEN 2 WHEN WP.tp_Version >= 2147483647 THEN 1 ELSE WP.tp_Version + 1 END),
        WP.tp_AllUsersProperties = @AllUsersProperties,
        WP.tp_Source = @Source,
        WP.tp_Cache = NULL,
        WP.tp_Size = @NewSize
    FROM
        TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
    IF (@@ERROR <> 0)
    BEGIN
        SET @Ret = -2147467259
        GOTO cleanup
    END
    IF (@Level = 1)
    BEGIN
        EXEC @Ret = proc_InvalidatePerUserWebPartCache
            @SiteId,
            @WebPartId
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
     END
    IF NOT EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level))
    BEGIN
        SET @Ret = 2  
    END
cleanup:
    IF (0 <> @@ERROR OR 0 <> @Ret)
    BEGIN
        RETURN CASE WHEN (0 = @Ret) THEN -2147467259 ELSE @Ret END
    END
    RETURN 0

go

