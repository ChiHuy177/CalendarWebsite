CREATE FUNCTION [dbo].[TVF_AllDocs_ALL]
(
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (INDEX=AllDocs_ParentId)
    WHERE
        1 = 1

go

