CREATE       PROCEDURE [Dynamic].[WorkflowDynamicDetailData_GetTableName] 
	@WorkflowId BIGINT,
	@TableNameResult nvarchar(max) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX), @TableCode NVARCHAR(MAX);



		SET @TableName =(
			SELECT Title
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
		SET @TableCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)

		set @TableNameResult = CONCAT (
			'Dynamic.Detail_'
			,dbo.fn_StripCharacters(@TableCode, '^a-z0-9')
			);		
END
go

