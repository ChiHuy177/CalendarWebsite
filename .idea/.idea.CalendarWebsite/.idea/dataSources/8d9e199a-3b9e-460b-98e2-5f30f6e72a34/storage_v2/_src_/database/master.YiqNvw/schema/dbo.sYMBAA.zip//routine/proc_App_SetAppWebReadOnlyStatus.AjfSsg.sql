CREATE Procedure [dbo].[proc_App_SetAppWebReadOnlyStatus] (
    @AppWebId uniqueidentifier,
    @SiteId uniqueidentifier,
    @NewStatus bit
)
AS
SET NOCOUNT ON
IF(@NewStatus = 1)
BEGIN
    UPDATE TVF_AllWebs_Id(@SiteId, @AppWebId)
        SET Flags = Flags | CAST (0x2000000 AS INT)
END
ELSE
BEGIN
    UPDATE TVF_AllWebs_Id(@SiteId, @AppWebId)
        SET Flags = Flags & (~ CAST (0x2000000 AS INT))
END

go

