CREATE Procedure [dbo].[proc_App_RemoveRuntimeIcon] (
    @SiteId uniqueidentifier,
    @IconId uniqueidentifier,
    @AppInstanceId uniqueidentifier
)
AS
SET NOCOUNT ON
BEGIN TRANSACTION
DELETE FROM TVF_AppRuntimeIcons_AppInstanceId(@SiteId, @AppInstanceId)
    --not worth building an index for this because the TVF never has more than two records
    WHERE IconId = @IconId
--There may still be an active icon if this is a DeprovisionOriginal
IF NOT EXISTS (SELECT TOP 1 1 FROM TVF_AppRuntimeIcons_AppInstanceIdActive(@SiteId, @AppInstanceId))
BEGIN
    UPDATE TVF_AppInstallations_Id(@SiteId, @AppInstanceId)
        SET IsIconHosted = 0
END
COMMIT TRANSACTION

go

