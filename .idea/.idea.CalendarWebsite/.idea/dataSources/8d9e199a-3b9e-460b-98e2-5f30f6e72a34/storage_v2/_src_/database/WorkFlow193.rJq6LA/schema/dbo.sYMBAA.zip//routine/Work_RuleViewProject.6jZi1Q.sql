CREATE   PROC  [dbo].[Work_RuleViewProject] 
   @projectId AS NVARCHAR(50)                              
   ,@UserId as nvarchar(50)=''            
   AS 
   select COUNT(c.id) AS dem    
   from Dynamic.Data_RuleViewProject a
   cross apply Split(a.Department,';' ) b
   inner join Dynamic.Data_RESOURCEDA c on c.Department=b.Item
   where a.[User]=@UserId and c.UserWorkflowId=@projectId 
go

