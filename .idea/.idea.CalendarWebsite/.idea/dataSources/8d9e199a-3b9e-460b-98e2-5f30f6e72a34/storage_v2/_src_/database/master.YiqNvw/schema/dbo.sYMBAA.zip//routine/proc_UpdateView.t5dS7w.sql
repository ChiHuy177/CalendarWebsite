CREATE PROCEDURE [dbo].[proc_UpdateView](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @ViewId uniqueidentifier,
    @UserId int,
    @IsPersonalView bit,
    @View tCompressedString,
    @DisplayName nvarchar(255),
    @ContentTypeId tContentTypeId,
    @ViewFlags int,
    @ViewMask int,
    @Level tinyint,
    @BypassCheck bit = 0, 
    @bUpdateAllPersonalViews bit = 0,
    @LCID int = 0
    )
AS
    SET NOCOUNT ON
    DECLARE @ViewSize int
    DECLARE @NewSize int
    DECLARE @Ret int
    DECLARE @IsCurrentVersion bit
    DECLARE @IsForceCheckout bit
    DECLARE @DeleteTransactionId varbinary(16)
    DECLARE @OldContentTypeId tContentTypeId
    DECLARE @WebId uniqueidentifier
    DECLARE @PageUrlId uniqueidentifier
    DECLARE @WebLanguage int
    DECLARE @AllowMUI bit
    SET @Ret = 0
    SELECT TOP 1
        @Level = AD.Level,
        @IsCurrentVersion = AD.IsCurrentVersion,
        @IsForceCheckout = CASE 
            WHEN L.tp_Flags & 0x40000 = 0x40000 THEN 1
            ELSE 0 END,
        @DeleteTransactionId = AD.DeleteTransactionId,
        @OldContentTypeId = WP.tp_ContentTypeId,
        @WebId = AD.WebId,
        @PageUrlId = AD.Id
    FROM 
        TVF_WebParts_SitePartIdLvl(@SiteId, @ViewId, @Level) AS WP
    CROSS APPLY
        TVF_AllDocs_Id_Level(WP.tp_SiteId, WP.tp_PageUrlID, WP.tp_Level) AS AD
    OUTER APPLY
        fn_Lists_DocLibItem(
            AD.SiteId,
            AD.WebId,
            AD.ListId,
            AD.DoclibRowId) AS L
    WHERE
        WP.tp_ListId = @ListId
    OPTION (FORCE ORDER)
    IF @Level IS NULL
        RETURN 3
    IF @BypassCheck = 0
    BEGIN
        IF @DeleteTransactionId <> 0x
            RETURN 3
        IF @IsCurrentVersion = 0 AND @IsPersonalView = 0
            RETURN 33
        IF (@IsForceCheckout = 1 AND @Level <> 255 AND
            @IsPersonalView = 0)
            RETURN 158
    END
    IF @LCID = 0
    BEGIN
        SET @WebLanguage = 0
        SET @AllowMUI = 0
    END
    ELSE
    BEGIN
    	SELECT TOP 1
        	@WebLanguage = W.Language,
	        @AllowMUI = W.AllowMUI
    	FROM
        	TVF_Webs_NoLock_Id(@SiteId, @WebId) AS W
    END
    IF @View IS NOT NULL
    BEGIN
        SET @ViewSize = DATALENGTH(@View)
        EXEC @Ret = proc_OnUpdateWebParts
            @SiteId,
            @ViewId,
            @Level,
            @ViewSize,
            NULL,    
            NULL,    
            NULL,    
            NULL,    
            NULL,    
            @DeleteTransactionId,
            @NewSize OUTPUT
    END
    IF (0 <> @Ret)
        GOTO cleanup
    UPDATE
        WP
    SET
        WP.tp_View =
            CASE
                WHEN @View IS NULL
                    THEN WP.tp_View
                WHEN @ViewSize = 0
                    THEN NULL
                ELSE @View
            END,
        WP.tp_DisplayName = CASE WHEN @DisplayName IS NULL OR (@AllowMUI = 1 AND @WebLanguage <> @LCID AND @IsPersonalView = 0) THEN
            WP.tp_DisplayName ELSE @DisplayName END,
        WP.tp_ContentTypeId = ISNULL(@ContentTypeId, WP.tp_ContentTypeId),
        WP.tp_Flags = CASE WHEN @ViewFlags IS NULL THEN WP.tp_Flags
            ELSE ((WP.tp_Flags & ~@ViewMask) |
                (@ViewFlags & @ViewMask))
            END,
        WP.tp_Size = CASE WHEN @View IS NULL THEN
            WP.tp_Size ELSE ISNULL(@NewSize, 0) END
    FROM
        TVF_WebParts_SitePageIdLvl(
            @SiteId, 
            @PageUrlId, 
            @Level) AS WP
    WHERE
        WP.tp_ID = @ViewId AND
        ((@bUpdateAllPersonalViews = 1 OR
         (WP.tp_UserID IS NOT NULL AND
            WP.tp_UserID = @UserId) AND
            @IsPersonalView = 1) OR
            (WP.tp_UserID IS NULL AND
                @IsPersonalView = 0))
    IF @@ROWCOUNT = 1
    BEGIN
        SET @Ret = 0
    END
    ELSE
    BEGIN
        SET @Ret = 3
        GOTO cleanup
    END
    IF (@DisplayName IS NOT NULL AND @AllowMUI = 1 AND @WebLanguage <> @LCID AND @IsPersonalView = 0)
    BEGIN
        DECLARE @TitleResource nvarchar(48)
        SET @TitleResource = '_ViewTitle{' + CAST(@ViewId AS nvarchar(36)) + '}'
        EXEC proc_UpdateUserResource
            @SiteId,
            @WebId,
            @ListId,
            @TitleResource,
            9,
            0,
            0,
            @LCID,
            @DisplayName,
            NULL
    END
    IF ((@ViewFlags & 16777216) <> 0)
    BEGIN
        EXEC @Ret = proc_MakeViewMobileDefaultForList @SiteId, @ListId, @ViewId
        IF @Ret <> 0
        BEGIN
            GOTO cleanup
        END
    END
    ELSE
    BEGIN
        EXEC @Ret = proc_EnsureMobileDefaultViewForList @SiteId, @ListId
        IF @Ret <> 0
        BEGIN
            GOTO cleanup
        END
    END
    IF ((@ViewFlags & 268435456) <> 0)
    BEGIN
        SET @ContentTypeId = ISNULL(@ContentTypeId, @OldContentTypeId)
        EXEC @Ret = proc_MakeViewDefaultForContentType 
            @SiteId,
            @ListId, 
            @ViewId, 
            @ContentTypeId
        IF @Ret <> 0
            GOTO cleanup
    END
cleanup:
    IF (0 <> @@ERROR OR 0 <> @Ret)
    BEGIN
        RETURN CASE WHEN (0 = @Ret) THEN 1 ELSE @Ret END
    END
    EXEC proc_LogChange @SiteId, @WebId, @ListId, NULL, NULL,
        @ViewId, NULL, NULL, 8192, 4096, NULL
    RETURN 0

go

