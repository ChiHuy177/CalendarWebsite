CREATE PROCEDURE [dbo].[proc_InsertListUniqueField](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier)
AS
    SET NOCOUNT ON;
    DECLARE @ReturnCode int,
            @RowCount int;
    SET @ReturnCode = 0;
    DECLARE @ListReadSecurity int;
    SELECT TOP 1 
        @ListReadSecurity = L.tp_ReadSecurity
    FROM 
        TVF_Lists_Id(@SiteId, @ListId) AS L
    IF (@ListReadSecurity = 0x00000002)
    BEGIN
        SET @ReturnCode = 5069;
        GOTO DONE;
    END
    IF EXISTS(SELECT TOP 1 1 FROM TVF_AllListUniqueFields_SiteListField(@SiteId, @ListId, @FieldId))
    BEGIN
        SET @ReturnCode = 1359;
        GOTO DONE;
    END
    INSERT INTO AllListUniqueFields
    (
        SiteId,
        ListId,
        FieldId
    )
    VALUES
    (
        @SiteId,
        @ListId,
        @FieldId
    )
DONE:
    RETURN @ReturnCode

go

