-- [Work_GetEmployeeByProject] 343927,''           
   CREATE   PROC [dbo].[Work_GetEmployeeByProject]           
   @projectId AS NVARCHAR(50)           
   ,@UserId as nvarchar(50)=''           
   AS           
   ;     
   if(@projectId='all')           
   begin           
   select 'P:'+ trim(str(a.Id)) AS Id ,AccountId,AccountName,Name,FullName,a.Email,0 as Contribute,0 as TotalWork  
   ,FullName +' - ' + AccountName +' - '+b.Title as Label, 'P:'+ trim(str(a.Id)) as value
   from PersonalProfile a  
   inner join Department b on a.DepartmentId=b.Id  
   where UserStatus<>-1 group by a.id,AccountId,AccountName,Name,FullName,a.Email  ,b.Title         
   end           
   else      
   begin           
   declare @check as int=0   
   set @check =(select COUNT(*) from Dynamic.Data_RESOURCEDA where UserWorkflowId=@projectId and AddAllUserWhenAddWork=1)  
   declare @tb table (Id nvarchar(50) , AccountId nvarchar(50), AccountName nvarchar(150)           
   , Name nvarchar(250), FullName nvarchar(250), Email nvarchar(150),Contribute int, TotalWork int, DepartmentId bigint)           
   declare @UserManager table(userId nvarchar(50), [Index] int)           
   insert into @UserManager           
   select * from (           
   SELECT            
   b.value AS userId           
   , 1 as [Index]           
   FROM DYNAMIC.Data_RESOURCEDA AS a            
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b           
   WHERE a.UserWorkflowId = @projectId and left(trim(b.value ),2)='P:'           
   union           
   SELECT            
   'P:'+trim(str(d.Id)) AS userId           
   , 1 as [Index]           
   FROM DYNAMIC.Data_RESOURCEDA AS a            
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b           
   inner join GroupPersonalProfile c on REPLACE(b.value,'G:','')=c.GroupsId           
   INNER JOIN PersonalProfile d ON d.Id =c.PersonalProfilesId           
   WHERE a.UserWorkflowId  = @projectId and left(trim(b.value ),2)='G:'           
   ) a           
   --%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
   select * into #a from (      
   SELECT            
   b.value AS userId           
   FROM DYNAMIC.Data_RESOURCEDA AS a            
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b           
   WHERE a.UserWorkflowId  = @projectId         
   union           
   SELECT            
   b.value AS userId           
   FROM DYNAMIC.Data_RESOURCEDA AS a            
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b           
   WHERE a.UserWorkflowId  = @projectId           
   ) a           
   if(@check>0)  
   begin   
   insert into @tb           
   SELECT 'P:'+ trim(str(c.Id)) AS Id           
   ,[AccountId]           
   ,[AccountName]            
   ,[Name]           
   ,[FullName]            
   ,[Email]           
   ,0 as Contribute           
   ,0 as TotalWork           
   ,c.DepartmentId  
   from PersonalProfile c where c.UserStatus = 1  
   end  
   else  
   begin   
   insert into @tb           
   SELECT 'P:'+ trim(str(c.Id)) AS Id           
   ,[AccountId]           
   ,[AccountName]            
   ,[Name]           
   ,[FullName]            
   ,[Email]           
   ,0 as Contribute           
   ,0 as TotalWork        
   ,c.DepartmentId  
   FROM #a a           
   INNER JOIN PersonalProfile c ON REPLACE(a.userId,'P:','') =trim(str(c.Id))           
   where left(trim(a.userId),1)='P' and c.UserStatus = 1  
   union  
   SELECT 'P:'+trim(str(b.Id)) AS Id           
   ,[AccountId]           
   ,[AccountName]           
   ,[Name]           
   ,[FullName]            
   ,[Email]           
   ,0 as Contribute          
   ,0 as TotalWork        
   ,b.DepartmentId  
   FROM #a a            
   inner join GroupPersonalProfile c on REPLACE(a.userId,'G:','')=c.GroupsId           
   INNER JOIN PersonalProfile b ON b.Id =c.PersonalProfilesId           
   where left(trim(a.userId),1)='G' and b.UserStatus = 1  
   end  
   if(@UserId='')           
   begin           
   select a.Id,AccountId,AccountName,Name,FullName,a.Email,Contribute,TotalWork,           
   case when b.userId<>'' then N'Quản lý dự án' else N'Thành viên' end as Position           
   ,FullName +' - ' + AccountName +' - '+c.Title as Label, a.Id as Value    
   from @tb a   
   left join @UserManager b on a.Id=b.userId       
   inner join Department c on a.DepartmentId=c.Id  
   order by b.[Index] desc           
   end           
   else           
   begin           
   select a.Id,AccountId,AccountName,Name,FullName,a.Email,Contribute,TotalWork     
   ,FullName +' - ' + AccountName +' - '+c.Title as Label, a.Id as Value    
   from @tb  a         
   inner join Department c on a.DepartmentId=c.Id  
   where a.Id=@UserId group by a.id,AccountId,AccountName,Name,FullName,a.Email,Contribute,TotalWork ,c.Title         
   end           
   drop table #a           
   end
go

