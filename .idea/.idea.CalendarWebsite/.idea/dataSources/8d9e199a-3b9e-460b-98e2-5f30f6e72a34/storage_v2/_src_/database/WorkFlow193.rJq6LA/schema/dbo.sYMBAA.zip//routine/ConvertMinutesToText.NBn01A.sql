-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE   FUNCTION [dbo].[ConvertMinutesToText]
(
	@theMinutes int
	,@Lang NVARCHAR(MAX) = 'vi'
)
RETURNS nvarchar(500)
AS
BEGIN
	DECLARE @days nvarchar(MAX) = '';
	DECLARE @hours nvarchar(MAX) = '';
	DECLARE @mins nvarchar(MAX) = '';
	DECLARE @Res nvarchar(MAX) = (CASE WHEN @Lang = 'vi' THEN '0 phút' ELSE '0 minute' END);

	IF @theMinutes = 0
	BEGIN
		RETURN ''
	END

	IF (@theMinutes / 1440) > 0
	BEGIN
		SET @days = convert(VARCHAR(15), @theMinutes / 1440) + (CASE @Lang WHEN 'vi' THEN N' ngày ' ELSE N' days ' END)
	END

	IF ((@theMinutes % 1440) / 60) > 0
	BEGIN
		SET @hours = convert(VARCHAR(2),(@theMinutes % 1440) / 60) + (CASE @Lang WHEN 'vi' THEN N' giờ ' ELSE N' hours ' END)
	END

	IF (@theMinutes % 60) > 0
	BEGIN
		SET @mins = convert(VARCHAR(2),(@theMinutes % 60)) + (CASE @Lang WHEN 'vi' THEN N' phút ' ELSE N' minutes ' END)
	END

	IF LTRIM(RTRIM(@days + @hours + @mins)) <> ''
		SET @Res = LTRIM(RTRIM(@days + @hours + @mins))
	
	RETURN @Res;
END
go

