CREATE   PROCEDURE [Dynamic].[WorkflowDynamicDetailData_DeleteAll]
	-- Add the parameters for the stored procedure here
	@UserWorkflowId BIGINT
	,@WorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @TableName NVARCHAR(MAX), @TableCode NVARCHAR(MAX);
	DECLARE @SqlScript NVARCHAR(MAX) = '';
	IF EXISTS (
			SELECT TOP 1 Id
			FROM UserWorkflow
			WHERE Id = @UserWorkflowId
			)
	BEGIN
		SET @TableCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
		SET @TableName = CONCAT (
			'Dynamic.Detail_'
			,dbo.fn_StripCharacters(@TableCode, '^a-z0-9')
			);

		SET @SqlScript = @SqlScript + 'DELETE ' + @TableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';';
		SET @SqlScript = @SqlScript + ' DELETE RecursivePermission WHERE ParentUserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR)
						+ ' AND WorkflowId = ' + CAST(@WorkflowId AS VARCHAR) + ';';
		print @SqlScript
		EXEC sp_ExecuteSql @SqlScript;
	END
END
go

