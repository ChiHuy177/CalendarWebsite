CREATE PROCEDURE [dbo].[proc_DoesUserHaveWorkItemInTypes] (
        @UserId                int,
        @WorkItemType1         uniqueidentifier  = NULL,
        @WorkItemType2         uniqueidentifier  = NULL,
        @WorkItemType3         uniqueidentifier  = NULL,
		@WorkItemType4         uniqueidentifier  = NULL,
        @WorkItemType5         uniqueidentifier  = NULL
        )
AS
    SET NOCOUNT ON
	IF EXISTS (
		SELECT TOP 1
			1
		FROM 
		    dbo.ScheduledWorkItems WITH (FORCESEEK(ScheduledWorkItems_OnDateType([Type])))
		WHERE
			UserId = @UserId AND
			[Type] IN (@WorkItemType1, @WorkItemType2, @WorkItemType3, @WorkItemType4, @WorkItemType5))
	BEGIN
		RETURN 1
	END
    RETURN 0

go

