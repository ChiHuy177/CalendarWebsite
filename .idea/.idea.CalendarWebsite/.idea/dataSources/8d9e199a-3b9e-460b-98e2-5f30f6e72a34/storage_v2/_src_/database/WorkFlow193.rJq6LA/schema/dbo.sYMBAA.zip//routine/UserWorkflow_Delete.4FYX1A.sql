
-- =============================================
-- Author:		Duy Dam
-- Create date: 22/10/2021
-- Description:	Remove temp USerWorkflow in DB
-- =============================================
CREATE   PROCEDURE [dbo].[UserWorkflow_Delete] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowId BIGINT;
	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @WorkflowTableName NVARCHAR(MAX);
	DECLARE @CheckListTableName NVARCHAR(MAX);
	DECLARE @SqlScript NVARCHAR(4000);

	IF (
			EXISTS (
				SELECT *
				FROM [dbo].[UserWorkflow]
				WHERE Id = @UserWorkflowId
					AND IsDraft = 1
				)
			)
	BEGIN
		SET @WorkflowId = (
				SELECT WorkflowId
				FROM [dbo].[UserWorkflow]
				WHERE Id = @UserWorkflowId
				)
		SET @TableName = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @WorkflowId
				)
		SET @WorkflowTableName = CONCAT (
				'Dynamic.Workflow_'
				,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
				);
		SET @CheckListTableName = CONCAT (
				'Dynamic.CheckList_'
				,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
				);
		SET @SqlScript = 'DELETE ' + @WorkflowTableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR);

		EXEC sp_executesql @SqlScript;

		SET @SqlScript = 'DELETE ' + @CheckListTableName + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR);

		EXEC sp_executesql @SqlScript;

		DELETE [dbo].[UserWorkflowLinking]
		WHERE MainUserWorkflowId = @UserWorkflowId;

		DELETE [dbo].[UserWorkflowShare]
		WHERE UserWorkflowId = @UserWorkflowId;

		DELETE [dbo].[UserWorkflowSeen]
		WHERE UserWorkflowId = @UserWorkflowId;

		DELETE [dbo].[UserWorkflow]
		WHERE Id = @UserWorkflowId;
	END
END
go

