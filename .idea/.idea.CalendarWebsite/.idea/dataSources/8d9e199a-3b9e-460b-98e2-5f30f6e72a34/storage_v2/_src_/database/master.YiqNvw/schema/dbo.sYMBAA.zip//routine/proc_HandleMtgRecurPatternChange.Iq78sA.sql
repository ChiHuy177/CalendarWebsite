CREATE PROCEDURE [dbo].[proc_HandleMtgRecurPatternChange]
(
    @SiteId                 uniqueidentifier,
    @WebId                  uniqueidentifier,
    @MtgListID              uniqueidentifier,
    @InstanceIDStart        int,   
    @InstanceIDEndDel       int,   
    @InstanceIDEndSplit     int,   
    @DTStamp                datetime,   
    @UserId                 int,
    @AppPrincipalId         int,
    @UserTitle              nvarchar(255),
    @InstanceIDSplitMax     int = NULL OUTPUT,  
    @RequestGuid            uniqueidentifier = NULL OUTPUT  
)
AS
    SET NOCOUNT ON
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
DELETE_DELETE_EXCPS:
    IF (@InstanceIDStart >= @InstanceIDEndDel)
        GOTO FETCH_MAX_SPLIT_INSTANCEID
    DECLARE @Exceptions_cursor CURSOR
    SET @Exceptions_cursor = CURSOR
        LOCAL
        FAST_FORWARD
    FOR
    SELECT
        UD.tp_ID
    FROM
        TVF_UserData_List_Mtg(@SiteId, @MtgListID) AS UD
    WHERE
        UD.int1 = 3 AND
        UD.tp_InstanceID >= @InstanceIDStart AND
        UD.tp_InstanceID < @InstanceIDEndDel AND
        UD.tp_RowOrdinal = 0
    DECLARE @ItemId int
    OPEN @Exceptions_cursor
    FETCH NEXT 
    FROM 
        @Exceptions_cursor
    INTO
        @ItemId
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @RetDropRecord int SET @RetDropRecord = 0 BEGIN TRAN
        EXEC @RetDropRecord = proc_DropListRecord
            @SiteId,
            @WebId,
            @MtgListID,
            NULL,       
            @ItemId,
            1,
            0,
            @UserTitle,
            NULL,       
            @UserId,
            @AppPrincipalId,
            0,          
            NULL,       
            @RequestGuid = @RequestGuid OUTPUT
        IF (@RetDropRecord <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
        FETCH NEXT 
        FROM 
            @Exceptions_cursor
        INTO
            @ItemId
    END
    CLOSE @Exceptions_cursor
    DEALLOCATE @Exceptions_cursor
SPLIT_MODIFY_EXCPS:
    IF (@InstanceIDStart >= @InstanceIDEndSplit)
        GOTO FETCH_MAX_SPLIT_INSTANCEID
    DECLARE @Now datetime
    SET @Now = GETUTCDATE()
    UPDATE 
        UD
    SET
        UD.tp_Version = UD.tp_Version + 1,
        UD.tp_Editor = @UserId,
        UD.tp_Modified = @Now
    FROM
        TVF_UserData_List_Mtg(@SiteId, @MtgListID) AS t
    CROSS APPLY
        TVF_UserData_ListItem(t.tp_SiteId, t.tp_ListId, t.tp_ID) AS UD
    WHERE
        t.int1 = 2 AND
        t.tp_InstanceID >= @InstanceIDStart AND
        t.tp_InstanceID < @InstanceIDEndSplit AND
        t.tp_RowOrdinal = 0
    UPDATE
        UserData
    SET
        int1  = 0,
        bit1 = (CASE WHEN datetime1 < @DTStamp
            THEN    
                (CASE (int4 & (0x10 - 1))
                    WHEN 3 THEN 1
                    WHEN 8   THEN 1
                    ELSE 0
                    END)
            ELSE 1
            END),
        int4 = (CASE WHEN datetime1 < @DTStamp
            THEN    
                (CASE (int4 & (0x10 - 1))
                    WHEN 3 THEN 3
                    WHEN 8   THEN 3
                    ELSE 0
                    END)
            ELSE 3
            END),
        bit3 = 0, uniqueidentifier1 = NULL, datetime3 = NULL, bit2 = NULL
    FROM
        TVF_UserData_List_Mtg(@SiteId, @MtgListID) AS UserData
    WHERE
        int1 = 2 AND
        tp_InstanceID >= @InstanceIDStart AND
        tp_InstanceID < @InstanceIDEndSplit AND
        tp_RowOrdinal = 0
FETCH_MAX_SPLIT_INSTANCEID:
    IF @InstanceIDSplitMax IS NULL  
        GOTO DONE
    SET @InstanceIDSplitMax = -3
    SELECT
        @InstanceIDSplitMax = MAX(UD.tp_InstanceID)
    FROM
        TVF_UserData_List_Mtg(@SiteId, @MtgListID) AS UD
    WHERE
        UD.int1 = 0 AND
        UD.tp_InstanceID < @InstanceIDEndSplit AND
        UD.tp_RowOrdinal = 0
DONE:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    IF (@RET = 0)
    BEGIN
        EXEC proc_UpdateListItemCount @SiteId, @MtgListID
        EXEC proc_UpdateDiskUsed @SiteId
    END
    RETURN @RET

go

