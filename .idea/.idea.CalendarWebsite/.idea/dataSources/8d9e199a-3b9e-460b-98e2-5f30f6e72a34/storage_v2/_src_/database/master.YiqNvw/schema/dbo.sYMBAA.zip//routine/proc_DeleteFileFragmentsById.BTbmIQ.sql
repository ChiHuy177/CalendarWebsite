CREATE PROCEDURE [dbo].[proc_DeleteFileFragmentsById]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @DocVersion int,
    @ContentVersion int,
    @UserId int,
    @Partition tinyint,
    @Id bigint,
    @DeleteUntil bit,
    @DeleteOnly bit,
    @CheckPerms bit,
    @UpdateQuota bit,
    @QuotaChange bigint OUTPUT
)
AS
    SET NOCOUNT ON
    DECLARE @quotaOrLockStatus int
    DECLARE @rowCountForSum int
    SET @rowCountForSum = 0    
    SET @QuotaChange = 0
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    IF @DeleteUntil = 1 AND @DeleteOnly = 1
    BEGIN
        SET @iRet = 87
        GOTO cleanup
    END
    IF @CheckPerms = 1
    BEGIN
        EXEC @iRet = dbo.proc_FileFragmentPermissionCheck @SiteId, @DocId, @UserId, @DocVersion, @ContentVersion, @Partition, 0
        IF @iRet <> 0 
            GOTO cleanup
    END
    IF @DeleteOnly = 1
    BEGIN
        SELECT TOP(1)
            @QuotaChange = -(ISNULL((SUM(CAST((F.BlobSize) AS BIGINT))),0))
        FROM
            TVF_AllFileFragments_XLock_DocIdPartId(@SiteId, @DocId, @Partition, @Id) AS F
        DELETE TOP(1)
            F
        FROM 
            TVF_AllFileFragments_DocIdPartId(@SiteId, @DocId, @Partition, @Id) AS F
    END
    ELSE IF @DeleteUntil = 1
    BEGIN
        WHILE (1=1)
        BEGIN
            SELECT
                @rowCountForSum = COUNT(1),
                @QuotaChange = @QuotaChange - (ISNULL((SUM(CAST((FD.BlobSize) AS BIGINT))),0))
            FROM 
            (
                SELECT TOP(4500)
                    F.*
                FROM
                    TVF_AllFileFragments_XLock_DocIdPartBeforeId(@SiteId, @DocId, @Partition, @Id) AS F
                ORDER BY
                    F.Id ASC
            ) AS FD
            OPTION (MAXDOP 1, FORCE ORDER)
            IF @rowCountForSum IS NULL OR @rowCountForSum = 0
                BREAK
            DELETE
                FD
            FROM 
            (
                SELECT TOP(@rowCountForSum)
                    F.*
                FROM
                    TVF_AllFileFragments_DocIdPartBeforeId(@SiteId, @DocId, @Partition, @Id) AS F
                ORDER BY
                    F.Id ASC
            ) AS FD
            OPTION (MAXDOP 1, FORCE ORDER)
        END
    END
    ELSE
    BEGIN
        WHILE (1=1)
        BEGIN
            SELECT 
                @rowCountForSum = COUNT(1),
                @QuotaChange = @QuotaChange - (ISNULL((SUM(CAST((FD.BlobSize) AS BIGINT))),0))
            FROM 
            (
                SELECT TOP(4500)
                    F.*
                FROM
                    TVF_AllFileFragments_XLock_DocIdPart(@SiteId, @DocId, @Partition) AS F
                ORDER BY
                    F.Id ASC                    
            ) AS FD
            OPTION (MAXDOP 1, FORCE ORDER)
            IF @rowCountForSum IS NULL OR @rowCountForSum = 0
                BREAK
            DELETE
                FD
            FROM 
            (
                SELECT TOP(@rowCountForSum)
                    F.*
                FROM
                    TVF_AllFileFragments_DocIdPart(@SiteId, @DocId, @Partition) AS F                        
                ORDER BY
                    F.Id ASC
            ) AS FD
            OPTION (MAXDOP 1, FORCE ORDER)
        END
    END
    IF @UpdateQuota = 1
    BEGIN
        SELECT @quotaOrLockStatus = dbo.fn_IsOverQuotaOrWriteLocked(@SiteId)
        IF @quotaOrLockStatus > 1
        BEGIN
            SET @iRet = 212
            GOTO cleanup
        END
        IF @QuotaChange <> 0 
            EXEC dbo.proc_QMChangeSiteDiskUsedAndContentTimestamp @SiteId, @QuotaChange, 0, @DocId
    END
cleanup:
     IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
     RETURN @iRet

go

