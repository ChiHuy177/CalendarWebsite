-- Work_GetPersonInf 
   -- [Work_ProjectGetPersonInf] '217001','ThanhPhanThamGia' 
   CREATE   PROC [dbo].[Work_ProjectGetPersonInf] 
   @UserWorkflowId AS NVARCHAR(max) 
   ,@columnName as NVARCHAR(max) 
   as 
   declare @sql as nvarchar(max) 
   set @sql=' 
   declare @tab table( userId nvarchar(50),ProjectId bigint) 
   insert into @tab 
   SELECT b.[value] AS kq 
   ,a.UserWorkflowId
   FROM [Dynamic].Data_RESOURCEDA AS a 
   CROSS APPLY STRING_SPLIT(ISNULL(a.'+@columnName+',''''),'';'') AS b 
   where a.UserWorkflowId in (select * from STRING_SPLIT('''+@UserWorkflowId+''','','')) 
   SELECT b.userId as Id 
   ,AccountName 
   ,Name 
   ,FullName 
   ,Email 
   ,b.ProjectId
   FROM [dbo].[PersonalProfile] a 
   INNER JOIN @tab b ON a.Id = REPLACE(b.userId, ''P:'', '''') 
   WHERE LEFT(b.userId,2)= ''P:'' 
   union 
   SELECT ''P:''+ trim(str(c.id)) as Id 
   ,AccountName 
   ,Name 
   ,FullName 
   ,Email 
   ,a.ProjectId
   FROM @tab a 
   inner join GroupPersonalProfile b ON b.GroupsId = REPLACE(a.userId, ''G:'', '''') 
   inner join [PersonalProfile] c on c.Id=b.PersonalProfilesId 
   WHERE LEFT(a.userId,2)= ''G:'' 
   ' 
   EXEC (@SQL) 
   print(@sql) 
go

