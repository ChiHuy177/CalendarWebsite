CREATE 
 
 
 PROCEDURE [dbo].[ChekListDynamic_GetAll] @WorkflowId BIGINT
	,@UserWorkflowId BIGINT = NULL
	,@CheckListId BIGINT = NULL
	,@Email NVARCHAR(max) = ''
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@CheckListId_Str AS NVARCHAR(MAX)
		,@UserWorkflowId_Str AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);

	IF @CheckListId IS NULL
		SET @CheckListId_Str = 'NULL'
	ELSE
		SET @CheckListId_Str = CAST(@CheckListId AS VARCHAR)

	IF @UserWorkflowId IS NULL
		SET @UserWorkflowId_Str = 'NULL'
	ELSE
		SET @UserWorkflowId_Str = CAST(@UserWorkflowId AS VARCHAR)

	--SET @Sql = 'SELECT a.*, b.IsReplaceText as IsReplaceText, b.IsOnlyAllowedAttachedAfterApproving as IsOnlyAllowedAttachedAfterApproving, b.IsAutoWatermarkEmbedWhenDownload AS IsAutoWatermarkEmbedWhenDownload, d.Title As DocumentTypeTitle, d.TitleEN as DocumentTypeTitleEN, p.FullName As CreatedByName, pm.FullName as ModifiedByName, b.Permission as Permission , (CASE a.CreatedBy WHEN N''' + @Email + ''' THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END) AS IsAllowEdit,u.Id  as UserId' + ' FROM ' + @TableName + ' a LEFT JOIN CheckList b On a.CheckListId = b.Id LEFT JOIN DocumentType d on b.TypeId = d.Id' + ' OUTER APPLY 
 --   (SELECT TOP 1 p.*
 --    FROM PersonalProfile p
 --    WHERE p.Email = a.CreatedBy
 --    ORDER BY p.IsDeleted
 --   ) AS p' + ' LEFT JOIN PersonalProfile pm on pm.Email = a.ModifiedBy LEFT JOIN UserWorkflow u ON u.Id = a.UserWorkflowId' + ' WHERE a.IsDeleted = 0 and ISNUMERIC(a.Path) = 1 and ' + '(ISNULL(' + @CheckListId_Str + ', 1) = 1 or a.CheckListId = ' + @CheckListId_Str + ') and ' + '(ISNULL(' + @UserWorkflowId_Str + ', 1) = 1 or a.UserWorkflowId = ' + @UserWorkflowId_Str + 
	--	') order by (CASE WHEN a.LastModified is null THEN a.CreatedTime ELSE a.LastModified END)';

	set @Sql = '
				SELECT a.*
					,b.IsReplaceText AS IsReplaceText
					,b.IsOnlyAllowedAttachedAfterApproving AS IsOnlyAllowedAttachedAfterApproving
					,b.IsAutoWatermarkEmbedWhenDownload AS IsAutoWatermarkEmbedWhenDownload
					,(CASE WHEN job.Id IS NULL THEN b.IsSignaturedManually ELSE CAST(0 AS BIT) END)AS IsSignaturedManually
					,d.Title AS DocumentTypeTitle
					,d.TitleEN AS DocumentTypeTitleEN
					,p.FullName AS CreatedByName
					,pm.FullName AS ModifiedByName
					,b.Permission AS Permission
					,(
						CASE a.CreatedBy
							WHEN N''' + @Email + '''
								THEN CAST(1 AS BIT)
							ELSE CAST(0 AS BIT)
							END
						) AS IsAllowEdit
					,u.Id AS UserId
					,u.WorkflowId as WorkflowId
				FROM ' + @TableName + ' a
				LEFT JOIN CheckList b ON a.CheckListId = b.Id
				LEFT JOIN DocumentType d ON b.TypeId = d.Id
				OUTER APPLY (
					SELECT TOP 1 p.*
					FROM PersonalProfile p
					WHERE p.Email = a.CreatedBy
					ORDER BY p.IsDeleted
					) AS p
				LEFT JOIN PersonalProfile pm ON pm.Email = a.ModifiedBy
				LEFT JOIN UserWorkflow u ON u.Id = a.UserWorkflowId
				OUTER APPLY (
					SELECT TOP 1 u.Id
					FROM UserWorkflowJob j
					WHERE j.UserWorkflowId = a.UserWorkflowId
						AND j.UserCheckListId = a.Id
					ORDER BY j.IsDeleted
					) AS job
				WHERE a.IsDeleted = 0
					AND ISNUMERIC(a.Path) = 1
					AND (
						ISNULL(' + @CheckListId_Str + ', 1) = 1
						OR a.CheckListId = ' + @CheckListId_Str + '
						)
					AND (
						ISNULL(' + @UserWorkflowId_Str + ', 1) = 1
						OR a.UserWorkflowId = ' + @UserWorkflowId_Str +'
						)
				ORDER BY (
						CASE 
							WHEN a.LastModified IS NULL
								THEN a.CreatedTime
							ELSE a.LastModified
							END
						)

				';
	PRINT @Sql

	EXEC sp_executesql @Sql;
END
go

