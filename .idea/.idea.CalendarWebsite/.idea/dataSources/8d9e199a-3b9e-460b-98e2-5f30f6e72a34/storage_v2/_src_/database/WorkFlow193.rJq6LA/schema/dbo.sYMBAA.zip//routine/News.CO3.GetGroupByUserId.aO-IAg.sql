-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[News.CO3.GetGroupByUserId] @userId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

SELECT dw.*

FROM [Dynamic].[Workflow_GroupNews] [dw]
INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
WHERE u.IsDeleted = 0

  AND (
    (
      ISNULL(dbo.JSON_VALUE([dw].Data, '$.Admin'), '') <> ''
      AND (
	  (dbo.JSON_VALUE([dw].Data, '$.Admin') LIKE ('%;P:' + CAST(@userId AS VARCHAR) ))
	  or	 
	  (dbo.JSON_VALUE([dw].Data, '$.Admin') LIKE ('%P:' + CAST(@userId AS VARCHAR) + ';%'))
	  or
	  (dbo.JSON_VALUE([dw].Data, '$.Admin') = ('P:' + CAST(@userId AS VARCHAR) ))
	  )
      )
	      OR (
      ISNULL(dbo.JSON_VALUE([dw].Data, '$.Member'), '') <> ''
      AND (
	  (dbo.JSON_VALUE([dw].Data, '$.Member') LIKE ('%;P:' + CAST(@userId AS VARCHAR) ))
      or
	   (dbo.JSON_VALUE([dw].Data, '$.Member') LIKE ('%P:' + CAST(@userId AS VARCHAR) + ';%'))
	   or
	    (dbo.JSON_VALUE([dw].Data, '$.Member') = (CAST(@userId AS VARCHAR)))
	  ))
    )
END
go

