-- [Work_CheckCompleteRunOnlyOneWork] 'node-00809b48-ac7d-46c2-904b-905326ed0d4e,node-378b852b-617d-47d1-b0b4-0f3261c738a3,node-65477f98-c689-4835-a5de-6875e9fe0ff4'      
 -- [Work_CheckCompleteRunOnlyOneWork] 'node-00809b48-ac7d-46c2-904b-905326ed0d4e,node-378b852b-617d-47d1-b0b4-0f3261c738a3,node-65477f98-c689-4835-a5de-6875e9fe0ff4,node-fdb6887d-93b4-40f4-a6a9-d2449eb68249,node-864fd717-b514-44cd-9d5d-829c4155dff0'    
CREATE PROC [dbo].[Work_CheckCompleteRunOnlyOneWork]                  
@nodeId as nvarchar(1000)       
,@parentWork nvarchar(100) =''    
as               
          
declare @Total as int,@Compelete as int              
select b.* into #a from Dynamic.Data_WORK a                  
inner join Dynamic.Data_RESOURCETTFC b on a.TrangThaiCongViec=b.UserWorkflowId                  
where a.Nodeid in (select Item from Split(@nodeId,',')) and a.CongViecCha = TRIM(@parentWork)  and ISNULL(a.IsActive,'True')='True'                      
                  
set @Total= (select COUNT(*) from #a )      
set @Compelete=( select COUNT(*) from #a where TrangThaiCongViec=N'Hoàn thành')                   
                  
if(@Compelete =@Total and @Total>0 and @Compelete >0)        
begin         
 select 1        
end        
else        
begin         
select 0        
end         
drop table #a                  
go

