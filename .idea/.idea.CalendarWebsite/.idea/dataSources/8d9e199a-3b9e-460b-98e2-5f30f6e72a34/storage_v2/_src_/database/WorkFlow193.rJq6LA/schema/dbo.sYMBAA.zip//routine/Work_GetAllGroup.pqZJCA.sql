CREATE   PROC [dbo].[Work_GetAllGroup]   
   @projectId as char(50)   =332666
   ,@userId as nvarchar(50)='P:287'  
   as 
   SELECT a.TenCV as Name   
   ,a.UserWorkflowId   
   ,0 as Qty
   into #a
   FROM DYNAMIC.Data_NHOMCV AS a   
   inner join UserWorkflow b on a.UserWorkflowId=b.Id  
   where ISNULL(b.IsDeleted,0)=0
   select b.UserWorkflowId,COUNT(a.UserWorkflowId) as Qty 
   into #b
   from Dynamic.Data_WORK a
   inner join  #a b on b.UserWorkflowId=a.Loaicv
   where ISNULL(a.IsActive,'True')='True' and ISNULL(a.WorkRepeat,'False')='False'   
   and @userId = (case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoixuly,''), ';') where value=@userId )>0 then @userId   
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoigiao,''), ';') where value=@userId )>0 then @userId   
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoiphoihop,''), ';') where value=@userId )>0 then @userId   
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoitheodoi,''), ';') where value=@userId )>0 then @userId   
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.NguoiXuLyDauTien,''), ';') where value=@userId )>0 then @userId   
   else '' end   
   )   
   and a.Duan =@projectId
   group by b.UserWorkflowId
   update a set a.Qty=b.Qty
   from #a a inner join #b b on a.UserWorkflowId=b.UserWorkflowId
   select * from #a
   drop table #a
   drop table #b
go

