CREATE PROCEDURE [dbo].[proc_DeleteEventReceiversBySourceId](
    @SourceId tContentTypeId,
    @SourceType int,
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @HostId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DELETE 
        ER
    FROM
        TVF_EventReceivers_SiteWebHost(@SiteId, @WebId, @HostId) AS ER
    WHERE
        ER.SourceId = @SourceId AND
        ER.SourceType = @SourceType

go

