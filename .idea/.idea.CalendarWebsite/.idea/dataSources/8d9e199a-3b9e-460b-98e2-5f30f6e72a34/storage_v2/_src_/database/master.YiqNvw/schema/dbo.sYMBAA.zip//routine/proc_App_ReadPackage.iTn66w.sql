CREATE Procedure [dbo].[proc_App_ReadPackage] (
    @PackageFingerprint binary(64),
    @SiteId uniqueidentifier
)
AS
SET NOCOUNT ON
SELECT Package FROM TVF_AppPackages_PackageFingerprint(@SiteId, @PackageFingerprint)

go

