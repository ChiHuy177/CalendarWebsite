CREATE FUNCTION [dbo].[TVF_AllLists_SiteId]
(
    @tp_SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllLists] WITH (INDEX=AllLists_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId

go

