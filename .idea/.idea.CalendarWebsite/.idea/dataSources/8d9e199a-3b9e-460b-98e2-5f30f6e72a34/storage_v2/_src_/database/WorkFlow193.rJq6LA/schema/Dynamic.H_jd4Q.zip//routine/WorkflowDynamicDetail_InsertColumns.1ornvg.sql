CREATE       PROCEDURE [Dynamic].[WorkflowDynamicDetail_InsertColumns] 
	-- Add the parameters for the stored procedure here
	@PropertyId bigint
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @ColumnName NVARCHAR(MAX);
	DECLARE @WorkflowId BIGINT;
	DECLARE @SqlScript NVARCHAR(4000);
	DECLARE @TableCode NVARCHAR(MAX);
	DECLARE @QueryString NVARCHAR(MAX);
    DECLARE @DataTableName NVARCHAR(MAX);

	SET @WorkflowId = (
				SELECT TOP 1 WorkflowId
				FROM Property
				WHERE Id = @PropertyId)
	SET @ColumnName = (
				SELECT TOP 1 Name
				FROM Property
				WHERE Id = @PropertyId
				);

	IF ISNULL((select top 1Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId), '') = ''
	BEGIN
		UPDATE [dbo].[Workflow] set Code = SUBSTRING(CONVERT(varchar(40), NEWID()),0,8) WHERE Id = @WorkflowId
	END

	SET @TableName =(
			SELECT Title
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @TableCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Detail_'
			,dbo.fn_StripCharacters(@TableCode, '^a-z0-9')
			);
	IF (
			EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'Dynamic'
					AND TABLE_NAME = CONCAT (
										'Detail_'
										,dbo.fn_StripCharacters(@TableCode, '^a-z0-9'))
										)				
			AND @DataTableName IS NOT NULL
		)
	BEGIN
			SET @SqlScript = 'IF OBJECT_ID(N''' + @DataTableName + ''', N''U'') IS NOT NULL
					AND NOT EXISTS(SELECT 1 FROM sys.columns 
									  WHERE Name = N''' + @ColumnName + '''
									  AND Object_ID = Object_ID(N''' + @DataTableName + '''))
					BEGIN ALTER TABLE ' + @DataTableName +
					' ADD [' + @ColumnName + ']' +
					(SELECT (
					CASE 
						WHEN p.IsSingle = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsMultiLine = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsChoice = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsNumber = 1 AND p.IsViewOnly <> 1
							THEN ' decimal(22,4) null'
						WHEN p.IsNumber = 1 AND p.IsViewOnly = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsCurrency = 1 AND p.IsViewOnly <> 1
							THEN ' decimal(22,4) null'
						WHEN p.IsCurrency = 1 AND p.IsViewOnly = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsDateAndTime = 1
							THEN ' datetime2(7) NULL'
						WHEN p.IsLookup = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsYesNo = 1
							THEN ' bit NULL'
						WHEN p.IsUser = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsCalculated = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsFile = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsApi = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						ELSE ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						END
					)	FROM Property p
					WHERE p.Id = @PropertyId)
					+ ' END'
		print @SqlScript;
		EXEC sp_ExecuteSql @SqlScript;
	END
END
go

