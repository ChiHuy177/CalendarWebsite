CREATE PROCEDURE [dbo].[proc_GetListItemWorkflowWithInstanceDataAndLock] (
        @SiteId                uniqueidentifier,
        @WebId                 uniqueidentifier,
        @ListId                uniqueidentifier,
        @ItemId                int,
        @WorkflowInstanceId    uniqueidentifier,
        @HasInstanceData       int OUTPUT,
        @RequestGuid           uniqueidentifier = NULL OUTPUT   
        )       
AS
    SET NOCOUNT ON
    DECLARE @InternalState int
    DECLARE @ProcessingId uniqueidentifier
    SET @ProcessingId = NEWID()
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    SET @HasInstanceData = 0            
    SELECT TOP 1
        @InternalState = WF.InternalState
    FROM
        TVF_Workflow_UpdLock_Id(@SiteId, @WorkflowInstanceId) AS WF
    WHERE
        WF.WebId = @WebId
    IF (@@ROWCOUNT = 0)
    BEGIN
        SET @iRet = 19
        GOTO CLEANUP 
    END
    IF (@InternalState & 1) = 0
    BEGIN
        EXEC @iRet = proc_AddFailOver @ProcessingId, @SiteId, @WorkflowInstanceId, 20, 1
        IF @iRet <> 0
            GOTO CLEANUP
        SELECT TOP 1
            Id, TemplateId, ListId, SiteId, WebId, ItemId, ItemGUID, TaskListId, AdminTaskListId, Author, Modified, Created, StatusVersion, Status1, Status2, Status3, Status4, Status5, Status6, Status7, Status8, Status9, Status10, TextStatus1, TextStatus2, TextStatus3, TextStatus4, TextStatus5, Modifications, ActivityDetails, CorrelationId,
            InstanceData,
            InstanceDataSize,
            InternalState | 1 as InternalState,
            @ProcessingId  as ProcessingId            
        FROM
            TVF_Workflow_UpdLock_Id(@SiteId, @WorkflowInstanceId) AS WF
        WHERE
            WF.WebId = @WebId AND
            (WF.InternalState & (1 | (4 | 8))) = 0 AND
            WF.LockMachineId IS NULL
        IF (@@ROWCOUNT = 0)
        BEGIN
            SET @iRet = 19
            GOTO CLEANUP 
        END
        SET @HasInstanceData = 1
        UPDATE
            WF
        SET
            WF.InternalState = (WF.InternalState | 1) & ~1024,
            WF.Status1 = 
                CASE 
                    WHEN (WF.Status1 = 0) THEN 2 
                    ELSE WF.Status1 
                END ,
            WF.LockMachineId = @ProcessingId,
            WF.HistorySize = WF.InstanceDataSize
        FROM
            TVF_Workflow_Id(@SiteId, @WorkflowInstanceId) AS WF
        WHERE    
            WF.WebId = @WebId
    END
    ELSE
    BEGIN
        EXEC @iRet = proc_GetListItemWorkflows @SiteId,
                                               @WebId,
                                               NULL,
                                               0,
                                               @WorkflowInstanceId,
                                               NULL,
                                               0xFFFFFFFF,
                                               0,
                                               1, 
                                               0, 
                                               @RequestGuid = @RequestGuid OUTPUT
    END
CLEANUP:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @iRet        

go

