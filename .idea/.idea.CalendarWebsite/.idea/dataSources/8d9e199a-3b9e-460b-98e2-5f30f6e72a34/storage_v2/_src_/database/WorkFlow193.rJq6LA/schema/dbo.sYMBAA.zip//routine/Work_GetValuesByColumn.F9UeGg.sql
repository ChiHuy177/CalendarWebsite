-- Work_GetValuesByColumn 31,'Nguoixuly' 
   CREATE   PROC [dbo].[Work_GetValuesByColumn] @id AS NVARCHAR(max) = '31'
   ,@columnName AS NVARCHAR(250) = 'Ngayketthuc'
   AS
   SELECT a.[value] AS ketqua
   INTO #a
   FROM [Dynamic].[Workflow_WORK] AS Tab
   CROSS APPLY OPENJSON(Tab.data, N'$') AS a
   WHERE Id IN (
   SELECT value
   FROM STRING_SPLIT(@id, ',')
   )
   AND a.[key] IN (
   SELECT value
   FROM STRING_SPLIT(@columnName, ',')
   )
   SELECT *
   FROM #a
go

