--  [Work_GetParent] 19807    
   CREATE   PROC [dbo].[Work_GetParent]       
   @WorkId AS NVARCHAR(500)       
   AS       
   SELECT a.Duan       
   ,a.Id       
   ,a.tieude AS title       
   ,ISNULL(a.noidung, '') AS description       
   ,a.TrangThaiCongViec AS STATUS       
   ,tieude       
   ,noidung       
   ,ISNULL(Nguoiphoihop, '') AS Nguoiphoihop       
   ,isnull(a.Nguoixuly, '') AS Nguoixuly       
   ,ISNULL(a.Nguoigiao, '') AS Nguoigiao       
   ,ISNULL(a.Nguoitheodoi, '') AS Nguoitheodoi        
   ,a.UserWorkflowId       
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, getdate()), 120)) AS [start]       
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, getdate()), 120)) AS [end]        
   ,trim(CONVERT(CHAR, ISNULL('', getdate()), 120)) AS CreatedTime       
   ,ISNULL(a.Loaicv, '') AS Loaicv       
   ,ISNULL(CongViecCha,'') as CongViecCha       
   ,a.Tiendo as tiendo            
   FROM [Dynamic].[Data_WORK] AS a       
   where a.UserWorkflowId = (select ISNULL(CongViecCha,0) from [Dynamic].[Data_WORK] where UserWorkflowId=@WorkId)
go

