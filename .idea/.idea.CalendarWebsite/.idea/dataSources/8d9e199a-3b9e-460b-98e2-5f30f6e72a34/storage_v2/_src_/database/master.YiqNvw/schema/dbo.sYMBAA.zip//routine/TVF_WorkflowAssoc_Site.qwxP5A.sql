CREATE FUNCTION [dbo].[TVF_WorkflowAssoc_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[WorkflowAssociation] WITH (INDEX=WorkflowAssociation_Parent, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

