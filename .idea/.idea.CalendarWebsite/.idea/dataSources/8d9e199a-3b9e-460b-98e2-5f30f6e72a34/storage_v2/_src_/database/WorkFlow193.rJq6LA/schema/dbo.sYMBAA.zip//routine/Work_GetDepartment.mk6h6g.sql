-- Work_GetDepartment 'P:285'
   CREATE   PROC [dbo].[Work_GetDepartment]
   @userId as nvarchar(50)
   as
   select * from Department
   where id in (select DepartmentId from PersonalProfile where 'P:'+ trim(str(id))=@userId)
   union 
   select * from Department
   where id in ( 
   select b.value from Dynamic.Data_RuleViewProject a
   cross apply string_split(Department,';') b
   where [User]=@userId
   )
go

