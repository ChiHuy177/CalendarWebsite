CREATE PROC [dbo].[proc_EnumEmailAliasesBySite](
    @SiteId uniqueidentifier)
AS
    SET NOCOUNT ON
    SELECT
        L.tp_EmailAlias,
        W.SiteId,
        L.tp_WebId,
        L.tp_ID
    FROM
        TVF_Webs_SiteId(@SiteId) AS W
    CROSS APPLY
        TVF_Lists_WebId(W.SiteId, W.Id) AS L
    WHERE
        L.tp_EmailAlias IS NOT NULL

go

