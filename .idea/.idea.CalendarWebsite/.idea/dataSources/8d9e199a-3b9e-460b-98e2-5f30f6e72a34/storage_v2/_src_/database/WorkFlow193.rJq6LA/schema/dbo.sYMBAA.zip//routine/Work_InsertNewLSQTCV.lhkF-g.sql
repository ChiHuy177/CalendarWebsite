CREATE   PROC [dbo].[Work_InsertNewLSQTCV] 
   @workProcessId as nvarchar(250), 
   @workId as nvarchar(250) 
   as 
   declare @workProcessIdOld as nvarchar(250) 
   set @workProcessIdOld = (select ISNULL(QuyTrinhDinhKem,'0') from Dynamic.Data_WORK where UserWorkflowId=@workId) 
   if not exists ( select * from Dynamic.Data_LSQTCV where IsUseForWork=@workId) 
   begin 
   INSERT INTO [Dynamic].[Data_LSQTCV] 
   ( 
   [Title] 
   ,[Step] 
   ,[NextStep] 
   ,[Nodeid] 
   ,[Version] 
   ,[CategoryWorkProcessId] 
   ,[IsUseForWork]) 
   select 
   [Title] 
   ,[Step] 
   ,[NextStep] 
   ,[Nodeid] 
   ,[Version] 
   ,@workProcessId 
   ,@workId 
   from [Dynamic].[Data_LSQTCV] where CategoryWorkProcessId=@workProcessIdOld 
   end 
go

