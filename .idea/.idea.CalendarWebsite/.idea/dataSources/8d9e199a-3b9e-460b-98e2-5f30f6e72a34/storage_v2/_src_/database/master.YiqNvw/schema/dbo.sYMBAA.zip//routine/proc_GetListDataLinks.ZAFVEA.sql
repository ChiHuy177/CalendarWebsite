CREATE PROCEDURE [dbo].[proc_GetListDataLinks](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @FirstDirName nvarchar(256),
    @FirstLeafName nvarchar(128),
    @FirstLevel tinyint,
    @LastDirName nvarchar(256),
    @LastLeafName nvarchar(128),
    @LastLevel tinyint,
    @GetWebListForNormalization bit,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    IF @GetWebListForNormalization = 1
    BEGIN
        SELECT
            FullUrl
        FROM
            TVF_Webs_SiteIdParent(@SiteId, @WebId) AS Webs
    END
    DECLARE @LinksList table( DirName nvarchar(256) COLLATE Latin1_General_CI_AS_KS_WS NULL, LeafName nvarchar(128) COLLATE Latin1_General_CI_AS_KS_WS NULL, ParentId uniqueidentifier NOT NULL, DocId uniqueidentifier NOT NULL, WebPartId uniqueidentifier NULL, FieldId uniqueidentifier NULL, LinkNumber int NOT NULL, TargetDirName nvarchar(256) COLLATE Latin1_General_CI_AS_KS_WS NOT NULL, TargetLeafName nvarchar(128) COLLATE Latin1_General_CI_AS_KS_WS NOT NULL, Type tinyint NOT NULL, Security tinyint NOT NULL, Dynamic tinyint NOT NULL, ServerRel bit NOT NULL, PointsToDir bit NOT NULL, Level tinyint DEFAULT 1 NOT NULL)
    INSERT INTO 
        @LinksList 
    SELECT
        Docs.DirName,
        Docs.LeafName,        
        Links.ParentId, 
        Links.DocId,
        Links.WebPartId,        
        Links.FieldId,
        Links.LinkNumber,
        Links.TargetDirName,
        Links.TargetLeafName,
        Links.Type,
        Links.Security,
        Links.Dynamic,
        Links.ServerRel,
        Links.PointsToDir,
        Links.Level
    FROM
        AllDocs AS Docs WITH (NOLOCK, INDEX=Docs_SiteDirLeafLevelUniqueFilteredDirty)
    CROSS APPLY
        TVF_Links_PId_DId_Lvl(Docs.SiteId, Docs.ParentId, Docs.Id, Docs.Level) AS Links
    WHERE
        Docs.SiteId = @SiteId AND
        Docs.DeleteTransactionId = 0x AND
        (
          (Docs.DirName = @FirstDirName AND Docs.LeafName = @FirstLeafName AND Docs.Level = @FirstLevel) OR
          (Docs.DirName = @FirstDirName AND Docs.LeafName = @FirstLeafName AND Docs.Level > @FirstLevel) OR
          (Docs.DirName = @FirstDirName AND Docs.LeafName > @FirstLeafName) OR
          (Docs.DirName > @FirstDirName)
        ) AND
        (
          (Docs.DirName = @LastDirName AND Docs.LeafName = @LastLeafName AND Docs.Level = @LastLevel) OR
          (Docs.DirName = @LastDirName AND Docs.LeafName = @LastLeafName AND Docs.Level < @LastLevel) OR
          (Docs.DirName = @LastDirName AND Docs.LeafName < @LastLeafName) OR (Docs.DirName < @LastDirName)
        ) AND
        Links.FieldId IS NOT NULL AND
        Docs.ListDataDirty = 1
    OPTION (FORCE ORDER, LOOP JOIN, MAXDOP 1)
    SELECT
        Links.DirName,
        Links.LeafName,
        Links.Level,
        Links.FieldId,
        Links.TargetDirName,
        Links.TargetLeafName,
        Links.Type,
        Links.Security,
        Links.Dynamic,
        Links.ServerRel,
        Docs2.Type,
        Links.PointsToDir
    FROM
        @LinksList AS Links
    OUTER APPLY
        TVF_Docs_NoLock_Url_Level(@SiteId, Links.TargetDirName, Links.TargetLeafName, 1) AS Docs2    
    ORDER BY
        Links.DirName Asc, Links.LeafName Asc, Links.Level Asc,
        Links.FieldId Asc, Links.LinkNumber Asc
    OPTION (FORCE ORDER, LOOP JOIN, MAXDOP 1)

go

