CREATE PROC [dbo].[proc_SecResolvePrincipal](
    @SiteId uniqueidentifier,
    @Input nvarchar(255),
    @InputIsEmailOnly bit,
    @AccountName nvarchar(255),
    @DLAlias nvarchar(128),
    @DLAliasServerAddress nvarchar(255),
    @SearchScope int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @OutMatchType int
    DECLARE @OutPrincipalType int
    DECLARE @OutUserId int
    DECLARE @OutLogin nvarchar(255)
    DECLARE @OutEmail nvarchar(255)
    DECLARE @OutDisplayName nvarchar(255)
    SET @OutMatchType = 0 
    IF @InputIsEmailOnly = 0
    BEGIN
        SELECT TOP 2
            @OutMatchType = 1,
            @OutPrincipalType = 8,
            @OutUserId = G.ID,
            @OutLogin = G.Title,
            @OutEmail = CASE WHEN G.DLAlias IS NULL OR @DLAliasServerAddress IS NULL THEN NULL ELSE G.DLAlias + N'@' + @DLAliasServerAddress END,
            @OutDisplayName = @Input
        FROM
            TVF_Groups_SiteTitle(@SiteId, @Input) AS G
        WHERE
            (@SearchScope & 8) <> 0 AND
            DATALENGTH(G.Title) = DATALENGTH(@Input)           
        IF @@ROWCOUNT = 1
            GOTO cleanup
        IF @AccountName IS NULL
        BEGIN
            SET @AccountName = @Input
        END
        SELECT TOP 1
            @OutMatchType = 1,
            @OutPrincipalType = CASE WHEN UI.tp_DomainGroup = 0 THEN 1 ELSE 4 END,
            @OutUserId = UI.tp_ID,
            @OutLogin = UI.tp_Login,
            @OutEmail = UI.tp_Email,
            @OutDisplayName = UI.tp_Title
        FROM
            TVF_UserInfo_SiteLoginDel(@SiteId, @AccountName, 0) AS UI
        WHERE
            (((@SearchScope & 1) <> 0 AND UI.tp_DomainGroup = CONVERT(bit,0)) OR
             ((@SearchScope & 4) <> 0 AND UI.tp_DomainGroup = CONVERT(bit,1))
            ) AND
            DATALENGTH(UI.tp_Login) = DATALENGTH(@AccountName)
        IF @@ROWCOUNT = 1
            GOTO cleanup
        SELECT TOP 1
            @OutMatchType = 5,
            @OutPrincipalType = 1,
            @OutUserId = UI.tp_ID,
            @OutLogin = UI.tp_Login,
            @OutEmail = UI.tp_Email,
            @OutDisplayName = UI.tp_Title
        FROM
            TVF_UserInfo_SiteMobile(@SiteId, @Input) AS UI
        WHERE
            ((@SearchScope & 1) <> 0 AND UI.tp_DomainGroup = CONVERT(bit,0)) AND
            DATALENGTH(UI.tp_Mobile) = DATALENGTH(@Input) AND
            UI.tp_Deleted = 0
        IF @@ROWCOUNT = 1
            GOTO cleanup
    END
    SELECT TOP 2
        @OutMatchType = MatchType,
        @OutPrincipalType = PrincipalType,
        @OutUserId = UserId,
        @OutLogin = Login,
        @OutEmail = Email,
        @OutDisplayName = Title
    FROM
        (
            SELECT TOP 2
                2 AS MatchType,
                CASE WHEN UI.tp_DomainGroup = 0 THEN 1 ELSE 4 END AS PrincipalType,
                UI.tp_ID AS UserId,
                UI.tp_Login AS Login,
                UI.tp_Email AS Email,
                UI.tp_Title AS Title
            FROM
                TVF_UserInfo_SiteDelEmail(@SiteId, 0, @Input) AS UI
            WHERE
                (((@SearchScope & 1) <> 0 AND UI.tp_DomainGroup = CONVERT(bit,0)) OR
                 ((@SearchScope & 4) <> 0 AND UI.tp_DomainGroup = CONVERT(bit,1))
                ) AND
                DATALENGTH(UI.tp_Email) = DATALENGTH(@Input)
            UNION
            SELECT TOP 2
                2 AS MatchType,
                8 AS PrincipalType,
                G.ID AS UserId,
                G.Title AS Login,
                CASE WHEN G.DLAlias IS NULL OR @DLAliasServerAddress IS NULL THEN NULL ELSE G.DLAlias + '@' + @DLAliasServerAddress END AS Email,
                G.Title AS DisplayName
            FROM
                TVF_Groups_SiteDLAlias(@SiteId, @DLAlias) AS G
            WHERE
                (@SearchScope & 8) <> 0 AND
                @DLAlias IS NOT NULL AND
                DATALENGTH(G.DLAlias) = DATALENGTH(@DLAlias)
        ) AllUserWithEmailMatch    
    IF @@ROWCOUNT = 1
        GOTO cleanup
    SELECT TOP 2
        @OutMatchType = MatchType,
        @OutPrincipalType = PrincipalType,
        @OutUserId = UserId,
        @OutLogin = Login,
        @OutEmail = Email,
        @OutDisplayName = Title
    FROM
        (
            SELECT TOP 2
                4 AS MatchType,
                CASE WHEN UI.tp_DomainGroup = 0 THEN 1 ELSE 4 END AS PrincipalType,
                UI.tp_ID AS UserId,
                UI.tp_Login AS Login,
                UI.tp_Email AS Email,
                UI.tp_Title AS Title
            FROM
                TVF_UserInfo_SiteTitle(@SiteId, @Input) AS UI
            WHERE
                (((@SearchScope & 1) <> 0 AND UI.tp_DomainGroup = CONVERT(bit,0)) OR
                 ((@SearchScope & 4) <>0 AND UI.tp_DomainGroup = CONVERT(bit,1))
                ) AND
                DATALENGTH(UI.tp_Title) = DATALENGTH(@Input) AND
                UI.tp_Deleted = 0
            UNION
            SELECT TOP 2
                4,
                8 AS PrincipalType,
                G.ID AS UserId,
                G.Title AS Login,
                CASE WHEN G.DLAlias IS NULL OR @DLAliasServerAddress IS NULL THEN NULL ELSE G.DLAlias + '@' + @DLAliasServerAddress END AS Email,
                G.Title AS DisplayName
            FROM
                TVF_Groups_SiteTitle(@SiteId, @Input) AS G
            WHERE
                (@SearchScope & 8) <> 0 AND
                DATALENGTH(G.Title) = DATALENGTH(@Input)
        ) AllUserWithDisplayNameMatch 
    IF @@ROWCOUNT = 1
        GOTO cleanup
    SELECT
            @OutMatchType = 0,
            @OutPrincipalType = 0,
            @OutUserId = -1,
            @OutLogin = NULL,
            @OutEmail = NULL,
            @OutDisplayName = NULL
cleanup:
    IF @OutMatchType <> 0
    BEGIN
        SELECT
                @OutMatchType,
                @OutPrincipalType,
                @OutUserId,
                @OutLogin,
                @OutEmail,
                @OutDisplayName
    END   
    RETURN 0

go

