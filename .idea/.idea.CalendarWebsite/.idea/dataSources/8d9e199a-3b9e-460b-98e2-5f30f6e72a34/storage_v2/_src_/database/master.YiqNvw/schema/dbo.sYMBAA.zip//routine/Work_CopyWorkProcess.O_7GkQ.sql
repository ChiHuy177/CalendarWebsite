CREATE PROC [dbo].[Work_CopyWorkProcess]  
@copyFrom as nvarchar(50)  
,@copyTo as nvarchar(50)  
as  
  
declare @chartData as nvarchar(max) =''  
  
set @chartData=(select FlowChartData from Dynamic.Data_TMDSQTCV where UserWorkflowId= @copyFrom)  
--set @chartData=REPLACE(@chartData,'***Sua***','***Them***')  
  
update Dynamic.Data_TMDSQTCV  set FlowChartData=@chartData where UserWorkflowId=@copyTo  
  
delete Dynamic.data_LSQTCV where CategoryWorkProcessId=@copyTo  
delete [Dynamic].[Data_FOLLOWCHART] where QuyTrinhDinhKem=@copyTo  

INSERT INTO [Dynamic].[Data_LSQTCV]
           ([UserWorkflowId]
           ,[Title]
           ,[Step]
           ,[NextStep]
           ,[Nodeid]
           ,[Version]
           ,[CategoryWorkProcessId]
           ,[IsUseForWork]
           ,[ProjectId])
select [UserWorkflowId]
           ,[Title]
           ,[Step]
           ,[NextStep]
           ,[Nodeid]
           ,[Version]
           ,@copyTo
           ,[IsUseForWork]
           ,[ProjectId]
from [Dynamic].[Data_LSQTCV] where CategoryWorkProcessId=@copyFrom;

INSERT INTO [Dynamic].[Data_FOLLOWCHART]
           ([UserWorkflowId]
           ,[Nguoixuly]
           ,[Nguoiphoihop]
           ,[Nguoitheodoi]
           ,[Mota]
           ,[Tieude]
           ,[Loaicv]
           ,[Douutien]
           ,[Thoigian]
           ,[Nodeid]
           ,[QuyTrinhDinhKem]
           ,[IsUseForWork]
           ,[Quytrinh]
           ,[TudonghoanthanhCV])
select [UserWorkflowId]
           ,[Nguoixuly]
           ,[Nguoiphoihop]
           ,[Nguoitheodoi]
           ,[Mota]
           ,[Tieude]
           ,[Loaicv]
           ,[Douutien]
           ,[Thoigian]
           ,[Nodeid]
           ,@copyTo
           ,[IsUseForWork]
           ,[Quytrinh]
           ,[TudonghoanthanhCV] 
from [Dynamic].[Data_FOLLOWCHART] where  QuyTrinhDinhKem=@copyFrom
go

