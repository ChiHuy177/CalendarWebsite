CREATE PROCEDURE [dbo].[proc_SecSetWebRequestAccess](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @RequestAccessEmail nvarchar(255),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        W
    SET
        W.RequestAccessEmail = @RequestAccessEmail        
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W

go

