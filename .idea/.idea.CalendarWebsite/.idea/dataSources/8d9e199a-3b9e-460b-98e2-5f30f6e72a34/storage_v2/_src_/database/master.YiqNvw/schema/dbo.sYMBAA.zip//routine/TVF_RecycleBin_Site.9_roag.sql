CREATE FUNCTION [dbo].[TVF_RecycleBin_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[RecycleBin] WITH (INDEX=RecycleBin_SiteBinWebUser, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

