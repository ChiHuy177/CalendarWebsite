CREATE PROCEDURE [dbo].[proc_RestoreWeb](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ThresholdRowCount int = 0,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
    )
AS
    SET NOCOUNT ON
    DECLARE @WebUrl nvarchar(260)
    DECLARE @WebDirName nvarchar(256)
    DECLARE @WebLeafName nvarchar(128)
    DECLARE @DeleteTransactionId varbinary(16)
    DECLARE @ParentWebId uniqueidentifier
    SELECT TOP 1
        @DeleteTransactionId = DeleteTransactionId,
        @WebUrl = FullUrl,
        @ParentWebId = ParentWebId
    FROM
        TVF_AllWebs_Id(@SiteId, @WebId)
    IF (@DeleteTransactionId IS NULL OR @DeleteTransactionId = 0x)
    BEGIN
        RETURN 3
    END
    IF NOT EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_Webs_Id(@SiteId, @ParentWebId) As W
        WHERE
            SUBSTRING(@WebUrl, 1, LEN(FullUrl)) = FullUrl)
    BEGIN
        RETURN 1979
    END
    DECLARE @UrlLike nvarchar(1024)
    EXEC proc_EscapeForLike @WebUrl, @UrlLike OUTPUT
    EXEC proc_SplitUrl @WebUrl, @WebDirName OUTPUT, 
        @WebLeafName OUTPUT
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_Docs_Url(@SiteId, @WebDirName, @WebLeafName))
    BEGIN
        RETURN 1979
    END
    DECLARE @ParentWebDirName nvarchar(256)
    DECLARE @ParentWebLeafName nvarchar(128)
    DECLARE @ExpectedParentWebId uniqueidentifier
    EXEC proc_SplitUrl @WebDirName, @ParentWebDirName OUTPUT, 
        @ParentWebLeafName OUTPUT
    SELECT
        @ExpectedParentWebId = WebId
    FROM
        TVF_Docs_Url(@SiteId, @ParentWebDirName, @ParentWebLeafName)
    IF (@ExpectedParentWebId IS NULL OR @ExpectedParentWebId <> @ParentWebId)
    BEGIN
        RETURN 1979
    END
    IF @ThresholdRowCount > 0
    BEGIN
        DECLARE @Count int
        SET @Count = 1
        SELECT  @Count = @Count + count(1) FROM (   
        SELECT TOP (@ThresholdRowCount + 1 - @Count)
            SiteId 
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @DeleteTransactionId) AS AD
        WHERE
            AD.Level = 1) AS D
        IF @Count IS NOT NULL AND @Count > @ThresholdRowCount
        BEGIN
            RETURN 36
        END
    END
    DECLARE @ReturnStatus int SET @ReturnStatus = 0 BEGIN TRAN
    UPDATE 
        AW
    SET
        AW.DeleteTransactionId = 0x
    FROM
        TVF_AllWebs_IdDelId(@SiteId, @WebId, @DeleteTransactionId) AS AW
    UPDATE
        AD
    SET
        AD.DeleteTransactionId = 0x
    FROM
        TVF_AllDocs_SiteDelTransId(@SiteId, @DeleteTransactionId) AS AD
    UPDATE
        AL
    SET
        AL.DeleteTransactionId = 0x
    FROM
        TVF_AllLinks_SiteDelTransId(@SiteId, @DeleteTransactionId) AS AL
    UPDATE 
        AL
    SET
        AL.tp_DeleteTransactionId = 0x
    FROM
        TVF_AllLists_WebId(@SiteId, @WebId) AS AL
    WHERE
        AL.tp_DeleteTransactionId = @DeleteTransactionId
    UPDATE
        AUD
    SET
        AUD.tp_DeleteTransactionId = 0x
    FROM
        TVF_AllLists_WebId(@SiteId, @WebId) AS AL
    CROSS APPLY
        TVF_AllUserData_ListDel(@SiteId, AL.tp_ID, @DeleteTransactionId) AS AUD
    UPDATE
        BD
    SET
        BD.DeleteTransactionId = 0x
    FROM
        TVF_BuildDependencies_DirNameEqLike_NotForDelete(@SiteId, @WebUrl, @UrlLike) AS BD
    WHERE
        BD.DeleteTransactionId = @DeleteTransactionId
    UPDATE 
        DP
    SET
        DP.DeleteTransactionId = 0x
    FROM
        TVF_Deps_SiteDelIdUrlEqLike_NotForDelete(@SiteId, @DeleteTransactionId, @WebUrl, @UrlLike) AS DP
    UPDATE
        P
    SET
        P.DelTransId = 0x
    FROM 
        TVF_Perms_SiteDelTransId(@SiteId, @DeleteTransactionId) AS P
    UPDATE
        G
    SET
        G.DeletionWebId = NULL
    FROM
        TVF_Groups_Site(@SiteId) AS G
    WHERE
        G.DeletionWebId = @WebId
    UPDATE 
        CT
    SET
        CT.DeleteTransactionId = 0x
    FROM
        TVF_ContentTypes_SiteClassScope(@SiteId, 0, @WebUrl) AS CT
    WHERE
        CT.DeleteTransactionId = @DeleteTransactionId
    UPDATE 
        CT
    SET
        CT.DeleteTransactionId = 0x
    FROM
        TVF_ContentTypes_SiteClassScope(@SiteId, 1, @WebUrl) AS CT
    WHERE
        CT.DeleteTransactionId = @DeleteTransactionId
    UPDATE
        ISubs
    SET
        ISubs.Deleted = 0
    FROM
        TVF_Lists_WebId(@SiteId, @WebId) AS L
    CROSS APPLY
        TVF_ImmedSubscriptions_SiteIdListIdItemId(
            L.tp_SiteId,
            L.tp_ID,
            NULL) AS ISubs
    WHERE
        ISubs.WebId = @WebId AND
        ISubs.Deleted = 1
    OPTION (FORCE ORDER)
    UPDATE
        ISubs
    SET
        ISubs.Deleted = 0
    FROM
        TVF_ImmedSubscriptions_SiteIdWebId(@SiteId, @WebId) AS ISubs
    CROSS APPLY
        TVF_UserData_ListItem(ISubs.SiteId, ISubs.ListId, ISubs.ItemId) AS UD
    WHERE
        ISubs.Deleted = 1 AND
        ISubs.ItemId IS NOT NULL
    OPTION (FORCE ORDER)
    UPDATE
        SSubs
    SET
        SSubs.Deleted = 0
    FROM
        TVF_Lists_WebId(@SiteId, @WebId) AS L
    CROSS APPLY
        TVF_SchedSubscriptions_SiteIdListIdItemId(
            L.tp_SiteId,
            L.tp_ID,
            NULL) AS SSubs
    WHERE
        SSubs.WebId = @WebId AND
        SSubs.Deleted = 1
    OPTION (FORCE ORDER)
    UPDATE
        SSubs
    SET
        SSubs.Deleted = 0
    FROM
        TVF_SchedSubscriptions_SiteIdWebId(@SiteId, @WebId) AS SSubs
    CROSS APPLY
        TVF_UserData_ListItem(SSubs.SiteId, SSubs.ListId, SSubs.ItemId) AS UD
    WHERE
        SSubs.Deleted = 1 AND
        SSubs.ItemId IS NOT NULL
    OPTION (FORCE ORDER)
    DELETE
        R
    FROM
        TVF_RecycleBin_DelIdChildId(
            @SiteId,
            @DeleteTransactionId, 
            0x) AS R
    WHERE
        R.WebId = @WebId
    DECLARE @ParentDocId uniqueidentifier
    DECLARE @DeltaSize bigint
    SELECT
        @ParentDocId = Docs.ParentId,
        @DeltaSize = SM.TotalSize
    FROM
        TVF_Docs_Url(@SiteId, @WebDirName, @WebLeafName) AS Docs
    CROSS APPLY
        TVF_StorageMetrics_DocId(@SiteId, Docs.Id) AS SM
    EXEC proc_AddStorageMetricsChange @SiteId, @ParentDocId, @DeltaSize, 1
    EXEC proc_LogChange @SiteId, @WebId, NULL, NULL, NULL, NULL, NULL, @WebUrl,
        131072,  4, NULL
cleanup:
    IF (@ReturnStatus = 0)
    BEGIN
        EXEC proc_UpdateDiskUsed @SiteId
    END
    IF (@ReturnStatus <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @ReturnStatus

go

