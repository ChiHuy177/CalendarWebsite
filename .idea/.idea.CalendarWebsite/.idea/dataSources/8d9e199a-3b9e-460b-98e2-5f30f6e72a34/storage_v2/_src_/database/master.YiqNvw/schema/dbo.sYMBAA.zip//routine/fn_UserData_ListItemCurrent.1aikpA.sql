CREATE FUNCTION [dbo].[fn_UserData_ListItemCurrent](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @ItemId int)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        TVF_UserData_ListItem_Mtg(@SiteId, @ListId, @ItemId)
    WHERE
        tp_IsCurrent = 1 AND
        tp_RowOrdinal = 0

go

