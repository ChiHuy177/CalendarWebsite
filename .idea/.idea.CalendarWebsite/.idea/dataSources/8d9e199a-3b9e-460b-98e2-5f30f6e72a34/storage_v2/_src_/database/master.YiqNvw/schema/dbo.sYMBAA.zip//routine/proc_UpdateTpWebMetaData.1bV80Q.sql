CREATE PROCEDURE [dbo].[proc_UpdateTpWebMetaData](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @Title nvarchar(255),
    @Description nvarchar(max),
    @Version int,
    @WebTemplate int,
    @Language int,
    @Locale int,
    @Collation smallint,
    @TimeZone smallint,
    @Time24 bit,
    @CalendarType smallint,
    @AdjustHijriDays smallint,    
    @AltCalendarType tinyint,
    @CalendarViewOptions tinyint,
    @WorkDays smallint,
    @WorkDayStartHour smallint,
    @WorkDayEndHour smallint,
    @Config smallint,
    @Flags int,
    @IgnoredFlagsMask int, 
    @Author int,
    @DefTheme nvarchar(64),    
    @AlternateCSSUrl nvarchar(260),
    @CustomizedCss nvarchar(260),
    @CustomJSUrl nvarchar(260),
    @AlternateHeaderUrl nvarchar(260),
    @ExternalSecurityProvider uniqueidentifier,
    @MasterUrl nvarchar(260),
    @CustomMasterUrl nvarchar(260),
    @SiteLogoUrl nvarchar(260),
    @SiteLogoDescription nvarchar(255),
    @AllowMUI bit,
    @TitleResource nvarchar(520),
    @DescriptionResource nvarchar(520),
    @AlternateMUICultures nvarchar(max),
    @OverwriteMUICultures bit,
    @TemplateVersion smallint,
    @UIVersion tinyint,
    @ClientTag smallint,
    @TimeCreated datetime = NULL,
    @TimeLastModified datetime = NULL,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @PreviousTitle nvarchar(255)
    DECLARE @PreviousDescription nvarchar(max)
    DECLARE @PreviousTitleResource nvarchar(520)
    DECLARE @PreviousDescriptionResource nvarchar(520)
    DECLARE @PreviousMasterUrl nvarchar(260)
    DECLARE @PreviousCustomMasterUrl nvarchar(260)
    DECLARE @WebUrl nvarchar(260)
    DECLARE @WebDir nvarchar(256)
    DECLARE @WebLeaf nvarchar(128)
    DECLARE @AncestrySize int
    DECLARE @WebsPlusRowCount int
    SELECT TOP 1
        @PreviousTitleResource = TitleResource,
        @PreviousDescriptionResource = DescriptionResource
    FROM 
        TVF_WebsPlus_UpdLock_WebId(@SiteId, @WebId) AS WP
    SET @WebsPlusRowCount = @@ROWCOUNT;
    IF @Title IS NOT NULL OR 
        @MasterUrl IS NOT NULL OR 
        @CustomMasterUrl IS NOT NULL
    BEGIN
        SELECT TOP 1
            @PreviousTitle = Title,
            @PreviousDescription = Description,
            @PreviousMasterUrl = MasterUrl,
            @PreviousCustomMasterUrl = CustomMasterUrl,
            @WebUrl = FullUrl,
            @AncestrySize = ISNULL(DATALENGTH(Ancestry), 0)
        FROM
            TVF_Webs_Id(@SiteId, @WebId) AS W
    END
    IF (@Title IS NOT NULL AND @Title = @PreviousTitle)
    BEGIN
        SET @TitleResource = NULL
    END
    IF (@Description IS NOT NULL AND @Description = @PreviousDescription)
    BEGIN
        SET @DescriptionResource = NULL
    END
    IF (@TitleResource IS NOT NULL)
    BEGIN
        IF (CHARINDEX(N'$Resources', @TitleResource) <> 1)
        BEGIN
            SET @TitleResource = N'_WebTitle'
            IF @WebsPlusRowCount = 0 OR @PreviousTitleResource <> @TitleResource
            BEGIN
                EXEC proc_AddUserResourceInternal
                    @SiteId,
                    @WebId ,
                    '00000000-0000-0000-0000-000000000000' ,
                    @TitleResource,
                    1,
                    0,
                    @Language,
                    @Title,
                    NULL,
                    0
            END
        END
        ELSE
        BEGIN
            IF (@WebsPlusRowCount <> 0 AND @PreviousTitleResource <> @TitleResource)
            BEGIN
                SET @TitleResource = NULL
            END
        END
    END    
    IF (@DescriptionResource IS NOT NULL)
    BEGIN
        IF (CHARINDEX(N'$Resources', @DescriptionResource) <> 1 
            AND LEN(@Description) >0)
        BEGIN
            SET @DescriptionResource = N'_WebDescription'
            IF @WebsPlusRowCount = 0 OR @PreviousDescriptionResource <> @DescriptionResource
            EXEC proc_AddUserResourceInternal
                @SiteId,
                @WebId ,
                '00000000-0000-0000-0000-000000000000' ,
                @DescriptionResource,
                2,
                1,
                @Language,
                NULL,
                @Description,
                0
        END
        ELSE
        BEGIN
            IF (@WebsPlusRowCount <> 0 AND @PreviousDescriptionResource <> @DescriptionResource)
            BEGIN
                SET @DescriptionResource = NULL
            END
        END
    END
    IF (@WebsPlusRowCount = 0)
    BEGIN
        INSERT INTO WebsPlus (
            SiteId,
            WebId, 
            TitleResource, 
            DescriptionResource,
            AlternateMUICultures,
            OverwriteMUICultures)
        VALUES (
            @SiteId, 
            @WebId, 
            @TitleResource,
            @DescriptionResource,
            @AlternateMUICultures,
            @OverwriteMUICultures)
    END
    ELSE
    BEGIN
        UPDATE
            WP
        SET
            TitleResource = CASE WHEN @TitleResource IS NULL THEN TitleResource ELSE @TitleResource END,
            DescriptionResource = CASE WHEN @DescriptionResource IS NULL THEN DescriptionResource ELSE @DescriptionResource END,
            AlternateMUICultures = @AlternateMUICultures,
            OverwriteMUICultures = @OverwriteMUICultures
        FROM
            TVF_WebsPlus_WebId(@SiteId, @WebId) AS WP
    END
    DECLARE @Now datetime
    SET @Now = GETUTCDATE()
    UPDATE
        W
    SET
        Title = CASE WHEN @Title IS NULL THEN Title ELSE @Title END,
        Description = CASE WHEN @Description IS NULL THEN Description ELSE
            @Description END,
        MetaInfoVersion = @Version + 1,
        WebTemplate = CASE WHEN @WebTemplate = -1 THEN WebTemplate ELSE
            @WebTemplate END,
        TemplateVersion = CASE WHEN @TemplateVersion = -1 THEN TemplateVersion ELSE
            @TemplateVersion END,
        Language = CASE WHEN @Language = 0 THEN Language ELSE
            @Language END,
        Locale = CASE WHEN @Locale = 0 THEN Locale ELSE
            @Locale END,
        Collation = CASE WHEN @Collation = -1 THEN Collation ELSE
            @Collation END,
        TimeZone = CASE WHEN @TimeZone = -1 THEN TimeZone ELSE
            @TimeZone END,
        Time24 = @Time24,
        CalendarType = CASE WHEN @CalendarType = -1 THEN CalendarType ELSE
            @CalendarType END,
        AdjustHijriDays = @AdjustHijriDays,            
        AltCalendarType = CASE WHEN @AltCalendarType = -1 THEN AltCalendarType ELSE
            @AltCalendarType END,
        CalendarViewOptions = @CalendarViewOptions,
        WorkDays = @WorkDays,        
        WorkDayStartHour = @WorkDayStartHour,  
        WorkDayEndHour = @WorkDayEndHour,  
        ProvisionConfig = CASE WHEN @Config = -1 THEN ProvisionConfig ELSE
            @Config END,
        Flags = CASE When @Flags IS NULL THEN Flags ELSE
            ((Flags & @IgnoredFlagsMask) | (@Flags & ~@IgnoredFlagsMask)) END, 
        Author = CASE WHEN @Author IS NULL THEN Author ELSE
            @Author END,
        DefTheme = @DefTheme,            
        AlternateCSSUrl = @AlternateCSSUrl,
        CustomizedCss = @CustomizedCss,
        CustomJSUrl = @CustomJSUrl,
        AlternateHeaderUrl = @AlternateHeaderUrl,
        SecurityProvider = @ExternalSecurityProvider,
        MasterUrl = CASE WHEN @MasterUrl IS NULL THEN MasterUrl ELSE
            @MasterUrl END,
        CustomMasterUrl = CASE WHEN @CustomMasterUrl IS NULL THEN CustomMasterUrl ELSE
            @CustomMasterUrl END,
        UIVersion = @UIVersion,
        ClientTag = @ClientTag,
        AllowMUI = @AllowMUI,
        SiteLogoUrl = @SiteLogoUrl,
        SiteLogoDescription = @SiteLogoDescription,
        TimeCreated = ISNULL(@TimeCreated, TimeCreated),
        LastMetadataChange = ISNULL(@TimeLastModified, @Now)
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
    WHERE
        MetaInfoVersion = @Version
    IF @@ROWCOUNT <> 1
    BEGIN
        IF EXISTS (
            SELECT TOP 1
                1 
            FROM 
                TVF_Webs_Id(@SiteId, @WebId))
        BEGIN
            RETURN 1150
        END
        ELSE
        BEGIN
            RETURN 3
        END
    END
    IF (@Title IS NOT NULL AND @Title <> @PreviousTitle)
    BEGIN
        DECLARE @IsEmptyUrl bit
        DECLARE @TitleStart int
        DECLARE @WebUrlLike nvarchar(1024)
        IF (DATALENGTH(@WebUrl) = 0)
        BEGIN
            SET @IsEmptyUrl = 1
        END
        ELSE
        BEGIN
            SET @IsEmptyUrl = 0
            EXEC proc_EscapeForLike @WebUrl, @WebUrlLike OUTPUT
        END
        SET @TitleStart = 1 + @AncestrySize
                            + CASE WHEN @AncestrySize = 0
                                   THEN 0
                                   ELSE DATALENGTH(CONVERT(varbinary(8), N';#;#'))
                                   END
                            + DATALENGTH(CONVERT(varbinary(16), @WebId))
                            + DATALENGTH(CONVERT(varbinary(4), N';#'))
                            + DATALENGTH(N'U')
                            + DATALENGTH(CONVERT(varbinary(4), N';#'))
        UPDATE
            W
        SET
            Ancestry = CONVERT(varbinary(max),STUFF(SUBSTRING(W.Ancestry, 1, DATALENGTH(W.Ancestry)), @TitleStart,
                             DATALENGTH(REPLACE(@PreviousTitle, N';', N';;')),
                             CONVERT(varbinary(520),
                                     REPLACE(@Title, N';', N';;'))))
        FROM
            TVF_Webs_SiteId(@SiteId) AS W
        WHERE
            W.Id <> @WebId AND
            (@IsEmptyUrl = 1 OR
             W.FullUrl LIKE @WebUrlLike)
    END
    IF @MasterUrl IS NOT NULL OR @CustomMasterUrl IS NOT NULL
    BEGIN
        DECLARE @MasterUrlInDb nvarchar(260)
        DECLARE @CustomMasterUrlInDb nvarchar(260)
        SELECT @MasterUrlInDb = ISNULL(@MasterUrl, @PreviousMasterUrl)
        SELECT @CustomMasterUrlInDb = ISNULL(@CustomMasterUrl, @PreviousCustomMasterUrl)
        EXEC proc_SplitUrl @WebUrl, @WebDir OUTPUT, @WebLeaf OUTPUT
        EXEC proc_RecordWebLinks @SiteId, @WebDir, @WebLeaf, 
            @MasterUrlInDb, @CustomMasterUrlInDb
        IF @MasterUrl IS NOT NULL AND @MasterUrl <> @PreviousMasterUrl
        BEGIN
            EXEC proc_UpdateBDSetForTargetUrl @SiteId, @PreviousMasterUrl, @WebId, @WebUrl
        END
        IF @CustomMasterUrl IS NOT NULL AND
           @CustomMasterUrl <> @PreviousCustomMasterUrl
        BEGIN
            EXEC proc_UpdateBDSetForTargetUrl @SiteId, @PreviousCustomMasterUrl, @WebId, @WebUrl 
        END        
    END
    EXEC proc_LogChange @SiteId, @WebId, NULL, NULL, NULL, NULL, NULL, NULL,
        8192, 4, @Now
    IF @Title IS NOT NULL OR
        @Language <> 0 OR
        @TimeZone <> -1
    BEGIN        
        UPDATE
            I
        SET
            I.WebTitle = ISNULL(@Title, I.WebTitle),
            I.WebLanguage = CASE WHEN @Language = 0 THEN I.WebLanguage 
                ELSE @Language END,
            I.WebLocale = CASE WHEN @Locale = 0 THEN I.WebLocale
                ELSE @Locale END,
            I.WebTimeZone = CASE WHEN @TimeZone = -1 THEN I.WebTimeZone 
                ELSE @TimeZone END,
            I.WebTime24 = @Time24,
            I.WebCalendarType = CASE WHEN @CalendarType = -1 THEN I.WebCalendarType 
                ELSE @CalendarType END,
            I.WebAdjustHijriDays = @AdjustHijriDays
        FROM
            TVF_ImmedSubscriptions_SiteIdWebId(@SiteId, @WebId) AS I            
        UPDATE
            S
        SET
            S.WebTitle = ISNULL(@Title, S.WebTitle),
            S.WebLanguage = CASE WHEN @Language = 0 THEN S.WebLanguage 
                ELSE @Language END,
            S.WebLocale = CASE WHEN @Locale = 0 THEN S.WebLocale
                ELSE @Locale END,
            S.WebTimeZone = CASE WHEN @TimeZone = -1 THEN S.WebTimeZone 
                ELSE @TimeZone END,
            S.WebTime24 = @Time24,
            S.WebCalendarType = CASE WHEN @CalendarType = -1 THEN S.WebCalendarType 
                ELSE @CalendarType END,
            S.WebAdjustHijriDays = @AdjustHijriDays
        FROM
            TVF_SchedSubscriptions_SiteIdWebId(@SiteId, @WebId) AS S
    END
    EXEC proc_QMChangeSiteDiskUsedAndContentTimestamp @SiteId, 0, 1, NULL
    RETURN 0

go

