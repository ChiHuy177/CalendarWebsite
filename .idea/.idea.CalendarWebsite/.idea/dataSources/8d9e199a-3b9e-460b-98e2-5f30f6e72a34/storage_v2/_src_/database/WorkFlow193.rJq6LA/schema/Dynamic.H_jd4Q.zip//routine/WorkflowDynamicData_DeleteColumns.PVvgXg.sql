-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicData_DeleteColumns]
	-- Add the parameters for the stored procedure here
	@PropertyId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @ColumnName NVARCHAR(MAX);
	DECLARE @WorkflowId BIGINT;
	DECLARE @SqlScript NVARCHAR(4000);

	SET @WorkflowId = (
			SELECT TOP 1 WorkflowId
			FROM Property
			WHERE Id = @PropertyId
			);
	SET @ColumnName = (
			SELECT TOP 1 Name
			FROM Property
			WHERE Id = @PropertyId
			);
	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @TableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	SET @SqlScript = 'IF OBJECT_ID(N''' + @TableName + ''', N''U'') IS NOT NULL AND COL_LENGTH(N''' + @TableName + ''', ''' + @ColumnName + ''') IS NOT NULL
					BEGIN ALTER TABLE ' + @TableName + ' DROP COLUMN ' + @ColumnName + ' END';

	PRINT @SqlScript;

	EXEC sp_ExecuteSql @SqlScript;

	UPDATE [Report].[ReportBaseColumn]
	SET IsDeleted = 1
	WHERE PropertyId = @PropertyId

	UPDATE [Resource].[ResourceBaseColumn]
	SET IsDeleted = 1
	WHERE PropertyId = @PropertyId

	UPDATE [Report].[ReportBaseFilter]
	SET IsDeleted = 1
	WHERE PropertyId = @PropertyId

	UPDATE [Resource].[ResourceBaseFilter]
	SET IsDeleted = 1
	WHERE PropertyId = @PropertyId
END
go

