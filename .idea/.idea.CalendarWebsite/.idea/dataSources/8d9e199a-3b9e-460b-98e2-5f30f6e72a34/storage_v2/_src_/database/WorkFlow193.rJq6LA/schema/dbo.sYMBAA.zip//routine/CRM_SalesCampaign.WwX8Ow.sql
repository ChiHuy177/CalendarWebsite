CREATE   PROC [dbo].[CRM_SalesCampaign]  
 @userName as nvarchar(50)='',            
 @id as bigint =0,  
 @str as nvarchar(250)='',  
 @menuId as bigint =0         
 as  
 declare @sql as nvarchar(max), @join as nvarchar(max)  
 --set @join= 'inner join (select * from FnGetUserPermission('''+@userName+''','+STR(@menuId)+')) f on a.UserCreate=f.UserName '        
 set @join= ' '     
 if(@id=0)        
 begin  
  declare @where as nvarchar(500)=''  
  if(@str <>'')  
  begin  
   set @where = 'and (a.Code like N''%'+@str+'%'' or a.Name  like N''%'+@str+'%'')'  
  end    
 set @sql='         
 SELECT a.*
   FROM Dynamic.data_CRMSalesCampaign a '+ @join +'  
     left join UserWorkflow u on u.id= a.UserWorkflowId
   where ISNULL(u.IsDeleted,0) = 0 '+ @where +'  
   order by a.ID desc '    
 end            
 else            
 begin  
 declare @ma as nvarchar = CAST(@id as nvarchar(max))  
 set @sql ='            
 SELECT a.*
   FROM Dynamic.data_CRMSalesCampaign a '+ @join+ ' 
     left join UserWorkflow u on u.id= a.UserWorkflowId
   where a.ID= '+@ma+'  and ISNULL(u.IsDeleted,0) = 0          
   order by a.ID desc '   
   end  
   print (@sql)  
   exec (@sql)
go

