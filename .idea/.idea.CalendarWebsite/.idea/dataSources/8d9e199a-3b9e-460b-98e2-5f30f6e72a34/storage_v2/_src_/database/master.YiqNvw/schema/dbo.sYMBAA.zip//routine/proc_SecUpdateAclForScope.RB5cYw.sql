CREATE PROCEDURE [dbo].[proc_SecUpdateAclForScope](
    @SiteId       uniqueidentifier,
    @ScopeId      uniqueidentifier,
    @NeedToUpdateDeps int = 1)
AS
    SET NOCOUNT ON
    DECLARE @RoleDefWebId uniqueidentifier
    DECLARE @aceCount   int
    DECLARE @pid        int
    DECLARE @pidNext    int
    DECLARE @perm       tPermMask
    DECLARE @permNext   tPermMask
    DECLARE @binary4    binary(4)
    DECLARE @binary8    binary(8)
    DECLARE @binaryPads  binary(4)
    DECLARE @binaryPerm binary(8)
    SET @aceCount = 0
    SELECT TOP 1
        @RoleDefWebId = P.RoleDefWebId
    FROM 
        TVF_Perms_UpdLock_ScopeId(@SiteId, @ScopeId) AS P
    IF @@ROWCOUNT = 0  
        RETURN
    SET @binary4 = dbo.fn_ChangeEndian4(0xfef3) 
    SET @binary8 = dbo.fn_ChangeEndian4(1)    
    SET @binaryPads = dbo.fn_ChangeEndian4(1)  
    UPDATE 
        P
    SET 
        P.Acl = @binary4+@binary8+@binaryPads
    FROM
        TVF_Perms_ScopeId(@SiteId, @ScopeId) AS P
    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR 
    SELECT 
        RA.PrincipalId, 
        R.PermMask 
    FROM
        TVF_Roles_SiteWeb(@SiteId, @RoleDefWebId) AS R
    CROSS APPLY
        TVF_RoleAssignment_RoleId(R.SiteId, @ScopeId, R.RoleId) AS RA
    ORDER BY
        RA.PrincipalId
    OPTION (FORCE ORDER)
    OPEN cur
    FETCH NEXT FROM cur INTO @pid, @perm
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        FETCH NEXT FROM cur INTO @pidNext, @permNext
        IF @pidNext <> @pid OR @@FETCH_STATUS <> 0
        BEGIN   
            SET @binary4 = dbo.fn_ChangeEndian4(@pid)
            SET @binaryPerm = dbo.fn_ChangeEndian8(@perm)
            UPDATE 
                Perms
            SET 
                Acl.WRITE(@binary4+@binaryPerm,NULL,0)
            FROM
                TVF_Perms_ScopeId(@SiteId, @ScopeId) AS Perms
            SET @aceCount = @aceCount + 1
            SET @pid = @pidNext
            SET @perm = @permNext
        END
        ELSE    
            SET @perm = @perm | @permNext
    END
    CLOSE cur
    DEALLOCATE cur
    SET @binary4 = dbo.fn_ChangeEndian4(@aceCount)
    UPDATE
        Perms
    SET
        Acl.WRITE(@binary4,12,4)
    FROM
        TVF_Perms_ScopeId(@SiteId, @ScopeId) AS Perms
    IF (@NeedToUpdateDeps = 1)
    BEGIN
        EXEC proc_SecUpdateDepsFromScope @SiteId, @ScopeId
    END
    RETURN 0

go

