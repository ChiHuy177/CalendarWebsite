CREATE PROCEDURE [dbo].[proc_SetInheritAuditMask]
(
    @ItemType           tinyint,
    @SiteId             uniqueidentifier,
    @DirName            nvarchar(256),
    @LeafName           nvarchar(128),
    @InheritAuditFlags  int
)
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    SET @Ret = 0
    DECLARE @Id uniqueidentifier
    IF (@ItemType = 1) OR 
        (@ItemType = 3) OR 
        (@ItemType = 5)
    BEGIN        
        DECLARE @DocParentId uniqueidentifier
        DECLARE @DocId uniqueidentifier
        EXEC proc_GetParentIdAndDocIdForUrl 
            @SiteId, @DirName, @LeafName, 
            @DocParentId OUTPUT, @DocId OUTPUT
        UPDATE
            Docs
        SET
            InheritAuditFlags = CASE WHEN (InheritAuditFlags IS NULL) 
                                        THEN @InheritAuditFlags
                             ELSE (@InheritAuditFlags | InheritAuditFlags)
                            END
        FROM
            TVF_Docs_CI(@SiteId, @DocParentId, @DocId, 1) AS Docs
    END
    ELSE IF (@ItemType = 4)
    BEGIN
        SELECT TOP 1
            @Id = Docs.ListId
        FROM 
            TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS Docs
        IF (0 = @@ROWCOUNT)
        BEGIN
            RETURN 2
        END
        UPDATE
            Lists
        SET 
            tp_InheritAuditFlags = CASE WHEN (tp_InheritAuditFlags IS NULL) 
                                   THEN @InheritAuditFlags
                                ELSE (@InheritAuditFlags | tp_InheritAuditFlags)
                               END
        FROM
            TVF_Lists_Id(@SiteId, @Id) AS Lists
    END
    ELSE IF (@ItemType = 6)
    BEGIN
        SELECT TOP 1
            @Id = Docs.WebId
        FROM
            TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS Docs
        IF (0 = @@ROWCOUNT)
        BEGIN
            RETURN 2
        END
        UPDATE
            Webs
        SET 
            InheritAuditFlags = CASE WHEN (InheritAuditFlags IS NULL) 
                                THEN @InheritAuditFlags
                                ELSE (@InheritAuditFlags | InheritAuditFlags)
                                END
        FROM
            TVF_Webs_Id(@SiteId, @Id) AS Webs
    END
    ELSE IF (@ItemType = 7)
    BEGIN
        UPDATE
            Sites
        SET
            InheritAuditFlags = CASE WHEN (InheritAuditFlags IS NULL) 
                                    THEN @InheritAuditFlags
                                ELSE (@InheritAuditFlags | InheritAuditFlags)
                                END
        FROM
            TVF_Sites_Id(@SiteId) AS Sites
    END
    IF (0 = @@ROWCOUNT)
    BEGIN
        RETURN 2
    END
    IF (@ItemType <> 7)
    BEGIN
        DECLARE @NewItemType    tinyint
        DECLARE @NewDirName     nvarchar(256)
        DECLARE @NewLeafName    nvarchar(128)
        EXEC @Ret = proc_GetParent 
            @ItemType, 
            @SiteId, 
            @DirName, 
            @LeafName,
            @NewItemType OUTPUT,
            @NewDirName OUTPUT,
            @NewLeafName OUTPUT
        IF @Ret <> 0
        BEGIN
            RETURN @Ret
        END
        EXEC @Ret = proc_SetInheritAuditMask @NewItemType, @SiteId, @NewDirName, 
                                    @NewLeafName, @InheritAuditFlags    
        IF @Ret <> 0
        BEGIN
            RETURN @Ret
        END
    END
    RETURN @Ret

go

