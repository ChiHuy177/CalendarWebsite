CREATE FUNCTION [dbo].[TVF_Deps_CI]
(
    @SiteId uniqueidentifier,
    @DeleteTransactionId varbinary(16),
    @FullUrl nvarchar(260),
    @Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Deps] WITH (INDEX=Deps_DocToDep, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = @DeleteTransactionId AND
        FullUrl = @FullUrl AND
        Level = @Level

go

