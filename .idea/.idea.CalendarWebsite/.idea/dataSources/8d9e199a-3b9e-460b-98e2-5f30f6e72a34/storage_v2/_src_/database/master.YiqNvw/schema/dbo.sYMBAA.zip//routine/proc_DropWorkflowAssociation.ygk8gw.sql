CREATE PROCEDURE [dbo].[proc_DropWorkflowAssociation] (
        @SiteId                uniqueidentifier,
        @Id                    uniqueidentifier,
        @DropAll               int=0,
        @RequestGuid           uniqueidentifier = NULL OUTPUT   
        )
AS
    SET NOCOUNT ON
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    DECLARE @WebId uniqueidentifier
    DECLARE @ListId uniqueidentifier
    SELECT TOP 1
        @WebId = WFA.WebId,
        @ListId = WFA.ListId
    FROM
        TVF_WorkflowAssoc_XLock_Id(@SiteId, @Id) AS WFA
    IF @@ROWCOUNT <> 0
    BEGIN
        IF @DropAll <> 0
        BEGIN
            EXEC proc_AutoDropWorkflows 
                @SiteId, 
                NULL, 
                @ListId, 
                NULL, 
                @Id, 
                NULL, 
                1 , 
                @RequestGuid = @RequestGuid OUTPUT
            DELETE 
                WFA
            FROM
                TVF_WorkflowAssoc_Id(@SiteId, @Id) AS WFA
        END
        ELSE
        BEGIN
            DECLARE @AllDeleted bit
            EXEC @AllDeleted = proc_AutoDropWorkflows 
                @SiteId, 
                NULL, 
                @ListId, 
                NULL, 
                @Id, 
                NULL, 
                1 , 
                200, 
                @RequestGuid OUTPUT
            IF @AllDeleted = 1
            BEGIN
                DELETE 
                    WFA
                FROM
                    TVF_WorkflowAssoc_Id(@SiteId, @Id) AS WFA
            END
        END
    END
CLEANUP:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @iRet

go

