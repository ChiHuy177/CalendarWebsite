CREATE FUNCTION [dbo].[TVF_AppTasks_SiteId]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppTasks] WITH (INDEX=AppTasks_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

