CREATE FUNCTION [dbo].[TVF_AllUserDataJunctions_PK]
(
    @tp_SiteId uniqueidentifier,
    @tp_DeleteTransactionId varbinary(16),
    @tp_IsCurrentVersion bit,
    @tp_ParentId uniqueidentifier,
    @tp_DocId uniqueidentifier,
    @tp_CalculatedVersion int,
    @tp_Level tinyint,
    @tp_FieldId uniqueidentifier,
    @tp_Ordinal int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserDataJunctions] WITH (INDEX=AllUserDataJunctions_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_DeleteTransactionId = @tp_DeleteTransactionId AND
        tp_IsCurrentVersion = @tp_IsCurrentVersion AND
        tp_ParentId = @tp_ParentId AND
        tp_DocId = @tp_DocId AND
        tp_CalculatedVersion = @tp_CalculatedVersion AND
        tp_Level = @tp_Level AND
        tp_FieldId = @tp_FieldId AND
        tp_Ordinal = @tp_Ordinal

go

