create view [dbo].[View.GetEmployer]
as
select a.[Id]  
     ,a.[FullName] 
      ,a.[Email]
	  ,a.PositionId
	  ,b.Title as PositionName
	  ,a.DepartmentId
	  ,c.Title as DepartmentName
	  ,c.Code as DepartmentCode
	  from [PersonalProfile] a 
inner join Position b on a.PositionId=b.Id
inner join Department c on a.DepartmentId=c.Id

go

