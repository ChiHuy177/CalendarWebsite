CREATE PROCEDURE [dbo].[proc_SetDeadWebNotificationCount](
    @SiteId uniqueidentifier,
    @NotifyCount smallint,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        S
    SET
        S.DeadWebNotifyCount = @NotifyCount
    FROM
        TVF_Sites_Id(@SiteId) AS S
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL,
        NULL, 8192,  8, NULL
    RETURN 0

go

