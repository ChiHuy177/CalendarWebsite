-- [Work_FlowChart_StatusGetData] 'node-d91a6823-b63a-46ca-a4f4-51ae2b764d0a',333572                       
   CREATE   PROC [dbo].[Work_FlowChart_StatusGetData]                       
   @nodeid AS NVARCHAR(500)                       
   ,@projectId as nvarchar(500)                       
   AS                       
   ----------------------------------------                       
   -- kiểm tra xem có phải là node đầu tiên sau node bắt đầu không nếu là node đầu thì show chức năng cho phép chọn chỉ dùng cho cv con                       
   declare @step as char(10)                       
   set @step=( select Step from Dynamic.Data_LSQTCV a                       
   WHERE ISNULL(a.nodeid, '') = @nodeid and a.ProjectId=@projectId)                       
   select * into #a from Dynamic.Data_LSQTCV a                       
   WHERE a.ProjectId=@projectId and @step in (select * from string_split(a.NextStep,','))                       
   SELECT a.[Id]                       
   ,a.[UserWorkflowId]                       
   ,a.[Ten]                       
   ,a.[Duan]                       
   ,a.[TrangThaiCongViec]                       
   ,a.[NguoiChinhSua]                       
   ,a.[nodeid]                       
   ,a.[QuyenXacNhanHoanThanhCV]                       
   ,ISNULL(a.[UseForChild],'0') as [UseForChild]                       
   ,case when ISNULL(a.[UseForChild],'0')='1' or a.IsSetting ='1' then 'false' else 'true' end as DisplayFormPriority                    
   ,case when (select COUNT(*) from #a where Step=0)>0 then 'true' else 'false' end as [Show]                
   ,a.ColumnFormExtendId    
   ,a.FormExtendId  
   into #data                    
   FROM DYNAMIC.Data_RESOURCETTFC AS a                       
   WHERE ISNULL(a.nodeid, '') = @nodeid and a.Duan=@projectId                       
   if(select COUNT(*) from #data)>0                    
   begin                     
   select * from #data                    
   end                    
   else               
   begin                          
   select                 
   b.Id                 
   , b.Ten as Name                  
   , b.Duan as ProjectId                  
   , b.TrangThaiCongViec                  
   ,isnull(b.NguoiChinhSua,'') as [user]                  
   ,b.UserWorkflowId                 
   ,c.Step                  
   --,c.WorkflowId                  
   ,c.NextStep                  
   ,ISNULL(a.QuanLy,'') as Manager                 
   , b.QuyenXacNhanHoanThanhCV                 
   ,b.IsSetting            
   ,UseForChild          
   into #b                  
   from [Dynamic].Data_RESOURCEDA a                 
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan                  
   inner join Dynamic.Data_LSQTCV c on a.UserWorkflowId = c.ProjectId and b.nodeid=c.Nodeid and c.Title<>''                  
   where c.Nodeid=@nodeid and c.ProjectId=@projectId                  
   order by c.Step              
   ;                  
   with tab as                  
   (                  
   select b.Id                 
   , b.Name                  
   , b.ProjectId                  
   , b.TrangThaiCongViec                  
   ,b.[user]                  
   ,b.UserWorkflowId                  
   ,b.Step                  
   ,b.Manager                 
   ,QuyenXacNhanHoanThanhCV                 
   ,b.IsSetting              
   ,UseForChild          
   from #b b --where UserWorkflowId=342595                  
   union                  
   select b.Id                 
   , b.Ten as Name                  
   , b.Duan as ProjectId                  
   , b.TrangThaiCongViec                  
   ,isnull(b.NguoiChinhSua,'') as [user]                 
   ,b.UserWorkflowId                  
   ,c.Step                  
   ,ISNULL(a.QuanLy,'') as Manager                 
   , b.QuyenXacNhanHoanThanhCV                 
   ,b.IsSetting               
   ,UseForChild          
   from [Dynamic].Data_RESOURCETTFC b                  
   inner join             
   (                  
   select Title,a.ProjectId,a.Step,a.Nodeid from Dynamic.Data_LSQTCV a                 
   inner join #b b on a.Step in (select * from string_split(b.NextStep,',')) and a.ProjectId=b.ProjectId                  
   ) c on b.nodeid=c.Nodeid and b.Duan=c.ProjectId                  
   inner join [Dynamic].Data_RESOURCEDA a on a.UserWorkflowId=b.Duan                 
   )                 
   select * into #c from tab order by Step         
   select                
   0 as [Id]                       
   ,0 as [UserWorkflowId]                     
   ,'' as [Ten]                       
   ,@projectId as [Duan]                       
   ,0 as [TrangThaiCongViec]                       
   ,'' [NguoiChinhSua]                       
   , @nodeid as [nodeid]                       
   ,'' as [QuyenXacNhanHoanThanhCV]               
   ,case when  (select COUNT(*) from #c where UseForChild=1)>0 then '1' else '0' end as UseForChild                  
   ,case when  (select COUNT(*) from #c where UseForChild=1 or IsSetting ='1' )>0 then 'false' else 'true' end as DisplayFormPriority                  
   ,case when (select COUNT(*) from #a where Step!=0)>0 then 'false' else 'True' end as [Show]               
   end                     
   --   begin                     
   --   select Id,Title, Step,Item as NextStep,Nodeid, ProjectId                
   --into #b                
   --from Dynamic.Data_LSQTCV a                    
   --  cross apply Split(ISNULL(a.nextstep,''),',')b                
   --  WHERE a.ProjectId=@projectId                 
   --;                 
   --  WITH Managers AS                    
   --     (                    
   --  select * from                 
   --  #b a                
   --  WHERE a.ProjectId=@projectId and Step=@step                
   --  UNION ALL                    
   --  --recursive execution                    
   --  SELECT                   
   --  a.*                
   --  FROM #b  a                    
   --  inner join Managers b on b.Step= a.NextStep                
   --  where b.NextStep<>''                
   --     )                 
   --  select a.*,UseForChild into #c from Managers a                
   --  left join DYNAMIC.Data_RESOURCETTFC b on a.Nodeid=b.nodeid and a.ProjectId=b.Duan                
   -- select                
   -- 0 as [Id]                       
   --    ,0 as [UserWorkflowId]                       
   --    ,'' as [Ten]                       
   --    ,@projectId as [Duan]                       
   --    ,0 as [TrangThaiCongViec]                       
   --    ,'' [NguoiChinhSua]                       
   --    , @nodeid as [nodeid]                       
   --    ,'' as [QuyenXacNhanHoanThanhCV]               
   -- ,case when  (select COUNT(*) from #c where UseForChild=1)>0 then '1' else '0' end as UseForChild                  
   --    ,case when  (select COUNT(*) from #c where UseForChild=1)>0 then 'false' else 'true' end as DisplayFormPriority                  
   --   ,case when (select COUNT(*) from #a where Step!=0)>0 then 'false' else 'True' end as [Show]                    
   --   end                     
   drop table #a                
   drop table #data
go

