-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [dbo].[CheckListCheckPath] @IdCheckList NVARCHAR(max)
	,@WorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @DataTableName NVARCHAR(MAX);
	DECLARE @sql AS NVARCHAR(max)
	declare @TableNameCheckListNews Nvarchar(max);
	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
						
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	SET @TableNameCheckListNews = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);	
set @sql='
  DECLARE @TableName bigint;
  set @TableName=(
  select TRY_PARSE(Path AS bigint USING ''en-US'')  FROM '+@TableNameCheckListNews+' where Id='+@IdCheckList+'
  )
  if(@TableName is null)
  begin
  update '+@TableNameCheckListNews+' set IsDeleted=1 where Id='+@IdCheckList+'
  end


		'
		
	PRINT @sql;

	EXEC sp_ExecuteSql @sql;

END
go

