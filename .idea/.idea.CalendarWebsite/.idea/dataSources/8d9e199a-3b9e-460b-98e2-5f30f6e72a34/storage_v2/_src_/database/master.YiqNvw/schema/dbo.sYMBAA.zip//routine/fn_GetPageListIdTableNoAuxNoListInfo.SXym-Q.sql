CREATE FUNCTION [dbo].[fn_GetPageListIdTableNoAuxNoListInfo](
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @RootWebId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @UserInfoListId uniqueidentifier,
    @UserId int,
    @Level tinyint)
RETURNS TABLE
AS
RETURN
(    
    SELECT
        WPL.tp_WebId AS tp_WebId,
        WPL.tp_ListId AS tp_ListId
    FROM
        TVF_WebPartLists_SitePageLvlUser(@SiteId, @DocId, @Level, NULL) AS WPL
    UNION 
    SELECT
        WPL.tp_WebId AS tp_WebId,
        WPL.tp_ListId AS tp_ListId
    FROM
        TVF_WebPartLists_SitePageLvlUser(@SiteId, @DocId, @Level, @UserId) AS WPL
    WHERE
        @UserId IS NOT NULL
)

go

