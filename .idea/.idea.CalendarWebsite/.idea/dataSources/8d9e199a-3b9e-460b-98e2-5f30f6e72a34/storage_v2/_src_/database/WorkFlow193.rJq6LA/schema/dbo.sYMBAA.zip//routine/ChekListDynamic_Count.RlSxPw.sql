
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE   PROCEDURE [dbo].[ChekListDynamic_Count] @WorkflowId BIGINT
	,@UserWorkflowId BIGINT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@CheckListId_Str AS NVARCHAR(MAX)
		,@UserWorkflowId_Str AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX)
		,@CheckListId AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);

	IF @CheckListId IS NULL
		SET @CheckListId_Str = 'NULL'
	ELSE
		SET @CheckListId_Str = CAST(@CheckListId AS VARCHAR)

	IF @UserWorkflowId IS NULL
		SET @UserWorkflowId_Str = 'NULL'
	ELSE
		SET @UserWorkflowId_Str = CAST(@UserWorkflowId AS VARCHAR)

	SET @Sql = 'SELECT top 1 a.Id  ' + ' FROM ' + @TableName + ' a LEFT JOIN CheckList b On a.CheckListId = b.id LEFT JOIN DocumentType d on b.TypeId = d.id' + ' LEFT JOIN PersonalProfile p on p.Email = a.CreatedBy' + ' LEFT JOIN PersonalProfile pm on pm.Email = a.ModifiedBy' + ' WHERE a.IsDeleted = 0 and ' + '(ISNULL(' + @CheckListId_Str + ', 1) = 1 or a.CheckListId = ' + @CheckListId_Str + ') and ' + '(ISNULL(' + @UserWorkflowId_Str + ', 1) = 1 or a.UserWorkflowId = ' + @UserWorkflowId_Str + ')';

	PRINT @Sql

	EXEC sp_executesql @Sql;
END
go

