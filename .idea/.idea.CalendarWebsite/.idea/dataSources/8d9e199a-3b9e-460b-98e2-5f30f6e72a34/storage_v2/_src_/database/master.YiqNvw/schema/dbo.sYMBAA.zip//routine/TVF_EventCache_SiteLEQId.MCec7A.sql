CREATE FUNCTION [dbo].[TVF_EventCache_SiteLEQId]
(
    @SiteId uniqueidentifier,
    @LEQId bigint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[EventCache] WITH (INDEX=EventCache_SiteId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Id <= @LEQId

go

