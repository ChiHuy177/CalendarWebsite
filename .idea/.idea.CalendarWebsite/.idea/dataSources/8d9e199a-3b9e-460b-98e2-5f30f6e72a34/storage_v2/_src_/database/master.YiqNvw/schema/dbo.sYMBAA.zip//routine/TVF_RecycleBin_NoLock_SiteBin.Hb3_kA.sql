CREATE FUNCTION [dbo].[TVF_RecycleBin_NoLock_SiteBin]
(
    @SiteId uniqueidentifier,
    @BinId tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[RecycleBin] WITH (NOLOCK, INDEX=RecycleBin_SiteBinWebUser, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        BinId = @BinId

go

