-- select dbo.Work_Fn_GetProgressProject ('RESOURCEDA22090003')    
                  CREATE   FUNCTION [dbo].[Work_Fn_GetProgressProject]     
                  (@projectCode as nvarchar(250)  )    
                  returns float    
                  as    
                  begin     
                      
                   return (select AVG(CONVERT(int, dbo.fn_GetNumeric(a.Tiendo)))                
                  FROM [Dynamic].Data_WORK AS a                
                    
                  where a.Duan=@projectCode   and ISNULL(a.IsActive,'True')='True'        
                      
                  )    
                  end
go

