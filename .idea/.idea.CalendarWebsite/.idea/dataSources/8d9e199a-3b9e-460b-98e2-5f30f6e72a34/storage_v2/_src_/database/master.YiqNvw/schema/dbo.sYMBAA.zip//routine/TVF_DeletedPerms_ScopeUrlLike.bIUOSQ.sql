CREATE FUNCTION [dbo].[TVF_DeletedPerms_ScopeUrlLike]
(
    @SiteId uniqueidentifier,
    @ScopeUrlLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Perms] WITH (INDEX=Perms_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DelTransId <> 0x AND
        ScopeUrl LIKE @ScopeUrlLike

go

