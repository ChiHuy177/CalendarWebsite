CREATE FUNCTION [dbo].[TVF_DocsToStreams_SiteIdDocId]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[DocsToStreams] WITH (INDEX=DocsToStreams_CI, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DocId = @DocId

go

