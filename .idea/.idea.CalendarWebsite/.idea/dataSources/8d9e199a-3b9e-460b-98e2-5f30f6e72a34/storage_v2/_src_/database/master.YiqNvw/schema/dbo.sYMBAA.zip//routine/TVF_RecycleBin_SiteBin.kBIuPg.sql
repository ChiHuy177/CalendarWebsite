CREATE FUNCTION [dbo].[TVF_RecycleBin_SiteBin]
(
    @SiteId uniqueidentifier,
    @BinId tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[RecycleBin] WITH (INDEX=RecycleBin_SiteBinWebUser, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        BinId = @BinId

go

