CREATE FUNCTION [dbo].[TVF_WorkflowAssoc_SiteWebList]
(
    @SiteId uniqueidentifier,
    @WebId varbinary(16),
    @ListId varbinary(16)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[WorkflowAssociation] WITH (INDEX=WorkflowAssociation_Parent, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@WebId IS NULL AND WebId IS NULL) OR @WebId=WebId) AND
        ((@ListId IS NULL AND ListId IS NULL) OR @ListId=ListId)

go

