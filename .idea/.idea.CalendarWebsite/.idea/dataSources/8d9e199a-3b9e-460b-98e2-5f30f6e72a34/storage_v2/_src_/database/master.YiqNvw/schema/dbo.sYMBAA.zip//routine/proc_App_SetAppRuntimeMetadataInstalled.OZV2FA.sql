CREATE Procedure [dbo].[proc_App_SetAppRuntimeMetadataInstalled] (
    @AppInstanceId uniqueidentifier,
    @IsInstalled bit,
    @SiteId uniqueidentifier
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
UPDATE TVF_AppRuntimeMetadata_AppInstanceId(@SiteId, @AppInstanceId)
    SET IsInstalled = @IsInstalled
COMMIT TRANSACTION

go

