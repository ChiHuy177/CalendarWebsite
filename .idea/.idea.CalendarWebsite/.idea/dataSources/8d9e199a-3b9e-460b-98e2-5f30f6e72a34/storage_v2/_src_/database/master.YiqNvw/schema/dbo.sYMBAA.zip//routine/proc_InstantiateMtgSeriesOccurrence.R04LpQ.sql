CREATE PROCEDURE [dbo].[proc_InstantiateMtgSeriesOccurrence]
(
    @SiteId                 uniqueidentifier,
    @WebId                  uniqueidentifier,
    @InstanceID             int,
    @DTStartUTC             datetime,
    @CreateOrphaned         bit = 0,
    @ForAttendees           bit = NULL, 
    @AlreadyInstantiated    bit = NULL OUTPUT,
    @RequestGuid            uniqueidentifier = NULL OUTPUT  
)
AS
    SET NOCOUNT ON
    SET @AlreadyInstantiated = 0
    DECLARE @MeetingsListID uniqueidentifier
    EXEC proc_GetUniqueList @SiteId, @WebId, 200, @MeetingsListID OUTPUT
    IF @MeetingsListID IS NULL
        RETURN 13
    DECLARE @Error int SET @Error = 0 BEGIN TRAN
    EXEC @Error = proc_SplitMtgSeriesOccurrenceEntry
        @SiteId,
        @WebId,
        @MeetingsListID,
        @InstanceID,
        @DTStartUTC,
        @CreateOrphaned
    IF @Error <> 0
        GOTO CLEANUP
    EXEC @Error = proc_InstantiateMtgInstance
        @SiteId,
        @WebId,
        NULL,   
        @InstanceID,
        @ForAttendees
    IF @Error <> 0
        GOTO CLEANUP
    IF (
        SELECT
            COUNT(1)
        FROM
            TVF_UserData_List(@SiteId, @MeetingsListID) AS UD
        WHERE
            UD.tp_InstanceID = @InstanceID AND
            UD.tp_RowOrdinal = 0
        ) > 1
    BEGIN
        SET @Error = 183
        IF NOT EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_UserData_List_Mtg(@SiteId, @MeetingsListID) AS UD
            WHERE
                UD.tp_InstanceID = @InstanceID AND
                UD.int1 <> 2 AND
                UD.tp_RowOrdinal = 0)
        BEGIN
            SET @Error = 80
            SET @AlreadyInstantiated = 1
        END
    END
CLEANUP:
    IF (@Error <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Error

go

