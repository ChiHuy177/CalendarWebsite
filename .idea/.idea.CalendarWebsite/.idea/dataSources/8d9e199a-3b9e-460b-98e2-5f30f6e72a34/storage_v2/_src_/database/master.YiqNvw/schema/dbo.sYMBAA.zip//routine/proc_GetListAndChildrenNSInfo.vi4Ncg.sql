CREATE PROCEDURE [dbo].[proc_GetListAndChildrenNSInfo](
    @SiteId uniqueidentifier,
    @WebId  uniqueidentifier,
    @ListId uniqueidentifier,
    @FolderId uniqueidentifier,
    @GetList bit = 0,
    @GetSubFolders bit = 0,
    @Lcid int = 0,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
SET NOCOUNT ON
IF @GetList = 1
BEGIN
    SELECT TOP 1
        @FolderId = l1.tp_RootFolder
    FROM
        TVF_Lists_NoLock_CI(@SiteId, @WebId, @ListId) AS l1
    SELECT
        l1.tp_Title,
        l1.tp_ID,
        dbo.fn_GetFullUrl(d1.DirName, d1.LeafName) AS FullUrl,
        l1.tp_RootFolder,
        l1.tp_ImageUrl,
        l1.tp_BaseType,
        l1.tp_ServerTemplate,
        d1.FolderChildCount,
        AllListsPlus.TitleResource,
        CASE WHEN Res.BitType = 0 THEN Res.NvarcharVal ELSE Res.NtextVal END AS UserResource,
        p1.Acl,
        p1.AnonymousPermMask
    FROM
       TVF_Lists_NoLock_CI(@SiteId, @WebId, @ListId) AS l1 
   OUTER APPLY
       TVF_Resources_PK(l1.tp_SiteId, l1.tp_WebId, l1.tp_ID, N'_ListTitle', @Lcid) AS Res
    CROSS APPLY 
        TVF_Docs_NoLock_Id_Level(l1.tp_SiteId, l1.tp_RootFolder, 1) AS d1 
    OUTER APPLY
        TVF_AllListsPlus_ListId(l1.tp_SiteId, l1.tp_ID) AS AllListsPlus
    CROSS APPLY 
        TVF_Perms_ScopeId(d1.SiteId, d1.ScopeId) AS p1
    WHERE
        d1.Type=1 AND     
        d1.SortBehavior=1 
    ORDER BY
        l1.tp_BaseType,
        l1.tp_Title
    OPTION (FORCE ORDER)
END
IF @GetSubFolders=1
BEGIN   
    SELECT
        d1.LeafName,
        d1.Id,
        dbo.fn_GetFullUrl(d1.DirName, d1.LeafName),
        d1.FolderChildCount,
        d1.ListId,
        p1.Acl,
        p1.AnonymousPermMask
    FROM
        TVF_Docs_NoLock_PId(@SiteId, @FolderId) AS d1
    CROSS APPLY 
        TVF_Perms_ScopeId(d1.SiteId, d1.ScopeId) AS p1
    WHERE
        d1.Type = 1 AND
        d1.SortBehavior = 1 AND
        d1.DoclibRowId IS NOT NULL AND
        d1.Level = 1
    ORDER BY
        d1.LeafName
    OPTION (FORCE ORDER, LOOP JOIN)
END
    RETURN 0

go

