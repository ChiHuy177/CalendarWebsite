CREATE FUNCTION [dbo].[TVF_EventCache_LTId]
(
    @LTId bigint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[EventCache] WITH (INDEX=EventCache_Id, FORCESEEK)
    WHERE
        Id < @LTId

go

