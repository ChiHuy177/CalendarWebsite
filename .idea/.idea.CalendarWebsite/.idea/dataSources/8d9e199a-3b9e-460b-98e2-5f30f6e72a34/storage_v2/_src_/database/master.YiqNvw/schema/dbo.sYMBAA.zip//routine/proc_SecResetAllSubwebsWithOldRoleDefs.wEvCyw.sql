CREATE PROCEDURE [dbo].[proc_SecResetAllSubwebsWithOldRoleDefs](
    @SiteId             uniqueidentifier,
    @WebId              uniqueidentifier,
    @WebUrl             nvarchar(256), 
    @NewScopeId         uniqueidentifier,
    @OldRoleDefWebId    uniqueidentifier)
AS
    SET NOCOUNT ON
    DECLARE @UrlLike nvarchar(1024)
    EXEC proc_EscapeForLike @WebUrl, @UrlLike OUTPUT
    UPDATE
        W
    SET
        W.ScopeId = @NewScopeId,
        W.FirstUniqueAncestorWebId = @WebId
    FROM
        TVF_Webs_SiteId(@SiteId) AS W
    CROSS APPLY
        TVF_Perms_ScopeId(W.SiteId, W.ScopeId) AS P
    WHERE
        P.RoleDefWebId = @OldRoleDefWebId AND
        (W.FullUrl = @WebUrl OR W.FullUrl LIKE @UrlLike)
    EXEC proc_SecSetDocsListsInSubwebsToNewScopeId @SiteId, @WebId, @WebUrl, @NewScopeId, @OldRoleDefWebId

go

