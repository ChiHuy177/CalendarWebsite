CREATE FUNCTION [dbo].[TVF_DocStreams_RbsIdNull]
(
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[DocStreams] WITH (INDEX=DocStreams_CI)
    WHERE
        RbsId IS NULL

go

