CREATE FUNCTION [dbo].[TVF_SiteQuota_Session]
(
    @SiteId uniqueidentifier,
    @SessionId smallint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SiteQuota] WITH (INDEX=SiteQuota_SiteId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SessionId = @SessionId

go

