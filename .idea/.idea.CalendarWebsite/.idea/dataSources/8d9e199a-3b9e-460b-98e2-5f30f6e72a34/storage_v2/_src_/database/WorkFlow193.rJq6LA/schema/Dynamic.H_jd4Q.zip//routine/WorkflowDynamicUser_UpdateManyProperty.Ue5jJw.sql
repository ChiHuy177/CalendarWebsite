-- =============================================
-- Author:		Duy Dam
-- Create date: 28/02/2024
-- Description:	Update Dynamic value of one property
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_UpdateManyProperty]
    @UserWorkflowId BIGINT,
    @Value NVARCHAR(MAX),
    @Email NVARCHAR(MAX) = NULL
WITH RECOMPILE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @WorkflowId AS BIGINT,
            @WorkflowCode AS NVARCHAR(MAX),
            @WorkflowTableName AS NVARCHAR(MAX),
            @DataTableName AS NVARCHAR(MAX),
            @Sql AS NVARCHAR(MAX),
            @WorkflowQueryUpdate AS NVARCHAR(MAX) = '[Data]',
            @IDVar INT,
            @IDName NVARCHAR(MAX),
            @IDValue NVARCHAR(MAX),
            @IDDefaultIndex INT,
            @IDPropertyName NVARCHAR(MAX),
            @LineBreak NCHAR(2) = NCHAR(13) + NCHAR(10);
    DECLARE @TempDestinationTable2 TABLE
    (
        Id BIGINT,
        Name NVARCHAR(max),
        Value NVARCHAR(max),
        DefaultIndex INT,
        DataQueryUpdate NVARCHAR(max),
        PropertyName NVARCHAR(max)
    );

    SET @WorkflowId =
    (
        SELECT [WorkflowId] FROM [dbo].[USerWorkflow] WHERE Id = @UserWorkflowId
    );

    INSERT @TempDestinationTable2
    (
        Id,
        DefaultIndex,
        Name,
        Value,
        DataQueryUpdate,
        PropertyName
    )
    SELECT j1.Id,
           j1.DefaultIndex,
           j1.Name,
           (CASE
                WHEN
                (
                    (
                        p.IsNumber = 1
                        OR p.IsCurrency = 1
                    )
                    AND p.IsViewOnly <> 1
                ) THEN
                    CAST(j1.Value AS VARCHAR)
                WHEN p.IsYesNo = 1 THEN
           (CASE j1.Value
                WHEN 'true' THEN
                    '1'
                WHEN 'false' THEN
                    '0'
                ELSE
                    'null'
            END
           )
                ELSE
                    CONCAT('N''', j1.Value, '''')
            END
           ) AS Value,
           CASE
               WHEN j1.Name LIKE 'dataJson_%'
                    AND j1.DefaultIndex IS NOT NULL THEN
                   CONCAT(
                             '[',
                             p.Name,
                             '] = JSON_MODIFY([',
                             p.Name,
                             '], ''$[',
                             CAST((j1.DefaultIndex) AS VARCHAR(max)) + '].',
                             REPLACE(j1.Name, 'dataJson_', ''),
                             ''', ',
                             (CASE
                                  WHEN
                                  (
                                      (
                                          p.IsNumber = 1
                                          OR p.IsCurrency = 1
                                      )
                                      AND p.IsViewOnly <> 1
                                  ) THEN
                                      CAST(j1.Value AS VARCHAR)
                                  WHEN p.IsYesNo = 1 THEN
                             (CASE j1.Value
                                  WHEN 'true' THEN
                                      '1'
                                  WHEN 'false' THEN
                                      '0'
                                  ELSE
                                      'null'
                              END
                             )
                                  ELSE
                                      CONCAT('N''', j1.Value, '''')
                              END
                             ),
                             ')'
                         )
               ELSE
                   CONCAT(   '[',
                             j1.Name,
                             '] = ',
                             (CASE
                                  WHEN
                                  (
                                      (
                                          p.IsNumber = 1
                                          OR p.IsCurrency = 1
                                      )
                                      AND p.IsViewOnly <> 1
                                  ) THEN
                                      CAST(j1.Value AS VARCHAR)
                                  WHEN p.IsYesNo = 1 THEN
                             (CASE j1.Value
                                  WHEN 'true' THEN
                                      '1'
                                  WHEN 'false' THEN
                                      '0'
                                  ELSE
                                      'null'
                              END
                             )
                                  ELSE
                                      CONCAT('N''', j1.Value, '''')
                              END
                             )
                         )
           END AS DataQueryUpdate,
           p.Name AS PropertyName
    FROM
        OPENJSON(@Value, '$.Data')
        WITH
        (
            Id NVARCHAR(max) '$.Id',
            DefaultIndex INT '$.DefaultIndex',
            Name NVARCHAR(max) '$.Name',
            Value NVARCHAR(max) '$.Value'
        ) j1
        JOIN [dbo].[Property] p
            ON p.Id = j1.Id

    SET @WorkflowCode =
    (
        SELECT Code FROM [dbo].[Workflow] WHERE Id = @WorkflowId
    );
    SET @WorkflowTableName = CONCAT('Dynamic.Workflow_', dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9'));
    SET @DataTableName = CONCAT('Dynamic.Data_', dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9'));

    DECLARE @RowCount INT = (
                                SELECT COUNT(*) FROM @TempDestinationTable2
                            );

    WHILE @RowCount > 0
    BEGIN
        SELECT @IDVar = Id,
               @IDName = Name,
               @IDValue = Value,
               @IDDefaultIndex = DefaultIndex,
               @IDPropertyName = PropertyName
        FROM @TempDestinationTable2
        ORDER BY Id DESC OFFSET @RowCount - 1 ROWS FETCH NEXT 1 ROWS ONLY;

        IF @IDName LIKE 'dataJson_%'
           AND @IDDefaultIndex IS NOT NULL
        BEGIN
            SET @WorkflowQueryUpdate
                = 'JSON_MODIFY(' + @WorkflowQueryUpdate + ', ''$.' + @IDPropertyName + ''', '
                  + 'CONCAT(N'''', JSON_MODIFY((SELECT value from OPENJSON((select top 1 [Data] from '
                  + @WorkflowTableName + ' where UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR)
                  + ')) where [key] = N''' + @IDPropertyName + '''), ''$[' + CAST((@IDDefaultIndex) AS VARCHAR(max))
                  + '].' + REPLACE(@IDName, 'dataJson_', '') + ''', ' + @IDValue + ')))'
        END
        ELSE
        BEGIN
            SET @WorkflowQueryUpdate
                = 'JSON_MODIFY(' + @WorkflowQueryUpdate + ', ''$.' + @IDName + ''', ' + @IDValue + ')'
        END

        SET @RowCount -= 1;
    END

    SET @Sql
        = 'BEGIN TRANSACTION' + @LineBreak + 'BEGIN TRY' + @LineBreak
          -- update Dynamic.Workflow_
          + 'UPDATE ' + @WorkflowTableName + ' SET [Data] = ' + @WorkflowQueryUpdate + ', LastModified = '
          + CONCAT('''', GETDATE(), '''') + ', ModifiedBy = ' + +CONCAT('''', @Email, '''') + @LineBreak
          + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';' + @LineBreak
          --update Dynamic.Data_
          + 'UPDATE ' + @DataTableName + ' SET ' +
          (
              SELECT STRING_AGG(DataQueryUpdate, ', ') FROM @TempDestinationTable2
          ) + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';' + @LineBreak + 'COMMIT TRANSACTION'
          + @LineBreak + 'END TRY' + @LineBreak + 'BEGIN CATCH' + @LineBreak + 'IF @@TRANCOUNT > 0' + @LineBreak
          + '    ROLLBACK TRANSACTION' + @LineBreak + 'END CATCH' + @LineBreak;

    PRINT @SQL;
    EXEC sp_ExecuteSql @SQL;
END
go

