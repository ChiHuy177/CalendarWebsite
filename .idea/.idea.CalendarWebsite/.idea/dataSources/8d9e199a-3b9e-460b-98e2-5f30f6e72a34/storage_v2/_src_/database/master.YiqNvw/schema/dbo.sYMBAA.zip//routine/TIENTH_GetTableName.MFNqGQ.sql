
-- =============================================
-- Author:		Duy Dam
-- Create date: 04/10/2021
-- Description:	Get all data from dynamuc CheckList
-- =============================================
CREATE PROCEDURE [dbo].[TIENTH_GetTableName] @WorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@CheckListId_Str AS NVARCHAR(MAX)
		,@UserWorkflowId_Str AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[WorkFlow165]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);

	IF OBJECT_ID (@TableName, N'U') IS NOT NULL 
   SELECT @TableName AS TableName ELSE SELECT 'NONE' AS TableName;
END
go

