CREATE FUNCTION [dbo].[fn_Lists_DocRootOrDocItems](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @DocType int,
    @DocId uniqueidentifier,
    @DoclibRowId int)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        TVF_Lists_NoLock_CI(@SiteId, @WebId, @ListId) L
    WHERE
        @DocType = 1 AND L.tp_RootFolder = @DocId 
        OR @DoclibRowId IS NOT NULL

go

