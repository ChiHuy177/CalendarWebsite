CREATE PROCEDURE [dbo].[proc_GetListSubset]
(
    @WebId uniqueidentifier,
    @PageSize int,
    @StartRow int,
    @LCID int,
    @SortDirection nvarchar(4)
)
AS
    SET NOCOUNT ON
    IF @SortDirection = 'DESC'
        SELECT
            Lists.tp_ID,
            CASE WHEN R.NvarcharVal IS NULL THEN
				CASE WHEN P.TitleResource IS NULL OR P.TitleResource = '_ListTitle' THEN 
					Lists.tp_Title
				ELSE
					P.TitleResource
				END 
			ELSE 
				R.NvarcharVal
			END
        FROM
            Lists
        INNER JOIN
        (SELECT
            tp_ID,
            tp_Title,
            ROW_NUMBER() OVER (ORDER BY Lists.tp_Title DESC) AS RowNumber
         FROM
             Lists
         WHERE
             Lists.tp_WebId = @WebId) Lists2
        ON
            Lists.tp_ID = Lists2.tp_ID
        OUTER APPLY
            TVF_AllListsPlus_ListId(Lists.tp_SiteId, Lists.tp_Id) AS P
        OUTER APPLY
            TVF_Resources_PK(Lists.tp_SiteId, Lists.tp_WebId, Lists.tp_Id, N'_ListTitle', @LCID) AS R
        WHERE
            tp_WebId=@WebId AND
            RowNumber >= @StartRow AND RowNumber < (@StartRow + @PageSize)
    ELSE
        SELECT
            Lists.tp_ID,
            CASE WHEN R.NvarcharVal IS NULL THEN
				CASE WHEN P.TitleResource IS NULL OR P.TitleResource = '_ListTitle' THEN
					Lists.tp_Title
				ELSE
					P.TitleResource
				END
			ELSE
				R.NvarcharVal
			END
        FROM
            Lists
        INNER JOIN
        (SELECT
            tp_ID,
            tp_Title,
            ROW_NUMBER() OVER (ORDER BY Lists.tp_Title ASC) AS RowNumber
         FROM
             Lists
         WHERE
             Lists.tp_WebId = @WebId) Lists2
        ON
            Lists.tp_ID = Lists2.tp_ID
        OUTER APPLY
            TVF_AllListsPlus_ListId(Lists.tp_SiteId, Lists.tp_Id) AS P
        OUTER APPLY
            TVF_Resources_PK(Lists.tp_SiteId, Lists.tp_WebId, Lists.tp_Id, N'_ListTitle', @LCID) AS R
        WHERE
            tp_WebId = @WebId AND
            RowNumber >= @StartRow AND RowNumber < (@StartRow + @PageSize)

go

