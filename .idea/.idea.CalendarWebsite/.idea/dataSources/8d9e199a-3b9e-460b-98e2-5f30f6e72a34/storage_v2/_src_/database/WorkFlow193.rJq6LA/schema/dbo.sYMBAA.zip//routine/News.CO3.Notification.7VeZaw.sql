-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[News.CO3.Notification] @userId VARCHAR(max)
	,@WorkflowId VARCHAR(max)
	,@InteractWorkflowId VARCHAR(max)


AS
BEGIN
	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @QueryString NVARCHAR(MAX);
	DECLARE @DataTableName NVARCHAR(MAX);
	DECLARE @DataTableNameWF NVARCHAR(MAX);
	DECLARE @DataTableNameNews NVARCHAR(MAX);
	DECLARE @TableNameNews NVARCHAR(MAX);
	declare @TableNameCheckListNews Nvarchar(max);
	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @InteractWorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	SET @DataTableNameWF = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);	
	SET @TableNameNews = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableNameNews = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableNameNews, '^a-z0-9')
			);
	SET @TableNameCheckListNews = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@TableNameNews, '^a-z0-9')
			);
		SET @QueryString = '
			  select ucl.*,dt.Content,ushTime.CreatedTime,u.Id,ush.InteractUser,dt.Department, ushTime.UserWorkflowId as NotiId,InGroup.InGroup,uwfseen.IsSeen from UserWorkflow u
  inner join '+@DataTableNameNews+' dt on u.Id= dt.UserWorkflowId
   outer apply (
   select distinct wf.CreatedBy as InteractUser  from  (('+@DataTableName+' dt
   inner join '+@DataTableNameWF+' wf on dt.UserWorkflowId= wf.UserWorkflowId)
   inner join UserWorkflow uwf on dt.UserWorkflowId= uwf.Id)

   where PostId= u.Id
   and uwf.IsDeleted!=1
   and uwf.UserId!='+@userId+'
   )AS ush
     outer apply (
   select top 1 wf.CreatedTime , wf.UserWorkflowId  from  (('+@DataTableName+' dt
   inner join '+@DataTableNameWF+' wf on dt.UserWorkflowId= wf.UserWorkflowId)
   inner join UserWorkflow uwf on dt.UserWorkflowId= uwf.Id)

   where PostId= u.Id
   and uwf.IsDeleted!=1
   and uwf.UserId!='+@userId+'
   order by wf.CreatedTime desc
   )AS ushTime
     outer apply(
   select count (wfs.UserId) as IsSeen from UserWorkflowSeen wfs
   where wfs.UserWorkflowId=ushTime.UserWorkflowId
   and wfs.UserId='+@userId+'
   )AS uwfseen
      outer apply (
   select count(dt.Type) as CountImg  from  '+@TableNameCheckListNews+' dt

   where dt.UserWorkflowId= u.Id
   and(dt.Type=''image/png'' or dt.Type=''image/jpeg'')
    
   )AS ucl
      outer apply(
   select count(*) as InGroup  from Dynamic.Data_GroupNews dtgr where dtgr.UserWorkflowId=SUBSTRING(dt.Department,3,5) and (dtgr.Member like ''%;P:'+@userId+''' or dtgr.Member like ''%;P:'+@userId+';%'' or dtgr.Member =''P:'+@userId+''' )
   )as InGroup
   
where u.WorkflowId='+@WorkflowId+'
	and u.IsDeleted!=1
	and u.UserId='+@userId+'
	and ush.InteractUser is not null
		order by ushTime.CreatedTime  desc
		
	'
		PRINT @QueryString;

	EXEC sp_ExecuteSql @QueryString;
	END
go

