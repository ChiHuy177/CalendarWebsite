CREATE PROCEDURE [dbo].[proc_IsFieldALookupRelationship](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @FieldId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON;
    IF (EXISTS(
       SELECT TOP 1
            1
       FROM 
            TVF_AllLookupRelationships_SiteListField(@SiteId, @ListId, @FieldId)))
        RETURN 1;
    ELSE
        RETURN 0;

go

