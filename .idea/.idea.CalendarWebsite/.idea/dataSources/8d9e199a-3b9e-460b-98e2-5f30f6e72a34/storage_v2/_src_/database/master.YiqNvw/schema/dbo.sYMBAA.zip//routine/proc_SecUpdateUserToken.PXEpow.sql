CREATE PROCEDURE [dbo].[proc_SecUpdateUserToken](
    @SiteId uniqueidentifier,
    @UserId int)
AS
    SET NOCOUNT ON
    DECLARE @ptr            binary(16)
    DECLARE @groupCount     int
    DECLARE @groupId        int
    DECLARE @binary4        binary(4)
    DECLARE @binary8        binary(8)
    IF NOT EXISTS (
        SELECT TOP 1
            1
        FROM 
            TVF_GroupMembership_NoLock_Member(@SiteId, @UserId))
    BEGIN
        UPDATE 
            UI
        SET 
            UI.tp_Token = NULL
        FROM
            TVF_UserInfo_PK(@SiteId, @UserId) AS UI
        RETURN 0
    END
    SET @groupCount = 0
    SET @binary4 = dbo.fn_ChangeEndian4(0xdcd3)
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    UPDATE 
        UI
    SET 
        UI.tp_Token = @binary4
    FROM
        TVF_UserInfo_PK(@SiteId, @UserId) AS UI
    SET @binary8 = dbo.fn_ChangeEndian4(1)
    UPDATE 
        UI
    SET 
        UI.tp_Token=@binary4+@binary8+0x00000000  
    FROM 
        TVF_UserInfo_UpdLock_PK(@SiteId, @UserId) AS UI
    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR 
    SELECT 
        GM.GroupID
    FROM 
        TVF_GroupMembership_Member(@SiteId, @UserId) AS GM
    ORDER BY
        GM.GroupID
    OPEN cur
    FETCH NEXT FROM cur INTO @groupId
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        SET @binary4 = dbo.fn_ChangeEndian4(@groupId)
        UPDATE 
            UserInfo
        SET 
            tp_Token.WRITE(@binary4,NULL,0)
        FROM 
            TVF_UserInfo_UpdLock_PK(@SiteId, @UserId) AS UserInfo
        SET @groupCount = @groupCount + 1
        FETCH NEXT FROM cur INTO @groupId
    END
    CLOSE cur
    DEALLOCATE cur
    SET @binary4 = dbo.fn_ChangeEndian4(@groupCount)
    UPDATE 
        UserInfo
    SET 
        tp_Token.WRITE(@binary4,12,4)
    FROM 
        TVF_UserInfo_UpdLock_PK(@SiteId, @UserId) AS UserInfo
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @RET

go

