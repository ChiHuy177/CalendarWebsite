CREATE PROCEDURE [dbo].[proc_DeleteSiteInternal](
    @SiteId uniqueidentifier,
    @DeleteIsForMigration bit)
AS
    SET NOCOUNT ON
    DECLARE @ReturnStatus int
    SELECT 
        S.BitFlags 
    FROM
        TVF_Sites_Id(@SiteId) AS S
    SELECT 
        G.DLAlias 
    FROM
        TVF_Groups_Site(@SiteId) AS G
    WHERE
        G.DLAlias IS NOT NULL AND
        G.DLAlias != ''
    EXEC @ReturnStatus = proc_DeleteContentPartition @SiteId, @DeleteIsForMigration
    DELETE
        PSR
    FROM
        TVF_PreviewSiteRequests_SiteId(@SiteId) AS PSR
    WHERE 
        PSR.Status <> 1 
    DELETE FROM
        TVF_SiteQuota_Site(@SiteId)
    DELETE FROM
        TVF_SiteDeletion_SiteId(@SiteId)
    RETURN 0

go

