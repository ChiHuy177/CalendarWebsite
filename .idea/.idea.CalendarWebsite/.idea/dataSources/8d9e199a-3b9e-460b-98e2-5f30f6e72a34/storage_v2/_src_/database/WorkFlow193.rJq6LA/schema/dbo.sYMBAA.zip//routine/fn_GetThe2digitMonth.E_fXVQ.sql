-- =============================================
-- Author:		DuyDam
-- Create date: 29/09/2021
-- Description:	Get two  digit in current month
-- =============================================
CREATE FUNCTION [dbo].[fn_GetThe2digitMonth]
(
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @Result NVARCHAR(MAX);
	SET @Result = RIGHT('00' + CAST(DATEPART(mm, GETDATE()) AS varchar(2)), 2);
	RETURN @Result
END
go

