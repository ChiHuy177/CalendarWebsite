CREATE FUNCTION [dbo].[TVF_SchedSubscriptions_NoLock_AlwaysNotifyBitSiteId]
(
    @AlwaysNotifyBit bit,
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SchedSubscriptions] WITH (NOLOCK, INDEX=SchedSubscriptions_AlwaysNotifyBitSiteId, FORCESEEK)
    WHERE
        ((@AlwaysNotifyBit IS NULL AND AlwaysNotifyBit IS NULL) OR @AlwaysNotifyBit=AlwaysNotifyBit) AND
        SiteId = @SiteId

go

