-- Work_GetAllByProject 'CO3.Workflow' 
   CREATE   PROC [dbo].[Work_GetAllByProject] @projectName AS NVARCHAR(500)
   AS
   SELECT tab.*
   ,a.[value] AS ketqua
   INTO #a
   FROM [Dynamic].[Workflow_WORK] AS Tab
   CROSS APPLY OPENJSON(Tab.data, N'$') AS a
   WHERE a.[key] = 'Duan'
   AND ISNULL(tab.IsDeleted, 0) <> 1
   SELECT a.*
   FROM #a a
   INNER JOIN UserWorkflow c ON a.UserWorkflowId = c.Id
   WHERE ketqua = @projectName
   DROP TABLE #a
go

