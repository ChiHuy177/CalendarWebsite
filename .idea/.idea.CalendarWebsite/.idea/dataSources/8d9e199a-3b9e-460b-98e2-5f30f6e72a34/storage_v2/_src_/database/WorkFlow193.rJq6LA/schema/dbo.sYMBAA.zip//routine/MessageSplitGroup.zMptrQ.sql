
CREATE FUNCTION [dbo].[MessageSplitGroup] (@stringToSplit VARCHAR(MAX))
RETURNS @returnList TABLE ([Name] [bigint])
AS
BEGIN
	DECLARE @name NVARCHAR(255)
	DECLARE @pos INT

	WHILE LEN(@stringToSplit) > 0
	BEGIN
		SELECT @pos = CHARINDEX(';', @stringToSplit)

		IF @pos = 0
			SELECT @pos = LEN(@stringToSplit)

		SELECT @name = SUBSTRING(@stringToSplit, 1, @pos)

		IF @name like '%G:%'
			INSERT INTO @returnList
			SELECT dbo.udf_GetNumeric(@name) 

		SELECT @stringToSplit = SUBSTRING(@stringToSplit, @pos + 1, LEN(@stringToSplit) - @pos)
	END

	RETURN
END
go

