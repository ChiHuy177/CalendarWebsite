CREATE PROCEDURE [dbo].[proc_SaveFileFragmentByTag]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @DocVersion int,
    @UserId int,
    @OldId bigint,
    @Partition tinyint,
    @Tag varbinary(40),
    @BlobData varbinary(max),
    @BlobSize int,
    @QuotaChange int OUTPUT,
    @NewId bigint OUTPUT
)
AS
    SET NOCOUNT ON
    DECLARE @quotaOrLockStatus int
    DECLARE @ERR int, @ROWC int
    DECLARE @latestIdForTag bigint
    DECLARE @iRet int SET @iRet = 0 BEGIN TRAN
    IF @OldId IS NOT NULL
    BEGIN   
        SELECT TOP 1
            @latestIdForTag = F.Id
        FROM
            TVF_AllFileFragments_UpdLock_DocIdPartTag(@SiteId, @DocId, @Partition, @Tag) AS F
        ORDER BY
            F.Id DESC
        IF @@ROWCOUNT <> 1
        BEGIN
            SET @iRet = 33
            GOTO cleanup
        END
        ELSE IF @latestIdForTag <> @OldId
        BEGIN
            SET @iRet = 33
            GOTO cleanup
        END
        INSERT INTO AllFileFragments 
            (SiteId, DocId, Partition, Tag, BlobData, BlobSize)
        VALUES 
            (@SiteId, @DocId, @Partition, @Tag, @BlobData, @BlobSize)
        SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
        IF @ROWC <> 1 OR @ERR <> 0
        BEGIN
            SET @iRet = 4317
            GOTO cleanup
        END
        SET @NewId = SCOPE_IDENTITY()
        SET @QuotaChange = @BlobSize
    END
    ELSE
    BEGIN
        IF EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_AllFileFragments_UpdLock_DocIdPartTag(@SiteId, @DocId, @Partition, @Tag))
        BEGIN
            SET @iRet = 33
            GOTO cleanup
        END
        INSERT INTO AllFileFragments 
            (SiteId, DocId, Partition, Tag, BlobData, BlobSize)
        VALUES 
            (@SiteId, @DocId, @Partition, @Tag, @BlobData, @BlobSize)
        SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
        IF @ROWC <> 1 OR @ERR <> 0
        BEGIN
            SET @iRet = 4317
            GOTO cleanup
        END
        SET @NewId = SCOPE_IDENTITY()
        SET @QuotaChange = @BlobSize
    END
cleanup:
     IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
     RETURN @iRet

go

