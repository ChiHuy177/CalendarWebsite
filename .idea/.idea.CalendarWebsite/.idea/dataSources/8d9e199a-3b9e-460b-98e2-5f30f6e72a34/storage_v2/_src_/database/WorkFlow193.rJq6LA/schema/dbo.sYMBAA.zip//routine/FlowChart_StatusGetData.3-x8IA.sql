      
CREATE PROC [dbo].[FlowChart_StatusGetData]    
@nodeid AS NVARCHAR(500)      
,@projectId as nvarchar(500)  
AS      
SELECT tab.*      
FROM DYNAMIC.Workflow_RESOURCETTFC AS Tab      
CROSS APPLY OPENJSON(Tab.data, N'$') WITH (nodeid NVARCHAR(500) N'$.nodeid',Duan NVARCHAR(500) N'$.Duan') AS a      
WHERE ISNULL(a.nodeid, '') = @nodeid  and a.Duan=@projectId  
  
go

