CREATE   PROC [dbo].[Work_CountComment] 
   @UserWorkflowId as nvarchar(max) 
   as 
   select COUNT(id) as TotalWork,UserWorkflowId as WorkId
   from UserWorkflowNote a 
   inner join (select * from Split(@UserWorkflowId,',')) b on a.UserWorkflowId=b.Item
   group by UserWorkflowId 
go

