CREATE PROCEDURE [dbo].[proc_RestoreWebPartForDoc]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @Level tinyint,
    @OldVersion int,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    DECLARE @cbDelta bigint
    DECLARE @DocId uniqueidentifier
    DECLARE @WebId uniqueidentifier
    DECLARE @IsCurrentVersion bit
    DECLARE @OldVersionLevel tinyint
    SELECT TOP 1
        @DocId = D.Id,
        @WebId = D.WebId
    FROM
        TVF_Docs_Url_Level(@SiteId, @DirName, @LeafName, @Level) AS D
    IF @DocId IS NULL
        RETURN 2 
    SELECT TOP 1
        @OldVersionLevel = DV.Level
    FROM
        TVF_DocVersions_SiteDocIdUIVersion(@SiteId, @DocId, @OldVersion) AS DV
    IF @OldVersionLevel IS NULL
    BEGIN
        SELECT TOP 1
            @OldVersionLevel = D.Level
        FROM
            TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS D
        WHERE
            D.Level < @Level AND
            D.UIVersion = @OldVersion
        ORDER BY
            D.Level ASC
        IF @OldVersionLevel IS NULL
            RETURN 2    
        SET @OldVersion = 0       
        SET @IsCurrentVersion = 1
    END
    ELSE
    BEGIN
        SET @IsCurrentVersion = 0
    END
    DELETE
        WPL
    FROM
        TVF_WebPartLists_SitePageLvlUser(@SiteId, @DocId, @Level, NULL) AS WPL
    DELETE
        WP
    FROM
        TVF_WebParts_CI(
            @SiteId,
            @DocId,
            @Level,
            NULL) 
        AS WP
    INSERT INTO WebPartLists(
        tp_SiteId,
        tp_ListId,
        tp_WebId,
        tp_PageUrlID,
        tp_WebPartID,
        tp_UserID,
        tp_Level)
    SELECT
        AWP.tp_SiteId,
        AWP.tp_ListId,
        @WebId,
        @DocId,
        AWP.tp_ID,
        NULL, 
        @Level
    FROM
        TVF_AllWebParts_SiteIsCurPageIdPageVerLvl(
            @SiteId,
            @IsCurrentVersion,
            @DocId,
            @OldVersion,
            @OldVersionLevel) AS AWP
    WHERE
        AWP.tp_ListId IS NOT NULL AND
        AWP.tp_UserID IS NULL
    INSERT INTO AllWebParts(
        tp_SiteId,
        tp_ID,
        tp_ListId,
        tp_Type,
        tp_Flags,
        tp_BaseViewID,
        tp_DisplayName,
        tp_ContentTypeId,
        tp_Version,
        tp_PageUrlID,
        tp_PartOrder,
        tp_ZoneID,
        tp_IsIncluded,
        tp_FrameState,
        tp_View,
        tp_WebPartTypeId,
        tp_Assembly,
        tp_Class,
        tp_SolutionId,
        tp_SolutionWebId,
        tp_AllUsersProperties,
        tp_PerUserProperties,
        tp_WebPartIdProperty,
        tp_Cache,
        tp_UserID,
        tp_Source,
        tp_CreationTime,
        tp_Size,
        tp_Level,
        tp_HasFGP,
        tp_PageVersion)
    SELECT
        @SiteId,
        AWP.tp_ID,
        AWP.tp_ListId,
        AWP.tp_Type,
        AWP.tp_Flags,
        AWP.tp_BaseViewID,
        AWP.tp_DisplayName,
        AWP.tp_ContentTypeId,
        AWP.tp_Version,
        @DocId,
        AWP.tp_PartOrder,
        AWP.tp_ZoneID,
        AWP.tp_IsIncluded,
        AWP.tp_FrameState,
        AWP.tp_View,
        AWP.tp_WebPartTypeId,
        AWP.tp_Assembly,
        AWP.tp_Class,
        AWP.tp_SolutionId,
        AWP.tp_SolutionWebId,
        AWP.tp_AllUsersProperties,
        AWP.tp_PerUserProperties,
        AWP.tp_WebPartIdProperty,
        AWP.tp_Cache,
        NULL, 
        AWP.tp_Source,
        AWP.tp_CreationTime,
        AWP.tp_Size,
        @Level,
        AWP.tp_HasFGP,
        0 
    FROM
        TVF_AllWebParts_CI(
            @SiteId,
            @IsCurrentVersion,
            @DocId,
            @OldVersion,
            @OldVersionLevel,
            NULL ) AS AWP
    IF (@@ERROR <> 0)
       RETURN -2147467259  
    RETURN 0   

go

