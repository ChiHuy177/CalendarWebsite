-- =============================================
-- Author:		DuyDam
-- Create date: 04/10/2021
-- Description:	Delete data in to dynamic checklist
-- =============================================
CREATE PROCEDURE [dbo].[ChekListDynamic_Delete] @Id BIGINT
	,@WorkflowId BIGINT
	,@ModifiedBy nvarchar(max) = null
	,@RemoveFromDB bit = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	print @TableName;
	SET @Sql = 'UPDATE ' + @TableName + ' SET IsDeleted = 1, ModifiedBy = N''' + ISNULL(@ModifiedBy,'') + ''' ,UserWorkflowId = ' + (CASE  @RemoveFromDB WHEN 1 THEN '-1' ELSE 'UserWorkflowId' END) 
				+' WHERE Id = ' + CAST(@Id AS VARCHAR);
	--SET @Sql = 'UPDATE ' + @TableName + ' SET IsDeleted = 1, ModifiedBy = N''' + @ModifiedBy + ''' ,UserWorkflowId = '
	--print @Sql;
	EXEC sp_executesql @Sql;
END
go

