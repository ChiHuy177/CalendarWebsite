                
-- Work_CheckWorkIsDone 117183,'node-4bccec6a-f1d3-4dc2-b5c2-fae4f1845ac8,node-e48febeb-3a85-436d-b452-46e666cb4cec'    
    
CREATE PROC [dbo].[Work_CheckWorkIsDone]                 
@workProcessId as nvarchar(500)                
,@nodeIdList as nvarchar(max)  
,@parentId as nvarchar(50)  
as              
              
select               
case when b.TrangThaiCongViec=N'Hủy' then N'Từ chối' else b.TrangThaiCongViec end as TrangThaiCongViec,              
a.QuyTrinhDinhKem, a.Nodeid      
,NextStep,d.Title, d.CategoryWorkProcessId      
into #a              
from Dynamic.Data_WORK a               
inner join Dynamic.Data_RESOURCETTFC b on a.TrangThaiCongViec=b.UserWorkflowId              
          
inner join Dynamic.Data_LSQTCV d on d.CategoryWorkProcessId=@workProcessId and a.Nodeid=d.Nodeid              
where a.Nodeid in (select value from string_split(@nodeIdList,','))              
and d.CategoryWorkProcessId=@workProcessId       
-- and a.IsActive ='True'            
and a.CongViecCha=@parentId  
      
      
select a.Title              
into #b              
from Dynamic.Data_LSQTCV a               
inner join         
(              
 select a.CategoryWorkProcessId, b.value from #a a              
 CROSS APPLY STRING_SPLIT(ISNULL(a.NextStep,''),',') AS b        
) as b        
on a.Step=b.value and a.CategoryWorkProcessId=b.CategoryWorkProcessId              
              
select case when a.TrangThaiCongViec=b.Title then 1 else 0 end as checkDone              
from #a a              
left join #b b on a.TrangThaiCongViec=b.Title              
              
drop table #a              
drop table #b       
      
go

