-- Work_GetListWorkProcess 4024,-122034255               
   CREATE   PROC [dbo].[Work_GetListWorkProcess]                
   @workProcessId as nvarchar(50) =''               
   ,@isUseForWork as nvarchar(50) = ''               
   as                
   DECLARE @NodeTrue TABLE(id INT,nodeid VARCHAR(150),Step int)               
   -- lấy ra node sau node bắt đầu               
   select * into #a from Dynamic.Data_LSQTCV where Step in                
   (               
   select b.value from Dynamic.Data_LSQTCV a               
   CROSS APPLY STRING_SPLIT(ISNULL(a.NextStep,''),',') AS b               
   where CategoryWorkProcessId=@workProcessId and Step = 0               
   and ISNULL(IsUseForWork,'')=isnull(@isUseForWork,'')               
   ) and CategoryWorkProcessId=@workProcessId and ISNULL(IsUseForWork,'')=isnull(@isUseForWork,'')               
   -- kiểm tra xem sau node bắt đầu có node chỉ chạy 1 quy trình hay không nếu có thêm vào table @NodeTrue               
   select a.*, b.value as StepValue into #b from #a a               
   cross apply string_split(a.NextStep,',') b               
   where Title=N'Chỉ chạy 1 quy trình'               
   -- thêm tất cả các node vào bảng NodeTrue để active node khi thêm mới CV               
   insert into @NodeTrue               
   select * from (               
   select a.Id,a.Nodeid, Step from #a a               
   union               
   select a.Id,a.Nodeid,a.Step from Dynamic.Data_LSQTCV a               
   inner join #b b on a.Step=b.StepValue               
   where a.CategoryWorkProcessId= @workProcessId               
   and ISNULL(a.IsUseForWork,'')=isnull(@isUseForWork,'')               
   ) a               
   select distinct a.[Id]               
   ,a.[UserWorkflowId]               
   ,a.[Nguoixuly]               
   ,a.[Nguoiphoihop]               
   ,a.[Nguoitheodoi]    
   ,a.[Nguoigiao]    
   ,a.[Mota]               
   ,a.[Tieude]               
   ,a.[Loaicv]               
   ,a.[Douutien]               
   ,a.[Thoigian]               
   ,a.[nodeid] as Nodeid               
   ,a.[Mota] as Noidung               
   ,case when ISNULL(c.Id,0) =0  then 'False'   
   when ISNULL(b.ActiveManual,'False')='True' then 'ActiveManual'  
   else 'True' end as IsActive               
   ,case when CAST(ISNULL( a.Thoigian,0) as int)=0 then null else trim(CONVERT(CHAR, GETDATE(), 120)) end as Ngaybatdau               
   ,case when CAST(ISNULL( a.Thoigian,0) as int)=0 then null else TRIM( CONVERT(char, DATEADD(DAY,CAST(ISNULL( a.Thoigian,0) as int) ,GETDATE()),120)) end as Ngayketthuc               
   ,a.Quytrinh               
   ,a.TudonghoanthanhCV               
   ,case when ISNULL(c.Id,0)> 0 and ISNULL(a.[Nguoixuly],'') <>'' then ISNULL(a.[Nguoixuly],'') else '' end as NguoiXuLyDauTien               
   ,case when ISNULL(c.Id,0)> 0 and ISNULL(a.[Nguoixuly],'') <>'' then trim(CONVERT(CHAR, GETDATE(), 120)) else null end as Ngaygiaoviec               
   ,a.IsCompeleteWhenAllChildDone               
   ,a.QuyTrinhDinhKem               
   ,ISNULL(d.FlowChartWorkId,0) as HasChild            
   ,c.Step        
   ,a.RequireAttachFileToCompleteWork      
   from Dynamic.Data_FOLLOWCHART a                
   inner join Dynamic.Data_TMDSQTCV b on a.CategoryWorkProcessId=b.UserWorkflowId and ISNULL(b.IsUseForWork,'')=isnull(@isUseForWork,'')                
   left join                
   (               
   select * from @NodeTrue               
   ) c on a.nodeid=c.Nodeid and a.CategoryWorkProcessId=@workProcessId and ISNULL(a.IsUseForWork,'')=isnull(@isUseForWork,'')                    
   left join Dynamic.Data_WorkChildFlowChart d on d.FlowChartWorkId=a.Id            
   where a.CategoryWorkProcessId=@workProcessId and ISNULL(a.IsUseForWork,'')=isnull(@isUseForWork,'')               
   order by c.Step desc               
   drop table #a               
   drop table #b
go

