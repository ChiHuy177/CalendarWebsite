CREATE Procedure [dbo].[proc_App_SetAppDatabaseMetadata] (
    @AppInstallationId uniqueidentifier,
    @DatabaseName nvarchar(128),
    @ReferenceId uniqueidentifier,
    @TargetAppId nvarchar(256),
    @SiteId uniqueidentifier,
    @AppSource tinyint
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
UPDATE TVF_AppDatabaseMetadata_AppInstallationId(@SiteId, @AppInstallationId)
    SET 
        DatabaseName = @DatabaseName,
        ReferenceId = @ReferenceId,
        TargetAppId = @TargetAppId
IF(@@ROWCOUNT = 0) --then we're inserting rather than updating
BEGIN
    INSERT INTO AppDatabaseMetadata
        (AppInstallationId, DatabaseName, ReferenceId, TargetAppId, SiteId, AppSource)
    VALUES
        (@AppInstallationId, @DatabaseName, @ReferenceId, @TargetAppId, @SiteId, @AppSource)
END
COMMIT TRANSACTION

go

