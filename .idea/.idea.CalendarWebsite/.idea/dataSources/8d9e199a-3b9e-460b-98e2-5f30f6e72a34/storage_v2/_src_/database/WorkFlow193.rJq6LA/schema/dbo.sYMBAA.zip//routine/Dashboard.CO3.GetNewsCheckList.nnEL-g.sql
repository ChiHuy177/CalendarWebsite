
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Dashboard.CO3.GetNewsCheckList] @userworkflowId NVARCHAR(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @sql AS NVARCHAR(max)

	SELECT dw.*
	FROM [Dynamic].[CheckList_NEWS] dw
	WHERE dw.IsDeleted = 0
		AND dw.UserWorkflowId = @userworkflowId
END
go

