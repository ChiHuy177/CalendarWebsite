CREATE PROCEDURE [dbo].[proc_GetListViewProperties](
    @SiteId uniqueidentifier,
    @WebPartId uniqueidentifier)
AS
    SET NOCOUNT ON
    SELECT
        WP.tp_AllUsersProperties,
        WP.tp_PerUserProperties,
        WP.tp_WebPartIdProperty
    FROM
        TVF_WebParts_SitePartId(@SiteId, @WebPartId) AS WP

go

