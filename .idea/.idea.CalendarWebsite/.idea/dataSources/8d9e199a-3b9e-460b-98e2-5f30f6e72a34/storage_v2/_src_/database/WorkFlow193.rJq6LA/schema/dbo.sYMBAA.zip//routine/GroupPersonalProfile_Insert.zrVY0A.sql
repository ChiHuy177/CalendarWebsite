
-- =============================================
-- Author:		duydam
-- Create date: 02/09/2021
-- Description:	insert GroupPersonalProfile
-- =============================================
CREATE   PROCEDURE [dbo].[GroupPersonalProfile_Insert] @GroupsId BIGINT
	,@PersonalProfilesId BIGINT
	,@ModifiedBy NVARCHAR(max)
AS
BEGIN
	SET NOCOUNT ON;

	IF NOT EXISTS (
			SELECT *
			FROM [dbo].[GroupPersonalProfile]
			WHERE [GroupsId] = @GroupsId
				AND [PersonalProfilesId] = @PersonalProfilesId
			)
	BEGIN
		INSERT INTO [dbo].[GroupPersonalProfile] (
			[GroupsId]
			,[PersonalProfilesId]
			)
		VALUES (
			@GroupsId
			,@PersonalProfilesId
			);

		UPDATE [dbo].[Group]
		SET ModifiedBy = @ModifiedBy
			,LastModified = GETDATE()
		WHERE Id = @GroupsId;

		UPDATE [dbo].[PersonalProfile]
		SET ModifiedBy = @ModifiedBy
			,LastModified = GETDATE()
		WHERE Id = @PersonalProfilesId;
	END
END
go

