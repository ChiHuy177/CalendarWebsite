CREATE   PROC [dbo].[Work_GetWorkParallel] 
   @workProcessId as nvarchar(250) 
   ,@nodeId as nvarchar(250) 
   as 
   select a.* from Dynamic.Data_LSQTCV a 
   where a.CategoryWorkProcessId=@workProcessId and a.Nodeid=@nodeId 
go

