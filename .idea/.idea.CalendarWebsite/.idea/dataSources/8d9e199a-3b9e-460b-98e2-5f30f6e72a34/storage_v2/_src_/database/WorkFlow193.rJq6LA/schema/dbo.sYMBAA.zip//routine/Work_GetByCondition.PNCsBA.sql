-- [Work_GetByCondition] '','','','','P:287','0','P:287','','343945','','','','','','','False','true'        
   CREATE   PROC [dbo].[Work_GetByCondition]          
   @title AS NVARCHAR(500) = ''         
   ,@projectName AS NVARCHAR(500) = ''         
   ,@group AS NVARCHAR(500) = ''         
   ,@status AS NVARCHAR(500) = ''         
   ,@employee AS NVARCHAR(500) = ''         
   ,@isComplete as int=0         
   ,@defaulUser as nvarchar(250)=''        
   ,@projectType as nvarchar(150)=''        
   ,@workId as nvarchar(150)=''        
   ,@fromDateBegin AS NVARCHAR(50) = ''        
   ,@fromDateEnd AS NVARCHAR(50) = ''        
   ,@toDateBegin AS NVARCHAR(50) = ''        
   ,@toDateEnd AS NVARCHAR(50) = ''        
   ,@dateCompeleteBegin as nvarchar(50)=''        
   ,@dateCompeleteEnd as nvarchar(50)=''        
   ,@isWorkRepeat as nvarchar(50)='False'        
   ,@maxRoot as nvarchar(50)='False'        
   ,@groupProject as nvarchar(50)=''        
   as        
   declare @sqlExec as nvarchar(max) =N'', @sql as nvarchar(max)=N'', @sqlwhere as nvarchar(max)=N'' , @titleSearch nvarchar(max)=N'' ,@whereDateFrom as nvarchar(max)=N''         
   , @whereIscomplete as nvarchar(max)=N'', @whereUser as nvarchar(max)=N'',@whereProject as nvarchar(max) =N'', @project as nvarchar(max)=N''        
   ,@whereDateTo as nvarchar(max)=N'',@whereDateCompelete as nvarchar(max)=N'',@whereStatus as nvarchar(max)=N''        
   ,@whereType as nvarchar(max)=N'',@whereTitle as nvarchar(max)=N'',@whereGroupProject as nvarchar(max)=N''         
   ,@tbTemMutiUser as nvarchar(max)=N'',@joinMutiUser as nvarchar(max)=N'', @select as nvarchar(max)=N''         
   ,@sql2 as nvarchar(max)=N',case when d.TrangThaiCongViec<> N''Hoàn thành''         
   and DATEDIFF(DAY, a.Ngayketthuc, GETDATE()) >0 then N''Trễ ''+ trim(str( DATEDIFF(DAY, a.Ngayketthuc, GETDATE()))) +N'' ngày''        
   when d.TrangThaiCongViec<> N''Hoàn thành'' and DATEDIFF(DAY, a.Ngayketthuc, GETDATE()) <0 then N''Còn ''+ trim(str( ABS( DATEDIFF(DAY, a.Ngayketthuc, GETDATE())))) +N'' ngày''        
   when d.TrangThaiCongViec<>N''Hoàn thành'' and DATEDIFF(DAY, a.Ngayketthuc, GETDATE()) =0 then N''Hôm nay ( ''+ trim(str( DATEDIFF(HOUR, GETDATE(), a.Ngayketthuc )))+''h )''        
   else '''' end as RemainTime '        
   if(@employee<>'')        
   begin        
   if(select COUNT(*) from Split(@employee,','))= 0 -- if search 1 empoyee where 1 employee else insert temp table then where this table         
   begin         
   set @whereUser =' and '''+@employee+''' = (case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoixuly,''''), '';'') where value='''+@employee+''' )>0 then '''+@employee+'''        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoigiao,''''), '';'') where value='''+@employee+''' )>0 then '''+@employee+'''        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoiphoihop,''''), '';'') where value='''+@employee+''' )>0 then '''+@employee+'''        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoitheodoi,''''), '';'') where value='''+@employee+''' )>0 then '''+@employee+'''        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.NguoiXuLyDauTien,''''), '';'') where value='''+@employee+''' )>0 then '''+@employee+'''        
   else '''' end )'         
   end        
   else         
   begin         
   set @tbTemMutiUser =N' ,k.Item as whereUser         
   into #a '        
   set @joinMutiUser =N' cross apply Split(isnull(a.Nguoigiao,'''')+'';''+isnull(a.Nguoiphoihop,'''') +'';''+         
   isnull(a.Nguoixuly,'''')+'';''+isnull(a.Nguoitheodoi,'''')+'';''+isnull(a.NguoiXuLyDauTien,''''),'';'') k '        
   set @select =' select * from #a a WHERE a.whereUser in (select * from Split('''+@employee+''','',''))'        
   end        
   end        
   if(@isComplete =1)        
   begin         
   set @whereIscomplete= N' and isnull(d.TrangThaiCongViec,'''') not in ( N''Hoàn thành'',N''Hủy'')'        
   end        
   if(@fromDateBegin<>'' and @fromDateEnd<>'')        
   begin        
   set @whereDateFrom = ' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''9999-12-12''),23) )>=0'+         
   ' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateEnd+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''9999-12-12''),23) )<=0 '        
   end         
   else if(@fromDateBegin<>'')         
   begin        
   set @whereDateFrom = ' and DATEDIFF(day, CONVERT(varchar,'''+@fromDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,''9999-12-12''),23) )>=0 '        
   end        
   if(@toDateBegin<>'' and @toDateEnd<>'')         
   begin        
   set @whereDateTo = ' and DATEDIFF(day, CONVERT(varchar,'''+@toDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )>=0 '+         
   ' and DATEDIFF(day, CONVERT(varchar,'''+@toDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )<=0 '        
   end         
   else if(@toDateBegin<>'')         
   begin         
   set @whereDateTo = ' and DATEDIFF(day, CONVERT(varchar,'''+@toDateBegin+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,''9999-12-12''),23) )<=0 '         
   end        
   if(@dateCompeleteBegin<>'' and @dateCompeleteEnd<>'')        
   begin         
   set @whereDateCompelete = ' and DATEDIFF(day, CONVERT(varchar,'''+@dateCompeleteBegin+''',23) , CONVERT(varchar,ISNULL(e.LastModified,''9999-12-12''),23) )>=0 '+         
   ' and DATEDIFF(day, CONVERT(varchar,'''+@dateCompeleteEnd+''',23) , CONVERT(varchar,ISNULL(e.LastModified,''9999-12-12''),23) )<=0 '        
   end         
   else if(@toDateBegin<>'')        
   begin         
   set @whereDateCompelete = ' and DATEDIFF(day, CONVERT(varchar,'''+@toDateBegin+''',23) , CONVERT(varchar,ISNULL(e.LastModified,''9999-12-12''),23) )>=0 '        
   end         
   if(@title='')         
   begin         
   set @titleSearch ='""'          
   end        
   else         
   begin         
   set @titleSearch = @title         
   set @whereTitle=' and a.Tieude LIKE N''%' +trim(@title)+ '%'''        
   end        
   if(@projectName<>'')        
   begin        
   set @whereProject = ' and a.Duan ='''+@projectName+''''         
   end        
   else        
   begin        
   if(@defaulUser<>'')         
   begin        
   set @project=(select STUFF((SELECT ',' + trim(str(UserWorkflowId)) from Dynamic.Data_RESOURCEDA        
   where (@defaulUser in ( select * from string_split(ThanhPhanThamGia,';')) or @defaulUser in ( select * from string_split(QuanLy,';'))) and ISNULL(IsDeleted,'False')='False' FOR XML PATH ('')), 1, 1, ''))        
   set @whereProject = ' and a.Duan in ('+@project+')'         
   end        
   end         
   if(@status<>'')        
   begin        
   set @whereStatus = ' and isnull(a.TrangThaiCongViec, '''') in (select * from Split('''+@status+''','',''))'        
   end        
   if(@group<>'')        
   begin        
   set @whereType=' AND isnull(a.Loaicv, '''') in (select * from Split('''+@group+''','',''))'        
   end        
   if(@groupProject<>'')         
   begin        
   set @whereGroupProject=' AND isnull(a.GroupProject, ''-999'') in (select * from Split('''+@groupProject+''','',''))'          
   end        
   else if(@projectName<>'')        
   begin        
   set @whereGroupProject=' AND (a.GroupProject in (select UserWorkflowId from Dynamic.Data_ProjectGroup where ProjectId='''+@projectName+'''         
   and ISNULL(IsDelete,''False'')=''False'' and Status <>''Closed'' ) or isnull(a.GroupProject, '''') ='''')'          
   end        
   set @sql ='        
   SELECT distinct        
   a.Duan as ProjectId         
   ,a.Id        
   ,a.tieude AS title         
   ,ISNULL(a.noidung, '''') AS description        
   ,a.TrangThaiCongViec AS STATUS         
   ,a.tieude         
   ,a.noidung        
   ,ISNULL(a.Nguoiphoihop, '''') AS Nguoiphoihop         
   ,isnull(a.Nguoixuly, '''') AS Nguoixuly         
   ,ISNULL(a.Nguoigiao, '''') AS Nguoigiao         
   ,ISNULL(a.Nguoitheodoi, '''') AS Nguoitheodoi         
   ,a.UserWorkflowId         
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, null), 120)) AS [start]         
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS [end]         
   ,trim(CONVERT(CHAR, ISNULL(e.CreatedTime, null), 120)) AS CreatedTime         
   ,ISNULL(a.Loaicv, '''') AS Loaicv         
   ,trim(ISNULL(a.CongViecCha,'''')) as CongViecCha         
   ,a.Tiendo as Progress          
   ,b.Ten as projectName        
   ,a.Douutien as Priority        
   ,c.TenCV as CategoryName        
   ,d.Ten as statusName         
   ,d.TrangThaiCongViec         
   ,e.CreatedBy         
   ,d.TrangThaiCongViec as StatusType         
   ,case when '+trim( str(@isComplete))+'=1 then 1 else 0 end as IsMyWork         
   ,case when d.TrangThaiCongViec=N''Hoàn thành'' then trim(CONVERT(CHAR, ISNULL(e.LastModified, null), 120)) else null end as DateComplete        
   ,CONVERT(CHAR, ISNULL(e.LastModified, e.CreatedTime), 120) as LastModified        
   ,ISNULL(a.CongViecCha,'''') as Parent         
   ,a.WorkRepeat as IsWorkRepeat         
   ,g.UserWorkflowId as WorkRepeatId         
   ,case when trim(ISNULL(a.CongViecCha,'''')) ='''' then ''True'' else '''' end as IsShowInGanttChart        
   ,a.IndexWork        
   ,i.Ten as GroupProject        
   ,case when d.TrangThaiCongViec<> N''Hoàn thành'' and DATEDIFF(DAY, a.Ngayketthuc, GETDATE()) >0 then trim(str( DATEDIFF(DAY, a.Ngayketthuc, GETDATE())))        
   when d.TrangThaiCongViec<> N''Hoàn thành'' and DATEDIFF(DAY, a.Ngayketthuc, GETDATE()) <0 then trim(str(( DATEDIFF(DAY, a.Ngayketthuc, GETDATE())))) else 0 end as RemainTimeInt        
   ,case when ISNULL(a.WorkRepeatId,'''')<> '''' then N'''+N'Việc lặp'+'''          
   when ISNULL(a.Nodeid,'''')<> '''' then N'''+N'Quy trình'+'''   
   when ISNULL(a.RequestChangeUser,0)=1 then N'''+N'Chuyển xử lý'+'''  
   else N'''+N'Công việc'+''' end as WorkType          
   ,case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoixuly,''''), '';'') where value='''+@employee+''' )>0 and '''+@maxRoot+'''<>''True'' then ISNULL(a.RootNguoiXuLy,a.UserWorkflowId)        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoigiao,''''), '';'') where value='''+@employee+''' )>0 and '''+@maxRoot+'''<>''True'' then ISNULL(a.RootNguoiGiao,a.UserWorkflowId)        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoiphoihop,''''), '';'') where value='''+@employee+''' )>0 and '''+@maxRoot+'''<>''True'' then ISNULL(a.RootNguoiPhoiHop,a.UserWorkflowId)        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoitheodoi,''''), '';'') where value='''+@employee+''' )>0 and '''+@maxRoot+'''<>''True'' then ISNULL(a.RootNguoiTheoDoi,a.UserWorkflowId)        
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.NguoiXuLyDauTien,''''), '';'') where value='''+@employee+''' )>0 and '''+@maxRoot+'''<>''True'' then ISNULL(a.RootViecDaXuly,a.UserWorkflowId)        
   else isnull(a.MaxRoot,a.UserWorkflowId) end as RootWork      
   ,a.GrantChartToId,a.GrantChartType      
   '+@sql2+@tbTemMutiUser + '        
   FROM [Dynamic].[Data_WORK] AS a        
   inner join DYNAMIC.Data_RESOURCEDA b on a.Duan=b.UserWorkflowId        
   left join DYNAMIC.Data_NHOMCV c on a.Loaicv=c.UserWorkflowId         
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId        
   inner join Dynamic.Workflow_WORK e on a.UserWorkflowId=e.UserWorkflowId        
   left join Dynamic.Data_WorkRepeat g on g.WorkId=a.UserWorkflowId         
   -- left join [Dynamic].[Data_WORK] h on h.CongViecCha=a.UserWorkflowId        
   left join Dynamic.Data_ProjectGroup i on i.UserWorkflowId=a.GroupProject and i.ProjectId=a.Duan '        
   set @sqlwhere=' where         
   ISNULL(a.WorkRepeat,''False'')='''+@isWorkRepeat+''' and ISNULL(a.IsActive,''True'')=''True'' and ISNULL(b.IsDeleted,''False'')=''False'''        
   + @whereDateFrom + @whereDateTo+ @whereDateCompelete + @whereIscomplete + @whereDateCompelete         
   + @whereUser + @whereProject + @whereType + @whereGroupProject + @whereStatus + @whereTitle        
   +' and ISNULL(b.Loai,'''') like N''%'+@projectType+'%''        
   -- order by ISNULL(DATEDIFF(DAY, a.Ngayketthuc, GETDATE()),999999) desc, d.TrangThaiCongViec,a.UserWorkflowId desc        
   '        
   if(@workId <>'')         
   begin         
   set @sqlExec =@sql +@joinMutiUser+  ' where ISNULL(a.IsActive,''True'')=''True'' and ISNULL(a.UserWorkflowId,'''') ='+@workId+' select top 1  * from #a'         
   end        
   else         
   begin        
   set @sqlExec =@sql +@joinMutiUser+ @sqlwhere + @select        
   end            
   exec (@sqlExec)        
   print cast(@sqlExec as ntext)
go

