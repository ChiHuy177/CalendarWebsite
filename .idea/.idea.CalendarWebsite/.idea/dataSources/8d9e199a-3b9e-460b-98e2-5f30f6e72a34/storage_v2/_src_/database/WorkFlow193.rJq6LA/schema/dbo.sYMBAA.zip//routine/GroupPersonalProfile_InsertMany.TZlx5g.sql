
-- =============================================
-- Author:		duydam
-- Create date: 30/09/2021
-- Description:	insert many GroupPersonalProfile
-- =============================================
CREATE   PROCEDURE [dbo].[GroupPersonalProfile_InsertMany] @GroupsId BIGINT
	,@PersonalProfilesId NVARCHAR(max)
	,@ModifiedBy NVARCHAR(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Str NVARCHAR(max)
		,@Pos INT
		,@NextPos INT
		,@NextString NVARCHAR(100);

	SET @Str = @PersonalProfilesId;
	SET @Str = @Str + ',';
	SET @Pos = charindex(',', @Str);

	WHILE (@Pos <> 0)
	BEGIN
		SET @NextString = Substring(@Str, 1, @Pos - 1);

		IF NOT EXISTS (
				SELECT *
				FROM [dbo].[GroupPersonalProfile]
				WHERE [GroupsId] = @GroupsId
					AND [PersonalProfilesId] = CAST(@NextString AS BIGINT)
				)
		BEGIN
			INSERT INTO [dbo].[GroupPersonalProfile] (
				[GroupsId]
				,[PersonalProfilesId]
				)
			VALUES (
				@GroupsId
				,CAST(@NextString AS BIGINT)
				);

			UPDATE [dbo].[PersonalProfile]
			SET ModifiedBy = @ModifiedBy
				,LastModified = GETDATE()
			WHERE Id = CAST(@NextString AS BIGINT);
		END

		SET @Str = substring(@Str, @Pos + 1, len(@Str))
		SET @Pos = charindex(',', @Str)
	END

	UPDATE [dbo].[Group]
	SET ModifiedBy = @ModifiedBy
		,LastModified = GETDATE()
	WHERE Id = @GroupsId;
END
go

