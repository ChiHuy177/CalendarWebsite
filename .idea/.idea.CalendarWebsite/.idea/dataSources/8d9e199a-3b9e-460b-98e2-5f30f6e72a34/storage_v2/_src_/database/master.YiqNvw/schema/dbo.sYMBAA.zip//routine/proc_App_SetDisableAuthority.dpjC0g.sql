CREATE Procedure [dbo].[proc_App_SetDisableAuthority] (
    @DisableAuthority tinyint,
    @InstallationId uniqueidentifier,
    @SiteId uniqueidentifier
    --absent: WebId. This isn't really a unique identifier but also isn't changeable
)
AS
SET NOCOUNT ON
UPDATE TVF_AppInstallations_Id(@SiteId, @InstallationId)
    SET
        DisableAuthority |= @DisableAuthority

go

