-- [Work_GetPartners] 39718 
   CREATE   PROC [dbo].[Work_GetPartners] 
   @id AS NVARCHAR(max) 
   as 
   declare @tab table(id bigint, userId nvarchar(150), type nvarchar(150) ) 
   declare @tab1 table(id bigint, Nguoixuly nvarchar(150), Nguoigiao nvarchar(150) 
   , Nguoiphoihop nvarchar(150), Nguoitheodoi nvarchar(150), NguoiXuLyDauTien nvarchar(150),NguoiGiaoDauTien nvarchar(150) ) ; 
   insert into @tab1 
   SELECT a.Id, b.[value] AS Nguoixuly ,c.value as Nguoigiao,d.value as Nguoiphoihop,e.value as Nguoitheodoi , t.value as NguoiXuLyDauTien 
   ,f.value as NguoiGiaoDauTien 
   FROM [Dynamic].Data_WORK AS a  
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoixuly,''),';') AS b  
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoigiao,''),';') AS c  
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoiphoihop,''),';') AS d  
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoitheodoi,''),';') AS e 
   CROSS APPLY STRING_SPLIT(ISNULL(a.NguoiXuLyDauTien,''),';') AS t 
   CROSS APPLY STRING_SPLIT(ISNULL(a.NguoiGiaoDauTien,''),';') AS f 
   where a.Id in (select * from STRING_SPLIT(@id,',')) 
   insert into @tab select a.id,a.Nguoixuly , N'Nguoixuly' from @tab1 a group by a.id,a.Nguoixuly 
   insert into @tab select a.id,a.NguoiXuLyDauTien,N'Nguoixulydautien' from @tab1 a left join @tab1 b on a.NguoiXuLyDauTien=b.Nguoixuly where b.Nguoixuly is null 
   group by a.id,a.NguoiXuLyDauTien 
   insert into @tab select a.id,a.Nguoigiao, N'Nguoigiao' from @tab1 a left join @tab b on a.Nguoigiao=b.userId group by a.id,a.Nguoigiao 
   insert into @tab select a.id,a.Nguoiphoihop, N'Nguoiphoihop' from @tab1 a left join @tab b on a.Nguoiphoihop=b.userId group by a.id,a.Nguoiphoihop 
   insert into @tab select a.id,a.Nguoitheodoi , N'Nguoitheodoi' from @tab1 a left join @tab b on a.Nguoitheodoi=b.userId group by a.id,a.Nguoitheodoi 
   insert into @tab select a.id,a.NguoiGiaoDauTien , N'Nguoigiaodautien' from @tab1 a 
   left join @tab1 b on a.NguoiGiaoDauTien=b.Nguoigiao 
   where b.Nguoigiao is null 
   group by a.id,a.NguoiGiaoDauTien 
   SELECT b.id as WorkId, b.userId as Id , b.type as UserType 
   ,AccountName  
   ,Name  
   ,FullName  
   ,Email  
   FROM [dbo].[PersonalProfile] a  
   --INNER JOIN @tab b ON a.Id in (select REPLACE(ttt.value, 'P:', '') from STRING_SPLIT(b.userId,',') ttt) --CAST( REPLACE(b.userId, 'P:', '') as int)  
   INNER JOIN @tab b ON a.Id = ( REPLACE(b.userId, 'P:', '') )  
   WHERE LEFT(b.userId,2)= 'P:' 
go

