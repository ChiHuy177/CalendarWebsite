CREATE FUNCTION [dbo].[TVF_AllLists_Id]
(
    @tp_SiteId uniqueidentifier,
    @tp_ID uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllLists] WITH (INDEX=Lists_FullText, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_ID = @tp_ID

go

