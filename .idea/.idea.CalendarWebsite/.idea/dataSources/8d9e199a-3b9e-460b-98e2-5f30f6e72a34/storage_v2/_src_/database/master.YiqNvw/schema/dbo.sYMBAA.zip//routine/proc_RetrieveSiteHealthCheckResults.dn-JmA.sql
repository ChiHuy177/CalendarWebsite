CREATE PROCEDURE [dbo].[proc_RetrieveSiteHealthCheckResults](
    @SiteId uniqueidentifier,
    @RuleId uniqueidentifier)
AS
    SET NOCOUNT ON;
    DECLARE @ReturnCode int;
    SET @ReturnCode = 0;
    SELECT
        Status, Message, TimeStamp
    FROM 
        SiteHealthCheckResults
    WHERE
        SiteId = @SiteId AND RuleId = @RuleId
DONE:
    RETURN @ReturnCode

go

