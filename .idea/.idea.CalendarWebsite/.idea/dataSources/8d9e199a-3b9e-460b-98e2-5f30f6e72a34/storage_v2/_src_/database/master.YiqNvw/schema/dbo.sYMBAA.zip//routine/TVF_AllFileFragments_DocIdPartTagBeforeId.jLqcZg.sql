CREATE FUNCTION [dbo].[TVF_AllFileFragments_DocIdPartTagBeforeId]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @Partition tinyint,
    @Tag varbinary(40),
    @LEQId bigint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllFileFragments] WITH (INDEX=AllFileFragments_PartTagId_UNCI, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DocId = @DocId AND
        Partition = @Partition AND
        ((@Tag IS NULL AND Tag IS NULL) OR @Tag=Tag) AND
        Id <= @LEQId

go

