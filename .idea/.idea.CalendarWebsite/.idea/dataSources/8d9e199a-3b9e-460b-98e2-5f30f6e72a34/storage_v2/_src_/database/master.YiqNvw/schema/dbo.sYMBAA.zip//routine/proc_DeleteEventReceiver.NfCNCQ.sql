CREATE PROCEDURE [dbo].[proc_DeleteEventReceiver](
    @Id uniqueidentifier,
    @Name nvarchar(256),
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @HostId uniqueidentifier,
    @HostType int,
    @ItemId int,                                
    @DirName nvarchar(256),     
    @LeafName nvarchar(128),   
    @Synchronization int,
    @Type int,
    @SequenceNumber int,
    @RemoteUrl nvarchar(4000),
    @Assembly nvarchar(256),
    @Class nvarchar(256),
    @Data nvarchar(256),
    @Filter nvarchar(256),
    @SourceId tContentTypeId,
    @SourceType int,
    @Credential int,
    @ContextType uniqueidentifier,
    @ContextEventType uniqueidentifier,
    @ContextId uniqueidentifier,
    @ContextObjectId uniqueidentifier,
    @ContextCollectionId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @RC int
    SET @RC = 0
    DELETE 
        ER
    FROM
        TVF_EventReceivers_PK(@SiteId, @Id) AS ER
    WHERE
        ER.Type != 32767
    IF @@ROWCOUNT <> 1
        SET @RC = 87
    ELSE
    BEGIN
        IF @ContextObjectId IS NOT NULL AND EXISTS (
                SELECT TOP 1
                    1
                FROM
                    TVF_EventReceivers_XLock_ContextCollId(@SiteId, @ContextObjectId) AS ER
                WHERE
                    ER.Type = 32767)
            AND NOT EXISTS (
                SELECT TOP 1
                    1
                FROM
                    TVF_EventReceivers_NoLock_ContextObjId(@SiteId, @ContextObjectId))
        BEGIN
            DELETE 
                ER
            FROM
                TVF_EventReceivers_ContextCollId(@SiteId, @ContextObjectId) AS ER
            WHERE
                ER.Type = 32767
        END
    END
    RETURN @RC

go

