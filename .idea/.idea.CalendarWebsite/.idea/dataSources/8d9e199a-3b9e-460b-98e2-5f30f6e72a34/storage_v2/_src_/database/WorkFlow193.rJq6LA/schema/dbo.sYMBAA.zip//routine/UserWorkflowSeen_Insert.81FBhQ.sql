CREATE   PROCEDURE [dbo].[UserWorkflowSeen_Insert] @UserWorkflowId BIGINT
	,@UserId BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on
	BEGIN TRAN
	IF (
			NOT EXISTS (
				SELECT top 1 Id
				FROM [dbo].[UserWorkflowSeen] with (nolock)
				WHERE UserWorkflowId = @UserWorkflowId
					AND UserId = @UserId
				)
			)
	BEGIN
		INSERT INTO [dbo].[UserWorkflowSeen] (
			UserWorkflowId
			,UserId
			,Email
			,IsDeleted
			,CreatedTime
			)
		VALUES (
			@UserWorkflowId
			,@UserId
			,(SELECT TOP 1 Email
				FROM [dbo].[PersonalProfile]
				WHERE Id = @UserId)
			,0
			,GETDATE()
			);
	END
	COMMIT TRAN
END
go

