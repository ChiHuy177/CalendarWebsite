CREATE FUNCTION [dbo].[TVF_Groups_PK]
(
    @SiteId uniqueidentifier,
    @ID int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Groups] WITH (INDEX=Groups_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ID = @ID

go

