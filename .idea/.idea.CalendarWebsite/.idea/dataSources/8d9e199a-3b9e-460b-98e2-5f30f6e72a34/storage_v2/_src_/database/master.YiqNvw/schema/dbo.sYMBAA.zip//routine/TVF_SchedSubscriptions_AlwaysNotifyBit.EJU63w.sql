CREATE FUNCTION [dbo].[TVF_SchedSubscriptions_AlwaysNotifyBit]
(
    @AlwaysNotifyBit bit
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SchedSubscriptions] WITH (INDEX=SchedSubscriptions_AlwaysNotifyBitSiteId, FORCESEEK)
    WHERE
        ((@AlwaysNotifyBit IS NULL AND AlwaysNotifyBit IS NULL) OR @AlwaysNotifyBit=AlwaysNotifyBit)

go

