CREATE PROCEDURE [dbo].[proc_DeleteStreamForPartitions] (
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @HistVersion int,
    @Level tinyint,
    @PartitionsToDelete nvarchar(max), 
    @QuotaChange bigint = NULL OUTPUT)
AS
    SET NOCOUNT ON
    SET @QuotaChange = 0
    IF (@PartitionsToDelete IS NOT NULL AND DATALENGTH(@PartitionsToDelete) = 0)
        RETURN 0
    IF (@PartitionsToDelete IS NULL AND NOT EXISTS (
        SELECT TOP 1 
            1 
        FROM
            TVF_DocsToStreams_SiteDocHistVerLvl(@SiteId, @DocId, @HistVersion, @Level) AS DTS
        WHERE
            DTS.Partition <> 0))
    BEGIN
        RETURN 0
    END
    DECLARE @ret int
    EXEC @ret = proc_DeleteStreamForPartitionsInternal
        @SiteId,
        @DocId,
        @HistVersion,
        @Level,
        @PartitionsToDelete,
        @QuotaChange OUTPUT
    RETURN @ret

go

