CREATE PROCEDURE [dbo].[proc_GetListBestMatch]
(
    @WebId uniqueidentifier,
    @PathSearch nvarchar(128),
    @BestMatchListId uniqueidentifier output,
    @BestMatchOffset int output,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    DECLARE @BestMatchPath nvarchar(128)
    SELECT @PathSearch = @PathSearch + '%'
    SELECT TOP 1
        @BestMatchListId = Lists.tp_ID,
        @BestMatchPath = Lists.tp_Title
    FROM
        Lists WITH (NOLOCK)
    WHERE
        Lists.tp_WebId = @WebId AND
        Lists.tp_Title LIKE @PathSearch
    ORDER BY
        Lists.tp_Title
    SELECT
        @BestMatchOffset = COUNT(*)
    FROM
        Lists
    WHERE
        Lists.tp_WebId = @WebId AND
        Lists.tp_Title < @BestMatchPath

go

