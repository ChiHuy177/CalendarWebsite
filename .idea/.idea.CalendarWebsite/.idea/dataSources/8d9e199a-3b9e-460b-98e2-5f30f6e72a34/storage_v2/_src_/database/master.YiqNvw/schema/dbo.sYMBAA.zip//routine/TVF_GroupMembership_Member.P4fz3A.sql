CREATE FUNCTION [dbo].[TVF_GroupMembership_Member]
(
    @SiteId uniqueidentifier,
    @MemberId int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[GroupMembership] WITH (INDEX=GroupMembership_MemberId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        MemberId = @MemberId

go

