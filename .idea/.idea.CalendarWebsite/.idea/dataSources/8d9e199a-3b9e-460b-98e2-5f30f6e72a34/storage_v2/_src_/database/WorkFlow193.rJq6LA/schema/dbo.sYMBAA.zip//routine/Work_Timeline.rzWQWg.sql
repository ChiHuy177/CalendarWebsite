-- Work_Timeline         
   CREATE   PROC  [dbo].[Work_Timeline]
   AS
   SELECT a.projectName
   ,Tab.Id
   ,a.tieude AS title
   ,ISNULL(a.noidung, N'Chưa nhập nội dung') AS description
   ,a.TrangThai AS STATUS
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, getdate()), 120)) AS [start]
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayhoantat, getdate()), 120)) AS [end]
   ,tab.UserWorkflowId
   ,tab.Data
   INTO #a
   FROM [Dynamic].[Workflow_WORK] AS Tab
   CROSS APPLY OPENJSON(Tab.data, N'$') WITH (
   projectName NVARCHAR(500) N'$.Duan'
   ,tieude NVARCHAR(500) N'$.Tieude'
   ,noidung NVARCHAR(500) N'$.Noidung'
   ,TrangThai NVARCHAR(500) N'$.TrangThai'
   ,Ngaybatdau DATETIME N'$.Ngaybatdau'
   ,Ngayhoantat DATETIME N'$.Ngayhoantat'
   ) AS a
   -- inner join UserWorkflow c on Tab.UserWorkflowId =c.Id              
   WHERE ISNULL(Tab.IsDeleted, 0) = 0
   SELECT *
   FROM #a
   DROP TABLE #a
go

