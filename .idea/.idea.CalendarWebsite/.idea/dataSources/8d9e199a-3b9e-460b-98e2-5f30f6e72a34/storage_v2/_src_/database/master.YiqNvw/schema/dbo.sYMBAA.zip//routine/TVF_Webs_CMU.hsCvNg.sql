CREATE FUNCTION [dbo].[TVF_Webs_CMU]
(
    @SiteId uniqueidentifier,
    @CustomMasterUrl nvarchar(260)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebs] WITH (INDEX=Webs_CMU, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@CustomMasterUrl IS NULL AND CustomMasterUrl IS NULL) OR @CustomMasterUrl=CustomMasterUrl) AND
        DeleteTransactionId = 0x

go

