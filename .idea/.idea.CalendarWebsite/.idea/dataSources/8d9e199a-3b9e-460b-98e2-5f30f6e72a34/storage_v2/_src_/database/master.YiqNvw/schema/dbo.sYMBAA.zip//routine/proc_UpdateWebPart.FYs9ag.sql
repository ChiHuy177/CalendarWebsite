CREATE PROCEDURE [dbo].[proc_UpdateWebPart](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @Level tinyint OUTPUT,
    @bAllUser bit,
    @SystemId tSystemID,
    @WebPartId uniqueidentifier,
    @WebPartTypeID uniqueidentifier,
    @Assembly nvarchar(255),
    @Class nvarchar(255),
    @SolutionId uniqueidentifier,
    @SolutionWebId uniqueidentifier,
    @bCheckLock bit,
    @IsIncluded bit,
    @FrameState tinyint,
    @ZoneID nvarchar(64),
    @PartOrder int,
    @TheFlags int,
    @TheType tinyint,
    @TheBaseViewID tinyint,
    @AllUsersProperties varbinary(max),
    @PerUserProperties varbinary(max),
    @WebPartIdProperty nvarchar(255),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocId uniqueidentifier
    DECLARE @PartDocId uniqueidentifier
    DECLARE @UserId int
    DECLARE @Ret int
    DECLARE @AllUsersSize int
    DECLARE @PerUserSize int
    DECLARE @WebPartIdPropertySize int
    DECLARE @NewSize bigint
    DECLARE @OldWebPartTypeID uniqueidentifier
    DECLARE @CurrentUserId int
    DECLARE @CurrentUserTitle nvarchar(255)
    DECLARE @IsCurrentVersion bit
    DECLARE @IsForceCheckout bit
    DECLARE @EnableMinorVersions bit
    DECLARE @IsModerate bit
    DECLARE @WebId uniqueidentifier
    DECLARE @ListId uniqueidentifier
    DECLARE @ItemId int
    DECLARE @DocParentId uniqueidentifier
    DECLARE @DocClientId varbinary(16)
    SET @Ret = 0
    SET @CurrentUserId = NULL
    IF (@SystemId IS NOT NULL)
    BEGIN
        SELECT
            @CurrentUserId = UI.tp_ID,
            @CurrentUserTitle = UI.tp_Title
        FROM
            TVF_UserInfo_SID(@SiteId, @SystemId) AS UI
    END
    SELECT TOP 1
        @IsForceCheckout =
            CASE 
                WHEN L.tp_Flags & 0x40000 <> 0 AND @bCheckLock = 1 AND D.DoclibRowId IS NOT NULL
                    THEN 1
                ELSE 0
            END,
        @EnableMinorVersions = 
            CASE 
                WHEN L.tp_Flags & 0x80000 <> 0 AND D.DoclibRowId IS NOT NULL
                    THEN 1
                ELSE 0
            END,
        @IsModerate = 
            CASE 
                WHEN L.tp_Flags & 0x400 <> 0 AND D.DoclibRowId IS NOT NULL
                    THEN 1
                ELSE 0
            END,
        @DocId = D.Id,
        @IsCurrentVersion = D.IsCurrentVersion,
        @DocParentId = D.ParentId,
        @WebId = D.WebId,
        @ListId = D.ListId,
        @ItemId = D.DoclibRowId,
        @DocClientId = D.ClientId
    FROM
        TVF_Docs_Url_Level(@SiteId, @DirName, @LeafName, @Level) AS D
    OUTER APPLY
        TVF_Lists_NoLock_CI(D.SiteId, D.WebId, D.ListId) AS L
    IF (@IsForceCheckout = 1
        AND @Level <> 255
        AND @bAllUser = 1)
        RETURN 158
    IF @DocId IS NULL
    BEGIN
        RETURN 2
    END
    IF @bCheckLock = 1
    BEGIN
        IF (@bAllUser = 0) AND (@Level = 255)
        BEGIN
            RETURN 12
        END
        IF (@bAllUser = 1) AND (@IsCurrentVersion = 0)
        BEGIN
            RETURN 33
        END
    END
    SELECT TOP 1
        @PartDocId = WP.tp_PageUrlID,
        @UserId = WP.tp_UserID,
        @OldWebPartTypeID = WP.tp_WebPartTypeId
    FROM
        TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
    IF (@DocId <> @PartDocId)
    BEGIN
        RETURN 5
    END
    IF (@EnableMinorVersions = 1 OR @IsModerate = 1 ) AND
        @Level = 1 AND @bAllUser = 1 AND
        @ItemId IS NOT NULL AND
        @bCheckLock = 1 AND @CurrentUserId IS NOT NULL
    BEGIN
        EXEC @Ret = proc_CloneDoc  
            @SiteId,
            @DirName,
            @LeafName,
            NULL,
            NULL,
            NULL,
            @Level,
            2,
            @EnableMinorVersions,
            @IsModerate,
            @CurrentUserId,
            NULL, NULL, 
            @RequestGuid = @RequestGuid OUTPUT
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        SET @Level = 2
    END
    IF (@bAllUser = 1 OR @UserId IS NOT NULL)
    BEGIN                
        SET @AllUsersSize = ISNULL(DATALENGTH(@AllUsersProperties), 0)
        SET @PerUserSize = ISNULL(DATALENGTH(@PerUserProperties), 0)
        SET @WebPartIdPropertySize = ISNULL(DATALENGTH(@WebPartIdProperty), 0)
        EXEC @Ret = proc_OnUpdateWebParts
            @SiteId,
            @WebPartId,
            @Level,
            NULL,    
            @AllUsersSize,
            @PerUserSize,
            @WebPartIdPropertySize,
            0,       
            0,       
            NULL,    
            @NewSize OUTPUT
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        IF (@OldWebPartTypeID IS NOT NULL) AND
            (@OldWebPartTypeID <> @WebPartTypeID) AND
            (@IsIncluded IS NULL) AND
            (@Level <> 255)
        BEGIN
            EXEC @Ret = proc_DeleteWebPartPersonalization
                @SiteId,
                @DirName,
                @LeafName,
                NULL,
                @WebPartId,
                @RequestGuid OUTPUT
        END
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        UPDATE
            WP
        SET
            WP.tp_WebPartTypeId = @WebPartTypeID,
            WP.tp_Assembly = @Assembly,
            WP.tp_Class = @Class,
            WP.tp_SolutionId = @SolutionId,
            WP.tp_SolutionWebId = @SolutionWebId,
            WP.tp_Version = (CASE WHEN WP.tp_Version IS NULL THEN 2 WHEN WP.tp_Version >= 2147483647 THEN 1 ELSE WP.tp_Version + 1 END),
            WP.tp_AllUsersProperties = @AllUsersProperties,
            WP.tp_PerUserProperties = @PerUserProperties,
            WP.tp_WebPartIdProperty = @WebPartIdProperty,
            WP.tp_ZoneID = CASE WHEN (@IsIncluded IS NULL) THEN WP.tp_ZoneID ELSE @ZoneID END,
            WP.tp_PartOrder = COALESCE(@PartOrder, WP.tp_PartOrder),
            WP.tp_Source = NULL,       
            WP.tp_IsIncluded = COALESCE(@IsIncluded, WP.tp_IsIncluded),
            WP.tp_FrameState = COALESCE(@FrameState, WP.tp_FrameState),
            WP.tp_Cache = NULL,
            WP.tp_Size = @NewSize,
            WP.tp_Type = COALESCE(@TheType, WP.tp_Type),
            WP.tp_Flags = COALESCE(@TheFlags, WP.tp_Flags),
            WP.tp_BaseViewID = COALESCE(@TheBaseViewID, WP.tp_BaseViewID)
        FROM
            TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        IF (@Level = 1)
        BEGIN
            EXEC @Ret = proc_InvalidatePerUserWebPartCache
                    @SiteId,
                    @WebPartId
            IF (@@ERROR <> 0 OR @Ret <> 0)
            BEGIN
                IF (@Ret = 0)
                    SET @Ret = -2147467259
                GOTO cleanup
            END
        END
        DELETE
            L
        FROM
            TVF_Links_PId_DId_Lvl(@SiteId, @DocParentId, @DocId, @Level) AS L
        WHERE
            L.FieldId IS NULL AND
            L.WebPartId = @WebPartId
        EXEC @Ret = proc_TryMakeFormDefaultForList 
                @SiteId, 
                @ListId, 
                @WebPartId, 
                @TheType, 
                @TheFlags,
                @RequestGuid OUTPUT
        IF @Ret <> 0
            GOTO cleanup
    END
    ELSE
    BEGIN                
        SET @UserId = @CurrentUserId
        IF (EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_Personalization_PK(@SiteId, @DocId, @WebPartId, @UserId)))
        BEGIN            
            SET @PerUserSize = ISNULL(DATALENGTH(@PerUserProperties), 0)
            EXEC @Ret = proc_OnUpdatePersonalization
                @SiteId,
                @DocId,
                @UserId,
                @WebPartId,
                @PerUserSize,
                0,    
                @NewSize OUTPUT
            IF (@@ERROR <> 0 OR @Ret <> 0)
            BEGIN
                IF (@Ret = 0)
                    SET @Ret = -2147467259
                GOTO cleanup
            END
            UPDATE
                P
            SET
                P.tp_PerUserProperties = @PerUserProperties,
                P.tp_ZoneID = @ZoneID,
                P.tp_PartOrder = @PartOrder,
                P.tp_IsIncluded = @IsIncluded,
                P.tp_FrameState = @FrameState,
                P.tp_Cache = NULL,
                P.tp_Size = @NewSize
            FROM
                TVF_Personalization_PK(@SiteId, @DocId, @WebPartId, @UserId) AS P
        END
        ELSE
        BEGIN            
            DECLARE @quotaOrLockStatus int SELECT @quotaOrLockStatus = dbo.fn_IsOverQuotaOrWriteLocked(@SiteId) IF (@quotaOrLockStatus = 1) BEGIN SET @Ret = 1816 END ELSE IF (@quotaOrLockStatus > 1) BEGIN SET @Ret = 212 END
            IF @Ret <> 0
                GOTO cleanup
            DECLARE @cbDelta bigint
            SET @cbDelta = 66 + ISNULL(DATALENGTH(@PerUserProperties), 0) + ISNULL(DATALENGTH(NULL), 0)
            EXEC proc_AppendSiteQuota
                @SiteId, @cbDelta, 0, @DocId
            INSERT INTO dbo.Personalization (
                tp_SiteId,
                tp_WebPartID,
                tp_PageUrlID,
                tp_UserID,
                tp_PerUserProperties,
                tp_ZoneID,
                tp_PartOrder,
                tp_IsIncluded,
                tp_FrameState,
                tp_Size)
            VALUES (
                @SiteId,
                @WebPartId,
                @DocId,
                @UserId,
                @PerUserProperties,
                @ZoneID,
                @PartOrder,
                @IsIncluded,
                @FrameState,
                @cbDelta)
        END
    END
    IF (@@ERROR <> 0 OR @Ret <> 0)
    BEGIN
        IF (@Ret = 0)
            SET @Ret = -2147467259
        GOTO cleanup
    END
    IF NOT EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level))
    BEGIN
        SET @Ret = 2  
    END
    ELSE
    BEGIN
        IF (@ItemId IS NOT NULL)
        BEGIN
            EXEC proc_LogChange @SiteId, @WebId, @ListId, @ItemId, @DocId,
                NULL, NULL, NULL, 8192, 1, NULL,
                NULL, NULL, @DocClientId, NULL, @CurrentUserTitle, @RequestGuid OUTPUT
        END
        ELSE
        BEGIN
            EXEC proc_LogChange @SiteId, @WebId, NULL, NULL, @DocId,
                NULL, NULL, NULL, 8192, 16, NULL,
                NULL, NULL, @DocClientId, NULL, @CurrentUserTitle, @RequestGuid OUTPUT
        END
    END
cleanup:
    IF (0 <> @@ERROR OR 0 <> @Ret)
    BEGIN
        RETURN CASE WHEN (0 = @Ret) THEN -2147467259 ELSE @Ret END
    END
    RETURN 0

go

