CREATE FUNCTION [dbo].[TVF_RecycleBin_HoldLock_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[RecycleBin] WITH (HOLDLOCK, INDEX=RecycleBin_SiteBinWebUser, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

