CREATE FUNCTION [dbo].[TVF_SiteQuota_CI]
(
    @SiteId uniqueidentifier,
    @SessionId smallint,
    @SMOpCode tinyint,
    @DocId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SiteQuota] WITH (INDEX=SiteQuota_SiteId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SessionId = @SessionId AND
        SMOpCode = @SMOpCode AND
        DocId = @DocId

go

