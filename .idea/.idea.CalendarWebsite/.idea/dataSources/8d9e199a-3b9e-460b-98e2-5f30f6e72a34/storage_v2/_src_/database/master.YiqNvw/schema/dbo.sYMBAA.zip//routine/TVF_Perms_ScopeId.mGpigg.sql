CREATE FUNCTION [dbo].[TVF_Perms_ScopeId]
(
    @SiteId uniqueidentifier,
    @ScopeId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Perms] WITH (INDEX=Perms_Url, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ScopeId = @ScopeId

go

