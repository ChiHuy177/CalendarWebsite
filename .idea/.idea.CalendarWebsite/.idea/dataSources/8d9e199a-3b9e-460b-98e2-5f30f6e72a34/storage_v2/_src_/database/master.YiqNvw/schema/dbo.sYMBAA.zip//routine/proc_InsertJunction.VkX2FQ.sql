CREATE PROC [dbo].[proc_InsertJunction](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @FieldId uniqueidentifier,
    @Id int,
    @Ordinal int,
    @Level tinyint = 1,
    @UIVersion int = 512,
    @IsCurrentVersion bit = 1,
    @CalculatedVersion int = 0,
    @DeleteTransactionId varbinary(16) = 0x,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
    )
AS
    SET NOCOUNT ON
    DECLARE @DocParentId uniqueidentifier
    DECLARE @DocListId uniqueidentifier
    DECLARE @DocId uniqueidentifier
    EXEC proc_GetParentIdAndDocIdForUrl @SiteId, @DirName, @LeafName, @DocParentId OUTPUT, @DocId OUTPUT
    SELECT TOP 1
        @DocListId = ListId
    FROM
        TVF_AllDocs_CI(@SiteId, @DeleteTransactionId, @DocParentId, @DocId, @Level) AS AD
    IF (0 = @@ROWCOUNT)
        RETURN 2
    INSERT INTO
        AllUserDataJunctions (
            tp_SiteId,
            tp_DeleteTransactionId,
            tp_IsCurrentVersion,
            tp_ParentId,
            tp_DocId,
            tp_FieldId,
            tp_CalculatedVersion,
            tp_Level,
            tp_UIVersion,
            tp_Id,
            tp_Ordinal,
            tp_SourceListId
            )
        VALUES (
            @SiteId,
            @DeleteTransactionId,
            @IsCurrentVersion,
            @DocParentId,
            @DocId,
            @FieldId,
            @CalculatedVersion,
            @Level,
            @UIVersion,
            @Id,
            @Ordinal,
            @DocListId
            )    

go

