-- [Work_CompeleWhenAllChildDone] 308455,'hiennct@vntt.com.vn',1            
   CREATE   PROC [dbo].[Work_CompeleWhenAllChildDone]             
   @parentId as bigint             
   ,@UpdateUser as nvarchar(100)=''            
   ,@check as bit =0          
   as             
   declare @tong as int , @tonghoanthanh as int
   select a.UserWorkflowId,a.TrangThaiCongViec,b.UserWorkflowId as WorkId into #b from Dynamic.Data_RESOURCETTFC a             
   inner join Dynamic.Data_WORK b on b.TrangThaiCongViec=a.UserWorkflowId and b.Duan=a.Duan             
   where b.CongViecCha = @parentId and ISNULL(b.IsActive,'True')='True'             
   set @tong = (select count (*) from #b)             
   set @tonghoanthanh = (select count (*) from #b where TrangThaiCongViec in( N'Hoàn thành',N'Hủy' ))      
   select  UserWorkflowId, TrangThaiCongViec into #C from Dynamic.Data_RESOURCETTFC             
   where Duan= (select Duan from Dynamic.Data_WORK where UserWorkflowId=@parentId ) and TrangThaiCongViec in( N'Hoàn thành',N'Hủy' )            
   if(@check=0)          
   begin           
   if(@tong = @tonghoanthanh and @tong<>0 and @tonghoanthanh<>0)             
   begin             
   if(select COUNT(*) from #C)>0             
   begin             
   INSERT INTO [Dynamic].[Data_LSCNTTCV]             
   (             
   [UpdateUser]             
   ,[Date]             
   ,[OldValue]             
   ,[NewValue]             
   ,[WorkId]             
   ,[ColumnName]             
   ,[Note]             
   )             
   select             
   @UpdateUser as [UpdateUser]             
   ,GETDATE() as [Date]             
   ,TrangThaiCongViec as [OldValue]             
   ,(select top 1 UserWorkflowId from #c where TrangThaiCongViec=N'Hoàn thành') as [NewValue]             
   ,UserWorkflowId as [WorkId]             
   ,'TrangThaiCongViec' as [ColumnName]             
   ,N'Tự động hoàn thành công việc khi công việc con hoàn thành (SQL)' as [Note]
   from Dynamic.Data_WORK where UserWorkflowId=@parentId and ISNULL(IsCompeleteWhenAllChildDone,'')  ='1'       
   ;             
   update Dynamic.Data_WORK set TrangThaiCongViec= (select top 1 UserWorkflowId from #c where TrangThaiCongViec=N'Hoàn thành'),Tiendo='100%'
   where UserWorkflowId=@parentId and ISNULL(IsCompeleteWhenAllChildDone,'')  ='1'   
   end             
   end             
   end          
   else          
   begin           
   if(@tong = @tonghoanthanh and @tong<>0 and @tonghoanthanh<>0)             
   begin             
   if(select COUNT(*) from #C)>0          
   begin           
   select 1 as [check]          
   end          
   else          
   begin           
   select 0 as [check]          
   end          
   end         
   else if(@tong=0 and @tonghoanthanh=0)        
   begin         
   select 1 as [check]          
   end         
   end          
   drop table #b        
   drop table #c
go

