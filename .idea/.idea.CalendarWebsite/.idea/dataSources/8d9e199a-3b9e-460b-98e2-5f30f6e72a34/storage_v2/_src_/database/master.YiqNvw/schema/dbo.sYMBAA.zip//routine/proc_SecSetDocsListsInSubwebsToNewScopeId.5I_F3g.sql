CREATE PROCEDURE [dbo].[proc_SecSetDocsListsInSubwebsToNewScopeId](
    @SiteId             uniqueidentifier,
    @WebId              uniqueidentifier,
    @WebUrl             nvarchar(256), 
    @NewScopeId         uniqueidentifier,
    @OldRoleDefWebId    uniqueidentifier)
AS
    SET NOCOUNT ON
    DECLARE @DirName nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    EXEC proc_SplitUrl @WebUrl, @DirName OUTPUT, @LeafName OUTPUT
    DECLARE @UrlLike nvarchar(1024)
    EXEC proc_EscapeForLike @WebUrl, @UrlLike OUTPUT
    UPDATE 
        D
    SET 
        D.ScopeId = @NewScopeId
    FROM
        TVF_Docs_Url(@SiteId, @DirName, @LeafName) AS D
    UPDATE 
        D
    SET 
        D.ScopeId = @NewScopeId
    FROM
        TVF_Docs_DirName(@SiteId, @WebUrl) AS D
    CROSS APPLY
        TVF_Webs_Id(D.SiteId, D.WebId) AS W
    WHERE 
        W.ScopeId = @NewScopeId
    UPDATE 
        D
    SET 
        D.ScopeId = @NewScopeId
    FROM
        TVF_Docs_DirNameLike(@SiteId, @UrlLike) AS D
    CROSS APPLY
        TVF_Webs_Id(D.SiteId, D.WebId) AS W
    WHERE 
        W.ScopeId = @NewScopeId
    UPDATE 
        DD
    SET 
        DD.ScopeId = @NewScopeId
    FROM
        TVF_DeletedDocs_DirName(@SiteId, @WebUrl) AS DD
    CROSS APPLY
        TVF_Webs_Id(DD.SiteId, DD.WebId) AS W
    WHERE 
        W.ScopeId = @NewScopeId
    UPDATE 
        DD
    SET 
        DD.ScopeId = @NewScopeId
    FROM
        TVF_DeletedDocs_DirNameLike(@SiteId, @UrlLike) AS DD
    CROSS APPLY
        TVF_Webs_Id(DD.SiteId, DD.WebId) AS W
    WHERE 
        W.ScopeId = @NewScopeId
    UPDATE
        AL
    SET 
        AL.tp_ScopeId = @NewScopeId
    FROM
        TVF_Webs_SiteId(@SiteId) AS W
    CROSS APPLY
        TVF_AllLists_WebId(W.SiteId, W.Id) AS AL
    WHERE
        W.ScopeId = @NewScopeId
    DELETE
        RA
    FROM
        TVF_RoleAssignment_SiteId(@SiteId) AS RA
    CROSS APPLY 
        TVF_Perms_ScopeId(RA.SiteId, RA.ScopeId) AS P 
    CROSS APPLY
        TVF_Webs_Id(P.SiteId, P.WebId) AS W
    WHERE
        W.ScopeId = @NewScopeId AND
        (@OldRoleDefWebId IS NULL OR
         (P.ScopeId <> @NewScopeId AND P.RoleDefWebId = @OldRoleDefWebId))
    DELETE
        P
    FROM
        TVF_Perms_ScopeUrl(@SiteId, @WebUrl) AS P
    CROSS APPLY
        TVF_Webs_Id(P.SiteId, P.WebId) AS W
    WHERE
        W.ScopeId = @NewScopeId AND
        (@OldRoleDefWebId IS NULL OR
         (P.ScopeId <> @NewScopeId AND P.RoleDefWebId = @OldRoleDefWebId))
    DELETE
        P
    FROM
        TVF_Perms_ScopeUrlLike(@SiteId, @UrlLike) AS P
    CROSS APPLY
        TVF_Webs_Id(P.SiteId, P.WebId) AS W
    WHERE
        W.ScopeId = @NewScopeId AND
        (@OldRoleDefWebId IS NULL OR
         (P.ScopeId <> @NewScopeId AND P.RoleDefWebId = @OldRoleDefWebId))
    DELETE
        DP
    FROM
        TVF_DeletedPerms_ScopeUrlLike(@SiteId, @UrlLike) AS DP
    CROSS APPLY
        TVF_Webs_Id(DP.SiteId, DP.WebId) AS W
    WHERE
        W.ScopeId = @NewScopeId AND
        (@OldRoleDefWebId IS NULL OR
         (DP.ScopeId <> @NewScopeId AND DP.RoleDefWebId = @OldRoleDefWebId))

go

