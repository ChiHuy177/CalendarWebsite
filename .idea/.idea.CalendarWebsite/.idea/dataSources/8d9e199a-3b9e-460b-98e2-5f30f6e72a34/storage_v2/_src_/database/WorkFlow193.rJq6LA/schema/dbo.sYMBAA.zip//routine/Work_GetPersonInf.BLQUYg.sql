-- [Work_GetPersonInf]'41625','nguoixuly'       
   CREATE   PROC [dbo].[Work_GetPersonInf]       
   @id AS NVARCHAR(max) ='39898'       
   ,@type AS NVARCHAR(250)=''       
   as       
   declare @tab1 table(WorkId bigint, userId nvarchar(50))       
   if(@type='')       
   begin       
   insert into @tab1       
   SELECT a.UserWorkflowId as Id       
   , c.[value] AS kq       
   FROM [Dynamic].Data_WORK AS a       
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoixuly,'')+';'+ISNULL(a.Nguoigiao,'')+';'+ISNULL(a.Nguoiphoihop,'')+';'+ISNULL(a.Nguoitheodoi,'')+';'+ISNULL(a.NguoiXuLyDauTien,''),';') AS c       
   where a.Id in (select * from STRING_SPLIT(@id,','))       
   group by a.UserWorkflowId,c.[value]       
   end       
   else if(@type='Nguoixuly')       
   begin       
   insert into @tab1       
   SELECT a.UserWorkflowId as Id       
   , c.[value] AS kq       
   FROM [Dynamic].Data_WORK AS a       
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoixuly,'')+';'+ISNULL(a.NguoiXuLyDauTien,''),';') AS c       
   where a.Id in (select * from STRING_SPLIT(@id,','))       
   group by a.UserWorkflowId,c.[value]    
   end   
   else if(@type='Nguoigiao,Nguoixuly')       
   begin       
   insert into @tab1       
   SELECT a.UserWorkflowId as Id       
   , c.[value] AS kq       
   FROM [Dynamic].Data_WORK AS a       
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoixuly,'')+';'+ISNULL(a.Nguoigiao,''),';') AS c       
   where a.Id in (select * from STRING_SPLIT(@id,','))       
   group by a.UserWorkflowId,c.[value]    
   end       
   else if(@type='Nguoigiao')       
   begin       
   insert into @tab1       
   SELECT a.UserWorkflowId as Id       
   , c.[value] AS kq       
   FROM [Dynamic].Data_WORK AS a       
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoigiao,'')+';'+ISNULL(a.NguoiGiaoDauTien,''),';') AS c       
   where a.Id in (select * from STRING_SPLIT(@id,','))       
   group by a.UserWorkflowId,c.[value]    
   end       
   else if(@type='Nguoiphoihop')       
   begin       
   insert into @tab1       
   SELECT a.UserWorkflowId as Id       
   , c.[value] AS kq       
   FROM [Dynamic].Data_WORK AS a       
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoiphoihop,''),';') AS c       
   where a.Id in (select * from STRING_SPLIT(@id,','))       
   end       
   else if(@type='Nguoitheodoi')       
   begin       
   insert into @tab1       
   SELECT a.UserWorkflowId as Id       
   , c.[value] AS kq       
   FROM [Dynamic].Data_WORK AS a       
   CROSS APPLY STRING_SPLIT(ISNULL(a.Nguoitheodoi,''),';') AS c       
   where a.Id in (select * from STRING_SPLIT(@id,','))       
   end       
   SELECT b.WorkId, b.userId as Id        
   ,AccountName        
   ,Name        
   ,FullName        
   ,Email      
   ,EnableEmail  
   ,EnableNotification  
   FROM [dbo].[PersonalProfile] a        
   --INNER JOIN @tab b ON a.Id in (select REPLACE(ttt.value, 'P:', '') from STRING_SPLIT(b.userId,',') ttt) --CAST( REPLACE(b.userId, 'P:', '') as int)        
   INNER JOIN @tab1 b ON a.Id = ( REPLACE(b.userId, 'P:', '') )       
   WHERE LEFT(b.userId,2)= 'P:'
go

