CREATE PROCEDURE [dbo].[proc_UpdateWebPartProps](
    @SiteId uniqueidentifier,
    @WebPartId uniqueidentifier,
    @Type tinyint,
    @Flags int,
    @IsIncluded bit,
    @FrameState tinyint,
    @AllUsersProperties varbinary(max),
    @PerUserProperties varbinary(max),
    @WebPartIdProperty nvarchar(255),
    @Level tinyint OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    DECLARE @AllUsersSize int
    DECLARE @PerUserSize int
    DECLARE @WebPartIdPropertySize int
    DECLARE @NewSize bigint
    SET @AllUsersSize = ISNULL(DATALENGTH(@AllUsersProperties), 0)
    SET @PerUserSize = ISNULL(DATALENGTH(@PerUserProperties), 0)
    SET @WebPartIdPropertySize = ISNULL(DATALENGTH(@WebPartIdProperty), 0)
    EXEC @Ret = proc_OnUpdateWebParts
        @SiteId,
        @WebPartId,
        @Level,
        NULL,     
        @AllUsersSize,
        @PerUserSize,
        @WebPartIdPropertySize,
        0,        
        NULL,     
        NULL,     
        @NewSize OUTPUT
    IF (@@ERROR <> 0 OR @Ret <> 0)
    BEGIN
        IF (@Ret = 0)
            SET @Ret = -2147467259
        GOTO cleanup
    END
    UPDATE
        WP
    SET
        WP.tp_Type = @Type,
        WP.tp_Flags = @Flags,
        WP.tp_Version = (CASE WHEN WP.tp_Version IS NULL THEN 2 WHEN WP.tp_Version >= 2147483647 THEN 1 ELSE WP.tp_Version + 1 END),
        WP.tp_IsIncluded = @IsIncluded,
        WP.tp_FrameState = @FrameState,
        WP.tp_AllUsersProperties = @AllUsersProperties,
        WP.tp_PerUserProperties = @PerUserProperties,
        WP.tp_Cache = NULL,
        WP.tp_Size = @NewSize
    FROM
        TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
    IF (@@ERROR <> 0)
    BEGIN
        SET @Ret = -2147467259
        GOTO cleanup
    END
    IF (@Level = 1)
    BEGIN
        EXEC @Ret = proc_InvalidatePerUserWebPartCache
                @SiteId,
                @WebPartId
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
    END
cleanup:
    RETURN @Ret

go

