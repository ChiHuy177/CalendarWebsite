CREATE FUNCTION [dbo].[TVF_WebParts_ListUserLvl]
(
    @tp_SiteId uniqueidentifier,
    @tp_ListId uniqueidentifier,
    @tp_UserID int,
    @tp_Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebParts] WITH (INDEX=ListIdUserId_NCI, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        ((@tp_ListId IS NULL AND tp_ListId IS NULL) OR @tp_ListId=tp_ListId) AND
        tp_IsCurrentVersion = CONVERT(bit, 1) AND
        tp_PageVersion = 0 AND
        ((@tp_UserID IS NULL AND tp_UserID IS NULL) OR @tp_UserID=tp_UserID) AND
        tp_Level = @tp_Level

go

