CREATE   PROC [dbo].[CRM_Purchase_GetAll]      
 @userName as nvarchar(50)='',      
 @str as nvarchar(250)='',        
 @menuId as bigint               
 as              
               
 SELECT a.[ID]              
       ,a.[RevisionNumber]              
       ,a.[Status]              
       ,a.[EmployeeID]  
    ,a.[Name]  
       ,a.SupplierID              
    ,b.Code as SupplierCode          
    ,b.Name as SupplierName          
       ,a.[ShipMethodID]              
       ,a.[OrderDate]              
       ,a.[ShipDate]              
       ,a.[SubTotal]              
       ,a.[TaxAmt]              
       ,a.[Freight]              
       ,a.[TotalDue]              
 
    ,e.Name as statusName    
   FROM Dynamic.Data_CRMPurchaseOrderHeader    a          
   inner join Dynamic.Data_CRMCustormer  b on a.SupplierID=b.userWorkflowId          
             
   inner join Dynamic.Data_CRMContractStatus e on e.userWorkflowId = a.Status     
 
   order by ID desc
go

