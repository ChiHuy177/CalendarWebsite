-- [Work_getComment] 310976   
   CREATE   PROC [dbo].[Work_getComment]   
   @workId as nvarchar(500)   
   as   
   --select b.FullName, a.Note,a.LastModified,b.ImageId,b.Id as UserId   
   --,a.UserWorkflowId as WorkId   
   --,c.Tieude as WorkName   
   --from UserWorkflowNote a   
   --inner join PersonalProfile b on a.UserId=b.Id   
   --inner join Dynamic.Data_WORK c on a.UserWorkflowId=c.UserWorkflowId   
   --where c.UserWorkflowId in (select value from string_split( @workId,','))   
   select e.id, b.FullName, e.Content as Note,FORMAT(e.CreatedTime, 'dd/MM/yyyy hh:mm:ss') as LastModified,b.ImageId,b.Id as UserId   
   ,a.UserWorkflowId as WorkId   
   ,c.Tieude as WorkName   
   from Chat.Info a   
   inner join Chat.Message e on a.Id=e.ChatId   
   inner join PersonalProfile b on e.UserId=b.Id   
   inner join Dynamic.Data_WORK c on a.UserWorkflowId=c.UserWorkflowId   
   where c.UserWorkflowId in (select value from string_split( @workId,','))   
   and a.Type=0 and ISNULL(c.IsActive,'True')='True'  and e.Content<>''  
   order by e.CreatedTime  
go

