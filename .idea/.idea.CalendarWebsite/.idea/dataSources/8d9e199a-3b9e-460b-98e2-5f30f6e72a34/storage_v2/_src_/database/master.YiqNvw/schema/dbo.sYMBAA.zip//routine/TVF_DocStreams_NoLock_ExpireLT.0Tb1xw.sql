CREATE FUNCTION [dbo].[TVF_DocStreams_NoLock_ExpireLT]
(
    @LTExpirationUTC datetime
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[DocStreams] WITH (NOLOCK, INDEX=DocStreams_Expiration, FORCESEEK)
    WHERE
        ExpirationUTC < @LTExpirationUTC

go

