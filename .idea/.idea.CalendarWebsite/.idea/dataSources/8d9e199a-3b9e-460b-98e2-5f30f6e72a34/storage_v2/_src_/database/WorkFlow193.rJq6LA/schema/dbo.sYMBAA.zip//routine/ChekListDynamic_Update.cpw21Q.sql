-- =============================================
-- Author:		DuyDam
-- Create date: 04/10/2021
-- Description:	Update data in to dynamic checklist
-- Changelog:   duydd 09/12/2024    update with position column
-- =============================================
CREATE   PROCEDURE [dbo].[ChekListDynamic_Update] @Id BIGINT
	,@WorkflowId BIGINT
	,@UserWorkflowId BIGINT
	,@CheckListId BIGINT
	,@Name NVARCHAR(MAX)
	,@Note NVARCHAR(MAX)
	,@Path NVARCHAR(MAX)
	,@Type NVARCHAR(MAX)
	,@CreatedBy NVARCHAR(MAX)
	,@CreatedTime DATETIME2
	,@ModifiedBy NVARCHAR(MAX)
	,@LastModified DATETIME2 = null
	,@Position NVARCHAR(MAX) = 'bottomRight'
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	print @TableName
	SET @Sql = 'UPDATE ' + @TableName + ' SET ' + 'CheckListId = ' + CAST(@CheckListId AS VARCHAR) + ',UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ',Name = ' + 'N''' + REPLACE(@Name, '''', '''''') + '''' + ',Note = ' + 'N''' + (
			CASE 
				WHEN @Note IS NULL
					THEN ''
				ELSE REPLACE(@Note, '''', '''''')
				END
			) + '''' + ',Position = ' + 'N''' + (
			CASE 
				WHEN @Position IS NULL
					THEN 'bottomRight'
				ELSE REPLACE(@Position, '''', '''''')
				END
			) + '''' + ',Path = ' + 'N''' + (
			CASE 
				WHEN @Path IS NULL
					THEN ''
				ELSE REPLACE(@Path, '''', '''''')
				END
			) + '''' + ',Type = ' + 'N''' + (
			CASE 
				WHEN @Type IS NULL
					THEN ''
				ELSE REPLACE(@Type, '''', '''''')
				END
			) + '''' + ',CreatedBy = ' + 'N''' + @CreatedBy + '''' + ',CreatedTime = ' + '''' + CAST(@CreatedTime AS VARCHAR) + '''' + ',ModifiedBy = ' + 'N''' + @ModifiedBy + '''' 
			+ ',LastModified = '  + (
			CASE 
				WHEN @LastModified IS NULL
					THEN 'NULL'
				ELSE ('''' + CAST(@LastModified AS VARCHAR) + '''')
				END
			)  + ' where Id = ' + CAST(@Id AS VARCHAR);
	print @sql
	EXEC sp_executesql @Sql;

	SET @Sql = 'SELECT * FROM ' + @TableName + ' WHERE Id = ' + CAST(@Id AS VARCHAR);

	EXEC sp_executesql @Sql;
END
go

