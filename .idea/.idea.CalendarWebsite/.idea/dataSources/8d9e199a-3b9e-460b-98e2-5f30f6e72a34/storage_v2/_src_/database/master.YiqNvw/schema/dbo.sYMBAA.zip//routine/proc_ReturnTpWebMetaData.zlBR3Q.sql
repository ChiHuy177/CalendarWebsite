CREATE PROCEDURE [dbo].[proc_ReturnTpWebMetaData](
    @WebSiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @SiteFlags int,
    @SitePortalURL nvarchar(260),
    @SitePortalName nvarchar(255),
    @SiteSecurityVersion bigint,
    @SystemId tSystemId,
    @AppPrincipalName nvarchar(256),
    @ReturnAppPrincipalInfo bit,
    @SiteHashKey binary(16),
    @DenyPermMask tPermMask,
    @UserInfoListId uniqueidentifier,
    @RootWebId uniqueidentifier,
    @DGCacheVersion bigint,
    @SiteLastContentChange datetime,
    @SiteLastSecurityChange datetime,
    @SiteRbsCollectionId int,
    @SitePlatformVersion nvarchar(64),
    @SiteClientTag smallint,
    @DGMapVersion bigint = NULL,
    @DGMapCacheVersion bigint = NULL,
    @DGMapCache varbinary(max) = NULL,
    @SourceSiteId uniqueidentifier = NULL, 
    @ExpirationDate datetime = NULL,
    @EvalSiteId uniqueidentifier = NULL,
    @LifeCycleFlags int = NULL,
    @ReminderDate datetime = NULL )
AS
    SET NOCOUNT ON
    DECLARE @RequestAccessEmail nvarchar(255) 
    DECLARE @FirstUniqueAncestorWebId uniqueidentifier
    DECLARE @bHasAncestry bit
    DECLARE @bAllowMUI bit
    DECLARE @bJointoWebsPlus bit
    DECLARE @TitleResource nvarchar(520)
    DECLARE @DescriptionResource nvarchar(520)
    DECLARE @DescriptionRootWeb nvarchar(255)
    DECLARE @LogoUrlRootWeb nvarchar(260)
    DECLARE @AppInstanceId uniqueidentifier
    DECLARE @RemoteAppUrl nvarchar(2080)
    DECLARE @OAuthAppId nvarchar(256)
    DECLARE @AppDatabaseName nvarchar(128)
    DECLARE @AppDatabaseServerReferenceId uniqueidentifier
    DECLARE @AppDatabaseTargetApplicationId nvarchar(256)
    SET @bJointoWebsPlus = 0
    SELECT TOP 1
        @FirstUniqueAncestorWebId = FirstUniqueAncestorWebId,
        @bHasAncestry = 
            CASE
                WHEN ParentWebId IS NOT NULL AND Ancestry IS NULL THEN 0
                ELSE 1
            END,
        @bAllowMUI = AllowMUI,
        @AppInstanceId = AppInstanceId,
        @DescriptionRootWeb = SiteLogoDescription,
        @LogoUrlRootWeb = SiteLogoUrl,
        @RequestAccessEmail = RequestAccessEmail
    FROM
        TVF_Webs_Id(@WebSiteId, @WebId) AS W
    IF @RootWebId <> @WebId
    BEGIN
        -- rootweb is not current web, get rootweb logo descrip and url
        SELECT TOP 1
            @DescriptionRootWeb = SiteLogoDescription,
            @LogoUrlRootWeb = SiteLogoUrl
        FROM
            TVF_Webs_NoLock_Id(@WebSiteId, @RootWebId) AS W    
    END
    IF @FirstUniqueAncestorWebId <> @WebId
    BEGIN
        -- firstUniqAncesWeb is not current web, get rootweb reqAccEmail
        SELECT TOP 1
            @RequestAccessEmail = RequestAccessEmail
        FROM
            TVF_Webs_Id(@WebSiteId, @FirstUniqueAncestorWebId) AS W
    END
    IF (@bHasAncestry <> 1)
    BEGIN
        EXEC proc_GenerateWebAncestry @WebSiteId, @WebId
    END
    IF (@bAllowMUI <> 0)
    BEGIN
        SET @bJointoWebsPlus = 1
    END
    DECLARE @UserId int
    SELECT TOP 1
        @UserId = UI.tp_ID
    FROM
        TVF_UserInfo_SID(@WebSiteId, @SystemId) AS UI
    WHERE
        UI.tp_Deleted = 0
    IF @DGMapVersion IS NOT NULL
        EXEC proc_SecGetDomainGroupMapDataInternal
            @WebSiteId,
            @DGCacheVersion,
            @DGMapVersion,
            @DGMapCacheVersion,
            @DGMapCache
    ELSE
        EXEC proc_SecGetDomainGroupMapData @WebSiteId, @DGCacheVersion
    EXEC proc_SecReturnAppPrincipalInfo @WebSiteId, @WebId, @AppPrincipalName, @ReturnAppPrincipalInfo
    IF (@AppInstanceId <> '00000000-0000-0000-0000-000000000000')
    BEGIN
        SELECT
            @RemoteAppUrl = Token.ValueString
        FROM
            TVF_AppRuntimeSubstitutionDictionary_AppInstanceId(@WebSiteId, @AppInstanceId) AS Token
        WHERE
            Token.ValueKey = 'remoteAppUrl'
        SELECT
            @OAuthAppId = AppMetaData.OAuthAppId
        FROM
            TVF_AppRuntimeMetadata_AppInstanceId(@WebSiteId, @AppInstanceId) AS AppMetaData
        SELECT
            @AppDatabaseName = AppDatabaseMetadata.DatabaseName,
            @AppDatabaseServerReferenceId = AppDatabaseMetadata.ReferenceId,
            @AppDatabaseTargetApplicationId = AppDatabaseMetadata.TargetAppId
        FROM
            TVF_AppDatabaseMetadata_AppInstallationId(@WebSiteId, @AppInstanceId) AS AppDatabaseMetadata
    END
    IF (@bJointoWebsPlus = 0)
    BEGIN
        SELECT
            Webs.Id,
            Webs.Title,
            Webs.Description,
            Webs.MetaInfoVersion,
            Webs.WebTemplate,
            Webs.Language,
            Webs.Locale,
            Webs.Collation,
            Webs.TimeZone,
            Webs.Time24,
            Webs.CalendarType,
            Webs.AdjustHijriDays,
            Webs.AltCalendarType,
            Webs.CalendarViewOptions,
            Webs.WorkDays,
            Webs.WorkDayStartHour,
            Webs.WorkDayEndHour,
            Webs.ProvisionConfig,
            Webs.Flags,
            Webs.Author,
            Webs.DefTheme,
            Webs.AlternateCSSUrl,
            Webs.CustomizedCss,
            Webs.CustomJSUrl,
            Webs.AlternateHeaderUrl,
            Webs.SecurityProvider,
            Webs.MasterUrl,
            Webs.CustomMasterUrl,
            ISNULL(Webs.SiteLogoUrl,@LogoUrlRootWeb),
            ISNULL(Webs.SiteLogoDescription,@DescriptionRootWeb),
            Webs.AllowMUI,
            NULL,
            NULL,
            NULL,
            NULL,
            Webs.UIVersion,
            Webs.ClientTag,
            Perms.AnonymousPermMask,
            @SiteFlags,
            @SitePortalURL,
            @SitePortalName,
            Webs.MeetingCount,
            Webs.CachedNav,
            Webs.CachedInheritedNav,
            Webs.CachedNavDirty,
            Webs.CachedDataVersion,
            Webs.NavParentWebId,
            Webs.FirstUniqueAncestorWebId,
            Webs.ScopeId,
            GETUTCDATE() as DbNow,
            Perms.Acl,
            @RequestAccessEmail,
            Webs.TimeCreated,
            Webs.Ancestry,
            Webs.ProductVersion,
            Webs.AppInstanceId,
            @RemoteAppUrl,
            @OAuthAppId,
            @AppDatabaseName,
            @AppDatabaseServerReferenceId,
            @AppDatabaseTargetApplicationId,
            Webs.AppWebDomainId,
            UserInfo.tp_ID,
            UserInfo.tp_SiteAdmin,
            UserInfo.tp_IsActive,
            UserInfo.tp_Login,
            UserInfo.tp_Email,
            UserInfo.tp_Title,
            UserInfo.tp_Notes,
            UserInfo.tp_ExternalTokenLastUpdated,
            UserInfo.tp_Token,
            UserInfo.tp_Flags,
            WM.UserId,
            @SiteSecurityVersion,
            UserInfo.tp_Locale,
            UserInfo.tp_TimeZone,
            UserInfo.tp_Time24,
            UserInfo.tp_CalendarType,
            UserInfo.tp_AdjustHijriDays,
            UserInfo.tp_AltCalendarType,
            UserInfo.tp_CalendarViewOptions,
            UserInfo.tp_WorkDays,
            UserInfo.tp_WorkDayStartHour,
            UserInfo.tp_WorkDayEndHour,
            UserInfo.tp_MUILanguages,
            UserInfo.tp_ContentLanguages,
            @SiteHashKey,
            @UserInfoListId,
            @RootWebId,
            @SiteLastContentChange,
            @SiteLastSecurityChange,
            @SiteRbsCollectionId,
            @SitePlatformVersion,
            @SiteClientTag,
            @SourceSiteId, 
            @ExpirationDate,
            @EvalSiteId,
            @LifeCycleFlags,
            @ReminderDate,
            @DenyPermMask
        FROM
            TVF_Webs_NoLock_Id(@WebSiteId, @WebId) AS Webs
        CROSS APPLY
            TVF_Perms_ScopeId(Webs.SiteId, Webs.ScopeId) AS Perms
        OUTER APPLY
            TVF_UserInfo_PK(Perms.SiteId, @UserId) AS UserInfo
        OUTER APPLY
            TVF_WebMembers_PK(UserInfo.tp_SiteId, @FirstUniqueAncestorWebId, UserInfo.tp_ID) AS WM
        OPTION (FORCE ORDER)
    END
    ELSE
    BEGIN
        SELECT
            Webs.Id,
            Webs.Title,
            Webs.Description,
            Webs.MetaInfoVersion,
            Webs.WebTemplate,
            Webs.Language,
            Webs.Locale,
            Webs.Collation,
            Webs.TimeZone,
            Webs.Time24,
            Webs.CalendarType,
            Webs.AdjustHijriDays,
            Webs.AltCalendarType,
            Webs.CalendarViewOptions,
            Webs.WorkDays,
            Webs.WorkDayStartHour,
            Webs.WorkDayEndHour,
            Webs.ProvisionConfig,
            Webs.Flags,
            Webs.Author,
            Webs.DefTheme,
            Webs.AlternateCSSUrl,
            Webs.CustomizedCss,
            Webs.CustomJSUrl,
            Webs.AlternateHeaderUrl,
            Webs.SecurityProvider,
            Webs.MasterUrl,
            Webs.CustomMasterUrl,
            ISNULL(Webs.SiteLogoUrl,@LogoUrlRootWeb),
            ISNULL(Webs.SiteLogoDescription,@DescriptionRootWeb),
            Webs.AllowMUI,
            WebsPlus.TitleResource,
            WebsPlus.DescriptionResource,
            WebsPlus.AlternateMUICultures,
            WebsPlus.OverwriteMUICultures,
            Webs.UIVersion,
            Webs.ClientTag,
            Perms.AnonymousPermMask,
            @SiteFlags,
            @SitePortalURL,
            @SitePortalName,
            Webs.MeetingCount,
            Webs.CachedNav,
            Webs.CachedInheritedNav,
            Webs.CachedNavDirty,
            Webs.CachedDataVersion,
            Webs.NavParentWebId,
            Webs.FirstUniqueAncestorWebId,
            Webs.ScopeId,
            GETUTCDATE() as DbNow,
            Perms.Acl,
            @RequestAccessEmail,
            Webs.TimeCreated,
            Webs.Ancestry,
            Webs.ProductVersion,
            Webs.AppInstanceId,
            @RemoteAppUrl,
            @OAuthAppId,
            @AppDatabaseName,
            @AppDatabaseServerReferenceId,
            @AppDatabaseTargetApplicationId,
            Webs.AppWebDomainId,
            UserInfo.tp_ID,
            UserInfo.tp_SiteAdmin,
            UserInfo.tp_IsActive,
            UserInfo.tp_Login,
            UserInfo.tp_Email,
            UserInfo.tp_Title,
            UserInfo.tp_Notes,
            UserInfo.tp_ExternalTokenLastUpdated,
            UserInfo.tp_Token,
            UserInfo.tp_Flags,
            WM.UserId,
            @SiteSecurityVersion,
            UserInfo.tp_Locale,
            UserInfo.tp_TimeZone,
            UserInfo.tp_Time24,
            UserInfo.tp_CalendarType,
            UserInfo.tp_AdjustHijriDays,
            UserInfo.tp_AltCalendarType,
            UserInfo.tp_CalendarViewOptions,
            UserInfo.tp_WorkDays,
            UserInfo.tp_WorkDayStartHour,
            UserInfo.tp_WorkDayEndHour,
            UserInfo.tp_MUILanguages,
            UserInfo.tp_ContentLanguages,
            @SiteHashKey,
            @UserInfoListId,
            @RootWebId,
            @SiteLastContentChange,
            @SiteLastSecurityChange,
            @SiteRbsCollectionId,
            @SitePlatformVersion,
            @SiteClientTag,
            @SourceSiteId,
            @ExpirationDate,
            @EvalSiteId,
            @LifeCycleFlags,
            @ReminderDate,
            @DenyPermMask
        FROM
            TVF_Webs_NoLock_Id(@WebSiteId, @WebId) AS Webs
        CROSS APPLY
            TVF_Perms_ScopeId(Webs.SiteId, Webs.ScopeId) AS Perms
        OUTER APPLY
            TVF_UserInfo_PK(Perms.SiteId, @UserId) AS UserInfo
        OUTER APPLY
            TVF_WebMembers_PK(UserInfo.tp_SiteId, @FirstUniqueAncestorWebId, UserInfo.tp_ID) AS WM
        OUTER APPLY
            TVF_WebsPlus_WebId(Webs.SiteId, Webs.Id) AS WebsPlus
        OPTION (FORCE ORDER)
    END
    DECLARE @status int
    SELECT
        @status = 
            CASE
                WHEN (@SiteFlags & 2 = 2) THEN 1271 
                ELSE 0
            END
    RETURN @status

go

