CREATE FUNCTION [dbo].[TVF_AllUserData_ListDelVerItemCal]
(
    @tp_SiteId uniqueidentifier,
    @tp_ListId uniqueidentifier,
    @tp_DeleteTransactionId varbinary(16),
    @tp_IsCurrentVersion bit,
    @tp_Id int,
    @tp_CalculatedVersion int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserData] WITH (INDEX=AllUserData_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_ListId = @tp_ListId AND
        tp_DeleteTransactionId = @tp_DeleteTransactionId AND
        tp_IsCurrentVersion = @tp_IsCurrentVersion AND
        tp_ID = @tp_Id AND
        tp_CalculatedVersion = @tp_CalculatedVersion

go

