CREATE PROCEDURE [dbo].[proc_UrlToWebUrlAndAppWebDomainIdOutput](
    @WebSiteId uniqueidentifier,
    @Url nvarchar(260),
    @OutWebDirName nvarchar(256) OUTPUT,
    @OutWebLeafName nvarchar(128) OUTPUT,
    @OutAppWebDomainId varchar(8) OUTPUT,
    @SiteExists bit = NULL)
AS
    SET NOCOUNT ON
    DECLARE @WebDirName nvarchar(256)
    DECLARE @WebLeafName nvarchar(128)
    DECLARE @WebId uniqueidentifier
    DECLARE @WebFullUrl  nvarchar(260)
    DECLARE @AppWebDomainId varchar(8)
    DECLARE @DocType  tinyint
    SET @WebDirName = @Url
    WHILE NOT((DATALENGTH(@WebDirName) = 0) AND (DATALENGTH(@WebLeafName) = 0))
    BEGIN
        EXEC proc_SplitUrl @WebDirName, @WebDirName OUTPUT,
            @WebLeafName OUTPUT
        SELECT TOP 1
            @DocType = Type,
            @WebId = WebId
        FROM
            TVF_Docs_NoLock_Url(@WebSiteId, @WebDirName, @WebLeafName) AS Docs
        IF @WebId IS NOT NULL
        BEGIN
            IF @DocType != 2
            BEGIN
                SELECT TOP 1
                    @WebFullUrl = FullUrl
                FROM
                    TVF_Webs_NoLock_Id(@WebSiteId, @WebId) AS Webs
                IF @WebFullUrl IS NULL
                    RETURN 1168
                EXEC proc_SplitUrl @WebFullUrl, @WebDirName OUTPUT,
                    @WebLeafName OUTPUT
            END
            SELECT TOP 1
                @AppWebDomainId = AppWebDomainId
            FROM
                TVF_Webs_NoLock_Id(@WebSiteId, @WebId) AS Webs
            SET @OutWebDirName = @WebDirName
            SET @OutWebLeafName = @WebLeafName
            SET @OutAppWebDomainId = @AppWebDomainId
            RETURN 0            
        END
    END
    SET @OutWebDirName = N''
    SET @OutWebLeafName = N''
    IF (@SiteExists IS NOT NULL AND @SiteExists = 0) OR NOT EXISTS (SELECT TOP 1 1 FROM TVF_Sites_NoLock_Id(@WebSiteId))
    BEGIN
        RETURN 1168
    END
    RETURN 0

go

