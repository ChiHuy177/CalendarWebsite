CREATE FUNCTION [dbo].[TVF_WebParts_List]
(
    @tp_SiteId uniqueidentifier,
    @tp_ListId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebParts] WITH (INDEX=ListIdUserId_NCI, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        ((@tp_ListId IS NULL AND tp_ListId IS NULL) OR @tp_ListId=tp_ListId) AND
        tp_IsCurrentVersion = CONVERT(bit, 1) AND
        tp_PageVersion = 0

go

