-- Work_ReportPercentComplete '2024-01-01','2024-03-31','P:285'                      
   CREATE   PROC  [dbo].[Work_ReportPercentComplete]                            
   @fromDate as datetime                          
   ,@toDate as datetime = null        
   ,@userId as nvarchar(10)                          
   as                          
   declare @sql nvarchar(max)=N'', @where as nvarchar(max)=N''                          
   declare @account as nvarchar(150)=N''                  
   set @account= ( select top 1 AccountName from PersonalProfile where UserStatus<>-1 and Id = REPLACE( @userId,'P:',''))                   
   CREATE TABLE #department  (                          
   DepartmentId INT,                          
   type int                          
   );                          
   if(select COUNT( *) from Split('tamctt',',') where Item= @account)>0                  
   begin                   
   insert into #department                          
   select Id,1 as type  from Department                          
   end                  
   insert into #department                          
   select b.Item,1 as type  from Dynamic.data_RuleViewProject                          
   cross apply Split(Department,';') b                          
   where [User]=@userId                          
   insert into #department                          
   select b.Id,1 from PersonalProfile a                           
   inner join Department b on a.DepartmentId=b.Id                          
   where a.UserStatus<>-1 and a.Id = REPLACE( @userId,'P:','') and b.ManagerId=REPLACE(@userId,'P:','')                          
   insert into #department                          
   select b.Id,2 from PersonalProfile a                           
   inner join Department b on a.DepartmentId=b.Id                          
   where a.UserStatus<>-1 and a.Id = REPLACE( @userId,'P:','')                          
   select max(c.Id) as Id,c.WorkId,b.TrangThaiCongViec,MAX(c.Date ) as Date                     
   into #abcd from  Dynamic.Data_LSCNTTCV c                                                                    
   inner join Dynamic.data_RESOURCETTFC b on c.NewValue=trim(str( b.UserWorkflowId))                       
   where  ColumnName='TrangThaiCongViec' and b.TrangThaiCongViec = (N'Người xử lý hoàn thành') and b.TrangThaiCongViec<>N'Hủy'                           
   group by WorkId , b.TrangThaiCongViec                    
   insert into #abcd                
   select max(c.Id) as Id,c.WorkId,b.TrangThaiCongViec,MAX(c.Date ) as Date                     
   from  Dynamic.Data_LSCNTTCV c                                                                    
   inner join Dynamic.data_RESOURCETTFC b on c.NewValue=trim(str( b.UserWorkflowId))                 
   left join #abcd d on c.WorkId=d.WorkId              
   where  ColumnName='TrangThaiCongViec' and b.TrangThaiCongViec = (N'Hoàn thành') and b.TrangThaiCongViec<>N'Hủy'                       
   and d.WorkId is null              
   group by  c.WorkId , b.TrangThaiCongViec            
   select                        
   a.UserWorkflowId                            
   ,a.Tieude                                                                    
   ,trim(CONVERT(CHAR, ISNULL(a.NgayBatDau, null), 120))  as NgayBatDau                            
   ,trim(CONVERT(CHAR, ISNULL(a.NgayKetThuc, null), 120))  as NgayKetThuc                            
   ,a.NguoiXuLyDauTien       
   ,DATEDIFF(HOUR,a.Ngaygiaoviec, d.Date ) as TimeExec                            
   , case when d.TrangThaiCongViec in (N'Hoàn thành',N'Người xử lý hoàn thành') and (isnull(a.Ngayketthuc,'')='' or DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0)              
   then N'Hoàn thành đúng tiến độ'                              
   when d.TrangThaiCongViec in (N'Hoàn thành',N'Người xử lý hoàn thành') and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0                              
   then N'Hoàn thành trễ tiến độ'   
   when (isnull(d.TrangThaiCongViec,'')='' or d.TrangThaiCongViec not in (N'Hoàn thành',N'Người xử lý hoàn thành')) and ((isnull(a.Ngayketthuc,'')='' ) or DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )<0)          
   then N'Chưa hoàn thành'                              
   when (isnull(d.TrangThaiCongViec,'')='' or d.TrangThaiCongViec not in (N'Hoàn thành',N'Người xử lý hoàn thành'))  and DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )>0                            
   then N'Quá hạn'                                
   else  N'' end as Status                                                                        
   , case when d.TrangThaiCongViec in (N'Hoàn thành',N'Người xử lý hoàn thành')   and (isnull(a.Ngayketthuc,'')='' or DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) <=0)                          
   then 1                              
   when d.TrangThaiCongViec in (N'Hoàn thành',N'Người xử lý hoàn thành')  and DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) >0                                 
   then 2                              
   when (isnull(d.TrangThaiCongViec,'')='' or d.TrangThaiCongViec not in (N'Hoàn thành',N'Người xử lý hoàn thành')) and ((isnull(a.Ngayketthuc,'')='' ) or DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )<0)                              
   then 3                              
   when (isnull(d.TrangThaiCongViec,'')='' or d.TrangThaiCongViec not in (N'Hoàn thành',N'Người xử lý hoàn thành'))  and DATEDIFF(HOUR,a.Ngayketthuc, GETDATE() )>0                              
   then 4                              
   else  0 end as StatusInt                            
   ,d.TrangThaiCongViec                                                          
   ,d.Date as DateCompelete                                                        
   ,DATEDIFF(HOUR,a.Ngayketthuc, d.Date ) as abc                            
   , b.UserWorkflowId as ProjectId                               
   ,REPLACE(e.Item,'P:','') as UserId              
   ,a.TrangThaiCongViec as TrangThaiCongViec1            
   into #a                             
   from Dynamic.Data_WORK a                            
   inner join Dynamic.Data_RESOURCEDA b on a.Duan=b.UserWorkflowId                            
   left join                            
   (                            
   select * from #abcd                      
   --select  a.WorkId, b.TrangThaiCongViec, a.Date from Dynamic.Data_LSCNTTCV a                            
   --inner join Dynamic.data_RESOURCETTFC b on a.NewValue=trim(str( b.UserWorkflowId))                            
   --inner join ( select MAX(Id) as Id,WorkId from  Dynamic.Data_LSCNTTCV where ColumnName='TrangThaiCongViec'   group by WorkId )  c on c.Id=a.Id                            
   --where a.ColumnName='TrangThaiCongViec'and b.TrangThaiCongViec<>N'Hủy'                            
   ) d on a.UserWorkflowId=d.WorkId                            
   cross apply Split(a.NguoiXuLyDauTien,';') e                            
   where (ISNULL(b.IsDeleted,'False')='False' and ISNULL(b.TrangThai,'') <>N'hủy' and ISNULL(a.IsActive,'True')='True'        
   and DATEDIFF(day, CONVERT(varchar,@fromDate,23), CONVERT(varchar,ISNULL(a.Ngaybatdau,'0001-12-12'),23) )>=0                          
   and (DATEDIFF(day, CONVERT(varchar,@toDate,23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,'9999-12-12'),23)))<=0        
   and ISNULL(d.TrangThaiCongViec,'') <>N'Hủy'        
   )        
   or (        
   ISNULL(b.IsDeleted,'False')='False' and b.TrangThai <>N'hủy' and ISNULL(a.IsActive,'True')='True'         
   and ISNULL(d.TrangThaiCongViec,'') in (N'Hoàn thành',N'Người xử lý hoàn thành')         
   and DATEDIFF(day, CONVERT(varchar,@fromDate,23), CONVERT(varchar,ISNULL(a.Ngaybatdau,'0001-12-12'),23) )>=0             
   and DATEDIFF(day, CONVERT(varchar,@toDate,23) , CONVERT(varchar,ISNULL(d.Date,'9999-12-12'),23) )<=0     
   )    
   if(select COUNT(*) from #department where type=1)=0                          
   begin                           
   set @where=' and a.Id = '''+REPLACE( @userId,'P:','') +''''                          
   end                          
   set @sql=N'                          
   select a.*,b.Id as DepartmentId,b.DepartmentName,b.Code,b.FullName                          
   into #b                          
   from #a a           
   inner join                            (                          
   select distinct b.Id, b.Title as DepartmentName,a.StaffId as Code, a.FullName                            
   ,a.Id as UserId                            
   from PersonalProfile a        
   inner join Department b on a.DepartmentId=b.Id                            
   inner join #department c on c.DepartmentId=b.Id                          
   where a.UserStatus <>-1 '+@where+'                           
   ) b on a.UserId=b.UserId                           
   inner join Dynamic.Data_RESOURCETTFC i on i.Duan= a.ProjectId and a.TrangThaiCongViec1=i.UserWorkflowId                
   where  i.TrangThaiCongViec<>N'''+N'Hủy'+'''            
   select  a.DepartmentId,a.DepartmentName,a.Code,a.FullName,a.UserId                            
   ,COUNT(a.UserWorkflowId) as TotalWork                            
   ,COUNT(b.UserWorkflowId) Complete                            
   ,COUNT(c.UserWorkflowId) as CompleteButLate                            
   ,COUNT(d.UserWorkflowId) as NotComplete                            
   ,COUNT(e.UserWorkflowId) as Overdue                           
   ,COUNT( a.code) over (PARTITION BY a.DepartmentId)  as CountEmp                          
   into #c                            
   from #b a                            
   left join #b b on a.UserWorkflowId=b.UserWorkflowId and b.StatusInt =1 and a.UserId=b.UserId                            
   left join #b c on a.UserWorkflowId=c.UserWorkflowId and c.StatusInt =2 and a.UserId=c.UserId                            
   left join #b d on a.UserWorkflowId=d.UserWorkflowId and d.StatusInt =3 and a.UserId=d.UserId                            
   left join #b e on a.UserWorkflowId=e.UserWorkflowId and e.StatusInt =4 and a.UserId=e.UserId                            
   group by a.DepartmentId,a.DepartmentName,a.Code,a.FullName,a.UserId                          
   select *                          
   ,CONVERT(nvarchar,cast(ROUND( 100.0*( Complete/(1.0* (case when TotalWork-NotComplete =0 then 1 else TotalWork-NotComplete end )) ),1) as float)) +''%''                          
   as PercentComplete from #c                              
   order by DepartmentId                           
   drop table #a                            
   drop table #b                            
   drop table #c                            
   drop table #department                          
   '                           
   exec(@sql)                          
   print(@sql)
go

