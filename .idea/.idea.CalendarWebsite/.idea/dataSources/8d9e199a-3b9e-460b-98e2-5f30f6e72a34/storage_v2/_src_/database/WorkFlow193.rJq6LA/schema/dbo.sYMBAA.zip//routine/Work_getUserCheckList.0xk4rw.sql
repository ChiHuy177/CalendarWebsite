CREATE   PROC [dbo].[Work_getUserCheckList]    
   @id as bigint    
   as    
   select 
   d.Title as Title 
   ,d.TitleEN as TitleEN
   ,c.Id
   ,[WorkflowStepId]
   ,[TypeId]
   ,c.[IsRequired]
   ,[IsQRCode]
   ,[IsSignature]
   ,c.[CreatedBy]
   ,c.[CreatedTime]
   ,c.[LastModified]
   ,c.[ModifiedBy]
   ,c.[IsDeleted]
   ,c.[Order]
   ,[IsReplaceText]
   ,[IsReplaceSignature]
   ,[IsPublicForEveryone]
   ,[IsReplaceFlashSignature]
   ,[Permission]
   ,[IsOnlyAllowedAttachedAfterApproving]
   ,[IsAutoWatermarkEmbedWhenDownload]
   ,[IsSignaturedManually]
   ,[CustomFile] from Workflow a     
   inner join WorkflowStep b on a.Id=b.WorkflowId    
   inner join CheckList c on c.WorkflowStepId=b.Id   
   inner join DocumentType d on  c.TypeId = d.Id
   where a.Id=@id  and ISNULL(CustomFile,'')=''
go

