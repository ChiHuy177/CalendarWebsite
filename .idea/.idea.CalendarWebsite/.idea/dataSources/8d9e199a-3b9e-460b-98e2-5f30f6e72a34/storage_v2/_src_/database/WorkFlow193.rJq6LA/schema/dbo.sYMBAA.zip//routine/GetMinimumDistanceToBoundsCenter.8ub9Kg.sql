CREATE
	

 FUNCTION dbo.GetMinimumDistanceToBoundsCenter (
	@TopLeftLat FLOAT
	,@TopLeftLong FLOAT
	,@BottomRightLat FLOAT
	,@BottomRightLong FLOAT
	,@UserWorkflowId INT
	)
RETURNS TABLE
AS
RETURN (
		WITH Points AS (
				SELECT Location.MakeValid().STAsText() AS Location
				FROM Asset.Coordinates
				WHERE UserWorkflowId = @UserWorkflowId
				)
			,Center AS (
				SELECT geometry::STGeomFromText('POINT(' + CAST((@TopLeftLong + @BottomRightLong) / 2 AS VARCHAR(20)) + ' ' + CAST((@TopLeftLat + @BottomRightLat) / 2 AS VARCHAR(20)) + ')', 4326) AS CenterPoint
				)
		SELECT MIN(Center.CenterPoint.STDistance(geometry::STGeomFromText(Location, 4326))) AS MinimumDistance
		FROM Points
		CROSS JOIN Center
		);
go

