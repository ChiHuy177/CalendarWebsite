-- Work_GetWorkflowRelationshipBefore 342180    
   CREATE   PROC Work_GetWorkflowRelationshipBefore     
   @workId as nvarchar(50)    
   as    
   declare @nodeId as nvarchar(100)     
   select a.Nodeid,a.CongViecCha, b.QuyTrinhDinhKem into #a    
   from Dynamic.Data_WORK a     
   inner join Dynamic.Data_WORK b on a.CongViecCha=b.UserWorkflowId     
   where a.UserWorkflowId=@workId    
   -- lay danh sach cong viec quy trinh     
   select a.* into #b from Dynamic.Data_FOLLOWCHART a    
   inner join #a b on a.CategoryWorkProcessId=b.QuyTrinhDinhKem where ISNULL(a.IsDelete,'False')='False'  
   set @nodeId=( select ChoiceWorkflowRelationshipBefore from #b where Nodeid in (select Nodeid from #a))    
   if(ISNULL(@nodeId,'')<>'')    
   begin     
   select PhieuQuyTrinhId from Dynamic.Data_WORK a    
   inner join #a b on a.CongViecCha=b.CongViecCha where a.Nodeid in (select * from Split(@nodeId,';'))  
   and ISNULL(PhieuQuyTrinhId,'')<>''  
   end     
   else    
   begin     
   select '' as PhieuQuyTrinhId    
   end     
   --select * from #a  
   --select * from #b  
   drop table #a    
   drop table #b
go

