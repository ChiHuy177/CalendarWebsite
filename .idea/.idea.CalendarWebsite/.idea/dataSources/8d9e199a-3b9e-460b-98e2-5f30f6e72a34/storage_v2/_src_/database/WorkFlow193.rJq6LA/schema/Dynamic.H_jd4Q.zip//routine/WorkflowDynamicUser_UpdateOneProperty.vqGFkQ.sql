-- =============================================
-- Author:		Duy Dam
-- Create date: 28/02/2024
-- Description:	Update Dynamic value of one property
-- =============================================
CREATE
	
 PROCEDURE [Dynamic].[WorkflowDynamicUser_UpdateOneProperty] @UserWorkflowId BIGINT
	,@PropertyName NVARCHAR(MAX)
	,@Value NVARCHAR(MAX)
	,@Email NVARCHAR(MAX) = NULL
	WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowId AS BIGINT
		,@WorkflowCode AS NVARCHAR(MAX)
		,@WorkflowTableName AS NVARCHAR(MAX)
		,@DataTableName AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX)
		,@LineBreak NCHAR(2) = NCHAR(13) + NCHAR(10);

	SET @WorkflowId = (
			SELECT [WorkflowId]
			FROM [dbo].[USerWorkflow]
			WHERE Id = @UserWorkflowId
			);

	SELECT TOP 1 IsNumber
		,IsCurrency
		,IsYesNo
		,IsViewOnly
	INTO #TempDestinationTable2
	FROM [dbo].[Property]
	WHERE WorkflowId = @WorkflowId
		AND Name = @PropertyName
	ORDER BY CASE IsDeleted
			WHEN 0
				THEN 1
			ELSE 0
			END DESC

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @WorkflowTableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	SET @Sql = 'BEGIN TRANSACTION' + @LineBreak + 'BEGIN TRY' + @LineBreak
		-- update Dynamic.Workflow_
		+ 'UPDATE ' + @WorkflowTableName + ' SET [Data] = JSON_MODIFY([Data], ''$.' + @PropertyName + ''', ' + (
			CASE 
				WHEN EXISTS (
						SELECT 1
						FROM #TempDestinationTable2
						WHERE (
								IsNumber = 1
								OR IsCurrency = 1
								)
							AND IsViewOnly <> 1
						)
					THEN CAST(@Value AS VARCHAR)
				WHEN EXISTS (
						SELECT 1
						FROM #TempDestinationTable2
						WHERE IsYesNo = 1
						)
					THEN (
							CASE @Value
								WHEN 'true'
									THEN '1'
								WHEN 'false'
									THEN '0'
								ELSE 'null'
								END
							)
				ELSE CONCAT (
						'N'''
						,@Value
						,''''
						)
				END
			) + ')' + ', LastModified = ' + CONCAT (
			''''
			,GETDATE()
			,''''
			) + ', ModifiedBy = ' + + CONCAT (
			''''
			,@Email
			,''''
			) + @LineBreak + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';' + @LineBreak

		--update Dynamic.Data_
		+ 'UPDATE ' + @DataTableName + ' SET [' + @PropertyName + '] = ' + (
			CASE 
				WHEN EXISTS (
						SELECT 1
						FROM #TempDestinationTable2
						WHERE (
								IsNumber = 1
								OR IsCurrency = 1
								)
							AND IsViewOnly <> 1
						)
					THEN CAST(@Value AS VARCHAR)
				WHEN EXISTS (
						SELECT 1
						FROM #TempDestinationTable2
						WHERE IsYesNo = 1
						)
					THEN (
							CASE @Value
								WHEN 'true'
									THEN '1'
								WHEN 'false'
									THEN '0'
								ELSE 'null'
								END
							)
				ELSE CONCAT (
						'N'''
						,@Value
						,''''
						)
				END
			) + ' WHERE UserWorkflowId = ' + CAST(@UserWorkflowId AS VARCHAR) + ';' + @LineBreak 
			
			+ 'COMMIT TRANSACTION' + @LineBreak + 'END TRY' + @LineBreak + 'BEGIN CATCH' + @LineBreak + 'IF @@TRANCOUNT > 0' + @LineBreak + '    ROLLBACK TRANSACTION' + @LineBreak + 'END CATCH' + @LineBreak;

	PRINT @SQL;

	EXEC sp_ExecuteSql @SQL;
END
go

