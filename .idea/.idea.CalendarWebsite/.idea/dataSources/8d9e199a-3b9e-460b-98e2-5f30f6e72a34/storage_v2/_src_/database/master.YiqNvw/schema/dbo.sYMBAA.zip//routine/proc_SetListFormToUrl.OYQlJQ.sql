CREATE PROCEDURE [dbo].[proc_SetListFormToUrl](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @PageUrl nvarchar(260),
    @PageType tinyint,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @PageUrlId uniqueidentifier
    DECLARE @DirName nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    DECLARE @OldFormId uniqueidentifier
    EXEC proc_SplitUrl @PageUrl, @DirName OUTPUT, @LeafName OUTPUT
    DECLARE @ReturnValue int SET @ReturnValue = 0 BEGIN TRAN
    SELECT TOP 1
        @PageUrlId = Id
    FROM
        TVF_Docs_RepeatableRead_Url(@SiteId, @DirName, @LeafName) AS D
    IF @PageUrlId IS NULL
    BEGIN
        SET @ReturnValue = 126
        GOTO CLEANUP
    END
    UPDATE
        WP
    SET
        WP.tp_Flags = WP.tp_Flags & ~(0 | 1048576)
    FROM
        TVF_WebParts_ListUser(@SiteId, @ListId, NULL ) AS WP
    WHERE
        WP.tp_Type = @PageType
    IF @@ROWCOUNT = 0
    BEGIN
        SET @ReturnValue = 126
        GOTO CLEANUP
    END
    UPDATE
        WP
    SET
        WP.tp_Flags = WP.tp_Flags | 1048576
    FROM
        TVF_WebParts_SitePageId(@SiteId, @PageUrlId) AS WP
    WHERE
        WP.tp_ListId = @ListId AND
        WP.tp_UserID IS NULL AND
        WP.tp_Type = @PageType        
    IF @@ROWCOUNT <> 1
    BEGIN
        SET @ReturnValue = 127
        GOTO CLEANUP
    END
CLEANUP:
    IF (@ReturnValue <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @ReturnValue

go

