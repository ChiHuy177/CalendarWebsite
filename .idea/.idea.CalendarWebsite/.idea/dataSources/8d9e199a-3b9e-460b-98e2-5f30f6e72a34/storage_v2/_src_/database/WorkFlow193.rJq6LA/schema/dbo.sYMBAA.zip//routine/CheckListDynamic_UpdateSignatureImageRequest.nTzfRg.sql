-- =============================================
-- Author:		DuyDam
-- Create date: 01/02/2024
-- Description:	Update SignatureImageRequest in to dynamic checklist
-- =============================================
CREATE   PROCEDURE [dbo].[CheckListDynamic_UpdateSignatureImageRequest] @Id BIGINT
	,@WorkflowId BIGINT
	,@SignatureImageRequest NVARCHAR(MAX) = NULL
	,@ModifiedBy NVARCHAR(MAX)
	,@LastModified DATETIME2 = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName AS NVARCHAR(MAX)
		,@WorkflowCode AS NVARCHAR(MAX)
		,@Sql AS NVARCHAR(MAX);

	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);

	PRINT @TableName

	SET @Sql = 'UPDATE ' + @TableName + ' SET SignatureImageRequest = N''' + @SignatureImageRequest + '''' + ',ModifiedBy = ' + 'N''' + @ModifiedBy + '''' + ',LastModified = ' + (
			CASE 
				WHEN @LastModified IS NULL
					THEN 'NULL'
				ELSE ('''' + CAST(@LastModified AS VARCHAR) + '''')
				END
			) + ' where Id = ' + CAST(@Id AS VARCHAR);

	PRINT @sql

	EXEC sp_executesql @Sql;
END
go

