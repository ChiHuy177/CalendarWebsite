-- [Work_GetKeysWorkInProcess] 
   CREATE   PROC [dbo].[Work_GetKeysWorkInProcess] 
   AS 
   BEGIN 
   SET NOCOUNT ON; 
   SELECT 
   case when lower(TRIM(a.column_name))='tieude' then 'title' 
   when lower(TRIM(a.column_name))='tiendo' then 'progress' 
   when lower(TRIM(a.column_name))='ngayketthuc' then 'end' 
   when lower(TRIM(a.column_name))='douutien' then 'priority' 
   when lower(TRIM(a.column_name))='trangthaicongviec' then 'statusName' 
   when lower(TRIM(a.column_name))='loaicv' then 'categoryName' 
   when lower(TRIM(a.column_name))='CREATEdtime' then 'CREATEdTime' 
   else a.column_name end AS columnName 
   from information_schema.columns as a 
   where a.table_name = 'Data_Work' 
   and a.column_name NOT IN ( 
   'Chonbutton' 
   ,'isDraftTemp' 
   ,'Nhomcv' 
   ,'Nguoigiao' 
   ,'Nguoitheodoi' 
   ,'Nguoixuly' 
   ,'Nguoiphoihop' 
   ,'workflowCode' 
   ) 
   GROUP BY a.column_name 
   UNION ALL 
   SELECT 'userPartner' 
   UNION ALL 
   SELECT 'CREATEdTime' 
   UNION ALL 
   SELECT 'projectName' 
   UNION ALL 
   SELECT 'dateComplete' 
   END 
go

