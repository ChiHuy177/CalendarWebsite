-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[News.CO3.NotificationCmt] @userId VARCHAR(max)
	,@WorkflowId VARCHAR(max)
	,@InteractWorkflowId VARCHAR(max)
	,@NewsfeedWorkflowId VARCHAR(max)

AS
BEGIN
	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @QueryString NVARCHAR(MAX);
	DECLARE @DataTableName NVARCHAR(MAX);
	DECLARE @DataTableNameInteractWF NVARCHAR(MAX);
	DECLARE @DataTableNameInteract NVARCHAR(MAX);
	DECLARE @TableNameInteract NVARCHAR(MAX);
	declare @TableNameCheckListNews Nvarchar(max);
	declare @TableNameNewsfeed Nvarchar(max);
	DECLARE @DataTableNameNewsfeed NVARCHAR(MAX);
	SET @TableNameInteract = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @InteractWorkflowId
			)
	SET @DataTableNameInteract = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableNameInteract, '^a-z0-9')
			);
	SET @DataTableNameInteractWF = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@TableNameInteract, '^a-z0-9')
			);	
	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	SET @TableNameCheckListNews = CONCAT (
			'Dynamic.CheckList_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
				set @TableNameNewsfeed= (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @NewsfeedWorkflowId
			)
	SET @DataTableNameNewsfeed = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableNameNewsfeed, '^a-z0-9')
			);
		
			if(@TableNameInteract ='Like')
			begin

		SET @QueryString = '
			  select news.Content,ushTime.CreatedTime,ush.InteractUser ,news.Department , news.UserWorkflowId as Id, ushTime.UserWorkflowId as NotiId,InGroup.InGroup,uwfseen.IsSeen,ush.PostId
  from UserWorkflow u
  inner join '+@DataTableName+' dt on u.Id= dt.UserWorkflowId
   outer apply (
   select distinct wf.CreatedBy as InteractUser ,dt.PostId ,wf.UserWorkflowId from  (('+@DataTableNameInteract+' dt
   inner join '+@DataTableNameInteractWF+' wf on dt.UserWorkflowId= wf.UserWorkflowId)
   inner join UserWorkflow uwf on dt.UserWorkflowId= uwf.Id)

   where dt.PostId= u.Id
   and uwf.IsDeleted!=1
   and uwf.UserId!='+@userId+'
   )AS ush
    outer apply (
   select top 1 wf.CreatedTime ,dt.PostId , wf.UserWorkflowId from  (('+@DataTableNameInteract+' dt
   inner join '+@DataTableNameInteractWF+' wf on dt.UserWorkflowId= wf.UserWorkflowId)
   inner join UserWorkflow uwf on dt.UserWorkflowId= uwf.Id)

   where dt.PostId= u.Id
   and uwf.IsDeleted!=1
   and uwf.UserId!='+@userId+'
   order by wf.CreatedTime desc
   )AS ushTime
        outer apply(
   select count (wfs.UserId) as IsSeen from UserWorkflowSeen wfs
   where wfs.UserWorkflowId=ushTime.UserWorkflowId
   and wfs.UserId='+@userId+'
   )AS uwfseen

     outer apply(
   select * from '+@DataTableNameNewsfeed+' nf where dt.PostId=nf.UserWorkflowId
   )as news
      outer apply(
   select count(*) as InGroup  from Dynamic.Data_GroupNews dtgr where dtgr.UserWorkflowId=SUBSTRING(news.Department,3,5) and (dtgr.Member like ''%;P:'+@userId+''' or dtgr.Member like ''%;P:'+@userId+';%'' or dtgr.Member =''P:'+@userId+''' )
   )as InGroup
where  u.IsDeleted!=1
	and u.UserId='+@userId+'
	and ush.InteractUser is not null
		order by ushTime.CreatedTime desc

	'
	end
	else
	begin 
		SET @QueryString = '
		   select news.Content,ush.CreatedTime,ush.InteractUser ,news.Department , news.UserWorkflowId as Id, ush.UserWorkflowId as NotiId,uwfseen.IsSeen , ush.CommentId as PostId,InGroup.InGroup
  from UserWorkflow u
  inner join '+@DataTableName+' dt on u.Id= dt.UserWorkflowId
   outer apply (
   select distinct wf.CreatedBy as InteractUser,wf.CreatedTime ,dt.CommentId ,wf.UserWorkflowId from  (('+@DataTableNameInteract+' dt
   inner join '+@DataTableNameInteractWF+' wf on dt.UserWorkflowId= wf.UserWorkflowId)
   inner join UserWorkflow uwf on dt.UserWorkflowId= uwf.Id)

   where dt.CommentId= u.Id
   and uwf.IsDeleted!=1
   and uwf.UserId!='+@userId+'
   )AS ush
        outer apply(
   select count (wfs.UserId) as IsSeen from UserWorkflowSeen wfs
   where wfs.UserWorkflowId=ush.UserWorkflowId
   and wfs.UserId='+@userId+'
   )AS uwfseen
     outer apply(
   select * from '+@DataTableNameNewsfeed+' nf where dt.PostId=nf.UserWorkflowId
   )as news
      outer apply(
   select count(*) as InGroup  from Dynamic.Data_GroupNews dtgr where dtgr.UserWorkflowId=SUBSTRING(news.Department,3,5) and (dtgr.Member like ''%;P:'+@userId+''' or dtgr.Member like ''%;P:'+@userId+';%'' or dtgr.Member =''P:'+@userId+''' )
   )as InGroup
where  u.IsDeleted!=1
	and u.UserId='+@userId+'
	and ush.InteractUser is not null
		order by ush.CreatedTime desc

		'
	end
		PRINT @QueryString;

	EXEC sp_ExecuteSql @QueryString;
	END
go

