-- [Work_ReportShowInfoExtendRecursive] '258921',''    
   CREATE   PROC [Work_ReportShowInfoExtendRecursive]        
   @projectId as nvarchar(50)  =258921        
   ,@groupId as nvarchar(50)=''  
   as        
   ;        
   -- rowIndex thứ tự node tính từ cha xuống băt đầu là 0 (0->1->2....)                          
   WITH Managers AS                          
   (                          
   --initialization                          
   select UserWorkflowId as GroupID,Ten,Status,[Index],ISNULL(a.GroupParent,'') as GroupParent        
   ,UserWorkFlowId  
   from Dynamic.Data_ProjectGroup a         
   where a.ProjectId=@projectId and a.UserWorkflowId=(case when @groupId<>'' then @groupId  else a.UserWorkflowId end)  and ISNULL(a.IsDelete,'False')<>'True' --and ISNULL(a.GroupParent,'')=''          
   and ISNULL(a.Status,'')<>'Closed'        
   UNION ALL                          
   --recursive execution                         
   select a.UserWorkflowId as GroupID,a.Ten,a.Status,a.[Index],ISNULL(a.GroupParent,'') as GroupParent    
   ,a.UserWorkFlowId  
   from Dynamic.Data_ProjectGroup a        
   inner join Managers b on ISNULL(b.GroupID,'') = ISNULL(a.GroupParent,'')            
   where a.ProjectId=@projectId  and ISNULL(a.IsDelete,'False')<>'True'         
   and ISNULL(a.Status,'')<>'Closed'        
   )                          
   -- ***************** đệ quy trong sql lấy ra tất cả cha con **************************                          
   --bảng #a thêm vào bang tạm #a workId                          
   SELECT GroupID,GroupID as GroupProject, Ten, Ten as Name, Ten as Code,Status,ISNULL([Index],9999) as [Index],GroupParent        
   ,UserWorkFlowId  
   FROM Managers a     
   group by GroupID, Ten,Status,ISNULL([Index],9999),GroupParent ,UserWorkFlowId
   -- [Work_ReportShowInfoExtendRecursive] '333572' 
go

