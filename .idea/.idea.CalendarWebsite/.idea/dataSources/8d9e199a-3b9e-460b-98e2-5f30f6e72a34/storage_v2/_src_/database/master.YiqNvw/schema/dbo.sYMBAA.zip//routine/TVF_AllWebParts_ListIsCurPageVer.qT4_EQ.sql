CREATE FUNCTION [dbo].[TVF_AllWebParts_ListIsCurPageVer]
(
    @tp_SiteId uniqueidentifier,
    @tp_ListId uniqueidentifier,
    @tp_IsCurrentVersion bit,
    @tp_PageVersion int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebParts] WITH (INDEX=ListIdUserId_NCI, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        ((@tp_ListId IS NULL AND tp_ListId IS NULL) OR @tp_ListId=tp_ListId) AND
        tp_IsCurrentVersion = @tp_IsCurrentVersion AND
        tp_PageVersion = @tp_PageVersion

go

