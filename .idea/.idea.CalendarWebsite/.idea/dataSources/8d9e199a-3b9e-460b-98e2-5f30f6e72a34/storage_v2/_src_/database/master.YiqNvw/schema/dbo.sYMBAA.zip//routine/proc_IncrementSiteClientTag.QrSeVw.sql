CREATE PROCEDURE [dbo].[proc_IncrementSiteClientTag](
    @SiteId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        S
    SET 
        S.ClientTag = S.ClientTag + 1
    FROM
        TVF_Sites_Id(@SiteId) AS S

go

