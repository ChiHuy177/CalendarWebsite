-- Work_GetAllProject 'P:287',99,'','','','',N'Nhóm công việc','vuongnq'        
   CREATE   PROC [dbo].[Work_GetAllProject]       
   @userId as nvarchar(500)        
   ,@Quytrinhduan as bigint= 99        
   ,@fromDate AS NVARCHAR(500) = ''        
   ,@toDate AS NVARCHAR(500) =''       
   ,@name as nvarchar(500)=''       
   ,@status as nvarchar(500)=''       
   ,@projectType as nvarchar(150)=''       
   ,@adminPage as nvarchar(150)='vuongnq'       
   as       
   declare @sql as nvarchar(max), @titleSearch nvarchar(500) ,@where as nvarchar(500)='', @whereIscomplete as nvarchar(500)='', @whereUser as nvarchar(500)=''        
   ,@whereProject as nvarchar(200) ='',@email as nvarchar(200) =''       
   set @email =(select Email from PersonalProfile where Id = (select [dbo].[fn_GetNumeric](@userId)))       
   if(@fromDate<>'')        
   begin        
   if(@toDate='')       
   begin       
   set @toDate=CONVERT(varchar, GETDATE(),23)       
   end       
   --set @where = ' and DATEDIFF(day, CONVERT(varchar,'''+@fromDate+''',23) , CONVERT(varchar,a.Ngaybatdau,23) )<=0 '        
   set @where = ' and (DATEDIFF(day, CONVERT(varchar,'''+@fromDate+''',23) , CONVERT(varchar,ISNULL(a.Ngaybatdau,getdate()),23) )>=0 and DATEDIFF(day, CONVERT(varchar,'''+@toDate+''',23) , CONVERT(varchar,ISNULL(a.Ngayketthuc,getdate()),23) )<=0)'           end        
   set @sql ='       
   select        
   a.[UserWorkflowId] as Id        
   ,a.[Ten] as Name        
   ,a.[MoTa] as Description        
   ,a.[ThanhPhanThamGia] as UserPartner        
   ,a.[NgayBatDau] as [Start]        
   ,a.[NgayKetThuc] as [End]        
   ,a.[TrangThai] as StatusProject        
   ,a.[TrangThaiDuAnTheoQuyTrinh] as StatusByWorkFlow        
   ,a.[Quanly] as Manager        
   ,a.UserWorkflowId       
   ,a.UserWorkflowId as ProjectId       
   ,( SELECT top 1 value FROM STRING_SPLIT(b.CreatedBy, ''@'')) as CreatedBy      
   ,a.ApplySLA    
   ,a.FormExtendInfo  
   from Dynamic.Data_RESOURCEDA a       
   inner join Dynamic.Workflow_RESOURCEDA b on a.UserWorkflowId=b.UserWorkflowId       
   where ('''+ @email+''' in ( select * from string_split(b.CreatedBy,'';'' )) or '''+@userId+''' in ( select * from string_split(a.QuanLy,'';'' ))       
   or '''+@adminPage+'''= (select AccountName from PersonalProfile       
   where Id= dbo.fn_GetNumeric('''+@userId+''')) ) -- and ISNULL(a.Loai,'''') like N''%'+trim(@projectType)+'%''       
   and ISNULL(a.IsDeleted,''False'')= ''False'' and isnull( a.[Ten],'''') LIKE N''%' + @name + '%'' and isnull(a.[TrangThai],'''') LIKE N''%' + @status + '%''       
   '+@where+' order by b.UserWorkflowId desc '       
   exec(@sql)       
   print(@sql)
go

