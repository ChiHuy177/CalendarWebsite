
-- =============================================
-- Author:		Duy Dam
-- Create date: 29/11/2022
-- Description:	Get MobileAppVersion Para in this system
-- =============================================
CREATE   PROCEDURE [dbo].[GetMobileAppVersionPara] @version nvarchar(max) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (
			SELECT *
			FROM WorkflowPara
			WHERE ParaName = 'MobileAppVersion'
				AND IsSystemPara = 1
			)
	BEGIN
		SET @version = (
				SELECT Value
				FROM WorkflowPara
				WHERE ParaName = 'MobileAppVersion'
					AND IsSystemPara = 1
				)
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[WorkflowPara]
           ([ParaName]
           ,[WorkflowId]
           ,[Value]
           ,[IsSystemPara])
		 VALUES
           ('MobileAppVersion'
           ,NULL
           ,'1.1.0'
           ,1);
		SET @version = '1.1.0';
	END
END
go

