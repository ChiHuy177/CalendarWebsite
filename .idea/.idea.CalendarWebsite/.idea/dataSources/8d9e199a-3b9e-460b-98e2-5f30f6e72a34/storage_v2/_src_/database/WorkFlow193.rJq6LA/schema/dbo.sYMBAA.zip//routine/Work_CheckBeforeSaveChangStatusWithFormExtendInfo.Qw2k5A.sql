CREATE   PROC Work_CheckBeforeSaveChangStatusWithFormExtendInfo
   @workId as nvarchar(50) =342905
   ,@column as nvarchar(500)='PhongBan'
   as
   declare @code as nvarchar(250)=N'', @sql as nvarchar(max)=N'',@fromExtendId as nvarchar(50)
   set @code=( select Code from Workflow where Id in (select FormExtendWorkflowId from Dynamic.Data_WORK where UserWorkflowId=@workId))
   set @code=( select [dbo].[Work_ReplaceInvalidChars](@code))
   set @fromExtendId=(select FormExtendInfo from Dynamic.Data_WORK where UserWorkflowId=@workId)
   set @sql=N'select LEN(ISNULL('+@column+','''')) as lenght from [Dynamic].[Data_'+@code+'] where UserWorkflowId='''+@fromExtendId+''''
   exec(@sql)
   print (@sql)
go

