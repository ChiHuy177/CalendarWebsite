CREATE PROCEDURE [dbo].[proc_EnumRecycleBinItemsForCleanup](
    @Days int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT TOP (1000)
        R.SiteId,
        R.WebId,
        CAST(R.DeleteTransactionId AS uniqueidentifier)
    FROM
        TVF_RecycleBin_ALL() AS R
    WHERE
        (R.BinId >= 1 AND R.BinId <= 2) AND
        R.DeleteDate + @Days <= GETUTCDATE() AND
        R.ChildDeleteTransactionId = 0x
    RETURN 0

go

