-- Work_GetNodeWorkFlowChart 'node-8ebab0e4-c6d8-42d9-96f8-72a1adb03979','341722',''           
   CREATE   PROC [dbo].[Work_GetNodeWorkFlowChart]           
   @nodeId as nvarchar(250),            
   @workProcessId as nvarchar(250) ,           
   @workId as nvarchar(250) =''           
   as            
   select           
   b.[Id]           
   ,b.[UserWorkflowId]           
   ,b.[Nguoixuly]           
   ,b.[Nguoiphoihop]           
   ,b.[Nguoitheodoi]  
   ,b.Nguoigiao
   ,b.[Mota]           
   ,b.[Tieude]           
   ,b.[Loaicv]           
   ,b.[Douutien]           
   ,b.[Thoigian]           
   ,b.[Nodeid]           
   ,b.[QuyTrinhDinhKem]           
   ,b.[IsUseForWork]           
   ,b.[Quytrinh]           
   ,b.[TudonghoanthanhCV]           
   ,b.ChoiceUserExecBefore           
   ,b.IsCompeleteWhenAllChildDone           
   ,c.Data,a.FlowChartData,b.Tieude as Name           
   ,a.WorkflowId           
   ,b.GetUserInWork           
   ,b.CategoryWorkProcessId          
   ,b.TimeUnit        
   ,b.ChoiceWorkflowRelationshipBefore      
   ,b.RequireAttachFileToCompleteWork    
   from [Dynamic].Data_TMDSQTCV a            
   inner join [Dynamic].Data_FOLLOWCHART b on a.UserWorkflowId=b.CategoryWorkProcessId            
   left join [Dynamic].Workflow_FOLLOWCHART c on b.UserWorkflowId=c.UserWorkflowId           
   where b.nodeid=@nodeId and b.CategoryWorkProcessId=@workProcessId -- and ISNULL(b.IsUseForWork,'') like '%'+@workId+'%' 
go

