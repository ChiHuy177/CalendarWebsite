-- [dbo].[Work_ReportChartByProject] 'yph@vntt.com.vn',25576     
   CREATE   PROC [dbo].[Work_ReportChartByProject]      
   @email AS NVARCHAR(50) ='vuongnq@vntt.com.vn'    
   ,@projectId AS bigint =25576    
   as        
   DECLARE @userId AS NVARCHAR(20)        
   SET @userId = (        
   SELECT 'P:' + TRIM(str(Id))        
   FROM PersonalProfile        
   WHERE Email = @email  and ISNULL(IsDeleted,0)=0      
   )        
   DECLARE @tab TABLE(Name  nvarchar(150), Quantity INT,UserID nVARCHAR(50), type int)    
   insert into @tab    
   select N'Xử lý' AS Name , 0 as Quantity, @userId as UserID , 1 as type    
   insert into @tab    
   select N'Theo dõi' AS Name , 0 as Quantity, @userId as UserID, 2 as type    
   insert into @tab    
   select N'Việc giao' AS Name , 0 as Quantity, @userId as UserID, 3 as type    
   insert into @tab    
   select N'Việc phối hợp' AS Name , 0 as Quantity, @userId as UserID, 4 as type    
   update @tab set Quantity= (    
   SELECT COUNT(*) AS Quantity        
   from  [Dynamic].Data_WORK a    
   CROSS APPLY STRING_SPLIT(a.Nguoixuly, ';')        
   WHERE value = @userId  and Duan=@projectId and ISNULL(a.IsActive,'True')='True'  
   GROUP BY value ) where type=1    
   update @tab set Quantity=(    
   SELECT COUNT(*) AS Quantity        
   from  [Dynamic].Data_WORK a    
   CROSS APPLY STRING_SPLIT(a.Nguoitheodoi, ';')        
   WHERE value = @userId    and Duan=@projectId  and ISNULL(a.IsActive,'True')='True'  
   GROUP BY value ) where type=2    
   update @tab set Quantity=(    
   SELECT COUNT(*) AS Quantity        
   from  [Dynamic].Data_WORK a    
   CROSS APPLY STRING_SPLIT(a.Nguoigiao, ';')        
   WHERE value = @userId    and Duan=@projectId  and ISNULL(a.IsActive,'True')='True'  
   GROUP BY value ) where type=3    
   update @tab set Quantity=(    
   SELECT COUNT(*) AS Quantity        
   from  [Dynamic].Data_WORK a    
   CROSS APPLY STRING_SPLIT(a.Nguoiphoihop, ';')        
   WHERE value = @userId    and Duan=@projectId  and ISNULL(a.IsActive,'True')='True'  
   GROUP BY value ) where type=4    
   select Name,ISNULL(Quantity,0) as Quantity,UserID from @tab    
go

