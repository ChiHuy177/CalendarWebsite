CREATE FUNCTION [dbo].[TVF_WebPartLists_SitePageLvlUser]
(
    @tp_SiteId uniqueidentifier,
    @tp_PageUrlID uniqueidentifier,
    @tp_Level tinyint,
    @tp_UserID int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[WebPartLists] WITH (INDEX=WebPartLists_PageUrlID, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_PageUrlID = @tp_PageUrlID AND
        tp_Level = @tp_Level AND
        ((@tp_UserID IS NULL AND tp_UserID IS NULL) OR @tp_UserID=tp_UserID)

go

