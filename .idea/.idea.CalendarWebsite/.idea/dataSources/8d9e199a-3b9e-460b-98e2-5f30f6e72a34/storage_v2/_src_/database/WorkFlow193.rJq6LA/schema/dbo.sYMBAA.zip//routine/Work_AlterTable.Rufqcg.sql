CREATE   PROC [dbo].[Work_AlterTable] 
   as
   alter table dynamic.data_work
   alter column Tieude nvarchar(1000)
   ;
   alter table dynamic.data_work
   alter column CongViecCha nvarchar(50)
   ;
   alter table dynamic.data_work
   alter column Duan nvarchar(50)
   ;
go

