-- =============================================
-- Author:		DuyDam
-- Create date: 16/11/2021
-- Description:	Remvoe all other un executed steps and set index of passed step into 0
-- =============================================
CREATE   PROCEDURE [dbo].[RejectUserWorkflowAndReturnToStep1] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; -- turn it on
	BEGIN TRAN
		DELETE [dbo].[UserWorkflowStep]
		WHERE UserWorkflowId = @UserWorkflowId
			AND FinishTime IS NULL
			AND (
				Action IS NULL
				OR Action = ''
				);

		UPDATE u
		SET u.[Index] = 0
		FROM [dbo].[UserWorkflowStep] u WITH(NOLOCK)		
		WHERE u.UserWorkflowId = @UserWorkflowId;
	COMMIT TRAN
END
go

