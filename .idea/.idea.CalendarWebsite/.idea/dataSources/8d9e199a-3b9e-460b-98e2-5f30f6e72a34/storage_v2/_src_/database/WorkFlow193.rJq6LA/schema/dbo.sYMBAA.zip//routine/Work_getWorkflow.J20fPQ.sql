CREATE   PROC [dbo].[Work_getWorkflow] 
   @workId as nvarchar(500) 
   as 
   select a.WorkflowCode +' - '+ a.ShortContent as Title 
   ,a.LastModified 
   ,c.UserWorkflowId as WorkId 
   ,c.Tieude as WorkName 
   ,c.PhieuQuyTrinhId 
   ,c.Quytrinh 
   from UserWorkflow a 
   inner join Dynamic.Data_WORK c on a.Id= c.PhieuQuyTrinhId 
   where c.UserWorkflowId in (select value from string_split( @workId,',')) 
go

