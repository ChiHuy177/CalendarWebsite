CREATE PROCEDURE [dbo].[proc_DeleteRecycleBinItemTVP](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @UserId int,
    @AppPrincipalId int,
    @ThresholdRowCount int,
    @IgnoreNotFound bit,
    @DeleteTransactionData tvpDeleteTransactionData READONLY,
    @FailedDeleteTransactionId varbinary(16) OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
    )
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    DECLARE @DeleteTransactionId varbinary(16)
    DECLARE @DeleteTransactionCur CURSOR
    SET @Ret = 1359
    SET @DeleteTransactionCur = CURSOR LOCAL READ_ONLY FAST_FORWARD FOR
    SELECT
        DeleteTransactionId
    FROM
        @DeleteTransactionData
    OPEN @DeleteTransactionCur
    WHILE (1=1)
    BEGIN
        FETCH NEXT FROM
            @DeleteTransactionCur
        INTO
            @DeleteTransactionId
        IF (@@FETCH_STATUS <> 0)
            BREAK
        EXEC @Ret = proc_DeleteRecycleBinItem @SiteId, @WebId, @UserId, @AppPrincipalId, @ThresholdRowCount, @DeleteTransactionId
        IF @IgnoreNotFound = 1
        BEGIN
            IF @Ret <> 0 AND @Ret <> 1168
            BEGIN
                SET @FailedDeleteTransactionId = @DeleteTransactionId
                GOTO cleanup
            END
        END
        ELSE
        BEGIN
            IF @Ret <> 0
            BEGIN
                SET @FailedDeleteTransactionId = @DeleteTransactionId
                GOTO cleanup
            END
        END
    END
    SET @Ret = 0
cleanup:
    CLOSE @DeleteTransactionCur
    DEALLOCATE @DeleteTransactionCur
    RETURN @Ret

go

