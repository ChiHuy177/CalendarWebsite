-- Work_GetAvatar 
   CREATE   PROC [dbo].[Work_GetAvatar] 
   @url as nvarchar(250)='https://library.vntts.vn', 
   @db as nvarchar(250)='LibraryBecawork290323' 
   as 
   declare @sql as nvarchar(max) 
   set @sql =' 
   select a.AccountName,a.email , a.FullName 
   , case when ISNULL(b.Path,'''')='''' then'''' else 
   TRIM('''+@url+''')+''/LibraryFiles/''+ISNULL(b.Path,'''') end as UrlAvatar 
   from PersonalProfile a 
   left join '+@db+'.[dbo].[File] b on b.ID=a.ImageId 
   where a.UserStatus=1 and ISNULL(b.Path,'''')<>'''' 
   ' 
   exec(@sql) 
   print(@sql)
go

