CREATE FUNCTION [dbo].[TVF_EventReceivers_NoLock_SiteWebHostHostTypeTypeItemId]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @HostId uniqueidentifier,
    @HostType int,
    @Type int,
    @ItemId int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[EventReceivers] WITH (NOLOCK, INDEX=EventReceivers_ByHost, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId AND
        HostId = @HostId AND
        HostType = @HostType AND
        Type = @Type AND
        ((@ItemId IS NULL AND ItemId IS NULL) OR @ItemId=ItemId)

go

