CREATE FUNCTION [dbo].[TVF_AllListsAux_NoLock_ListId]
(
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllListsAux] WITH (NOLOCK, INDEX=AllListsAux_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ListID = @ListId

go

