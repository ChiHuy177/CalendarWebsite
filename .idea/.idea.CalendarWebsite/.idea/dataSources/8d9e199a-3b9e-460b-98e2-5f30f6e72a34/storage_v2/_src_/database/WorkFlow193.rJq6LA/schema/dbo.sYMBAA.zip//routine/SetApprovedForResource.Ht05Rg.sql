CREATE 
 
    PROCEDURE [dbo].[SetApprovedForResource]
	-- Add the parameters for the stored procedure here
	@UserWorkflowId BIGINT
	,@WorkflowId BIGINT
	,@UserId BIGINT	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	BEGIN TRAN
		DECLARE @WorkflowCode AS NVARCHAR(MAX), @Email AS NVARCHAR(MAX), @WorkflowStepId as bigint;

		SET @Email = (
			SELECT Email
			FROM [dbo].[PersonalProfile]
			WHERE Id = @UserId
			);
		SET @WorkflowStepId = (SELECT top 1 Id from WorkflowStep WHERE WorkflowId = @WorkflowId and Step = 1 AND IsDeleted = 0);

		UPDATE UserWorkflow
		SET IsDraft = 0,
		Status = N'Phê duyệt',
		WorkflowStepId = @WorkflowStepId,
		UserWorkflowStatus = 1
		WHERE Id = @UserWorkflowId

		INSERT INTO [dbo].[UserWorkflowStep]
           ([UserWorkflowId]
           ,[UserId]
           ,[FromUserWorkflowId]
           ,[WorkflowStepId]
           ,[CreatedBy]
           ,[CreatedTime]
           ,[LastModified]
           ,[ModifiedBy]
           ,[IsDeleted]
           ,[IsActived]
           ,[Index]
           ,[StartTime]
           ,[FinishTime]
           ,[Action]
           ,[Note]
           ,[IsRecall]
           ,[IsAddInfo]
           ,[IsReplace]
           ,[DueDate]
           ,[IsDefault]
           ,[IsIdea]
           ,[IsReturned]
           ,[SkippedByUserWorkflowStepId]
           ,[IsAuthorizeApproval]
           ,[AuthorizeApprovalCode])
     VALUES
           (@UserWorkflowId
           ,@UserId
           ,NULL
           ,@WorkflowStepId
           ,@Email
           ,GETDATE()
           ,GETDATE()
           ,@Email
           ,0
           ,0
           ,1
           ,GETDATE()
           ,GETDATE()
           ,N'Gửi'
           ,''
           ,0
           ,0
           ,0
           ,NULL
           ,1
           ,0
           ,0
           ,NULL
           ,0
           ,NULL)

	SET @WorkflowCode = (
			SELECT WorkflowCode
			FROM UserWorkflow
			WHERE Id = @UserWorkflowId
			);

	IF @WorkflowCode IS NULL OR @WorkflowCode = N''
		EXEC [Dynamic].[CreateUserWorkflowCode] @UserWorkflowId

	COMMIT TRAN
END
go

