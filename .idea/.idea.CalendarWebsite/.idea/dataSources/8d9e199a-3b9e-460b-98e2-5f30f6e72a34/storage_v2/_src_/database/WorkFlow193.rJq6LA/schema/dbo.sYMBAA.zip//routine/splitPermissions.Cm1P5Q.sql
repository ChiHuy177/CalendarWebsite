
CREATE FUNCTION [dbo].[splitPermissions] (@InputString NVARCHAR(4000))
RETURNS @Items TABLE (Item NVARCHAR(4000))
AS
BEGIN
	DECLARE @Delimiter NVARCHAR(max) = N';';
	DECLARE @Item NVARCHAR(4000) = NULL;
	DECLARE @ItemList NVARCHAR(4000) = NULL;
	DECLARE @DelimIndex INT

	SET @ItemList = @InputString
	SET @DelimIndex = CHARINDEX(@Delimiter, @ItemList, 0)

	WHILE (@DelimIndex != 0)
	BEGIN
		SET @Item = SUBSTRING(@ItemList, 0, @DelimIndex)

		INSERT INTO @Items
		VALUES (@Item)

		-- Set @ItemList = @ItemList minus one less item
		SET @ItemList = SUBSTRING(@ItemList, @DelimIndex + 1, LEN(@ItemList) - @DelimIndex)
		SET @DelimIndex = CHARINDEX(@Delimiter, @ItemList, 0)
	END -- End WHILE

	IF @Item IS NOT NULL -- At least one delimiter was encountered in @InputString
	BEGIN
		SET @Item = @ItemList

		INSERT INTO @Items
		VALUES (LTRIM(RTRIM(@Item)))
	END
			-- No delimiters were encountered in @InputString, so just return @InputString
	ELSE
		INSERT INTO @Items
		VALUES (LTRIM(RTRIM(@InputString)))

	RETURN
END
go

