CREATE PROCEDURE [dbo].[proc_SecUpdateSiteLevelSecurityMetadata](
    @SiteId uniqueidentifier,
    @IncrementSecurityVersion int,
    @IncrementDGMapVersion int)
AS
    SET NOCOUNT ON
    UPDATE
        S
    SET
        S.SecurityVersion = SecurityVersion + @IncrementSecurityVersion,
        S.DomainGroupMapVersion = DomainGroupMapVersion + @IncrementDGMapVersion,
        S.LastSecurityChange = GETUTCDATE()
    FROM
        TVF_Sites_Id(@SiteId) AS S

go

