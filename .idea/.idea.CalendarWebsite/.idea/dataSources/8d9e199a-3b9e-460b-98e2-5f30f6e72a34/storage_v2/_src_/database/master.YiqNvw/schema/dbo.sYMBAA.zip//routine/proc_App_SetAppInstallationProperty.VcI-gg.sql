CREATE Procedure [dbo].[proc_App_SetAppInstallationProperty] (
    @InstallationId uniqueidentifier,
    @TaskType nvarchar(1000),
    @ValueKey nvarchar(2080),
    @Value nvarchar(2080),
    @IsolationKey uniqueidentifier,
    @SiteId uniqueidentifier
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
UPDATE TVF_AppInstallationProperty_InstallationIdIsolationKeyTaskType(@SiteId, @InstallationId, @IsolationKey, @TaskType)
    SET Value = @Value
    WHERE ValueKey = @ValueKey
IF(@@ROWCOUNT = 0) --then we're inserting rather than updating
BEGIN
    INSERT INTO AppInstallationProperty
        (InstallationId, ValueKey, TaskType, Value, SiteId, IsolationKey)
    VALUES
        (@InstallationId, @ValueKey, @TaskType, @Value, @SiteId, @IsolationKey)
END
COMMIT TRANSACTION

go

