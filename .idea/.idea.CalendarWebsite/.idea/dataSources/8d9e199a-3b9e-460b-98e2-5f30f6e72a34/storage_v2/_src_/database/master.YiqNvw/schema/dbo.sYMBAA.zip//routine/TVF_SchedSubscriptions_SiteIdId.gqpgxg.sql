CREATE FUNCTION [dbo].[TVF_SchedSubscriptions_SiteIdId]
(
    @SiteId uniqueidentifier,
    @Id uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SchedSubscriptions] WITH (INDEX=SchedSubscriptions_SiteIdId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        Id = @Id

go

