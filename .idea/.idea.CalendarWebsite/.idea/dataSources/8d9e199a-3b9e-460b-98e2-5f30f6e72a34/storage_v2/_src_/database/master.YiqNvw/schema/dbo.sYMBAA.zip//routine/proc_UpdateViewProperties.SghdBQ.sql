CREATE PROCEDURE [dbo].[proc_UpdateViewProperties](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @UserId int,
    @ViewId uniqueidentifier,
    @DisplayName nvarchar(255),
    @ContentTypeId tContentTypeId,
    @Type tinyint,
    @Flags int,
    @BaseViewID tinyint)
AS
    SET NOCOUNT ON
    DECLARE @Ret int, @ERR int, @ROWC int
    DECLARE @OldContentTypeId tContentTypeId
    SET @Ret = 0
    IF (@ContentTypeId IS NULL)
    BEGIN
        SELECT TOP 1
            @OldContentTypeId = WP.tp_ContentTypeId
        FROM 
            TVF_WebParts_SitePartId(@SiteId, @ViewId) AS WP
        CROSS APPLY
            TVF_Docs_Id_Level(WP.tp_SiteId, WP.tp_PageUrlID, WP.tp_Level) AS D
        WHERE
            WP.tp_ListId = @ListId AND
            (WP.tp_UserID IS NULL OR WP.tp_UserID = @UserId) AND
            (D.Level = 255 AND 
                D.LTCheckoutUserId = @UserId OR
            ((D.Level = 1 AND 
            D.DraftOwnerId IS NULL OR 
            D.Level = 2)  AND
            (D.LTCheckoutUserId IS NULL OR 
                D.LTCheckoutUserId <> @UserId)))
    END
    UPDATE
        WP
    SET
        WP.tp_DisplayName = CASE WHEN @DisplayName IS NULL THEN
            WP.tp_DisplayName ELSE @DisplayName END,
        WP.tp_ContentTypeId = ISNULL(@ContentTypeId, WP.tp_ContentTypeId),
        WP.tp_Type = CASE WHEN @Type IS NULL THEN
            WP.tp_Type ELSE @Type END,
        WP.tp_BaseViewID = CASE WHEN @BaseViewID IS NULL THEN
            WP.tp_BaseViewID ELSE @BaseViewID END,
        WP.tp_Flags = CASE WHEN @Flags IS NULL THEN
            WP.tp_Flags ELSE @Flags END
    FROM
        TVF_WebParts_SitePartId(@SiteId, @ViewId) AS WP
    CROSS APPLY
        TVF_Docs_Id_Level(WP.tp_SiteId, WP.tp_PageUrlID, WP.tp_Level) AS D
    WHERE
        WP.tp_ListId = @ListId AND
        (WP.tp_UserID IS NULL OR WP.tp_UserID = @UserId) AND
        (D.Level = 255 AND 
            D.LTCheckoutUserId = @UserId OR
        ((D.Level = 1 AND 
          D.DraftOwnerId IS NULL OR 
          D.Level = 2)  AND
        (D.LTCheckoutUserId IS NULL OR 
            D.LTCheckoutUserId <> @UserId)))
    SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT   
    IF (0 <> @ERR OR @ROWC <> 1)
    BEGIN
        SET @Ret = 3
        GOTO cleanup
    END
    IF ((@Flags & 16777216) <> 0)
    BEGIN
        EXEC @Ret = proc_MakeViewMobileDefaultForList @SiteId, @ListId, @ViewId
        IF @Ret <> 0
        BEGIN
            GOTO cleanup
        END
    END
    ELSE
    BEGIN
        EXEC @Ret = proc_EnsureMobileDefaultViewForList @SiteId, @ListId
        IF @Ret <> 0
        BEGIN
            GOTO cleanup
        END
    END
    IF ((@Flags & 268435456) <> 0)
    BEGIN
        SET @ContentTypeId = ISNULL(@ContentTypeId, @OldContentTypeId)
        EXEC @Ret = proc_MakeViewDefaultForContentType 
            @SiteId,
            @ListId, 
            @ViewId, 
            @ContentTypeId
        IF (0 <> @Ret)
            GOTO cleanup
    END
cleanup:
    IF (0 <> @@ERROR OR 0 <> @Ret)
    BEGIN
        RETURN CASE WHEN (0 = @Ret) THEN 1 ELSE @Ret END
    END
    RETURN 0

go

