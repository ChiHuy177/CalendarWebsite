
create FUNCTION [dbo].[fun_Split](@String nvarchar(max), @Delimiter char(1))  
RETURNS @Results TABLE (Items nvarchar(100) )  
AS  
  
    BEGIN  
    DECLARE @INDEX INT  
    DECLARE @SLICE nvarchar(max)  
      
    SELECT @INDEX = 1      
    IF @String IS NULL RETURN  
    WHILE @INDEX !=0  
  
        BEGIN   
         SELECT @INDEX = CHARINDEX(@Delimiter,@STRING)           
         IF @INDEX !=0  
          SELECT @SLICE = LEFT(@STRING,@INDEX - 1)  
         ELSE  
          SELECT @SLICE = @STRING  
         INSERT INTO @Results(Items) VALUES(@SLICE)  
         SELECT @STRING = RIGHT(@STRING,LEN(@STRING) - @INDEX)  
         IF LEN(@STRING) = 0 BREAK  
    END  
    RETURN  
END  




go

