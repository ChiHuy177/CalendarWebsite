CREATE PROCEDURE [dbo].[proc_IsFieldTemplateUsedInContentTypeTemplate](
    @SiteId uniqueidentifier,
    @FieldId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON    
    IF EXISTS (
        SELECT TOP 1
            1
        FROM
            TVF_ContentTypeUsage_SiteIsFListClass(
                @SiteId,
                1, 
                @FieldId,
                0))
    BEGIN
        RETURN 1
    END
    RETURN 0

go

