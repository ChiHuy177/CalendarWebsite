CREATE PROCEDURE [dbo].[proc_RenameUrl](
    @SiteId                uniqueidentifier,
    @SubWebId              uniqueidentifier,
    @OldUrl                nvarchar(260),
    @NewUrl                nvarchar(260),
    @UserId                int,
    @AppPrincipalId        int,
    @ThresholdRowCount     int,
    @NewDoclibRowIdInput int,
    @MaxNewRowsInput int,
    @RenameFlags           int = 0,
    @PutFlags              int = 0,
    @ReturnFlags           int = 0,
    @AttachmentOpOldUrl    int = 3,
    @AttachmentOpNewUrl    int = 3,
    @OldItemId             int = NULL OUTPUT,
    @ParseDocsNow          tinyint = NULL OUTPUT,
    @FailedUrl             nvarchar(260) = NULL OUTPUT,
    @RequestGuid           uniqueidentifier = NULL OUTPUT)  
AS
    SET NOCOUNT ON
    DECLARE @WebUrl nvarchar(256)
    DECLARE @SrcUrlType tinyint
    DECLARE @DstUrlType tinyint
    DECLARE @DstUrlParentType tinyint
    DECLARE @DstUrlParentWebId uniqueidentifier
    DECLARE @SrcUrlDocId uniqueidentifier
    DECLARE @SrcUrlParentDocId uniqueidentifier
    DECLARE @DstUrlParentDocId uniqueidentifier
    DECLARE @ParentWebId uniqueidentifier
    DECLARE @DstWebId uniqueidentifier    
    DECLARE @ReturnStatus int
    DECLARE @UrlsAreEquivalent bit
    DECLARE @RenamingWeb bit
    DECLARE @MakingThicket bit
    DECLARE @ThicketFlag bit
    DECLARE @OldDirName nvarchar(256)
    DECLARE @OldLeafName nvarchar(128)
    DECLARE @SrcDoclibRowId int
    DECLARE @NewDirName nvarchar(256)
    DECLARE @NewLeafName nvarchar(128)
    DECLARE @NewDirDirName nvarchar(256)
    DECLARE @NewDirLeafName nvarchar(128)
    DECLARE @FailedDirName nvarchar(256)
    DECLARE @FailedLeafName nvarchar(128)
    DECLARE @ScopeId uniqueidentifier
    DECLARE @FirstUniqueAncestorWebId uniqueidentifier 
    DECLARE @NewListSchemaVersion int
    DECLARE @NeedXLock bit
    SELECT @RenamingWeb = @RenameFlags & 32
    SELECT @MakingThicket =
        CASE
            WHEN ((@PutFlags & 128) =
                128)
        THEN
            1
        ELSE
            0
        END
    SET @ParseDocsNow = 0
    SELECT TOP 1
        @WebUrl = FullUrl,
        @ScopeId = ScopeId,
        @ParentWebId = ParentWebId,
        @FirstUniqueAncestorWebId = FirstUniqueAncestorWebId
    FROM
        TVF_Webs_Id(@SiteId, @SubWebId) AS Webs
    IF @@ROWCOUNT = 0
    BEGIN
        RETURN 3
    END
    EXEC proc_SplitUrl @OldUrl, @OldDirName OUTPUT, @OldLeafName OUTPUT
    EXEC proc_SplitUrl @NewUrl, @NewDirName OUTPUT, @NewLeafName OUTPUT
    IF (@RenamingWeb = 1 AND
        @OldDirName <> @NewDirName)
    BEGIN
        SET @RenameFlags = @RenameFlags | 256
    END
    EXEC proc_SplitUrl @NewDirName,
        @NewDirDirName OUTPUT,
        @NewDirLeafName OUTPUT
    SELECT TOP 1
        @SrcUrlType = Type,
        @ThicketFlag = ThicketFlag,
        @SrcDoclibRowId = DoclibRowId,
        @SrcUrlDocId = Id,
        @SrcUrlParentDocId = ParentId
    FROM
        TVF_Docs_Url(@SiteId, @OldDirName, @OldLeafName) AS Docs
    WHERE
        (Type = 0 OR Type = 1 OR
        (Type = 2 AND @RenamingWeb = 1)) AND
        WebId = @SubWebId
    IF @@ROWCOUNT = 0
    BEGIN
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_Docs_Url(@SiteId, @OldDirName, @OldLeafName) AS Docs
            WHERE 
                WebId = @SubWebId)
        BEGIN
            RETURN 50
        END
        ELSE
        BEGIN
            RETURN 3
        END
    END
    IF @ThicketFlag IS NULL OR (@ThicketFlag = 1 AND NOT
            (@SrcUrlType = 0 AND
            (@RenameFlags & 2048) =
                2048))
    BEGIN
        RETURN 214
    END
    IF @MakingThicket = 1
    BEGIN
        RETURN 190
    END
    SET @UrlsAreEquivalent = CASE WHEN (@OldUrl = @NewUrl) THEN 1 ELSE 0 END
    BEGIN TRAN
    DECLARE @guidT uniqueidentifier
    DECLARE @guidTOld uniqueidentifier
    DECLARE @count int
    EXEC proc_GetContainingListOutput
            @SiteId,
            @SubWebId,
            @NewUrl,
            @guidT OUTPUT
    EXEC proc_GetContainingListOutput
            @SiteId,
            @SubWebId,
            @OldUrl,
            @guidTOld OUTPUT
    IF @SrcUrlType = 0
    BEGIN
        SET @NeedXLock = 0        
    END
    ELSE
    BEGIN
        SET @NeedXLock = 1 
    END
    IF @guidT IS NOT NULL
    BEGIN
        EXEC proc_LockListAuxForDocumentUpdate @SiteId, @guidT, @NeedXLock        
    END 
    IF @guidTOld IS NOT NULL
    BEGIN
        EXEC proc_LockListAuxForDocumentUpdate @SiteId,@guidTOld, @NeedXLock
    END    
    SELECT TOP 1
        @DstUrlParentType = Type,
        @DstUrlParentWebId = WebId,
        @DstUrlParentDocId = Id,
        @NewDirDirName = DirName,
        @NewDirLeafName = LeafName
    FROM
        TVF_Docs_RepeatableRead_Url(@SiteId, @NewDirDirName, @NewDirLeafName) AS Docs
    IF @DstUrlParentType IS NULL OR
       (@DstUrlParentWebId <> @SubWebId AND @RenamingWeb = 0) OR
       (@NewDirDirName = @OldDirName AND
        @NewDirLeafName = @OldLeafName)
    BEGIN
        SET @ReturnStatus = 2
        GOTO CLEANUP
    END
    SET @NewDirName = CASE WHEN (DATALENGTH(@NewDirDirName) = 0) THEN @NewDirLeafName WHEN (DATALENGTH(@NewDirLeafName) = 0) THEN @NewDirDirName ELSE @NewDirDirName + N'/' + @NewDirLeafName END
    SET @NewUrl = CASE WHEN (DATALENGTH(@NewDirName) = 0) THEN @NewLeafName WHEN (DATALENGTH(@NewLeafName) = 0) THEN @NewDirName ELSE @NewDirName + N'/' + @NewLeafName END
    DECLARE @OldUrlLike nvarchar(1024)
    EXEC proc_EscapeForLike @OldUrl, @OldUrlLike OUTPUT
    IF @NewUrl LIKE @OldUrlLike COLLATE Latin1_General_CI_AS_KS_WS
    BEGIN
        SET @ReturnStatus = 2
        GOTO CLEANUP
    END
    SELECT TOP 1
        @DstUrlType = Type,
        @DstWebId = WebId
    FROM
        TVF_Docs_Url(@SiteId, @NewDirName, @NewLeafName) AS Docs
    IF @guidT IS NOT NULL
    BEGIN
        SELECT TOP 1
            @NewListSchemaVersion = L.tp_ListSchemaVersion
        FROM
            TVF_Lists_CI(@SiteId, @DstWebId, @guidT) AS L
    END
    IF @DstUrlType IS NOT NULL
    BEGIN
        IF (@UrlsAreEquivalent = 0)
        BEGIN
            IF (@PutFlags & 2 = 2 AND
                @SrcUrlType = 0 AND
                @DstUrlType = 0)
            BEGIN
                EXEC @ReturnStatus = proc_DeleteUrlCore
                    @SiteId,
                    @DstWebId,
                    @NewUrl,
                    @UserId,
                    @AppPrincipalId,
                    1, 
                    NULL, 
                    0,
                    0,
                    0,
                    3,
                    0,
                    0,
                    3,
                    0x,
                    0,
                    0,
                    @FailedUrl OUTPUT
                IF (@ReturnStatus <> 0) AND
                    (@ReturnStatus <> 3)
                BEGIN
                    EXEC proc_SplitUrl @FailedUrl,
                        @FailedDirName OUTPUT,
                        @FailedLeafName OUTPUT
                    GOTO CLEANUP
                END
            END
            ELSE
            BEGIN
                IF (@SrcUrlType = 0 AND
                    @DstUrlType = 0)
                BEGIN
                    SET @ReturnStatus = 80
                    GOTO CLEANUP
                END
                ELSE
                BEGIN
                    SET @ReturnStatus = 144
                    GOTO CLEANUP
                END
            END
        END
    END
    IF (@OldDirName <> @NewDirName)
    BEGIN
        EXEC proc_UpdateChildCount @SiteId, @OldDirName, @OldLeafName,
                                   @SrcDoclibRowId, 0, @SrcUrlType, -1
        EXEC proc_UpdateChildCount @SiteId, @NewDirName, @NewLeafName,
                                   @SrcDoclibRowId, 0, @SrcUrlType, 1
    END
    IF @SrcUrlType = 0
        BEGIN
            EXEC @ReturnStatus = proc_RenameFile @SiteId,
                @SubWebId,
                @WebUrl,
                @OldUrl,
                @NewUrl,
                @NewListSchemaVersion,
                @DstUrlParentDocId,
                @UserId,
                @AppPrincipalId,
                @NewDoclibRowIdInput,
                @RenameFlags,
                @PutFlags,
                @ReturnFlags,
                @AttachmentOpOldUrl,
                @AttachmentOpNewUrl,
                @OldItemId OUTPUT,
                @ParseDocsNow OUTPUT,
                @FailedDirName OUTPUT,
                @FailedLeafName OUTPUT
        END
    ELSE 
        BEGIN
            EXEC @ReturnStatus = proc_RenameDir @SiteId,
                @SubWebId,
                @ParentWebId,
                @ScopeId,
                @FirstUniqueAncestorWebId,
                @DstUrlParentWebId,
                @WebUrl,
                @OldUrl,
                @NewUrl,
                @NewListSchemaVersion,
                @DstUrlParentDocId,
                @UserId,
                @ThresholdRowCount,
                @NewDoclibRowIdInput,
                @MaxNewRowsInput,
                @RenameFlags,
                @PutFlags,
                @ReturnFlags,
                @ParseDocsNow OUTPUT,
                @FailedDirName OUTPUT,
                @FailedLeafName OUTPUT
        END
    IF (@ReturnStatus = 0 AND @OldDirName <> @NewDirName)
    BEGIN
        DECLARE @LastModified datetime
        SET @LastModified = GETUTCDATE()
        DECLARE @TotalSize bigint
        SELECT
            @TotalSize = SM.TotalSize
        FROM
            TVF_StorageMetrics_DocId(@SiteId, @SrcUrlDocId) AS SM
        EXEC proc_AddStorageMetricsChange @SiteId, @DstUrlParentDocId, @TotalSize, 1
        SET @TotalSize = -@TotalSize
        EXEC proc_AddStorageMetricsChange @SiteId, @SrcUrlParentDocId, @TotalSize, 1
    END
CLEANUP:
    IF (@ReturnStatus <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    IF @FailedDirName IS NOT NULL AND @FailedLeafName IS NOT NULL
    BEGIN
        SET @FailedUrl = CASE WHEN (DATALENGTH(@FailedDirName) = 0) THEN @FailedLeafName WHEN (DATALENGTH(@FailedLeafName) = 0) THEN @FailedDirName ELSE @FailedDirName + N'/' + @FailedLeafName END
    END
    RETURN @ReturnStatus

go

