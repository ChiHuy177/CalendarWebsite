CREATE Procedure [dbo].[proc_App_MarkTaskForRetry] (
    @TaskId uniqueidentifier,
    @SiteId uniqueidentifier    
)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
DECLARE @iRet int
SET @iRet = 0
--shouldn't need an applock for this, always know what we're getting/setting when using this data
DECLARE @InstallationId uniqueidentifier
DECLARE @JobId uniqueidentifier
SELECT @InstallationId = Job.InstallationId, @JobId = Task.JobId
    FROM TVF_AppTasks_TaskId(@SiteId, @TaskId) AS Task
    CROSS APPLY TVF_AppJobs_Id(@SiteId, Task.JobId) AS Job
-- Previous errors must be cleared before retrying tasks.
EXEC proc_App_ClearAppInstanceErrorsById @InstallationId,@SiteId
UPDATE TVF_AppTasks_TaskId(@SiteId, @TaskId)
    SET Retries = Retries - 1
EXEC @iRet = sub_CheckForUnderMaxRetries @JobId, @InstallationId, @SiteId
if(@iRet <> 0) GOTO cleanup
cleanup:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    return @iRet

go

