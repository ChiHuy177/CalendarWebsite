CREATE Procedure [dbo].[proc_App_SetUpdateAvailableOnAppsList] (
    @SPApps tvpArrayOfSPApps READONLY)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
-- If the version number for a particular assetId in the TVP is less than the
-- version number of the assetId in the database then set the UpdateAvailable bit.
-- As each component of the version number is stored separately we need to compare each 
-- version component separately and doing so using TVF would not be practical. 
-- If we had ONLY a single TVF then following checks would fail. Example: 1.3.2.4 is greater than 1.2.3.4
UPDATE AppSourceInfo
    SET UpdateAvailable = CASE
        WHEN Apps.VersionMajor > Packages.VersionMajor OR
            (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor > Packages.VersionMinor) OR
            (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor = Packages.VersionMinor AND Apps.VersionBuild > Packages.VersionBuild) OR
            (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor = Packages.VersionMinor AND Apps.VersionBuild = Packages.VersionBuild AND Apps.VersionRevision > Packages.VersionRevision)
            THEN 1
        ELSE 0
        END
    FROM @SPApps as Apps
    CROSS APPLY TVF_AppSourceInfo_AssetIdAllSites_AppSource(Apps.AssetId, 1) as AppSourceInfo
    CROSS APPLY TVF_AppPackages_PackageFingerprint(AppSourceInfo.SiteId, AppSourceInfo.PackageFingerprint) as Packages
COMMIT TRANSACTION

go

