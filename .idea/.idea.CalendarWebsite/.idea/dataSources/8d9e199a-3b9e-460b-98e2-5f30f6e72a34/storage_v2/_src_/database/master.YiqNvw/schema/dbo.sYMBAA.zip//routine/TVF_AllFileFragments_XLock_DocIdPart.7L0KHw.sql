CREATE FUNCTION [dbo].[TVF_AllFileFragments_XLock_DocIdPart]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @Partition tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllFileFragments] WITH (XLOCK, INDEX=AllFileFragments_PartId_UCI, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DocId = @DocId AND
        Partition = @Partition

go

