CREATE PROCEDURE [dbo].[proc_RestoreRecycleBinItem](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @UserId int,
    @AppPrincipalId int,
    @ThresholdRowCount int,
    @TranLockStatus tinyint,
    @DeleteTransactionId varbinary(16),
    @FailedDirName nvarchar(256) = NULL OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DeleteUserId int
    DECLARE @ItemType tinyint
    DECLARE @OriginalItemType tinyint
    DECLARE @DeleteItemType tinyint
    DECLARE @DocId uniqueidentifier
    DECLARE @DocVersionId int
    DECLARE @ListId uniqueidentifier
    DECLARE @ListItemId int
    DECLARE @DirName nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    DECLARE @Title nvarchar(260)
    DECLARE @ListDirName nvarchar(256)
    DECLARE @ScopeId uniqueidentifier
    DECLARE @ContainingListBaseType int
    DECLARE @ContainingListFlags bigint
    DECLARE @ContainingListId uniqueidentifier
    DECLARE @ChildDeleteTransactionId varbinary(16)
    DECLARE @SizeOccupied bigint
    DECLARE @Ret int
    SET @Ret = 0;
    SET @SizeOccupied = 0
    IF (@UserId = 0)
    BEGIN
        SELECT TOP 1
            @WebId = R.WebId,
            @DeleteUserId = R.DeleteUserId,
            @ItemType = R.ItemType,
            @OriginalItemType = R.OriginalItemType,
            @DocId = R.DocId,
            @DocVersionId = R.DocVersionId,
            @ListId = R.ListId,
            @ListItemId = R.ListItemId,
            @DirName = R.DirName,
            @LeafName = R.LeafName,
            @Title = R.Title,
            @ListDirName = R.ListDirName,
            @SizeOccupied = 
                CASE 
                WHEN R.BinId = 2 THEN 
                       (SELECT SUM(R2.Size)
                        FROM TVF_RecycleBin_DelId(R.SiteId, R.DeleteTransactionId) AS R2)
                ELSE 0 
                END,
            @ScopeId = R.ScopeId    
        FROM
            TVF_RecycleBin_DelIdChildId(@SiteId, @DeleteTransactionId, 0x) AS R
        IF (@@ROWCOUNT <> 1)
        BEGIN
            SET @Ret = 1168
            GOTO cleanup
        END
        IF (NOT EXISTS(SELECT TOP 1 1 FROM AllWebs WHERE Id = @WebId AND SiteId = @SiteId AND 
            (DeleteTransactionId = 0x OR DeleteTransactionId = @DeleteTransactionId)))
        BEGIN
            SET @Ret = 1168
            GOTO cleanup
        END
    END
    ELSE
    BEGIN
        SELECT TOP 1
            @ItemType = R.ItemType,
            @OriginalItemType = R.OriginalItemType,
            @DocId = R.DocId,
            @DocVersionId = R.DocVersionId,
            @ListId = R.ListId,
            @ListItemId = R.ListItemId,
            @DirName = R.DirName,
            @LeafName = R.LeafName,
            @Title = R.Title,
            @ListDirName = R.ListDirName,
            @SizeOccupied = 
                CASE 
                WHEN R.BinId = 2 THEN 
                       (SELECT SUM(R2.Size)
                        FROM TVF_RecycleBin_DelId(R.SiteId, R.DeleteTransactionId) AS R2)
                ELSE 0 
                END,
            @ScopeId = R.ScopeId
        FROM
            TVF_RecycleBin_DelIdChildId(@SiteId, @DeleteTransactionId, 0x) AS R
        WHERE
            R.WebId = @WebId AND
            R.DeleteUserId = @UserId            
        IF (@@ROWCOUNT <> 1)
        BEGIN
            SET @Ret = 1168
            GOTO cleanup
        END
        SET @DeleteUserId = @UserId
    END
    DECLARE @quotaOrLockStatus int SELECT @quotaOrLockStatus = dbo.fn_IsOverQuotaOrWriteLocked(@SiteId) IF (@quotaOrLockStatus = 1) BEGIN SET @Ret = 1816 END ELSE IF (@quotaOrLockStatus > 1) BEGIN SET @Ret = 212 END
    IF @Ret <> 0
        GOTO cleanup
    IF (@ItemType = 10)
    BEGIN
        EXEC @Ret = proc_RestoreWeb
            @SiteId,
            @WebId,
            @ThresholdRowCount
    END
    ELSE IF (@ItemType = 9)
    BEGIN
        DECLARE @ItemsToRestore TABLE
        (
            ItemType tinyint,
            OriginalItemType tinyint, 
            ListId uniqueidentifier,
            ListItemId int,
            DocId uniqueidentifier,
            DocVersionId int,
            DirName nvarchar(256),
            LeafName nvarchar(128),
            Title nvarchar(260),
            ListDirName nvarchar(256),
            ScopeId uniqueidentifier,
            ChildDeleteTransactionId varbinary(16)
        );
        INSERT INTO @ItemsToRestore
        SELECT 
            R.ItemType, R.OriginalItemType, R.ListId, R.ListItemId, R.DocId, R.DocVersionId, 
            R.DirName, R.LeafName, R.Title, R.ListDirName, R.ScopeId, R.ChildDeleteTransactionId
        FROM
            TVF_RecycleBin_DelId(@SiteId, @DeleteTransactionId) AS R
        WHERE
            R.WebId = @WebId
        DECLARE @RestoreTask CURSOR
        SET @RestoreTask = CURSOR LOCAL FAST_FORWARD FOR
        SELECT 
            ItemType, OriginalItemType, ListId, ListItemId, DocId, DocVersionId, 
            DirName, LeafName, Title, ListDirName, ScopeId, ChildDeleteTransactionId
        FROM 
            @ItemsToRestore
        ORDER BY DirName ASC
        OPEN @RestoreTask
        IF @@CURSOR_ROWS <> 0
        BEGIN
            FETCH NEXT FROM @RestoreTask INTO 
                @ItemType, @OriginalItemType, @ListId, @ListItemId, @DocId, @DocVersionId, 
                @DirName, @LeafName, @Title, @ListDirName, @ScopeId, @ChildDeleteTransactionId;
            WHILE @@FETCH_STATUS = 0
            BEGIN
                SET @DeleteItemType = CASE WHEN (@ItemType = 9) THEN @OriginalItemType ELSE @ItemType END;
                EXEC proc_LockListAuxForDocumentUpdate @SiteId, @ListId, 1
                EXEC @Ret = proc_RestoreOneRecycleBinItem
                    @SiteId,
                    @WebId,
                    @UserId, 
                    @AppPrincipalId,
                    @DeleteUserId,
                    @DeleteItemType, 
                    @ListId,
                    @ListItemId,
                    @DocId,
                    @DocVersionId,
                    @DirName,
                    @LeafName,
                    @Title,
                    @ListDirName, 
                    @ScopeId,
                    @ThresholdRowCount,
                    @DeleteTransactionId,
                    @ChildDeleteTransactionId,
                    @FailedDirName OUTPUT,
                    @RequestGuid OUTPUT;
                IF (@Ret <> 0)
                    BREAK;
                FETCH NEXT FROM @RestoreTask INTO 
                    @ItemType, @OriginalItemType, @ListId, @ListItemId, @DocId, @DocVersionId, 
                    @DirName, @LeafName, @Title, @ListDirName, @ScopeId, @ChildDeleteTransactionId;
            END
        END
        CLOSE @RestoreTask
        DEALLOCATE @RestoreTask
    END
    ELSE 
    BEGIN
        EXEC proc_LockListAuxForDocumentUpdate @SiteId, @ListId, 1
        EXEC @Ret = proc_RestoreOneRecycleBinItem
            @SiteId,
            @WebId,
            @UserId, 
            @AppPrincipalId,
            @DeleteUserId,
            @ItemType,
            @ListId,
            @ListItemId,
            @DocId,
            @DocVersionId,
            @DirName,
            @LeafName,
            @Title,
            @ListDirName,
            @ScopeId,
            @ThresholdRowCount,
            @DeleteTransactionId,
            0x,
            @FailedDirName OUTPUT,
            @RequestGuid OUTPUT;
        IF (@ItemType = 1 OR
             @ItemType = 3 OR
             @ItemType = 5)
        BEGIN
            IF (@Ret = 0 AND @TranLockStatus = 1)
                EXEC @Ret = proc_EnsureTranLockNotRequired
                    @SiteId,
                    @ListId;
        END
    END
cleanup:
    IF (@Ret = 0)
    BEGIN
        EXEC proc_SecUpdateListInternalFGP @SiteId, @WebId, @ListId, 0    
        IF NOT (@ItemType = 2 OR 
                @ItemType = 8 OR 
                @ItemType = 10)
        BEGIN
            DECLARE @ParentDocId uniqueidentifier
            DECLARE @DeltaSize bigint
            SELECT
                @ParentDocId = AD.ParentId,
                @DeltaSize = SM.TotalSize
            FROM
                TVF_StorageMetrics_DocId(@SiteId, @DocId) AS SM
            CROSS APPLY
                TVF_AllDocs_Id(@SiteId, @DocId) AS AD
            EXEC proc_AddStorageMetricsChange @SiteId, @ParentDocId, @DeltaSize, 1
        END
        EXEC proc_ProcessSiteQuotaForStorageMetricsChanges @SiteId
        IF (@SizeOccupied > 0)
        BEGIN
            EXEC proc_QMChangeSiteDiskUsedAndContentTimestamp @SiteId, @SizeOccupied, 1, NULL
            UPDATE
                S
            SET
                S.SecondStageDiskUsed = S.SecondStageDiskUsed - @SizeOccupied
            FROM
                TVF_Sites_Id(@SiteId) AS S
        END
        ELSE
        BEGIN
            EXEC proc_QMChangeSiteDiskUsedAndContentTimestamp @SiteId, 0, 1, NULL
        END
    END
    ELSE
    BEGIN
        SELECT 
            CASE WHEN 
                (@ItemType = 9) 
            THEN 
                @OriginalItemType 
            ELSE 
                @ItemType 
            END,
            CASE WHEN
                (@ItemType = 10) 
            THEN 
                @WebId 
            ELSE 
                @ListId 
            END,
            @ListItemId, 
            @DirName, 
            @LeafName, 
            @Title;
    END
    RETURN @Ret

go

