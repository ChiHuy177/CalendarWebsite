CREATE PROCEDURE [dbo].[proc_IsDeletedSiteLocked](
    @SiteId uniqueidentifier)
AS
    SET NOCOUNT ON    
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
            SiteDeletion
        WHERE
            SiteId = @SiteId AND
            (LockTime IS NOT NULL AND DATEADD(hour, 24, LockTime) >= GETUTCDATE()))
    BEGIN
        RETURN 1
    END
    RETURN 0

go

