CREATE FUNCTION [dbo].[TVF_AllWebParts_SiteIsCurPageId]
(
    @tp_SiteId uniqueidentifier,
    @tp_IsCurrentVersion bit,
    @tp_PageUrlID uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllWebParts] WITH (INDEX=PageUrlID_FK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_IsCurrentVersion = @tp_IsCurrentVersion AND
        tp_PageUrlID = @tp_PageUrlID

go

