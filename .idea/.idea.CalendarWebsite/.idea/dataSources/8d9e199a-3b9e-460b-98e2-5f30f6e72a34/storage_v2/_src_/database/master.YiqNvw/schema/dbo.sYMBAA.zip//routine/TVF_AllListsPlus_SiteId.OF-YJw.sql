CREATE FUNCTION [dbo].[TVF_AllListsPlus_SiteId]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllListsPlus] WITH (INDEX=AllListsPlus_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

