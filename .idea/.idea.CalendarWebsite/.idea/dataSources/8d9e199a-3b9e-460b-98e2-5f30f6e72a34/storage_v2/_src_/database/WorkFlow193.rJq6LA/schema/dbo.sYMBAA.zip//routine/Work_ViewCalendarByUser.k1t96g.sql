-- [Work_ViewCalendarByUser] 'P:285'                                    
   CREATE   PROC [dbo].[Work_ViewCalendarByUser]                         
   @employee AS NVARCHAR(50)                                
   AS                        
   CREATE TABLE #duan (UserWorkflowId char(50)  NOT NULL PRIMARY KEY, Ten nvarchar(500), Loai nvarchar(500))              
   DECLARE @tab TABLE(Name  nvarchar(150), Quantity INT,UserID nVARCHAR(50), type int)        
   insert into #duan select UserWorkflowId,Ten,Loai from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False' and TrangThai<>N'Hủy'                                 
   insert into #duan select '','',''          
   SELECT top 1000 a.Id                                
   ,a.Tieude AS title                                
   ,a.TrangThaiCongViec                                
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, null), 120)) AS dateTo                                
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS DateEnd                              
   ,a.Nguoiphoihop                                
   ,a.Nguoixuly                                
   ,a.Nguoigiao  as UserAllot                  
   ,a.Nguoitheodoi                                
   ,a.UserWorkflowId                             
   ,b.Ten as Status            
   ,[dbo].[fn_GetNumeric](ISNULL(a.Tiendo,'0')) as WorkCurrentState              
   FROM [Dynamic].[Data_WORK] AS a                              
   inner join Dynamic.Data_RESOURCETTFC b on a.TrangThaiCongViec=b.UserWorkflowId             
   inner join #duan c on c.UserWorkflowId=a.Duan          
   -- cross apply Split(ISNULL(a.Nguoixuly,''),';') e
   where ISNULL(a.IsActive,'True')='True' and                     
   --                           e.Item=@employee and 
   ISNULL(a.WorkRepeat,'False')='False' and  @employee= (select top 1 *  from Split(ISNULL(a.Nguoixuly,''),';') where Item=@employee)  
   and b.TrangThaiCongViec not in ( N'Hoàn thành',N'Hủy')        
   order by a.UserWorkflowId desc
go

