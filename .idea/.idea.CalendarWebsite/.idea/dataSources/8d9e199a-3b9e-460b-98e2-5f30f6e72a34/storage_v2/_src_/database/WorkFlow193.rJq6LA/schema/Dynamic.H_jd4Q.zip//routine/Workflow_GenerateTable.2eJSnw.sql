-- =============================================
-- Author:		duydam
-- Create date: 05/11/2021
-- Description:	Create custom table for each workflow
-- =============================================
CREATE       PROCEDURE [Dynamic].[Workflow_GenerateTable] @WorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @WorkflowTableName NVARCHAR(MAX);
	DECLARE @CheckListTableName NVARCHAR(MAX);
	DECLARE @SqlScript NVARCHAR(4000);

	/* Check Schema Dynamic is exited*/
	IF NOT EXISTS (
				SELECT *
				FROM sys.schemas
				WHERE name = 'Dynamic'
				)
	BEGIN
			EXEC ('CREATE SCHEMA Dynamic')
	END

	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	/* Generate dynamic table workflow*/
	SET @WorkflowTableName = CONCAT (
			'Workflow_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);

	IF (
			NOT EXISTS (
				SELECT *
				FROM INFORMATION_SCHEMA.TABLES
				WHERE TABLE_SCHEMA = 'Dynamic'
					AND TABLE_NAME = @WorkflowTableName
				)
			AND @TableName IS NOT NULL
			)
	BEGIN
		SET @WorkflowTableName = CONCAT (
				'Dynamic.'
				,@WorkflowTableName
				);
		/* Generate dynamic table workflow*/
		SET @SqlScript = 'CREATE TABLE ' + @WorkflowTableName + '([Id] [bigint] primary key IDENTITY(1,1) NOT NULL,
			[CreatedBy] [nvarchar](max) NULL,
			[CreatedTime] [datetime2](7) NULL,
			[LastModified] [datetime2](7) NULL,
			[ModifiedBy] [nvarchar](max) NULL,
			[IsDeleted] [bit] NULL,
			[UserWorkflowId] [bigint] NULL,
			[Data] [nvarchar](max) NULL,			
			[DefaultWorkflowStep] [nvarchar](max) NULL)';

		EXEC sp_executesql @SqlScript;

		/* Insert index to WOrkflow table*/
		SET @SqlScript = 'CREATE INDEX index_name ON ' + @WorkflowTableName + '(UserWorkflowId)';

		EXEC sp_executesql @SqlScript;

		/* Generate dynamic table checklist*/
		SET @CheckListTableName = CONCAT (
				'Dynamic.CheckList_'
				,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
				);
		SET @SqlScript = 'CREATE TABLE ' + @CheckListTableName + '([Id] [bigint] primary key IDENTITY(1,1) NOT NULL,
			[UserWorkflowId] [bigint] NULL,
			[CheckListId] [bigint] NULL,
			[Name] [nvarchar](max) NULL,
			[Note] [nvarchar](max) NULL,
			[Path] [nvarchar](max) NULL,
			[Type] [nvarchar](max) NULL,
			[SignatureImageRequest] [nvarchar](max) NULL,
			[Position] [nvarchar](max) NULL,
			[CreatedBy] [nvarchar](max) NULL,
			[CreatedTime] [datetime2](7) NULL,
			[LastModified] [datetime2](7) NULL,
			[ModifiedBy] [nvarchar](max) NULL,
			[IsDeleted] [bit] NULL)';

		EXEC sp_executesql @SqlScript;

		/* Generate basic para for workflow*/
		IF (
				NOT EXISTS (
					SELECT *
					FROM [dbo].[WorkflowPara]
					WHERE [WorkflowId] = @WorkflowId
						AND ParaName = 'Year'
					)
				)
		BEGIN
			INSERT INTO [dbo].[WorkflowPara] (
				ParaName
				,WorkflowId
				,Value
				,[Order]
				)
			VALUES (
				'Year'
				,@WorkflowId
				,[dbo].[fn_GetThe2digitYear]()
				,0
				);
		END

		IF (
				NOT EXISTS (
					SELECT *
					FROM [dbo].[WorkflowPara]
					WHERE [WorkflowId] = @WorkflowId
						AND ParaName = 'Month'
					)
				)
		BEGIN
			INSERT INTO [dbo].[WorkflowPara] (
				ParaName
				,WorkflowId
				,Value
				,[Order]
				)
			VALUES (
				'Month'
				,@WorkflowId
				,[dbo].[fn_GetThe2digitMonth]()
				,0
				);
		END

		IF (
				NOT EXISTS (
					SELECT *
					FROM [dbo].[WorkflowPara]
					WHERE [WorkflowId] = @WorkflowId
						AND ParaName = 'CodeCount'
					)
				)
		BEGIN
			INSERT INTO [dbo].[WorkflowPara] (
				ParaName
				,WorkflowId
				,Value
				,[Order]
				)
			VALUES (
				'CodeCount'
				,@WorkflowId
				,'1'
				,0
				);
		END
	END
END
go

