CREATE FUNCTION [dbo].[TVF_AppTasks_TaskCloneId]
(
    @SiteId uniqueidentifier,
    @TaskCloneId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppTasks] WITH (INDEX=AppTasks_TaskCloneId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ((@TaskCloneId IS NULL AND TaskCloneId IS NULL) OR @TaskCloneId=TaskCloneId)

go

