CREATE PROCEDURE [dbo].[proc_InvalidatePerUserWebPartCache](
    @SiteId uniqueidentifier,
    @WebPartId uniqueidentifier)
AS
    SET NOCOUNT ON
    DECLARE @cbDelta bigint
    DECLARE @PageUrlId uniqueidentifier
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    SELECT TOP 1
        @PageUrlId  = WP.tp_PageUrlID
    FROM
        TVF_WebParts_SitePartId(@SiteId, @WebPartId) AS WP
    IF (@PageUrlId IS NULL)
    BEGIN
        SET @Ret = -2147467259
        GOTO cleanup
    END    
    SELECT
       @cbDelta = -((SUM(CAST((DATALENGTH(P.tp_Cache)) AS BIGINT))))
    FROM
        TVF_Personalization_SitePagePartId(@SiteId, @PageUrlId, @WebPartId) AS P
    WHERE
        P.tp_Cache IS NOT NULL
    IF (@@ERROR <> 0)
    BEGIN
        SET @Ret = -2147467259
        GOTO cleanup
    END
    IF (ISNULL(@cbDelta,0) != 0)
    BEGIN
        EXEC @Ret = proc_AppendSiteQuota
            @SiteId, @cbDelta, 0, @PageUrlId
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        UPDATE
            P
        SET
            P.tp_Cache = null,
            P.tp_Size = P.tp_Size - DATALENGTH(P.tp_Cache)
        FROM
            TVF_Personalization_SitePagePartId(@SiteId, @PageUrlId, @WebPartId) AS P
        WHERE
            P.tp_Cache IS NOT NULL
        IF (@@ERROR <> 0)
        BEGIN
            SET @Ret = -2147467259
            GOTO cleanup
        END
    END
cleanup:
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

