CREATE PROCEDURE [dbo].[proc_EnumerateWebPartsForList](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @IncludeAppWebParts bit,
    @ListId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT
        WP.tp_ID,
        WP.tp_ListId,
        WP.tp_Type,
        WP.tp_Flags,
        WP.tp_DisplayName,
        WP.tp_Version,
        CASE WHEN (DATALENGTH(Docs.DirName) = 0) THEN Docs.LeafName WHEN (DATALENGTH(Docs.LeafName) = 0) THEN Docs.DirName ELSE Docs.DirName + N'/' + Docs.LeafName END, 
        WP.tp_PartOrder,
        WP.tp_ZoneID,            
        WP.tp_IsIncluded,
        WP.tp_FrameState,
        WP.tp_WebPartTypeId,
        WP.tp_Assembly,
        WP.tp_Class,
        WP.tp_SolutionId,
        WP.tp_SolutionWebId,
        WP.tp_AllUsersProperties,
        WP.tp_PerUserProperties,
        WP.tp_WebPartIdProperty,
        WP.tp_Cache,
        WP.tp_Source
    FROM
        TVF_WebParts_ListUserLvl(
            @SiteId,
            @ListId, 
            NULL, 
            1) AS WP
    CROSS APPLY
        TVF_Docs_Id_Level(WP.tp_SiteId, WP.tp_PageUrlID, WP.tp_Level) AS Docs
    WHERE
        WP.tp_SiteId = @SiteId AND
        Docs.WebId = @WebId AND
        Docs.ListId = @ListId AND
       (@IncludeAppWebParts = 1 OR WP.tp_SolutionWebId IS NULL)
    RETURN 0            

go

