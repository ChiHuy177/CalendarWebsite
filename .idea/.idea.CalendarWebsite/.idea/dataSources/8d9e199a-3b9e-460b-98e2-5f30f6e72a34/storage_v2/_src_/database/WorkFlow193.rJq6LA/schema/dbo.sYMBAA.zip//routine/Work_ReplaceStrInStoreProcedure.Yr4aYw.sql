-- Work_ReplaceStrInStoreProcedure' CREATE OR ALTER PROC   Work_Generate_InsertScripts   '
   CREATE   PROC  [dbo].[Work_ReplaceStrInStoreProcedure]
   @strQuery as nvarchar(max)=N''
   as
   set @strQuery =REPLACE(@strQuery,'CREATE','CREATE OR ALTER ')
   --set @strQuery =REPLACE(@strQuery,'CREATE OR ALTER PROC EDURE','CREATE OR ALTER PROC  ');
   --set @strQuery =REPLACE(@strQuery,'CREATE OR ALTER PROCEDURE','CREATE OR ALTER PROC  ');
   --set @strQuery =REPLACE(@strQuery,'CREATE OR ALTER PROCEDURE','CREATE OR ALTER PROC  ');
   select @strQuery;
   -- CREATE OR ALTER PROC  [dbo].[Work_ReportChartByProject]      
go

