CREATE FUNCTION [dbo].[TVF_BuildDependencies_DirNameEqLike_Value]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @DirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        BuildDependencies WITH (INDEX=BuildDependencies_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DirName = @DirName
    UNION ALL
    SELECT
        *
    FROM
        BuildDependencies WITH (INDEX=BuildDependencies_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DirName LIKE @DirNameLike

go

