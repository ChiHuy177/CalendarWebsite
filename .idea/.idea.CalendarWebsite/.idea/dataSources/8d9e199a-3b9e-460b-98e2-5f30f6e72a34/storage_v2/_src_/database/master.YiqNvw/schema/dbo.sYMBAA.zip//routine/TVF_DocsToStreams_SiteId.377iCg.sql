CREATE FUNCTION [dbo].[TVF_DocsToStreams_SiteId]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[DocsToStreams] WITH (INDEX=DocsToStreams_CI, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

