
-- [dbo].[UserWorkflow_IncomingTextByStatus] 'vuongnq@vntt.com.vn', 1
CREATE PROCEDURE [dbo].[UserWorkflow_IncomingTextByStatus] @email AS NVARCHAR(500) = ''
	,@status INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT d.*
		,a.*
	INTO #a
	FROM [Dynamic].[Workflow_VANBANDEN] AS Tab
	CROSS APPLY OPENJSON(Tab.data, N'$') WITH (
			TextBook NVARCHAR(500) N'$.Sovanban'
			,IncomingBook NVARCHAR(500) N'$.Soden'
			,TextBook1 NVARCHAR(500) N'$.Sovanban1'
			,TextType NVARCHAR(500) N'$.Loaivb'
			,Abstract NVARCHAR(500) N'$.Trichyeu'
			,PlaceSending NVARCHAR(500) N'$.Noigui'
			,Fields NVARCHAR(500) N'$.Linhvuc'
			,ArrivalDate DATETIME N'$.Ngayden'
			,DateOnText DATETIME N'$.Ngaytrenvb'
			,Urgency NVARCHAR(500) N'$.Dokhan'
			,[Security] NVARCHAR(500) N'$.Domat'
			,[Priority] NVARCHAR(500) N'$.Douutien'
			,NumberOfCopies BIGINT N'$.Soban'
			,NumberOfPages BIGINT N'$.Sotrang'
			,AnswerTextOutNumber NVARCHAR(500) N'$.Traloivanbandiso'
			) AS a
	INNER JOIN UserWorkflow d ON d.Id = Tab.UserWorkflowId

	SELECT a.*
	FROM #a a
	WHERE a.UserWorkflowStatus = @status
		AND a.CreatedBy LIKE N'%' + @email + '%'

	DROP TABLE #a
END
go

