CREATE PROC [dbo].[proc_GetListContentTypes](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    SELECT
        tp_ContentTypes
    FROM
        TVF_Lists_CI(@SiteId, @WebId, @ListId) AS L

go

