CREATE PROCEDURE [dbo].[proc_DropListRecord](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @ListId uniqueidentifier,
    @ServerTemplate int,
    @Id int,
    @UseNvarchar1ItemName bit = 1,
    @AuditIfNecessary bit = 0,
    @UserTitle nvarchar(255), 
    @Version int = NULL,
    @UserId int = 0,
    @AppPrincipalId int = 0,
    @NeedsAuthorRestriction bit = 0,
    @Basetype int = NULL,                       
    @DeleteOp int = 3,
    @eventData varbinary(max) = NULL,
    @acl varbinary(max) = NULL,
    @ThresholdRowCount int = 0,
    @DeleteTransactionId varbinary(16) = 0x OUTPUT,
    @Size bigint = 0 OUTPUT,
    @IsCascadeDeleteOperation bit = 0,
    @IsCascadeParent bit = 0,
    @ChildDeleteTransactionId varbinary(16) = NULL OUTPUT,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    IF @DeleteTransactionId IS NULL
        SET @DeleteTransactionId = 0x
    DECLARE @ReturnCode int;
    SET @ReturnCode = 0;        
    DECLARE @DirName nvarchar(256)
    DECLARE @LeafName nvarchar(128)
    DECLARE @FullUrl nvarchar(260)
    DECLARE @guidT uniqueidentifier
    DECLARE @ItemGuid uniqueidentifier
    DECLARE @ItemName nvarchar(255)
    DECLARE @AuthorId int
    DECLARE @VersionNbr int
    DECLARE @MeetingEventType int
    EXEC proc_LockListAuxForDocumentUpdate @SiteId, @ListId, 0
    SELECT
        @ItemName = 
            CASE 
                WHEN @UseNvarchar1ItemName = 1 THEN UD.nvarchar1 
                ELSE CAST(tp_ID AS NVARCHAR(10)) 
            END,
        @AuthorId = UD.tp_Author,
        @VersionNbr = UD.tp_Version,
        @MeetingEventType = int1,
        @DirName = D.DirName,
        @LeafName = D.LeafName,
        @ItemGuid = UD.tp_GUID
    FROM
        TVF_UserData_XLock_ListItem_Mtg(@SiteId, @ListId, @Id) AS UD
    CROSS APPLY
        TVF_Docs_UpdLock_CI(UD.tp_SiteId, UD.tp_ParentId, UD.tp_DocId, UD.tp_Level) AS D
    WHERE
        UD.tp_RowOrdinal = 0
    OPTION(FORCE ORDER, MAXDOP 1, LOOP JOIN)
    IF (@@ROWCOUNT >= 1)
    BEGIN
        EXEC @ReturnCode = proc_VerifyUpdateConditions
            @VersionNbr,
            @AuthorId,
            @Version,
            @UserId,
            @NeedsAuthorRestriction
    END
    ELSE
    BEGIN
        SET @ReturnCode = 3
    END
    IF (@ReturnCode <> 0)
        GOTO FAILED
EXEC proc_DeleteContextCollectionEventReceivers @SiteId, @ItemGuid
    IF @AuditIfNecessary = 1
    BEGIN
        EXEC proc_AddAuditEntryFromSql
            @SiteId,
            @DirName,
            @LeafName,
            3,
            @UserId,
            @AppPrincipalId,
            4,
            NULL,
            0x00000008
    END
    SET @FullUrl = CASE WHEN (DATALENGTH(@DirName) = 0) THEN @LeafName WHEN (DATALENGTH(@LeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @LeafName END
    EXEC @ReturnCode = proc_DeleteUrlCore
         @SiteId,
         @WebId,
         @FullUrl,
         @UserId,
         @AppPrincipalId,
         1, 
         @ItemName,
         0,
         0,
         0,
         3,
         0,
         0,
         @DeleteOp,
         @DeleteTransactionId OUTPUT,
         1,
         @ThresholdRowCount,
         @FullUrl OUTPUT,
         @Size OUTPUT,
         @eventData,
         @acl,
         0, 
         @IsCascadeDeleteOperation,
         @IsCascadeParent,
         @ChildDeleteTransactionId OUTPUT,
         @RequestGuid OUTPUT;
    IF @ReturnCode <> 0
        GOTO FAILED
IF @ServerTemplate = 200
    BEGIN
        EXEC proc_PostProcessDelMtgListItem
            @SiteId,
            @WebId,
            @ListId,
            @MeetingEventType
    END
FAILED:
    RETURN @ReturnCode

go

