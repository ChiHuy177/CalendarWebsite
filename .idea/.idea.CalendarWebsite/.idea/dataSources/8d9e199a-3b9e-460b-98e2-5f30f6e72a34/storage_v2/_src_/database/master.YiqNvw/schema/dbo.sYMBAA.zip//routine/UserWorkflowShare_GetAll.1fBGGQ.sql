
-- =============================================
-- Author:		TienCTV
-- Create date: 29/12/2021
-- Description:	Get all UserWorkflowShare
-- Changelog: 25/04/2022 - binhnt - Add totalItems into sp
-- =============================================
CREATE   PROCEDURE [dbo].[UserWorkflowShare_GetAll] @UserWorkflowId BIGINT = NULL
	,@UserId BIGINT = NULL
	,@Page INT = NULL
	,@PageSize INT = NULL
	,@WorkflowId BIGINT = NULL
	,@TotalItems BIGINT OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Take INT = 0
		,@Skip INT = 0;

	IF @PageSize IS NULL
		OR @PageSize <= 0
		SET @Take = 10
	ELSE
		SET @Take = @PageSize

	IF @Page IS NULL
		OR @Page <= 0
		SET @Skip = 0
	ELSE
		SET @Skip = (@Page - 1) * @Take

	IF OBJECT_ID(N'tempdb..#TempUserWorkflowShare') IS NOT NULL
		DROP TABLE #TempUserWorkflowShare;

	SELECT ush.[Id]
		,ush.[UserId]
		,ush.[UserWorkflowId]
		,ush.[Note]
		,ush.[CreatedBy]
		,ush.[CreatedTime]
		,ush.[LastModified]
		,ush.[ModifiedBy]
		,(
			CASE WHEN us.Id is not null				
				THEN us.CreatedTime
				ELSE ush.[LastModified]
				END
			) AS [SeenTime]
		,ush.[IsDeleted]
	INTO #TempUserWorkflowShare
	FROM UserWorkflowShare ush
	INNER JOIN UserWorkflow u ON u.Id = ush.UserWorkflowId
	OUTER APPLY (
		SELECT TOP 1 *
		FROM [dbo].[UserWorkflowSeen]
		WHERE UserWorkflowId = ush.UserWorkflowId
			AND UserId = ush.UserId
		) AS us
	WHERE ush.IsDeleted <> 1
		AND (
			(@UserWorkflowId IS NULL)
			OR (ush.[UserWorkflowId] = @UserWorkflowId)
			)
		AND (
			(@UserId IS NULL)
			OR (ush.[UserId] = @UserId)
			)
		AND (
			(@WorkflowId IS NULL)
			OR (u.WorkflowId = @WorkflowId)
			)
	SET @TotalItems = (
			SELECT COUNT(*)
			FROM #TempUserWorkflowShare
			);

	SELECT *
	FROM #TempUserWorkflowShare
	ORDER BY [LastModified] DESC
		,[CreatedTime] DESC OFFSET @Skip ROWS

	FETCH NEXT @Take ROWS ONLY;

	IF OBJECT_ID('tempdb..#TempUserWorkflowShare') IS NOT NULL
		DROP TABLE #TempUserWorkflowShare
END
go

