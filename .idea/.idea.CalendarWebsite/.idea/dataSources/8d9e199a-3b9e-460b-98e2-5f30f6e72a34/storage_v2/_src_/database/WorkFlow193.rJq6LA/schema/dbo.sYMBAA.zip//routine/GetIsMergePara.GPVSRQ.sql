
-- =============================================
-- Author:		Duy Dam
-- Create date: 30/11/2021
-- Description:	Get IsMerge Para in this system
-- =============================================
CREATE   PROCEDURE [dbo].[GetIsMergePara] @bit BIT OUTPUT
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (
			SELECT *
			FROM WorkflowPara
			WHERE ParaName = 'IsMerge'
				AND IsSystemPara = 1
			)
	BEGIN
		SET @bit = (
				SELECT CONVERT(BIT, Value)
				FROM WorkflowPara
				WHERE ParaName = 'IsMerge'
					AND IsSystemPara = 1
				)
	END
	ELSE
	BEGIN
		SET @bit = 0;
	END
END
go

