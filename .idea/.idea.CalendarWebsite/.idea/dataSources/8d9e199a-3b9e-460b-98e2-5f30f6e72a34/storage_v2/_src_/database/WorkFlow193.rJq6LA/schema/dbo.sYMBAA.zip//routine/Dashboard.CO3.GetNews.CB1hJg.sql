
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Dashboard.CO3.GetNews]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @sql AS NVARCHAR(max)

	SELECT dw.*
	FROM [Dynamic].[Workflow_NEWS] dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE u.IsDeleted = 0
		AND dbo.JSON_VALUE(dw.Data, '$.trueorfall') = 'false'
		and u.UserWorkflowStatus=1
END
go

