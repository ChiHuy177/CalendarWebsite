-- Work_ReportShowInfoExtend 258921            
   CREATE   PROC  [dbo].[Work_ReportShowInfoExtend]            
   @projectId as nvarchar(50)  =258921          
   as          
   select         
   a.UserWorkflowId as GroupId        
   , a.Ten        
   ,a.ProjectId        
   ,a.GroupParent     
   ,a.Status  
   ,e.*           
   into #a            
   from Dynamic.Data_ProjectGroup a            
   left join Dynamic.Data_WORK b on a.ProjectId=b.Duan and a.UserWorkflowId=b.GroupProject            
   inner join Dynamic.Data_ProjectLinkCoupon c on c.WorkId = b.UserWorkflowId            
   inner join UserWorkflow d on d.Id = c.CouponId             
   inner join Dynamic.data_PLTTGTCV e on e.UserWorkflowId=c.CouponId        
   where a.ProjectId=@projectId and c.Type = 4 and ISNULL(b.CongViecCha,'')=''  and ISNULL(c.IsDelete,'False')='False'          
   and isnull(b.IsDelete,'False')='False' and ISNULL(a.Status,'')<>'Closed'     
   select        
   a.Ten         
   ,a.GroupId  
   ,isnull(sum(a.giatrihd),0) as giatrihd            
   ,isnull(sum(a.giatriqt),0) as giatriqt        
   , ISNULL(SUM(a.giatritt1),0) +ISNULL(SUM(a.giatritt2),0) as tongtt            
   , isnull(sum(a.giatriqt),0) - (ISNULL(SUM(a.giatritt1),0) +ISNULL(SUM(a.giatritt2),0)) as conlai               
   ,ISNULL(a.GroupParent,'') as GroupParent   
   ,a.Status          
   ,ISNULL(Qty,0) as Qty
   from #a a    
   left join          
   (          
   select b.GroupProject, COUNT(*) as Qty          
   from Dynamic.Data_ProjectGroup a            
   inner join Dynamic.Data_WORK b on a.ProjectId=b.Duan and a.UserWorkflowId=b.GroupProject           
   where a.ProjectId=@projectId and ISNULL(b.CongViecCha,'')=''  and ISNULL(b.IsDelete,'False')='False'          
   group by b.GroupProject          
   ) b on a.GroupId=b.GroupProject    
   group by a.Ten,  a.GroupId,a.GroupParent,a.Status,b.Qty
   drop table #a
go

