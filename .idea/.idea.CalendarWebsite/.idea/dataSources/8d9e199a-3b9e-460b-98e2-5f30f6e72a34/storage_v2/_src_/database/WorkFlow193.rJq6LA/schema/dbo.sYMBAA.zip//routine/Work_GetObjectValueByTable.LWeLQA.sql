-- Work_GetObjectValueByTable 'P:287','Dynamic.Data_WORK','Tieude'  
   CREATE   PROC [dbo].[Work_GetObjectValueByTable]   
   @userId as nvarchar(500)   
   ,@tableName as nvarchar(500)='Dynamic.Data_RESOURCEDA'   
   ,@columnName as nvarchar(150) ='Ten'   
   ,@projectType as nvarchar(150)=''   
   as   
   declare @sql as nvarchar(max)   
   set @sql=N'   
   if('''+@tableName+'''=''Dynamic.Data_RESOURCEDA'')   
   begin   
   declare @tbUser table ( UserId nvarchar(50), UserWorkflowId bigint)   
   insert into @tbUser   
   select * from   
   (   
   SELECT    
   ''P:''+ trim(str(c.PersonalProfilesId)) AS userId   
   ,a.UserWorkflowId   
   -- into #da   
   FROM DYNAMIC.Data_RESOURCEDA AS a   
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, '';'') as b   
   inner join GroupPersonalProfile c on ''G:''+ trim(str(GroupsId))=b.value   
   where left(trim(b.value),2)=''G:''   
   union   
   SELECT    
   b.value AS userId   
   ,a.UserWorkflowId   
   -- into #da   
   FROM DYNAMIC.Data_RESOURCEDA AS a   
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, '';'') as b   
   where left(trim(b.value),2)=''P:''   
   union   
   SELECT    
   b.value AS userId   
   ,a.UserWorkflowId   
   -- into #da   
   FROM DYNAMIC.Data_RESOURCEDA AS a   
   CROSS APPLY STRING_SPLIT(a.QuanLy, '';'') as b   
   where left(trim(b.value),2)=''P:''   
   ) a group by userId,UserWorkflowId   
   select a.UserWorkflowId as Value,a.Ten as Label from Dynamic.Data_RESOURCEDA a  
   inner join @tbUser b on b.UserWorkflowId=a.UserWorkflowId   
   where ISNULL(IsDeleted,''False'')=''False'' and b.UserId='''+@userId+'''  
   and ISNULL(a.Loai,'''') like N''%'+ @projectType+'%''   
   end   
   else   
   begin   
   select UserWorkflowId as Value,'+@columnName+' as Label from '+@tableName+'   
   where trim(str(UserWorkflowId))='''+@userId+'''   
   end   
   '   
   print(@sql)   
   exec(@sql)   
   --print(@sql) 
go

