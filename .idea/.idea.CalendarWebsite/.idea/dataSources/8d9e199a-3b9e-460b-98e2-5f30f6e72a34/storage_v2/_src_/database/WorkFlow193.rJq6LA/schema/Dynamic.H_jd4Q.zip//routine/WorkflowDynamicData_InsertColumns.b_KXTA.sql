-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE     PROCEDURE [Dynamic].[WorkflowDynamicData_InsertColumns] 
	-- Add the parameters for the stored procedure here
	@PropertyId bigint
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @ColumnName NVARCHAR(MAX);
	DECLARE @WorkflowId BIGINT;
	DECLARE @SqlScript NVARCHAR(4000);

	SET @WorkflowId = (
				SELECT TOP 1 WorkflowId
				FROM Property
				WHERE Id = @PropertyId
				);
	SET @ColumnName = (
				SELECT TOP 1 Name
				FROM Property
				WHERE Id = @PropertyId
				);
	SET @TableName = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @WorkflowId
				)
	SET @TableName = CONCAT (
				'Dynamic.Data_'
				,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
				);

	SET @SqlScript = 'IF OBJECT_ID(N''' + @TableName + ''', N''U'') IS NOT NULL
					AND NOT EXISTS(SELECT 1 FROM sys.columns 
									  WHERE Name = N''' + @ColumnName + '''
									  AND Object_ID = Object_ID(N''' + @TableName + '''))
					BEGIN ALTER TABLE ' + @TableName +
					' ADD [' + @ColumnName + ']' +
					(SELECT (
					CASE 
						WHEN p.IsSingle = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsMultiLine = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsChoice = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsNumber = 1 AND p.IsViewOnly <> 1
							THEN ' decimal(22,4) null'
						WHEN p.IsNumber = 1 AND p.IsViewOnly = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsCurrency = 1 AND p.IsViewOnly <> 1
							THEN ' decimal(22,4) null'
						WHEN p.IsCurrency = 1 AND p.IsViewOnly = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsDateAndTime = 1
							THEN ' datetime2(7) NULL'
						WHEN p.IsLookup = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsYesNo = 1
							THEN ' bit NULL'
						WHEN p.IsUser = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsCalculated = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsFile = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						WHEN p.IsApi = 1
							THEN ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						ELSE ' [nvarchar](' + (CASE WHEN p.SqlLength IS NULL THEN 'max' ELSE CAST(p.SqlLength AS nvarchar(max)) END) + ') NULL'
						END
					)	FROM Property p
					WHERE p.Id = @PropertyId)
					+ ' END'
		print @SqlScript;
		EXEC sp_ExecuteSql @SqlScript;
END
go

