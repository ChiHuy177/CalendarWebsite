CREATE PROCEDURE [dbo].[proc_SecResolveAppPrincipalNameFromHostName](
    @SiteId uniqueidentifier,
    @HostName nvarchar(256),
    @AppPrincipalName nvarchar(256) OUTPUT)
AS
    SET NOCOUNT ON
    SET @AppPrincipalName = NULL
    SELECT
        @AppPrincipalName = AppRTMD.OAuthAppId
    FROM
        TVF_Webs_AWDI(@SiteId, @HostName) AS Webs
    CROSS APPLY
       TVF_AppRuntimeMetadata_AppInstanceId(@SiteId, Webs.AppInstanceId) AS AppRTMD        
    IF @AppPrincipalName IS NULL
        RETURN 2
    RETURN 0

go

