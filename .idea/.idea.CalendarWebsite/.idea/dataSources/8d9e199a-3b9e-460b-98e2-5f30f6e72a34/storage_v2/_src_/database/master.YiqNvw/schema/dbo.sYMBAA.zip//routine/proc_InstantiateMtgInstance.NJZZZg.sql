CREATE PROCEDURE [dbo].[proc_InstantiateMtgInstance]
(
    @SiteId                 uniqueidentifier,
    @WebId                  uniqueidentifier,
    @WebUrl                 nvarchar(256) = NULL, 
    @InstanceID             int,
    @ForAttendees           bit = NULL  
)
AS
    SET NOCOUNT ON
    DECLARE @Error int SET @Error = 0 BEGIN TRAN
    IF (@ForAttendees IS NULL OR @ForAttendees = 0)
    BEGIN
        EXEC @Error = proc_CreateDocLibSubFoldersForMtgInst
            @SiteId,
            @WebId,
            @WebUrl,
            @InstanceID
        IF @Error <> 0
            GOTO cleanup
    END
    EXEC @Error = proc_CloneSeedDataForMtgInst
        @SiteId,
        @WebId,
        @InstanceID,
        @ForAttendees
cleanup:
    IF (@Error <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Error

go

