CREATE FUNCTION [dbo].[TVF_ImmedSubscriptions_AlwaysNotifyBit]
(
    @AlwaysNotifyBit bit
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[ImmedSubscriptions] WITH (INDEX=ImmedSubscriptions_AlwaysNotifyBitSiteId, FORCESEEK)
    WHERE
        ((@AlwaysNotifyBit IS NULL AND AlwaysNotifyBit IS NULL) OR @AlwaysNotifyBit=AlwaysNotifyBit)

go

