CREATE PROC [dbo].[proc_EnumListsWithMetadata](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @WebsFilter int,
    @ListsFilter int,
    @BaseType int,
    @ServerTemplate int,
    @IncludeHidden bit,
    @FieldId uniqueidentifier,
    @FieldValue nvarchar(255),
    @FieldType int,
    @PrefetchListScopes bit,
    @ThresholdRowCount int,    
    @MaxLists int,
    @NumLists int,
    @ListIds varbinary(max),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @iListIter int
    DECLARE @InputLists TABLE
    (
        tp_ID uniqueidentifier
    )
    DECLARE @ListIdTable TABLE
    (
        tp_ListId uniqueidentifier, 
        tp_HasFGP bit,
        tp_HasInternalFGP bit,
        tp_ScopeId uniqueidentifier,
        tp_RootFolder uniqueidentifier,
        tp_WebId uniqueidentifier,
        tp_WebFullUrl nvarchar(280),
        tp_WebTitle nvarchar(255),
        tp_WebTemplate int,
        tp_WebLanguage int,
        tp_WebCollation smallint,
        tp_CachedSchema bigint,
        tp_CheckForTranLock bigint,
        tp_TitleResource nvarchar(520),
        tp_DescriptionResource nvarchar(520)
    )
    DECLARE @WebScopeId uniqueidentifier
    DECLARE @ParentWebId uniqueidentifier
    DECLARE @WebUrlLike nvarchar(1024)
    SELECT TOP 1
        @WebScopeId = ScopeId,
        @ParentWebId = ParentWebId,
        @WebUrlLike =
            CASE
                WHEN @WebsFilter = 1 AND ParentWebId IS NOT NULL
                    THEN dbo.fn_EscapeForLike(FullUrl, 1)
                ELSE NULL
            END
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
    IF (@ListsFilter = 2)
    BEGIN
        SET @iListIter = 0
        WHILE (@iListIter < @NumLists)
        BEGIN
            INSERT INTO @InputLists
            VALUES
                (CAST(SUBSTRING(@ListIds, @iListIter*16 + 1, 16)
                    AS uniqueidentifier))
            SET @iListIter = @iListIter + 1
        END
        IF @WebsFilter = 2
        BEGIN
            INSERT INTO 
                @ListIdTable
            SELECT DISTINCT
                L.tp_ID,
                L.tp_HasFGP,
                L.tp_HasInternalFGP,
                L.tp_ScopeId,
                L.tp_RootFolder,
                L.tp_WebId,
                W.FullUrl,
                W.Title,
                W.WebTemplate,
                W.Language,
                W.Collation,
                (L.tp_Flags & 0x200000000) | (W.Flags & 0x200),
                W.Flags & 16384,
                ALP.TitleResource,
                ALP.DescriptionResource
            FROM
                @InputLists AS InputLists
            CROSS APPLY
                TVF_Lists_Id(@SiteId, InputLists.tp_ID) AS L
            OUTER APPLY
                TVF_AllListsPlus_ListId(L.tp_SiteId, L.tp_ID) AS ALP
            CROSS APPLY
                TVF_Webs_Id(L.tp_SiteId, L.tp_WebId) AS W
            WHERE
                ((@IncludeHidden = 1) OR ((L.tp_Flags & 256) = 0))
            OPTION (FORCE ORDER)
        END
        ELSE
        BEGIN
            INSERT INTO 
                @ListIdTable
            SELECT DISTINCT
                L.tp_ID,
                L.tp_HasFGP,
                L.tp_HasInternalFGP,
                L.tp_ScopeId,
                L.tp_RootFolder,
                L.tp_WebId,
                W.FullUrl,
                W.Title,
                W.WebTemplate,
                W.Language,
                W.Collation,
                (L.tp_Flags & 0x200000000) | (W.Flags & 0x200),
                W.Flags & 16384,
                ALP.TitleResource,
                ALP.DescriptionResource
            FROM
                @InputLists AS InputLists
            CROSS APPLY
                TVF_Lists_Id(@SiteId, InputLists.tp_ID) AS L
            OUTER APPLY
                TVF_AllListsPlus_ListId(L.tp_SiteId, L.tp_ID) AS ALP
            CROSS APPLY
                TVF_Webs_Id(L.tp_SiteId, L.tp_WebId) AS W
            WHERE
                ((@IncludeHidden = 1) OR ((L.tp_Flags & 256) = 0)) AND
                (L.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR W.FullUrl LIKE @WebUrlLike)))
            OPTION (FORCE ORDER)
        END       
    END
    ELSE IF @ListsFilter = 3
    BEGIN
        SET @iListIter = 0
        WHILE (@iListIter < @NumLists)
        BEGIN
            INSERT INTO @InputLists
            VALUES
                (CAST(SUBSTRING(@ListIds, @iListIter*16 + 1, 16)
                    AS uniqueidentifier))
            SET @iListIter = @iListIter + 1
        END
        INSERT INTO 
            @ListIdTable
        SELECT DISTINCT
            L.tp_ID,
            L.tp_HasFGP,
            L.tp_HasInternalFGP,
            L.tp_ScopeId,
            L.tp_RootFolder,
            L.tp_WebId,
            W.FullUrl,
            W.Title,
            W.WebTemplate,
            W.Language,
            W.Collation,
            (L.tp_Flags & 0x200000000) | (W.Flags & 0x200),
            W.Flags & 16384,
            ALP.TitleResource,
            ALP.DescriptionResource
        FROM
            @InputLists AS InputLists
        CROSS APPLY
            TVF_Lists_Id(@SiteId, InputLists.tp_ID) AS L
        OUTER APPLY
            TVF_AllListsPlus_ListId(L.tp_SiteId, L.tp_ID) AS ALP
        CROSS APPLY
            TVF_Webs_Id(L.tp_SiteId, L.tp_WebId) AS W
        WHERE
            ((@IncludeHidden = 1) OR ((L.tp_Flags & 256) = 0)) AND
            EXISTS ( 
                SELECT 1 
                FROM TVF_EventReceivers_SiteWebHost(@SiteId, L.tp_WebId, L.tp_ID) AS ER
                WHERE (ER.Type = 3 OR ER.Type = 10003))
        OPTION (FORCE ORDER)
    END
    ELSE IF @ListsFilter = 1
    BEGIN
        IF @FieldType = 1 OR @FieldType = 5  
        BEGIN
            DECLARE @Collation smallint
            SELECT TOP 1
                @Collation = Collation
            FROM
                TVF_Webs_Id(@SiteId, @WebId) AS W
    IF @Collation = 0
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Albanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Albanian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 1
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Arabic_CI_AS AS NVP WITH (INDEX=NameValuePair_Arabic_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 2
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Simplified_Pinyin_100_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 3
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Chinese_PRC_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_PRC_Stroke_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 4
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Bopomofo_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 5
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Chinese_Taiwan_Stroke_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Taiwan_Stroke_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 6
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Croatian_CI_AS AS NVP WITH (INDEX=NameValuePair_Croatian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 7
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Cyrillic_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Cyrillic_General_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 8
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Czech_CI_AS AS NVP WITH (INDEX=NameValuePair_Czech_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 9
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Danish_Norwegian_CI_AS AS NVP WITH (INDEX=NameValuePair_Danish_Norwegian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 10
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Estonian_CI_AS AS NVP WITH (INDEX=NameValuePair_Estonian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 11
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Finnish_Swedish_CI_AS AS NVP WITH (INDEX=NameValuePair_Finnish_Swedish_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 12
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_French_CI_AS AS NVP WITH (INDEX=NameValuePair_French_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 13
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Georgian_Modern_Sort_CI_AS AS NVP WITH (INDEX=NameValuePair_Georgian_Modern_Sort_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 14
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_German_PhoneBook_CI_AS AS NVP WITH (INDEX=NameValuePair_German_PhoneBook_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 15
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Greek_CI_AS AS NVP WITH (INDEX=NameValuePair_Greek_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 16
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Hebrew_CI_AS AS NVP WITH (INDEX=NameValuePair_Hebrew_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 17
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Hindi_CI_AS AS NVP WITH (INDEX=NameValuePair_Hindi_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 18
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Hungarian_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 19
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Hungarian_Technical_CI_AS AS NVP WITH (INDEX=NameValuePair_Hungarian_Technical_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 20
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Icelandic_CI_AS AS NVP WITH (INDEX=NameValuePair_Icelandic_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 21
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Japanese_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 22
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Japanese_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Japanese_Unicode_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 23
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Korean_Wansung_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 24
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Korean_Wansung_Unicode_CI_AS AS NVP WITH (INDEX=NameValuePair_Korean_Wansung_Unicode_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 25
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Latin1_General_CI_AS AS NVP WITH (INDEX=NameValuePair_Latin1_General_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 26
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Latvian_CI_AS AS NVP WITH (INDEX=NameValuePair_Latvian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 27
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Lithuanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 28
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Lithuanian_Classic_CI_AS AS NVP WITH (INDEX=NameValuePair_Lithuanian_Classic_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 29
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Traditional_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Traditional_Spanish_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 30
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Modern_Spanish_CI_AS AS NVP WITH (INDEX=NameValuePair_Modern_Spanish_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 31
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Polish_CI_AS AS NVP WITH (INDEX=NameValuePair_Polish_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 32
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Romanian_CI_AS AS NVP WITH (INDEX=NameValuePair_Romanian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 33
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Slovak_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovak_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 34
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Slovenian_CI_AS AS NVP WITH (INDEX=NameValuePair_Slovenian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 35
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Thai_CI_AS AS NVP WITH (INDEX=NameValuePair_Thai_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 36
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Turkish_CI_AS AS NVP WITH (INDEX=NameValuePair_Turkish_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 37
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Ukrainian_CI_AS AS NVP WITH (INDEX=NameValuePair_Ukrainian_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 38
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Vietnamese_CI_AS AS NVP WITH (INDEX=NameValuePair_Vietnamese_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 39
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Azeri_Cyrillic_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Cyrillic_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 40
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Azeri_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Azeri_Latin_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 41
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Chinese_Hong_Kong_Stroke_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 42
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Divehi_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Divehi_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 43
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Indic_General_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Indic_General_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 44
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Kazakh_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Kazakh_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 45
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Macedonian_FYROM_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Macedonian_FYROM_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 46
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Syriac_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Syriac_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 47
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Tatar_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Tatar_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
    ELSE
    IF @Collation = 48
    BEGIN
        INSERT INTO @ListIdTable SELECT DISTINCT Lists.tp_ID, Lists.tp_HasFGP, Lists.tp_HasInternalFGP, Lists.tp_ScopeId, Lists.tp_RootFolder, Lists.tp_WebId , Webs.FullUrl , Webs.Title , Webs.WebTemplate , Webs.Language , Webs.Collation , (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200) , Webs.Flags & 16384 , AllListsPlus.TitleResource , AllListsPlus.DescriptionResource FROM
            NameValuePair_Uzbek_Latin_90_CI_AS AS NVP WITH (INDEX=NameValuePair_Uzbek_Latin_90_CI_AS_CI)
        CROSS APPLY TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs OUTER APPLY TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus CROSS APPLY TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists WHERE Nvp.SiteId = @SiteId AND (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND (@ServerTemplate = -1 OR Lists.tp_ServerTemplate = @ServerTemplate) AND ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND (@WebsFilter = 2 OR Lists.tp_WebId = @WebId OR (@WebsFilter = 1 AND (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike))) OPTION (FORCE ORDER)
    END
        END
        ELSE
        BEGIN
            INSERT INTO 
                @ListIdTable
            SELECT DISTINCT
                Lists.tp_ID,
                Lists.tp_HasFGP,
                Lists.tp_HasInternalFGP,
                Lists.tp_ScopeId,
                Lists.tp_RootFolder,
                Lists.tp_WebId,
                Webs.FullUrl,
                Webs.Title,
                Webs.WebTemplate,
                Webs.Language,
                Webs.Collation,
                (Lists.tp_Flags & 0x200000000) | (Webs.Flags & 0x200),
                Webs.Flags & 16384,
                AllListsPlus.TitleResource,
                AllListsPlus.DescriptionResource
            FROM
                NameValuePair AS Nvp WITH (INDEX=NameValuePair_CI)
            OUTER APPLY
                TVF_AllListsPlus_ListId(Nvp.SiteId, Nvp.ListId) AS AllListsPlus
            CROSS APPLY
                TVF_Webs_Id(Nvp.SiteId, Nvp.WebId) AS Webs
            CROSS APPLY
                TVF_Lists_Id(Nvp.SiteId, Nvp.ListId) AS Lists 
            WHERE
                Nvp.SiteId = @SiteId AND
                (@FieldId IS NULL OR Nvp.FieldId = @FieldId) AND
                (@FieldValue IS NULL OR Nvp.Value = @FieldValue) AND
                (@BaseType = -1 OR Lists.tp_BaseType = @BaseType) AND
                (@ServerTemplate = -1 OR
                 Lists.tp_ServerTemplate = @ServerTemplate) AND
                ((@IncludeHidden = 1) OR ((Lists.tp_Flags & 256) = 0)) AND
                (@WebsFilter = 2 OR
                 Lists.tp_WebId = @WebId OR
                 (@WebsFilter = 1 AND
                  (@ParentWebId IS NULL OR Webs.FullUrl LIKE @WebUrlLike)))
              OPTION (FORCE ORDER)
        END
    END
    ELSE
    BEGIN
        IF ((@WebsFilter = 2) OR
            ((@WebsFilter = 1) AND (@ParentWebId IS NULL)))
        BEGIN
            INSERT INTO 
                @ListIdTable
            SELECT DISTINCT
                L.tp_ID,
                L.tp_HasFGP,
                L.tp_HasInternalFGP,
                L.tp_ScopeId,
                L.tp_RootFolder,
                L.tp_WebId, 
                W.FullUrl, 
                W.Title, 
                W.WebTemplate, 
                W.Language, 
                W.Collation, 
                (L.tp_Flags & 0x200000000) | (W.Flags & 0x200), 
                W.Flags & 16384, 
                ALP.TitleResource, 
                ALP.DescriptionResource
            FROM
                TVF_Webs_SiteId(@SiteId) AS W
            CROSS APPLY
                TVF_Lists_WebId(W.SiteId, W.Id) AS L
            OUTER APPLY
                TVF_AllListsPlus_ListId(L.tp_SiteId, L.tp_ID) AS ALP
            WHERE
                (@BaseType = -1 OR L.tp_BaseType = @BaseType) AND
                (@ServerTemplate = -1 OR
                    L.tp_ServerTemplate = @ServerTemplate) AND
                ((@IncludeHidden = 1) OR ((L.tp_Flags & 256) = 0))
            OPTION (FORCE ORDER)
        END
        ELSE IF @WebsFilter = 1
        BEGIN
            INSERT INTO 
                @ListIdTable
            SELECT DISTINCT
                L.tp_ID,
                L.tp_HasFGP,
                L.tp_HasInternalFGP,
                L.tp_ScopeId,
                L.tp_RootFolder,
                L.tp_WebId, 
                W.FullUrl, 
                W.Title, 
                W.WebTemplate, 
                W.Language, 
                W.Collation, 
                (L.tp_Flags & 0x200000000) | (W.Flags & 0x200), 
                W.Flags & 16384, 
                ALP.TitleResource, 
                ALP.DescriptionResource
            FROM
                TVF_Webs_SiteId(@SiteId) AS W
            CROSS APPLY
                TVF_Lists_WebId(W.SiteId, W.Id) AS L
            OUTER APPLY
                TVF_AllListsPlus_ListId(L.tp_SiteId, L.tp_ID) AS ALP
            WHERE
                (L.tp_WebId = @WebId OR W.FullUrl LIKE @WebUrlLike) AND
                (@BaseType = -1 OR L.tp_BaseType = @BaseType) AND
                (@ServerTemplate = -1 OR
                    L.tp_ServerTemplate = @ServerTemplate) AND
                ((@IncludeHidden = 1) OR ((L.tp_Flags & 256) = 0))
            OPTION (FORCE ORDER)
        END
        ELSE 
        BEGIN
            INSERT INTO 
                @ListIdTable
            SELECT DISTINCT
                L.tp_ID,
                L.tp_HasFGP,
                L.tp_HasInternalFGP,
                L.tp_ScopeId,
                L.tp_RootFolder,
                L.tp_WebId, 
                W.FullUrl, 
                W.Title, 
                W.WebTemplate, 
                W.Language, 
                W.Collation, 
                (L.tp_Flags & 0x200000000) | (W.Flags & 0x200), 
                W.Flags & 16384, 
                ALP.TitleResource, 
                ALP.DescriptionResource
            FROM
                TVF_Webs_Id(@SiteId, @WebId) AS W
            CROSS APPLY
                TVF_Lists_WebId(W.SiteId, W.Id) AS L
            OUTER APPLY
                TVF_AllListsPlus_ListId(L.tp_SiteId, L.tp_ID) AS ALP
            WHERE
                (@BaseType = -1 OR L.tp_BaseType = @BaseType) AND
                (@ServerTemplate = -1 OR
                    L.tp_ServerTemplate = @ServerTemplate) AND
                ((@IncludeHidden = 1) OR ((L.tp_Flags & 256) = 0))
            OPTION (FORCE ORDER)
        END
    END
    DECLARE @ListsInBatch int
    SET @ListsInBatch = @@ROWCOUNT
    IF (@MaxLists > 0) AND (@ListsInBatch > @MaxLists)
    BEGIN
        SELECT -1
        RETURN 68
    END
    ELSE
    BEGIN
        SELECT @ListsInBatch
    END
    SELECT
        Lists.tp_ID,
        Lists.tp_Title,
        ALAux.Modified AS tp_Modified,
        Lists.tp_Created,
        ALAux.LastDeleted AS tp_LastDeleted,
        Lists.tp_Version,
        Lists.tp_BaseType,
        Lists.tp_FeatureId,
        Lists.tp_ServerTemplate,
        AllDocs1.DirName,        
        AllDocs1.LeafName,
        AllDocs2.DirName,        
        AllDocs2.LeafName,
        Lists.tp_ReadSecurity,
        Lists.tp_WriteSecurity,
        Lists.tp_Description,
        CASE WHEN
            ListManifest.tp_CachedSchema <> 0
        THEN
             NULL
        ELSE
             Lists.tp_Fields
        END,
        Lists.tp_Direction,
        CASE WHEN Lists.tp_ScopeId = @WebScopeId 
             THEN NULL
             ELSE Perms.AnonymousPermMask
        END,
        Lists.tp_Flags,
        Lists.tp_ThumbnailSize,
        Lists.tp_WebImageWidth,
        Lists.tp_WebImageHeight,
        Lists.tp_ImageUrl,
        ALAux.ItemCount AS tp_ItemCount,
        Lists.tp_Author,
        Lists.tp_HasInternalFGP,
        Lists.tp_ScopeId,
        CASE WHEN Lists.tp_ScopeId = @WebScopeId 
             THEN NULL
             ELSE Perms.Acl
        END,
        Lists.tp_EventSinkAssembly,
        Lists.tp_EventSinkClass,
        Lists.tp_EventSinkData,
        Lists.tp_EmailAlias,
        N'/' + ListManifest.tp_WebFullUrl,
        ListManifest.tp_WebId,
        ListManifest.tp_WebTitle,
        ListManifest.tp_WebTemplate,
        ListManifest.tp_WebLanguage,
        ListManifest.tp_WebCollation,
        Lists.tp_SendToLocation,
        ISNULL(Lists.tp_MaxMajorVersionCount, 0),
        ISNULL(Lists.tp_MaxMajorwithMinorVersionCount, 0),
        Lists.tp_MaxRowOrdinal,
        Lists.tp_ListDataDirty,
        Lists.tp_DefaultWorkflowId,
        CAST((CASE WHEN 
            ListManifest.tp_CheckForTranLock <> 0
        THEN
            CASE WHEN EXISTS( SELECT TOP 1 1 FROM TVF_AllLookupRelationships_SiteLookupList(@SiteId, Lists.tp_ID) AS ALR CROSS APPLY TVF_Lists_CI(@SiteId, @WebId, ALR.ListId) WHERE ALR.DeleteBehavior <> 0) THEN 1 ELSE 0 END
        ELSE
            0
        END)as bit),
        CASE WHEN
             ListManifest.tp_CachedSchema <> 0
        THEN
             NULL
        ELSE
             Lists.tp_ContentTypes
        END,
        Lists.tp_Subscribed,
        AllDocs1.ItemChildCount + AllDocs1.FolderChildCount,
        Lists.tp_NoThrottleListOperations,
        ListManifest.tp_TitleResource,
        ListManifest.tp_DescriptionResource,
        NULL AS tp_ValidationFormula,
        NULL AS tp_ValidationMessage,
        ALAux.Followable
    FROM
        @ListIdTable AS ListManifest
    CROSS APPLY
        TVF_Lists_CI(@SiteId, ListManifest.tp_WebId, ListManifest.tp_ListId) AS Lists
    CROSS APPLY
        TVF_AllListsAux_NoLock_ListId(Lists.tp_SiteId, Lists.tp_ID) AS ALAux
    CROSS APPLY
        TVF_Perms_ScopeId(Lists.tp_SiteId, Lists.tp_ScopeId) AS Perms
    CROSS APPLY
        TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_RootFolder, 1) AS AllDocs1
    OUTER APPLY
        TVF_AllDocs_NoLock_Id_Level(Lists.tp_SiteId, Lists.tp_Template, 1) AS AllDocs2
    ORDER BY
        Lists.tp_ID
    OPTION (FORCE ORDER)
    IF @@ROWCOUNT = 0
    BEGIN
        RETURN 0
    END
    SELECT
        ER.Id, ER.Name, ER.SiteId, ER.WebId, ER.HostId, ER.HostType, ER.ItemId, ER.DirName, ER.LeafName, ER.Synchronization, ER.Type, ER.SequenceNumber, ER.RemoteUrl, ER.Assembly, ER.Class, ER.SolutionId, ER.Data, ER.Filter, ER.SourceId, ER.SourceType, ER.Credential, ER.ContextType, ER.ContextEventType, ER.ContextId, ER.ContextObjectId, ER.ContextCollectionId,
        S.Hash, S.ValidatorsHash, S.ValidationErrorUrl, S.ValidationErrorMessage
    FROM
        @ListIdTable AS ListManifest
    CROSS APPLY
        TVF_EventReceivers_SiteWebHost(
            @SiteId, 
            ListManifest.tp_WebId, 
            ListManifest.tp_ListId) AS ER
    OUTER APPLY
        TVF_Solutions_PTCSolution(
            ER.SiteId,
            ER.SolutionId) AS S
    WHERE
        ER.HostType = 2
    OPTION (FORCE ORDER)
    IF (@PrefetchListScopes = 1)
    BEGIN
        IF @ThresholdRowCount = 0 
            SET @ThresholdRowCount = -1
        SELECT
            tp_ListId AS ListId,
            0x0 AS ScopeId,
            NULL AS Acl,
            0 AS AnonymousPermMask
        FROM 
            @ListIdTable AS ListManifest
        WHERE
            tp_HasFGP = 0
        UNION ALL
        SELECT
            ListManifest.tp_ListId AS ListId, 
            P.ScopeId AS ScopeId,
            P.Acl AS Acl,
            P.AnonymousPermMask AS AnonymousPermMask
        FROM 
            @ListIdTable AS ListManifest
        CROSS APPLY
            TVF_Perms_ScopeId(@SiteId, ListManifest.tp_ScopeId) AS P
        WHERE
            ListManifest.tp_HasFGP = 1
        UNION ALL
        SELECT TOP (@ThresholdRowCount)
            ListManifest.tp_ListId AS ListId, 
            P.ScopeId AS ScopeId,
            P.Acl AS Acl,
            P.AnonymousPermMask AS AnonymousPermMask
        FROM 
            @ListIdTable AS ListManifest
        CROSS APPLY
            TVF_AllDocs_Id_Level(@SiteId, ListManifest.tp_RootFolder, 1) AS AD
        CROSS APPLY
            TVF_Perms_ScopeUrlLike(
                AD.SiteId, 
                dbo.fn_EscapeForLike(
                    CASE WHEN (DATALENGTH(AD.DirName) = 0) THEN AD.LeafName WHEN (DATALENGTH(AD.LeafName) = 0) THEN AD.DirName ELSE AD.DirName + N'/' + AD.LeafName END, 
                    1) COLLATE Latin1_General_CI_AS_KS_WS) AS P
        WHERE            
            ListManifest.tp_HasInternalFGP = 1
        OPTION (FORCE ORDER)
    END

go

