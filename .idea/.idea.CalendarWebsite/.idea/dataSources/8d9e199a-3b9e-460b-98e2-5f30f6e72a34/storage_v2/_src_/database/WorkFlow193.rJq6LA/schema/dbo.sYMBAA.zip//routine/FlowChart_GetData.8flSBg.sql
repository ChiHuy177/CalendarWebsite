
CREATE PROC [dbo].[FlowChart_GetData] @nodeid AS NVARCHAR(500)
AS
SELECT tab.*
FROM DYNAMIC.Workflow_FOLLOWCHART AS Tab
CROSS APPLY OPENJSON(Tab.data, N'$') WITH (nodeid NVARCHAR(500) N'$.nodeid') AS a
WHERE ISNULL(a.nodeid, '') = @nodeid
go

