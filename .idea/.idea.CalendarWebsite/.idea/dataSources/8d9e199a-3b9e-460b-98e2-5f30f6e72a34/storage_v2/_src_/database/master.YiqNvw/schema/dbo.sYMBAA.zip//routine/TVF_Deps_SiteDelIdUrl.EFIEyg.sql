CREATE FUNCTION [dbo].[TVF_Deps_SiteDelIdUrl]
(
    @SiteId uniqueidentifier,
    @DeleteTransactionId varbinary(16),
    @FullUrl nvarchar(260)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Deps] WITH (INDEX=Deps_DocToDep, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DeleteTransactionId = @DeleteTransactionId AND
        FullUrl = @FullUrl

go

