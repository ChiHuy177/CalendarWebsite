CREATE PROCEDURE [dbo].[proc_SecSetSiteGroupProperties](
    @SiteId         uniqueidentifier,
    @GroupId        int,
    @Title          nvarchar(255),
    @Description    nvarchar(512),
    @OwnerId        int,
    @OwnerIsUser    bit,
    @UserId         int,
    @SiteAdmin      bit,
    @GroupOwnerId   int,
    @CurrentUserIsOwner bit,
    @DLAlias        nvarchar(255),
    @DLErrorMessage nvarchar(255),
    @DLFlags        int,
    @DLJobId        int,
    @DLArchives     varchar(4000),
    @RequestEmail   nvarchar(255),
    @Flags          int,
    @RequestGuid    uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    IF dbo.fn_CanUserManageGroup(@SiteId, @UserId, @SiteAdmin, @GroupId, @GroupOwnerId, @CurrentUserIsOwner) = 0 RETURN 5
    UPDATE
        G
    SET
        G.Title = @Title,
        G.Description = @Description,
        G.Owner = @OwnerId,
        G.OwnerIsUser = @OwnerIsUser,
        G.DLAlias = @DLAlias,
        G.DLErrorMessage = @DLErrorMessage,
        G.DLFlags = @DLFlags,
        G.DLJobId = @DLJobId,
        G.DLArchives = @DLArchives,
        G.RequestEmail = @RequestEmail,
        G.Flags = @Flags
    FROM
        TVF_Groups_PK(@SiteId, @GroupId) AS G
    IF (0 <> @@ERROR)
    BEGIN
        RETURN 80
    END
    ELSE
    BEGIN
    IF (@OwnerIsUser = 1)
    BEGIN
        EXEC proc_SecUpdateUserActiveStatus @SiteId, @OwnerId, @RequestGuid OUTPUT
    END
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, @GroupId,
        NULL, 8192, 256, NULL
        RETURN 0
    END

go

