CREATE PROCEDURE [dbo].[proc_DeleteRecycleBinItem](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @UserId int,
    @AppPrincipalId int,
    @ThresholdRowCount int,
    @DeleteTransactionId varbinary(16),
    @RequestGuid uniqueidentifier = NULL OUTPUT     
    )
AS
    SET NOCOUNT ON
    DECLARE @DeleteUserId int
    DECLARE @ItemType tinyint
    DECLARE @OriginalItemType tinyint
    DECLARE @DeleteItemType tinyint
    DECLARE @DocId uniqueidentifier
    DECLARE @DocVersionId int
    DECLARE @ListId uniqueidentifier
    DECLARE @ListItemId int
    DECLARE @ChildDeleteTransactionId varbinary(16)
    DECLARE @FreedSpace bigint
    DECLARE @FreedRecycleBinSpace bigint
    DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
    IF (@UserId = 0)
    BEGIN
        SELECT TOP 1
            @WebId = R.WebId,
            @DeleteUserId = R.DeleteUserId,
            @ItemType = R.ItemType,
            @OriginalItemType = R.OriginalItemType,
            @DocId = R.DocId,
            @DocVersionId = R.DocVersionId,
            @ListId = R.ListId,
            @ListItemId = R.ListItemId,
            @FreedSpace =
                CASE
                WHEN R.BinId <> 2 THEN 
                    (SELECT SUM(R2.Size)
                        FROM TVF_RecycleBin_DelId(R.SiteId, R.DeleteTransactionId) AS R2)
                ELSE 0
                END,
            @FreedRecycleBinSpace =
                CASE
                WHEN R.BinId = 2 THEN 
                    (SELECT SUM(R3.Size)
                        FROM TVF_RecycleBin_DelId(R.SiteId, R.DeleteTransactionId) AS R3)
                ELSE 0
                END
        FROM
            TVF_RecycleBin_DelIdChildId(@SiteId, @DeleteTransactionId, 0x) AS R
        IF (@@ROWCOUNT <> 1)
        BEGIN
            SET @Ret = 1168
            GOTO cleanup
        END
    END
    ELSE
    BEGIN
        SELECT TOP 1
            @ItemType = R.ItemType,
            @OriginalItemType = R.OriginalItemType,
            @DocId = R.DocId,
            @DocVersionId = R.DocVersionId,
            @ListId = R.ListId,
            @ListItemId = R.ListItemId,
            @FreedSpace =
                CASE
                    WHEN R.BinId <> 2 THEN 
                       (SELECT SUM(R2.Size)
                        FROM TVF_RecycleBin_DelId(R.SiteId, R.DeleteTransactionId) AS R2)
                    ELSE 0
                END,
            @FreedRecycleBinSpace =
                CASE
                    WHEN R.BinId = 2 THEN 
                       (SELECT SUM(R3.Size)
                        FROM TVF_RecycleBin_DelId(R.SiteId, R.DeleteTransactionId) AS R3)
                    ELSE 0
                END
        FROM
            TVF_RecycleBin_DelIdChildId(@SiteId, @DeleteTransactionId, 0x) AS R
        WHERE
            R.WebId = @WebId AND
            R.DeleteUserId = @UserId
        IF (@@ROWCOUNT <> 1)
        BEGIN
            SET @Ret = 1168
            GOTO cleanup
        END
        SET @DeleteUserId = @UserId
    END
    IF ((@ThresholdRowCount > 0) AND (@ItemType = 4 OR
                @ItemType = 5 OR
                @ItemType = 6))
    BEGIN
        DECLARE   @Count int
        SET @Count = 0
        SELECT TOP (@ThresholdRowCount + 1)
            @Count = count(1) 
        FROM
            TVF_AllDocs_SiteDelTransId(@SiteId, @DeleteTransactionId) AS AD
        WHERE
            AD.Level = 1
        IF @Count > @ThresholdRowCount
        BEGIN
            SET @Ret = 36
            GOTO cleanup
        END
    END
    IF (@ItemType = 9)
    BEGIN
        DECLARE @ItemsToDelete TABLE
        (
            ItemType tinyint,
            OriginalItemType tinyint,
            ListId uniqueidentifier,
            ListItemId int,
            DocId uniqueidentifier,
            DocVersionId int,
            DirName nvarchar(256),
            LeafName nvarchar(256),
            ChildDeleteTransactionId varbinary(16)
        );
        INSERT INTO @ItemsToDelete
        SELECT 
            R.ItemType, 
            R.OriginalItemType, 
            R.ListId, 
            R.ListItemId, 
            R.DocId, 
            R.DocVersionId,
            R.DirName,
            R.LeafName,
            R.ChildDeleteTransactionId
        FROM 
            TVF_RecycleBin_DelId(@SiteId, @DeleteTransactionId) AS R
        WHERE
            R.WebId = @WebId
        DECLARE @DeleteTask CURSOR
        SET @DeleteTask = CURSOR LOCAL FAST_FORWARD FOR
        SELECT 
            ItemType, OriginalItemType, ListId, ListItemId, DocId, DocVersionId, ChildDeleteTransactionId
        FROM 
            @ItemsToDelete
        ORDER BY 
            DirName DESC
        OPEN @DeleteTask
        IF @@CURSOR_ROWS <> 0
        BEGIN
            FETCH NEXT FROM 
                @DeleteTask 
            INTO 
                @ItemType, @OriginalItemType, @ListId, @ListItemId, @DocId, 
                @DocVersionId, @ChildDeleteTransactionId;
            WHILE @@FETCH_STATUS = 0
            BEGIN
                SET @DeleteItemType = CASE 
                        WHEN (@ItemType = 9) 
                        THEN @OriginalItemType 
                        ELSE @ItemType
                    END;
                EXEC @Ret = proc_DeleteOneRecycleBinItem
                    @SiteId,
                    @WebId,
                    @DeleteUserId,
                    @DeleteItemType,
                    @ListId,
                    @ListItemId,
                    @DocId,
                    @DocVersionId,
                    @ThresholdRowCount,
                    @DeleteTransactionId,
                    @ChildDeleteTransactionId, 
                    @FreedSpace OUTPUT,
                    @FreedRecycleBinSpace OUTPUT;
                IF (@Ret <> 0)
                    BREAK;
                FETCH NEXT FROM 
                    @DeleteTask 
                INTO 
                    @ItemType, @OriginalItemType, @ListId, @ListItemId, 
                    @DocId, @DocVersionId, @ChildDeleteTransactionId;
            END
        END
        CLOSE @DeleteTask
        DEALLOCATE @DeleteTask
    END
    ELSE 
    BEGIN
        EXEC @Ret = proc_DeleteOneRecycleBinItem
            @SiteId,
            @WebId,
            @DeleteUserId,
            @ItemType,
            @ListId,
            @ListItemId,
            @DocId,
            @DocVersionId,
            @ThresholdRowCount, 
            @DeleteTransactionId,
            0x, 
            @FreedSpace OUTPUT,
            @FreedRecycleBinSpace OUTPUT;
    END
    IF (@Ret = 0)
    BEGIN
        DELETE 
            R
        FROM
            TVF_RecycleBin_DelId(@SiteId, @DeleteTransactionId) AS R
        WHERE
            R.WebId = @WebId
    END
cleanup:
    IF (@Ret = 0)
    BEGIN
        IF (@FreedSpace > 0)
        BEGIN
            SET @FreedSpace = -@FreedSpace
            EXEC proc_AppendSiteQuota 
                @SiteId, @FreedSpace, 1, NULL
        END
        IF (@FreedRecycleBinSpace > 0)
        BEGIN
            UPDATE
                S
            SET
                S.SecondStageDiskUsed = S.SecondStageDiskUsed - @FreedRecycleBinSpace
            FROM
                TVF_Sites_Id(@SiteId) AS S
        END
        EXEC proc_UpdateDiskUsed @SiteId
    END
    IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @Ret

go

