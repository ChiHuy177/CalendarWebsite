CREATE PROCEDURE [dbo].[proc_DTClearRelationshipFromParent](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @ParentLeafName nvarchar(128)
)
AS
    SET NOCOUNT ON
    DECLARE @FullParentUrl nvarchar(260)
    SET @FullParentUrl = CASE WHEN (DATALENGTH(@DirName) = 0) THEN @ParentLeafName WHEN (DATALENGTH(@ParentLeafName) = 0) THEN @DirName ELSE @DirName + N'/' + @ParentLeafName END
    UPDATE
        Docs
    SET
        Docs.ParentVersion = NULL,
        Docs.TransformerId = NULL,
        Docs.ParentLeafName = NULL
    FROM 
        TVF_Deps_UpdLock_SiteDescType(@SiteId, @FullParentUrl, 8) AS Deps
    CROSS APPLY
        TVF_Docs_Url(Deps.SiteId, CASE WHEN (CHARINDEX(N'/', REVERSE(Deps.FullUrl)) > 0) THEN LEFT(Deps.FullUrl, DATALENGTH(Deps.FullUrl)/2 - CHARINDEX(N'/', REVERSE(Deps.FullUrl) COLLATE Latin1_General_BIN)) ELSE N'' END, CASE WHEN (CHARINDEX(N'/', REVERSE(Deps.FullUrl) COLLATE Latin1_General_BIN) > 0) THEN RIGHT(Deps.FullUrl, CHARINDEX(N'/', REVERSE(Deps.FullUrl) COLLATE Latin1_General_BIN) - 1) ELSE Deps.FullUrl END) AS Docs
    WHERE
        Deps.DeleteTransactionId = 0x
    DELETE FROM
        TVF_Deps_SiteDescType(@SiteId, @FullParentUrl, 8)

go

