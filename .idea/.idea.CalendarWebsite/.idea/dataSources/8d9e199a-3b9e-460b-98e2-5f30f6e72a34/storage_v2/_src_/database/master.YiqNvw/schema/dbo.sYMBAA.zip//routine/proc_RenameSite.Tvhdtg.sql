CREATE PROCEDURE [dbo].[proc_RenameSite](
    @SiteId uniqueidentifier,
    @OldUrl nvarchar(260),
    @NewUrl nvarchar(260),
    @SiteFullUrl nvarchar(260),
    @useHostHeaderSite bit,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @OldUrlDirName nvarchar(256)
    DECLARE @NewUrlDirName nvarchar(256)
    DECLARE @OldUrlLeafName nvarchar(128)
    DECLARE @NewUrlLeafName nvarchar(128)
    DECLARE @RowCount int, @ErrorCode int
    DECLARE @OldUrlLike nvarchar(1024)
    EXEC proc_SplitUrl
        @OldUrl,
        @OldUrlDirName OUTPUT,
        @OldUrlLeafName OUTPUT
    EXEC proc_SplitUrl
        @NewUrl,
        @NewUrlDirName OUTPUT,
        @NewUrlLeafName OUTPUT
    DECLARE @SlashOffset int
    SET @SlashOffset = CASE
        WHEN
            LEN(@NewUrl) <> 0 OR LEN(@OldUrl) = 0
        THEN
            0
        ELSE
            1
        END
    IF LEN(@OldUrl) <> 0
    BEGIN
        EXEC proc_EscapeForLike @OldUrl, @OldUrlLike OUTPUT
    END
    ELSE
    BEGIN
        SET @OldUrlLike = '%'
    END
    DECLARE @Delta int
    SET @Delta = (DATALENGTH(@NewUrl) - DATALENGTH(@OldUrl))/2
    UPDATE
        Docs
    SET
        DirName = COALESCE(
            CASE
            WHEN
                (DirName=@OldUrlDirName AND
                LeafName=@OldUrlLeafName)
            THEN 
                @NewUrlDirName
            ELSE
                CASE
                WHEN
                    LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
                THEN 
                    STUFF(DirName, 1,
                    LEN(@OldUrl), @NewUrl+N'/')
                ELSE 
                    STUFF(DirName, 1,
                    LEN(@OldUrl) + @SlashOffset, @NewUrl)
                END
            END,
            @NewUrl),
        LeafName = COALESCE(
            CASE
            WHEN
                (DirName=@OldUrlDirName AND
                LeafName=@OldUrlLeafName)
            THEN
                @NewUrlLeafName
            ELSE
                LeafName
            END,
            LeafName
            ),
        Docs.BumpVersion = CASE WHEN (CAST(1 AS bit)) = CAST(0 AS bit) THEN Docs.BumpVersion WHEN CASE WHEN Docs.DocFlags IS NULL OR (Docs.DocFlags & 4) = 0 THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END = CAST(0 AS bit) THEN Docs.BumpVersion WHEN Docs.BumpVersion > 250 THEN 1 ELSE Docs.BumpVersion + 1 END, Docs.ContentVersion = CASE WHEN (CAST(1 AS bit)) = CAST(0 AS bit) THEN Docs.ContentVersion ELSE CASE WHEN CASE WHEN Docs.DocFlags IS NULL OR (Docs.DocFlags & 4) = 0 THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END = CAST(0 AS bit) THEN Docs.ContentVersion ELSE Docs.ContentVersion + 1 END END,
        BuildDependencySet = NULL,
        CtoOffset = 
                    CASE 
                    WHEN CtoOffset IS NULL THEN NULL
                    ELSE CtoOffset + @Delta
                    END           
    FROM
        TVF_Docs_Site(@SiteId) AS Docs
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 1) BEGIN RETURN 1003 END END
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
        32768,  8, NULL, NULL, NULL, NULL, 
        NULL, NULL, @RequestGuid OUTPUT
    UPDATE
        Webs
    SET
        FullUrl = COALESCE(
            CASE
            WHEN
                LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
            THEN  
                STUFF(FullUrl, 1,
                LEN(@OldUrl), @NewUrl+N'/')
            ELSE  
                STUFF(FullUrl, 1,
                LEN(@OldUrl) + @SlashOffset, @NewUrl)
            END,  
            @NewUrl),
        Ancestry = NULL, 
        MasterUrl = COALESCE(
            CASE
            WHEN
                LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
            THEN  
                STUFF(MasterUrl, 1,
                LEN(@OldUrl), @NewUrl+N'/')
            ELSE  
                STUFF(MasterUrl, 1,
                LEN(@OldUrl) + @SlashOffset, @NewUrl)
            END,  
            MasterUrl),
        CustomMasterUrl = COALESCE(
            CASE
            WHEN
                LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
            THEN  
                STUFF(CustomMasterUrl, 1,
                LEN(@OldUrl), @NewUrl+N'/')
            ELSE  
                STUFF(CustomMasterUrl, 1,
                LEN(@OldUrl) + @SlashOffset, @NewUrl)
            END,  
            CustomMasterUrl),
        CachedNavDirty = 1     
    FROM
        TVF_Webs_SiteId(@SiteId) AS Webs
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 1) BEGIN RETURN 1003 END END
    UPDATE
        CT
    SET
        CT.Scope = COALESCE(
            CASE
            WHEN
                LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
            THEN  
                STUFF(CT.Scope, 1,
                LEN(@OldUrl), @NewUrl+N'/')
            ELSE  
                STUFF(CT.Scope, 1,
                LEN(@OldUrl) + @SlashOffset, @NewUrl)
            END,  
            @NewUrl)
    FROM
        TVF_ContentTypes_Site(@SiteId) AS CT
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 1) BEGIN RETURN 1003 END END
    UPDATE
        Perms
    SET
        ScopeUrl = COALESCE(
            CASE
            WHEN
                LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
            THEN  
                STUFF(ScopeUrl, 1,
                LEN(@OldUrl), @NewUrl+N'/')
            ELSE  
                STUFF(ScopeUrl, 1,
                LEN(@OldUrl) + @SlashOffset, @NewUrl)
            END,  
            @NewUrl)
    FROM
        TVF_Perms_Site(@SiteId) AS Perms
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 1) BEGIN RETURN 1003 END END
    SELECT
        @RowCount = COUNT(1)
    FROM 
        TVF_Docs_Site(@SiteId) AS D
    WHERE
        LEN(CASE WHEN (DATALENGTH(D.DirName) = 0) THEN D.LeafName WHEN (DATALENGTH(D.LeafName) = 0) THEN D.DirName ELSE D.DirName + N'/' + D.LeafName END) > 260
    IF(@RowCount > 0)
    BEGIN
        RETURN 206
    END
    EXEC proc_DirtyDependents @SiteId, 1, NULL, @OldUrlLike, @RequestGuid = @RequestGuid OUTPUT
    EXEC @ErrorCode  =
        proc_DirtyListData @SiteId, @OldUrlDirName, @OldUrlLeafName, 1
    IF @ErrorCode  <> 0
    BEGIN
        RETURN @ErrorCode 
    END
    UPDATE
        Links
    SET
        TargetDirName = COALESCE(
            CASE
            WHEN
                (TargetDirName=@OldUrlDirName AND
                TargetLeafName=@OldUrlLeafName)
            THEN 
                LEFT(@NewUrlDirName, 256)
            ELSE
                CASE
                WHEN
                    LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
                THEN 
                    LEFT(STUFF(TargetDirName, 1,
                    LEN(@OldUrl), @NewUrl+N'/'), 256)
                ELSE 
                    LEFT(STUFF(TargetDirName, 1,
                    LEN(@OldUrl) + @SlashOffset, @NewUrl), 256)
                END
            END,
            @NewUrl),
        TargetLeafName = COALESCE(
            CASE
            WHEN
                (TargetDirName=@OldUrlDirName AND
                TargetLeafName=@OldUrlLeafName)
            THEN
                @NewUrlLeafName
            ELSE
                TargetLeafName
            END,
            TargetLeafName
            )
    FROM
        TVF_Links_TargetUrlNotPointsToDir(@SiteId, @OldUrlDirName, @OldUrlLeafName) AS Links
    WHERE
        Links.ServerRel = 1
    UPDATE
        Links
    SET
        TargetDirName = COALESCE(
            CASE
            WHEN
                (TargetDirName=@OldUrlDirName AND
                TargetLeafName=@OldUrlLeafName)
            THEN 
                LEFT(@NewUrlDirName, 256)
            ELSE
                CASE
                WHEN
                    LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
                THEN 
                    LEFT(STUFF(TargetDirName, 1,
                    LEN(@OldUrl), @NewUrl+N'/'), 256)
                ELSE 
                    LEFT(STUFF(TargetDirName, 1,
                    LEN(@OldUrl) + @SlashOffset, @NewUrl), 256)
                END
            END,
            @NewUrl),
        TargetLeafName = COALESCE(
            CASE
            WHEN
                (TargetDirName=@OldUrlDirName AND
                TargetLeafName=@OldUrlLeafName)
            THEN
                @NewUrlLeafName
            ELSE
                TargetLeafName
            END,
            TargetLeafName
            )
    FROM
        TVF_Links_TargetUrlPointsToDir(@SiteId, @OldUrlDirName, @OldUrlLeafName) AS Links
    WHERE
        Links.ServerRel = 1    
    UPDATE
        Links
    SET
        TargetDirName = COALESCE(
            CASE
            WHEN
                (TargetDirName=@OldUrlDirName AND
                TargetLeafName=@OldUrlLeafName)
            THEN 
                LEFT(@NewUrlDirName, 256)
            ELSE
                CASE
                WHEN
                    LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
                THEN 
                    LEFT(STUFF(TargetDirName, 1,
                    LEN(@OldUrl), @NewUrl+N'/'), 256)
                ELSE 
                    LEFT(STUFF(TargetDirName, 1,
                    LEN(@OldUrl) + @SlashOffset, @NewUrl), 256)
                END
            END,
            @NewUrl),
        TargetLeafName = COALESCE(
            CASE
            WHEN
                (TargetDirName=@OldUrlDirName AND
                TargetLeafName=@OldUrlLeafName)
            THEN
                @NewUrlLeafName
            ELSE
                TargetLeafName
            END,
            TargetLeafName
            )
    FROM
        TVF_Links_TargetDirNameEqLike_NotForDelete(@SiteId, @OldUrl, @OldUrlLike) AS Links
    WHERE
        Links.ServerRel = 1
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 0) BEGIN RETURN 1003 END END
    UPDATE
        Deps
    SET
        FullUrl = COALESCE(
            CASE
            WHEN
                LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
            THEN  
                STUFF(FullUrl, 1,
                LEN(@OldUrl), @NewUrl+N'/')
            ELSE  
                STUFF(FullUrl, 1,
                LEN(@OldUrl) + @SlashOffset, @NewUrl)
            END,  
            @NewUrl)
    FROM
        TVF_Deps_SiteDelIdUrlEqLike_NotForDelete(@SiteId, 0x, @OldUrl, @OldUrlLike) AS Deps
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 0) BEGIN RETURN 1003 END END
    UPDATE
        Deps
    SET
        DepDesc = COALESCE(
            CASE
            WHEN
                LEN(@OldUrl) = 0 AND LEN(@NewUrl) <> 0
            THEN  
                STUFF(DepDesc, 1,
                LEN(@OldUrl), @NewUrl+N'/')
            ELSE  
                STUFF(DepDesc, 1,
                LEN(@OldUrl) + @SlashOffset, @NewUrl)
            END,  
            @NewUrl)
    FROM
        TVF_Deps_SiteDescEqLike_NotForDelete(@SiteId, @OldUrl, @OldUrlLike) AS Deps
    WHERE
        DeleteTransactionId = 0x AND
        (DepType = 1 OR DepType = 8)
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 0) BEGIN RETURN 1003 END END
    DECLARE @NewSiteUrl nvarchar(260)
    DECLARE @OldWebUrl nvarchar(1024)
    DECLARE @NewWebUrl nvarchar(1024)
    DECLARE @OldWebUrlLike nvarchar(1024)
    IF (@OldUrl = N'')
    BEGIN
        SET @OldWebUrl = N''
        SET @OldWebUrlLike = @OldUrlLike
    END
    ELSE
    BEGIN
        SET @OldWebUrl = N'/' + @OldUrl
        SET @OldWebUrlLike = N'/' + @OldUrlLike
    END
    SET @NewWebUrl = CASE WHEN @NewUrl = N'' THEN N''
        ELSE N'/' + @NewUrl
        END
    UPDATE
        I
    SET
        I.SiteUrl = @SiteFullUrl
    FROM
        TVF_ImmedSubscriptions_SiteId(@SiteId) AS I
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 0) BEGIN RETURN 1003 END END
    UPDATE
        S
    SET
        S.SiteUrl = @SiteFullUrl
    FROM
        TVF_SchedSubscriptions_SiteId(@SiteId) AS S
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 0) BEGIN RETURN 1003 END END
    UPDATE
        I
    SET
        I.WebUrl = COALESCE(
            STUFF(I.WebUrl, 1, LEN(@OldWebUrl), @NewWebUrl),
            @NewWebUrl)
    FROM
        TVF_ImmedSubscriptions_SiteIdWebUrl(@SiteId, @OldWebUrl) AS I
    UPDATE
        I
    SET
        I.WebUrl = COALESCE(
            STUFF(I.WebUrl, 1, LEN(@OldWebUrl), @NewWebUrl),
            @NewWebUrl)
    FROM
        TVF_ImmedSubscriptions_SiteIdLikeWebUrl(@SiteId, @OldWebUrlLike) AS I
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 0) BEGIN RETURN 1003 END END
    UPDATE
        S
    SET
        S.WebUrl = COALESCE(
            STUFF(S.WebUrl, 1, LEN(@OldWebUrl), @NewWebUrl),
            @NewWebUrl)
    FROM
        TVF_SchedSubscriptions_SiteIdWebUrl(@SiteId, @OldWebUrl) AS S
    UPDATE
        S
    SET
        S.WebUrl = COALESCE(
            STUFF(S.WebUrl, 1, LEN(@OldWebUrl), @NewWebUrl),
            @NewWebUrl)
    FROM
        TVF_SchedSubscriptions_SiteIdLikeWebUrl(@SiteId, @OldWebUrlLike) AS S
    SELECT @RowCount=@@ROWCOUNT,@ErrorCode=@@ERROR IF(@ErrorCode = 8152) BEGIN RETURN 206 END ELSE BEGIN IF(@ErrorCode <> 0 OR @RowCount < 0) BEGIN RETURN 1003 END END
    DELETE
        BD
    FROM
        TVF_BuildDependencies_Site(@SiteId) AS BD
    IF (@useHostHeaderSite=0)
        UPDATE
            S
        SET
            S.HostHeader = NULL
        FROM
            TVF_Sites_Id(@SiteId) AS S

go

