CREATE FUNCTION [dbo].[TVF_DocStreams_RbsIdNotNull]
(
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[DocStreams] WITH (INDEX=DocStreams_RbsId)
    WHERE
        RbsId IS NOT NULL

go

