CREATE PROC [dbo].[proc_IsContentTypeInUse](
    @SiteId uniqueidentifier,
    @Class tinyint,
    @ContentTypeId tContentTypeId)
AS
    SET NOCOUNT ON    
    IF @Class = 1
    BEGIN
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_ContentTypes_SiteClassCTIdLEQCTIdGT(
                    @SiteId, 
                    @Class, 
                    @ContentTypeId + 0xFF, 
                    @ContentTypeId))
        BEGIN
            RETURN 1
        END
        IF EXISTS (
            SELECT TOP 1
                1
            FROM 
                TVF_ContentTypeUsage_SiteIsFClassCTIdLEQCTIdGEQ(
                    @SiteId,
                    0, 
                    @Class,
                    @ContentTypeId + 0xFF,
                    @ContentTypeId))
        BEGIN
            RETURN 1
        END
    END
    ELSE IF @Class = 0
    BEGIN
        IF EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_ContentTypeUsage_SiteIsFClassCTId(
                    @SiteId,
                    0, 
                    @Class,
                    @ContentTypeId))
        BEGIN
            RETURN 1
        END
        IF EXISTS (
            SELECT TOP 1
                1
            FROM
                TVF_ContentTypeUsage_SiteIsFListClass(
                    @SiteId,
                    1, 
                    cast(@ContentTypeId as uniqueidentifier),
                    @Class))
        BEGIN
            RETURN 1
        END
    END
    RETURN 0

go

