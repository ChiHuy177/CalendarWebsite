CREATE FUNCTION [dbo].[TVF_NavNodes_SiteWebParentLEQRank]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @EidParent int,
    @LEQRankChild int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NavNodes] WITH (INDEX=NavNodes_AltPK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId AND
        EidParent = @EidParent AND
        RankChild <= @LEQRankChild

go

