CREATE   PROC [dbo].[CRM_GetCustomerDetail]                 
 @id as bigint                 
 as                  
 select     
  a.[Id]  
       ,a.[UserWorkflowId]  
       ,[ID_Source] as IdSource  
       ,a.[CountryRegionCode]  
       ,a.[Code]  
       ,a.[Name]  
       ,[ShortName]  
       ,[Address]  
       ,[Fax]  
       ,[Mobile]  
       ,[PhoneNumber]  
       ,[Email]  
       ,[TaxNumber]  
       ,[IdentityCard]  
       ,[IndentityCreate]  
       ,[IndentityAddress]  
       ,a.[Description]  
       ,[BirthDay]  
       ,[Website]  
       ,[BankAccount]  
       ,[BankName]  
       ,[DistrictID]  
       ,[VillageID]  
       ,[StreetID]  
       ,[HouseNumber]  
       ,[AddressOffice]  
       ,[AddressDelivery]  
       ,[ProposalDueDate]  
       ,[Rating]  
       ,[Budget]  
       ,[BackgroundInfo]  
       ,[Type]  
       ,[AreaID]  
       ,[Note]  
       ,[UserManager]  
       ,[Sex]  
       ,[BusinessLicense]  
       ,[PlaceLicense]  
       ,[DateLicense]  
       ,[Representative]  
       ,[Postion]  
       ,[Reference]  
       ,[ParentID]  
       ,[OldId]  
       ,[TicketCode]  
       ,[AccountantCode]  
       ,[ID_Status] as IdStatus  
       ,[ID_Category]  as IdStatus  
       ,[ProvinceID]  
       
 from Dynamic.Data_CRMCustormer a                  
 left join  Dynamic.Data_CRMCustomerCategory b on a.ID_Category = b.Id                  
 left join Dynamic.Data_CRMStatusCustomer c on a.ID_Status = c.Id                  
 left join Dynamic.Data_CRMSource d on a.ID_Source = d.Id                  
 left join Dynamic.Data_CRMCountryRegion e on a.CountryRegionCode = e.CountryRegionCode                  
              
 where a.UserWorkflowId=@id
go

