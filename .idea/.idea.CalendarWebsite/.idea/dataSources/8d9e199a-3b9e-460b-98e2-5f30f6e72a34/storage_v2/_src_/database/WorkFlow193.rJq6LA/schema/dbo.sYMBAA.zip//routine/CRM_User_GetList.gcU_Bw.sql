CREATE   PROC [dbo].[CRM_User_GetList]  
  @str as nvarchar(250)=''  
 as    
 begin    
 SELECT a.[ID]       
       ,a.[AccountName]      
       ,[FullName]    
    ,a.[Email]    
    ,a.BirthDay    
    ,b.Title as Department    
    ,c.Title as Position    
 FROM PersonalProfile AS a     
  JOIN  Department AS b ON a.DepartmentID= b.ID     
  JOIN Position AS C ON a.PositionId = c.ID    
 where (a.IsDeleted= 0 or ISNULL(a.IsDeleted,0)= 0  ) and (a.UserStatus <> -1  )  and ( a.[AccountName] like N'%'+@str+'%' or a.FullName like N'%'+@str+'%' or b.Title like N'%'+@str+'%' or c.Title like N'%'+@str+'%' ) 
 end
go

