-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.NotificationTag] @userId VARCHAR(max)
	,@WorkflowId VARCHAR(max)
	,@WorkflowNewsId VARCHAR(max)


AS
BEGIN

	DECLARE @QueryString NVARCHAR(MAX);

	DECLARE @DataTableName NVARCHAR(MAX);
	DECLARE @TableName NVARCHAR(MAX);
	DECLARE @DataTableNameNews NVARCHAR(MAX);
	DECLARE @TableNameNews NVARCHAR(MAX);

	SET @TableName = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			)
	SET @DataTableName = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableName, '^a-z0-9')
			);
	SET @TableNameNews = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowNewsId
			)
	SET @DataTableNameNews = CONCAT (
			'Dynamic.Data_'
			,dbo.fn_StripCharacters(@TableNameNews, '^a-z0-9')
			);
			if(@TableName = 'NewsFeed')begin
		SET @QueryString = '
			  select dt.Content,u.CreatedTime,u.CreatedBy as InteractUser,dt.Department,CAST(dt.UserWorkflowId AS decimal(18, 0) ) as PostId, dt.UserWorkflowId as NotiId,uwfseen.IsSeen,InGroup.InGroup  
			  from UserWorkflow u
  inner join '+@DataTableName+' dt on u.Id= dt.UserWorkflowId
   outer apply(
   select count (wfs.UserId) as IsSeen from UserWorkflowSeen wfs
   where wfs.UserWorkflowId=dt.UserWorkflowId
   and wfs.UserId='+@userId+'
   )AS uwfseen
     outer apply(
   select count(*) as InGroup  from Dynamic.Data_GroupNews dtgr where dtgr.UserWorkflowId=SUBSTRING(dt.Department,3,5) and (dtgr.Member like ''%;P:'+@userId+''' or dtgr.Member like ''%;P:'+@userId+';%'' or dtgr.Member =''P:'+@userId+''' )
   )as InGroup
where u.WorkflowId='+@WorkflowId+'
	and u.IsDeleted!=1
		and
		(
				ISNULL(dt.ListTag, '''') <> ''''
				AND (
				
					(
					dt.ListTag  LIKE (''%''+ CAST('';P:' + @userId + ''' AS VARCHAR))
					or
					(
					dt.ListTag  LIKE (''%''+ CAST(''P:' + @userId + 
		';'' AS VARCHAR) + ''%'')
					)
					or
					(
					dt.ListTag = ( CAST(''P:' + @userId + ''' AS VARCHAR)  )
					)
					)
					)
				)	
	'
	end
	else
	begin
		SET @QueryString = '
			  select News.Content,u.CreatedTime,u.CreatedBy as InteractUser,News.Department,dt.PostId, dt.UserWorkflowId as NotiId,uwfseen.IsSeen,InGroup.InGroup  
			  from UserWorkflow u
  inner join '+@DataTableName+' dt on u.Id= dt.UserWorkflowId
   outer apply(
   select count (wfs.UserId) as IsSeen from UserWorkflowSeen wfs
   where wfs.UserWorkflowId=dt.UserWorkflowId
   and wfs.UserId='+@userId+'
   )AS uwfseen
   outer apply(
   select news.Department, news.Content from '+@DataTableNameNews+' news where dt.PostId=news.UserWorkflowId
   )as News
     outer apply(
   select count(*) as InGroup  from Dynamic.Data_GroupNews dtgr where dtgr.UserWorkflowId=SUBSTRING(News.Department,3,5) and (dtgr.Member like ''%;P:'+@userId+''' or dtgr.Member like ''%;P:'+@userId+';%'' or dtgr.Member =''P:'+@userId+''' )
   )as InGroup
          outer apply(
   select IsDeleted from UserWorkflow where Id= dt.PostId
   )as CheckIsDeleted
where u.WorkflowId='+@WorkflowId+'
and CheckIsDeleted.IsDeleted!=1
	and u.IsDeleted!=1
		and
		(
				ISNULL(dt.ListTag, '''') <> ''''
				AND (
				
					(
					dt.ListTag  LIKE (''%''+ CAST('';P:' + @userId + ''' AS VARCHAR))
					or
					(
					dt.ListTag  LIKE (''%''+ CAST(''P:' + @userId + 
		';'' AS VARCHAR) + ''%'')
					)
					or
					(
					dt.ListTag = ( CAST(''P:' + @userId + ''' AS VARCHAR)  )
					)
					)
					)
				)	
	'
	end
		PRINT @QueryString;

	EXEC sp_ExecuteSql @QueryString;
	END
go

