CREATE PROCEDURE [dbo].[proc_SetAppSiteDomainPrefixInContentDb](
    @SiteId uniqueidentifier,
    @SubscriptionName nvarchar(48),
    @AppSiteDomainId varchar(6),
    @SiteUrls tvpSiteUrls2 READONLY,
    @RequestGuid uniqueidentifier = NULL OUTPUT
)
AS
    SET NOCOUNT ON
    DECLARE @returnCode int SET @returnCode = 0 BEGIN TRAN
    UPDATE
        S
    SET 
        S.SubscriptionName = @SubscriptionName,
        S.AppSiteDomainId = @AppSiteDomainId
    FROM
        TVF_AllSites_Id(@SiteId) AS S
    WHERE
        ('' = (ISNULL(S.SubscriptionName, ''))) OR
        ('' = (ISNULL(S.AppSiteDomainId, '')))  OR
        S.SubscriptionName <> @SubscriptionName     OR
        S.AppSiteDomainId <> @AppSiteDomainId
    SELECT @returnCode=@@ERROR
    IF @returnCode <> 0
    BEGIN
        GOTO Cleanup
    END
    IF (0 <> (SELECT COUNT(*) FROM @SiteUrls))
    BEGIN
        EXEC dbo.proc_UpdateSiteUrlsColumn @SiteId, @SiteUrls
    END
Cleanup:
    IF (@returnCode <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @returnCode

go

