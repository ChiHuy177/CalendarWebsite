
-- =============================================
-- Author:		duydam
-- Create date: 24/09/2021
-- Description:	Find Code is belong to another Workflow
-- =============================================
CREATE PROCEDURE [dbo].[Workflow_CheckCodeExisted] @Code NVARCHAR(max)
	,@WorkflowId BIGINT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @StripCode NVARCHAR(MAX);

	SET @StripCode = dbo.fn_StripCharacters(@Code, '^a-z0-9');

	IF (@WorkflowId IS NULL)
	BEGIN
		SELECT CASE 
				WHEN EXISTS (
						SELECT TOP 1 *
						FROM [dbo].[Workflow]
						WHERE dbo.fn_StripCharacters(Code, '^a-z0-9') = @StripCode
						)
					THEN CAST(1 AS BIT)
				ELSE CAST(0 AS BIT)
				END;
	END
	ELSE
	BEGIN
		SELECT CASE 
				WHEN EXISTS (
						SELECT TOP 1 *
						FROM [dbo].[Workflow]
						WHERE dbo.fn_StripCharacters(Code, '^a-z0-9') = @StripCode
							AND Id != @WorkflowId
						)
					THEN CAST(1 AS BIT)
				ELSE CAST(0 AS BIT)
				END;
	END
END
go

