CREATE   PROC [dbo].[Work_CheckUserIsManager] 
   @projectId AS NVARCHAR(50) ='314586'  
   ,@UserId as nvarchar(50)='P:287' 
   as 
   declare @UserManager table(userId nvarchar(50), [Index] int) 
   insert into @UserManager 
   select * from ( 
   SELECT  
   b.value AS userId 
   , 1 as [Index] 
   FROM DYNAMIC.Data_RESOURCEDA AS a  
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   WHERE a.UserWorkflowId = @projectId and left(trim(b.value ),2)='P:' 
   union 
   SELECT  
   'P:'+trim(str(d.Id)) AS userId 
   , 1 as [Index] 
   FROM DYNAMIC.Data_RESOURCEDA AS a  
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   inner join GroupPersonalProfile c on REPLACE(a.QuanLy,'G:','')= trim(str(c.GroupsId)) 
   INNER JOIN PersonalProfile d ON d.Id =c.PersonalProfilesId 
   WHERE a.UserWorkflowId = @projectId and left(trim(b.value ),2)='G:' 
   ) a 
   select case when COUNT(*)>0 then 1 else 0 end as [check] from @UserManager where userId=@UserId 
go

