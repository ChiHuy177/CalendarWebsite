CREATE PROCEDURE [dbo].[proc_SecUpdateRoleDef](
    @SiteId       uniqueidentifier,
    @WebId        uniqueidentifier,
    @RoleId       int,
    @Title        nvarchar(255),
    @Description  nvarchar(512),
    @Order        int,
    @Type         tinyint,
    @PermMask     tPermMask,
    @RequestGuid  uniqueidentifier = NULL OUTPUT)   
AS
    SET NOCOUNT ON
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_Roles_UpdLock_SiteWeb(@SiteId, @WebId) AS R
        WHERE
            R.Title = @Title AND
            R.RoleId <> @RoleId)
    BEGIN
        SET @RET = 80
        GOTO cleanup
    END
    UPDATE
        R
    SET
        R.Title = @Title,
        R.Description = @Description,
        R.RoleOrder = @Order,
        R.Type = @Type,
        R.PermMask = COALESCE(@PermMask, R.PermMask)
    FROM
        TVF_Roles_PK(@SiteId, @WebId, @RoleId) AS R
    IF 0 <> @@ERROR
    BEGIN
        SET @RET = 80
        GOTO cleanup
    END
    IF @PermMask IS NOT NULL
    BEGIN
        EXEC proc_SecUpdateAcl @SiteId, @WebId            
        EXEC proc_SecUpdateSiteLevelSecurityMetadata @SiteId, 1, 0
    END
    DECLARE @ScopeId uniqueidentifier
    SELECT TOP 1
        @ScopeId = W.ScopeId
    FROM
        TVF_Webs_Id(@SiteId, @WebId) AS W
    EXEC proc_SecLogChange @SiteId, @WebId, @ScopeId, NULL, @RoleId, NULL, 16777216, NULL
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    IF @RET <> 0
        RETURN @RET
    EXEC proc_GetWebIdAuditMask @SiteId, @WebId
    RETURN @RET

go

