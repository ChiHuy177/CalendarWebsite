-- [Work_GetLogtimeByWorkId] 117182 
   CREATE   PROC [dbo].[Work_GetLogtimeByWorkId] 
   @WorkFlowId AS BIGINT 
   AS 
   -- select WorkflowCode from UserWorkflow where Id=25198 
   SELECT * 
   FROM [Dynamic].Workflow_VNTTSLT AS Tab 
   CROSS APPLY OPENJSON(Tab.data, N'$') WITH ( 
   MaCV NVARCHAR(500) N'$.Congviec', 
   IsDelete NVARCHAR(500) N'$.IsDelete' 
   ) a
   inner join [Dynamic].Data_VNTTSLT b on Tab.UserWorkflowId=b.UserWorkflowId
   WHERE a.MaCV = @WorkFlowId and ISNULL(b.IsDelete,'False')='False' 
go

