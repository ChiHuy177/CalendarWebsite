CREATE PROCEDURE [dbo].[proc_DeleteEventLog](
    @SiteId         uniqueidentifier,
    @EventTime      datetime,
    @RequestGuid    uniqueidentifier = NULL OUTPUT)     
AS
    SET NOCOUNT ON
    DECLARE @maxId bigint
    SELECT TOP(1)
        @maxId = EC.Id
    FROM 
        TVF_EventCache_LTTime(@EventTime) AS EC
    ORDER BY
        EC.EventTime
    DESC
    DELETE
        ESM
    FROM
        (SELECT * FROM TVF_EventCache_SiteLEQId(@SiteId, @maxId) 
        WHERE EventType & ~1073737728 != 0) AS EC
    CROSS APPLY
        TVF_EventSubsMatches_SiteEvent(EC.SiteId, EC.Id) AS ESM
	OPTION (FORCE ORDER, MAXDOP 1)

go

