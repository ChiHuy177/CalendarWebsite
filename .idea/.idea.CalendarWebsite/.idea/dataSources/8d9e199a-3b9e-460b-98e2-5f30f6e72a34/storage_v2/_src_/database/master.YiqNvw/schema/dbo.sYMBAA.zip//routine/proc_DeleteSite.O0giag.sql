CREATE PROCEDURE [dbo].[proc_DeleteSite](
    @SiteId uniqueidentifier,
    @ThresholdRowCount int,
    @DeleteIsForMigration bit,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @iRet int
    DECLARE @RbsCollectionId int
    IF @ThresholdRowCount > 0
    BEGIN
        EXEC @iRet = proc_CheckFolderUsingThreshold  @SiteId, NULL, 
                            @ThresholdRowCount
        IF @iRet <> 0
        BEGIN
            RETURN @iRet
        END
    END
    BEGIN TRAN
    EXEC @iRet = proc_DeleteSiteInternal @SiteId, @DeleteIsForMigration
    IF @iRet = 0
    BEGIN
        SELECT
            @RbsCollectionId = S.RbsCollectionId 
        FROM
            TVF_Sites_XLock_Id(@SiteId) AS S
        IF @RbsCollectionId <> 0
        BEGIN
            EXEC proc_RbsDeleteCollection @RbsCollectionId
        END
        DELETE 
            S
        FROM
            TVF_AllSites_Id(@SiteId) AS S
        EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
            16384,  8, NULL, NULL, NULL, NULL, 
            NULL, NULL, @RequestGuid OUTPUT
    END
cleanup:
    IF (@iRet <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @iRet

go

