CREATE PROCEDURE [dbo].[proc_SecSetUserAccountDirectoryPath](
	@SiteId uniqueidentifier,
	@Restriction nvarchar(512),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        S
    SET
        S.UserAccountDirectoryPath = @Restriction,
        S.BitFlags = 
            CASE 
                WHEN @Restriction IS NULL THEN (S.BitFlags & (~524288)) 
                ELSE (S.BitFlags | 524288) 
            END
    FROM
        TVF_Sites_Id(@SiteId) AS S
    EXEC proc_LogChange @SiteId, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
        8192,  8, NULL
    RETURN 0    

go

