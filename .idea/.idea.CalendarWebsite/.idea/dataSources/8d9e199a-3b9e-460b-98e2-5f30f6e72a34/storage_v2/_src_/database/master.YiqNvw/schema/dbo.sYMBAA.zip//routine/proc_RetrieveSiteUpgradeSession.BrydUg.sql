CREATE PROCEDURE [dbo].[proc_RetrieveSiteUpgradeSession](
    @SiteId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @TimeRightNow datetime
    SET @TimeRightNow = GETUTCDATE()
    SELECT
        SiteId, SessionId, SessionXML, CASE WHEN DATEDIFF(second, LastUpdated, @TimeRightNow) > 60 AND UpgradeStatus = 1 THEN 0 ELSE UpgradeStatus END, UpgradeType, ErrorCount, WarningCount, RequestDate, StartTime, LastUpdated, RetryCount, LogFileLocation, SendEmail
    FROM
        TVF_SiteUpgradeSessions_SiteId(@SiteId) AS SiteUpgradeSessions
    RETURN

go

