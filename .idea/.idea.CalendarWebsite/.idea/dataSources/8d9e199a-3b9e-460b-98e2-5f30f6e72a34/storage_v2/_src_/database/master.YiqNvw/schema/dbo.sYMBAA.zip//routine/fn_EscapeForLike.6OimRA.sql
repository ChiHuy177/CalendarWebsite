CREATE FUNCTION [dbo].[fn_EscapeForLike](
    @Source nvarchar(260), 
    @AddTerminalWildcard bit = 1)
RETURNS nvarchar(1024)
WITH SCHEMABINDING
BEGIN
    RETURN
    CASE 
        WHEN @Source IS NULL THEN NULL
        WHEN @AddTerminalWildcard = 1 AND  DATALENGTH(@Source) = 0 THEN
            N'_%'
        WHEN @AddTerminalWildcard = 1 THEN
            REPLACE(
                REPLACE(
                    REPLACE(
                        @Source COLLATE Latin1_General_BIN,
                        N'[', N'[[]'), N'%', N'[%]'), N'_', N'[_]') + N'/%'
        ELSE
            REPLACE(
                REPLACE(
                    REPLACE(
                        @Source COLLATE Latin1_General_BIN,
                        N'[', N'[[]'), N'%', N'[%]'), N'_', N'[_]')
    END
END

go

