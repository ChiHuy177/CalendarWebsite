CREATE PROCEDURE [dbo].[proc_HasCurrentPublishVersion]
(
    @SiteId uniqueidentifier,
    @ListId      uniqueidentifier,
    @ItemId     int,    
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    IF EXISTS(
        SELECT TOP 1
            1
        FROM
            TVF_UserData_ListItemLevelRow(@SiteId, @ListId, @ItemId, 1, 0) AS U)
        BEGIN
            RETURN 1
        END
        ELSE
        BEGIN
            RETURN 0
        END

go

