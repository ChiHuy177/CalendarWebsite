CREATE PROCEDURE [dbo].[proc_UpdateWebPartWhileSaving](
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @LeafName nvarchar(128),
    @Level tinyint,
    @WebPartId uniqueidentifier,
    @WebPartTypeID uniqueidentifier,
    @Assembly nvarchar(255),
    @Class nvarchar(255),
    @SolutionId uniqueidentifier,
    @SolutionWebId uniqueidentifier,
    @TheListID uniqueidentifier,
    @IsIncluded bit,
    @FrameState tinyint,
    @ZoneID nvarchar(64),
    @PartOrder int,
    @TheFlags int,
    @TheType tinyint,
    @TheBaseViewID tinyint,
    @ContentTypeId tContentTypeId,
    @Source nvarchar(max),
    @AllUsersProperties varbinary(max),
    @PerUserProperties varbinary(max),
    @WebPartIdProperty nvarchar(255),
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    DECLARE @DocId uniqueidentifier
    DECLARE @ExistingWebPartID uniqueidentifier
    DECLARE @ExistingUserID int
    DECLARE @Ret int
    DECLARE @SourceSize int
    DECLARE @AllUsersPropertiesSize int
    DECLARE @PerUserPropertiesSize int
    DECLARE @WebPartIdPropertySize int
    DECLARE @NewSize bigint
    DECLARE @OldWebPartTypeID uniqueidentifier
    DECLARE @IsCurrentVersion bit
    DECLARE @DocParentId uniqueidentifier
    SET @Ret = 0
    SELECT TOP 1
        @DocId = D.Id,
        @IsCurrentVersion = D.IsCurrentVersion,
        @DocParentId = D.ParentId
    FROM
        TVF_Docs_Url_Level(@SiteId, @DirName, @LeafName, @Level) AS D
    IF @DocId IS NULL
    BEGIN
        RETURN 2
    END
    IF (@IsCurrentVersion = 0)
    BEGIN
        RETURN 33
    END
    SELECT TOP 1
        @ExistingWebPartID = WP.tp_ID,
        @OldWebPartTypeID = WP.tp_WebPartTypeId
    FROM
        TVF_WebParts_CI(@SiteId, @DocId, @Level, NULL ) AS WP
    WHERE
        WP.tp_ID = @WebPartId
    IF (@ExistingWebPartID IS NOT NULL)
    BEGIN
        SET @SourceSize = ISNULL(DATALENGTH(@Source), 0)
        SET @AllUsersPropertiesSize = ISNULL(DATALENGTH(@AllUsersProperties), 0)
        SET @PerUserPropertiesSize = ISNULL(DATALENGTH(@PerUserProperties), 0)
        SET @WebPartIdPropertySize = ISNULL(DATALENGTH(@WebPartIdProperty), 0)
        EXEC @Ret = proc_OnUpdateWebParts
            @SiteId,
            @WebPartId,
            @Level,
            NULL,    
            @AllUsersPropertiesSize,
            @PerUserPropertiesSize,
            @WebPartIdPropertySize,
            0,    
            @SourceSize,
            NULL,
            @NewSize OUTPUT
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        IF (@OldWebPartTypeID IS NOT NULL) AND
            (@OldWebPartTypeID <> @WebPartTypeID) AND
            (@IsIncluded IS NULL) AND
            (@Level <> 255)
        BEGIN
            EXEC @Ret = proc_DeleteWebPartPersonalization
                @SiteId,
                @DirName,
                @LeafName,
                NULL,
                @WebPartId,
                @RequestGuid OUTPUT
        END
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        UPDATE
            WP
        SET
            WP.tp_WebPartTypeId = @WebPartTypeID,
            WP.tp_Assembly = @Assembly,
            WP.tp_Class = @Class,
            WP.tp_SolutionId = @SolutionId,
            WP.tp_SolutionWebId = @SolutionWebId,
            WP.tp_Version = (CASE WHEN WP.tp_Version IS NULL THEN 2 WHEN WP.tp_Version >= 2147483647 THEN 1 ELSE WP.tp_Version + 1 END),
            WP.tp_ZoneID = @ZoneID,
            WP.tp_PartOrder = @PartOrder,
            WP.tp_Type = CASE WHEN @TheType IS NULL
                      THEN WP.tp_Type ELSE @TheType END,
            WP.tp_Flags = CASE WHEN @TheFlags IS NULL
                       THEN WP.tp_Flags ELSE @TheFlags END,
            WP.tp_BaseViewID = CASE WHEN @TheBaseViewID IS NULL
                            THEN WP.tp_BaseViewID ELSE @TheBaseViewID END,
            WP.tp_IsIncluded = @IsIncluded,
            WP.tp_FrameState = @FrameState,
            WP.tp_AllUsersProperties = @AllUsersProperties,
            WP.tp_PerUserProperties = @PerUserProperties,
            WP.tp_WebPartIdProperty = @WebPartIdProperty,
            WP.tp_Source = @Source,
            WP.tp_PageUrlID = @DocId,
            WP.tp_Cache = NULL,
            WP.tp_ContentTypeId = CASE WHEN @ContentTypeId IS NULL
                THEN WP.tp_ContentTypeId ELSE @ContentTypeId END,
            WP.tp_Size = @NewSize
        FROM
            TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level) AS WP
        IF (@@ERROR <> 0 OR @Ret <> 0)
        BEGIN
            IF (@Ret = 0)
                SET @Ret = -2147467259
            GOTO cleanup
        END
        IF (@Level = 1)
        BEGIN
            EXEC @Ret = proc_InvalidatePerUserWebPartCache
                    @SiteId,
                    @WebPartId
            IF (@@ERROR <> 0 OR @Ret <> 0)
            BEGIN
                IF (@Ret = 0)
                    SET @Ret = -2147467259
                GOTO cleanup
            END
        END
        DELETE
            L
        FROM
            TVF_Links_PId_DId_Lvl(@SiteId, @DocParentId, @DocId, @Level) AS L
        WHERE
            L.FieldId IS NULL AND
            L.WebPartId = @WebPartId
        IF NOT EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level))
        BEGIN
            SET @Ret = 2  
        END
    END
    ELSE
    BEGIN
        IF EXISTS(
            SELECT TOP 1
                1
            FROM
                TVF_WebParts_SitePartIdLvl(@SiteId, @WebPartId, @Level))
        BEGIN
            SET @WebPartId=NEWID()
        END
        DECLARE @cbDelta bigint
        SET @cbDelta = 116 + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(@AllUsersProperties), 0) + ISNULL(DATALENGTH(@PerUserProperties), 0) + ISNULL(DATALENGTH(NULL), 0) + ISNULL(DATALENGTH(@Source), 0) + ISNULL(DATALENGTH(@SolutionId), 0) + ISNULL(DATALENGTH(@SolutionWebId), 0) + ISNULL(DATALENGTH(@Assembly), 0) + ISNULL(DATALENGTH(@Class), 0) + ISNULL(DATALENGTH(@WebPartIdProperty), 0)
        EXEC proc_AppendSiteQuota @SiteId, @cbDelta, 0, @DocId
        INSERT INTO dbo.AllWebParts (
            tp_WebPartTypeId,
            tp_ListId,
            tp_Assembly,
            tp_Class,
            tp_SolutionId,
            tp_SolutionWebId,
            tp_SiteId,
            tp_Version,
            tp_ID,
            tp_ZoneID,
            tp_PartOrder,
            tp_Type,
            tp_Flags,
            tp_BaseViewID,
            tp_IsIncluded,
            tp_FrameState,
            tp_Source,
            tp_AllUsersProperties,
            tp_PerUserProperties,
            tp_WebPartIdProperty,
            tp_PageUrlID,
            tp_Size,
            tp_ContentTypeId,
            tp_Level)
        VALUES (
            @WebPartTypeID,
            @TheListID,
            @Assembly,
            @Class,
            @SolutionId,
            @SolutionWebId,
            @SiteId,
            1,
            @WebPartId,
            @ZoneID,
            @PartOrder,
            @TheType,
            @TheFlags,
            @TheBaseViewID,
            @IsIncluded,
            @FrameState,
            @Source,
            @AllUsersProperties,
            @PerUserProperties,
            @WebPartIdProperty,
            @DocId,
            @cbDelta,
            CASE WHEN @ContentTypeId IS NULL THEN 0x ELSE @ContentTypeId END,
            @Level)
    END
cleanup:
    IF (0 <> @@ERROR OR 0 <> @Ret)
    BEGIN
        RETURN CASE WHEN (0 = @Ret) THEN -2147467259 ELSE @Ret END
    END
    RETURN 0

go

