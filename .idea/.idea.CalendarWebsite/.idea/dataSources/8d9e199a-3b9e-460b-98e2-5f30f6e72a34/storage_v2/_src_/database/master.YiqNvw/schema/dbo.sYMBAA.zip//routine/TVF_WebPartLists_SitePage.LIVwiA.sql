CREATE FUNCTION [dbo].[TVF_WebPartLists_SitePage]
(
    @tp_SiteId uniqueidentifier,
    @tp_PageUrlID uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[WebPartLists] WITH (INDEX=WebPartLists_PageUrlID, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_PageUrlID = @tp_PageUrlID

go

