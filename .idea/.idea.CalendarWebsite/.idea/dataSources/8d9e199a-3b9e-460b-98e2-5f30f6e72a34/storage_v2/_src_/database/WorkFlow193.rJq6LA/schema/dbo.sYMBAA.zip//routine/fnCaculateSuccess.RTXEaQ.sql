CREATE   FUNCTION [dbo].[fnCaculateSuccess]
(
	-- Add the parameters for the function here
	@CompletedDate datetime,
	@StartDate datetime,
	@DueDate datetime,
	@Duration float,
	@TimeUnit nvarchar(250),
	@IsGetSuccess bit = 1
)
RETURNS INT
AS
BEGIN
	DECLARE @Result INT = 0
	DECLARE @Minutes float = 0;
	SET @Minutes = DATEDIFF_BIG(MINUTE, @StartDate, @CompletedDate) - (
					DATEDIFF_BIG(wk, @StartDate, @CompletedDate) * (2 * 24 * 60)
					-- End on Sunday
					- (
						CASE 
							WHEN DATEPART(dw, @CompletedDate) = 1
								THEN 24.0 * 60 - DATEDIFF_BIG(minute, CONVERT(DATE, @CompletedDate), @CompletedDate)
							ELSE 0
							END
						)
					-- Start on Saturday
					- (
						CASE 
							WHEN DATEPART(dw, @StartDate) = 7
								THEN DATEDIFF_BIG(minute, CONVERT(DATE, @StartDate), @StartDate)
							ELSE 0
							END
						)
					-- End on Saturday
					+ (
						CASE 
							WHEN DATEPART(dw, @CompletedDate) = 7
								THEN DATEDIFF_BIG(minute, CONVERT(DATE, @CompletedDate), @CompletedDate)
							ELSE 0
							END
						)
					-- Start on Saturday
					+ (
						CASE 
							WHEN DATEPART(dw, @StartDate) = 1
								THEN 24.0 * 60 - DATEDIFF_BIG(minute, CONVERT(DATE, @StartDate), @StartDate)
							ELSE 0
							END
						)
					)
	IF @Duration = 0
		SET @Result = 1
	ELSE IF @TimeUnit = N'days'
	BEGIN
		IF (@Minutes / CAST(1440 AS float)) > @Duration
			SET @Result = 0
		ELSe
			SET @Result = 1
	END
	ELSE IF @TimeUnit = N'hours'
	BEGIN
		IF @Minutes > @Duration
			SET @Result = 0
		ELSe
			SET @Result = 1
	END

	IF @IsGetSuccess = 0
	BEGIN
	IF @Result = 0
			SET @Result = 1
	ELSE
			SET @Result = 0
	END
	-- Return the result of the function
	RETURN @Result

	---- Declare the return variable here
	--DECLARE @Result INT = 0
	--DECLARE @TemD int = 0
	--DECLARE @TemH int = 0
	--DECLARE @TemM int = 0
	--DECLARE @ThoiGianThucHienD int = 0

	--IF DATEPART(wk,  @StartDate) <> DATEPART(wk,  @@CompletedDate) 
	--	BEGIN
	--		SET @TemD =  CASE
	--						WHEN ((DATEPART(DAY, @@CompletedDate - @StartDate) - 1) = 0)
	--						OR (DATEPART(DAY, @@CompletedDate - @StartDate) - 1 = NULL) THEN 0
	--						ELSE DATEPART(DAY, @@CompletedDate - @StartDate) - 2 END

	--		SET @TemH =  CASE
	--						WHEN (DATEPART(HOUR, @@CompletedDate - @StartDate) = 0)
	--						OR (DATEPART(HOUR, @@CompletedDate - @StartDate) = NULL) THEN 0
	--						ELSE DATEPART(HOUR, @@CompletedDate - @StartDate) END

	--		SET @TemM =  CASE
	--						WHEN (DATEPART(MINUTE, @@CompletedDate - @StartDate) = 0)
	--						OR (DATEPART(MINUTE, @@CompletedDate - @StartDate) = NULL) THEN 0
	--						ELSE DATEPART(MINUTE, @@CompletedDate - @StartDate) END
	--	END
	--ELSE IF ((DATEPART(WEEKDAY, @StartDate) = 1) OR (DATEPART(WEEKDAY, @@CompletedDate) = 1)) AND (ISNULL(@DueDate, '2050-01-01') > @@CompletedDate) AND (DATEPART(DAY, @@CompletedDate - @StartDate) > 1)
	--BEGIN
	--	SET @TemD = 1
	--	SET @TemH = 0
	--	SET @TemM = 0
	--END
	--ELSE
	--	BEGIN
	--		SET @TemD =  CASE
	--						WHEN ((DATEPART(DAY, @@CompletedDate - @StartDate) - 1) = 0)
	--						OR (DATEPART(DAY, @@CompletedDate - @StartDate) - 1 = NULL) THEN 0
	--						ELSE DATEPART(DAY, @@CompletedDate - @StartDate) - 1 END

	--		SET @TemH =  CASE
	--						WHEN (DATEPART(HOUR, @@CompletedDate - @StartDate) = 0)
	--						OR (DATEPART(HOUR, @@CompletedDate - @StartDate) = NULL) THEN 0
	--						ELSE DATEPART(HOUR, @@CompletedDate - @StartDate) END

	--		SET @TemM =  CASE
	--						WHEN (DATEPART(MINUTE, @@CompletedDate - @StartDate) = 0)
	--						OR (DATEPART(MINUTE, @@CompletedDate - @StartDate) = NULL) THEN 0
	--						ELSE DATEPART(MINUTE, @@CompletedDate - @StartDate) END
	--	END			
	----END
	----ELSE
	----BEGIN
	----	SET @TemD = 0
	----	SET @TemM = 0
	----	SET @TemH = 0
	----END
	--IF @TemH = 0 AND @TemM = 0 AND @TemD = 0
	--	SET @ThoiGianThucHienD = 0

	--ELSE IF @TemH = 0 AND @TemM = 0 AND @TemD <> 0
	--	SET @ThoiGianThucHienD = @TemD

	--ELSE 
	--	SET @ThoiGianThucHienD = @TemD + 1


	--IF @Duration = 0 AND @TimeUnit = N'days'
	--	SET @Result = 0
	--ELSE
	--	BEGIN
	--		IF @ThoiGianThucHienD <= @Duration
	--			SET  @Result = 1
	--		ELSE
	--			SET  @Result = 0
	--	END
	----Tinh tre han
	--IF @IsGetSuccess = 0 AND @Duration <> 0
	--	BEGIN
	--	IF @Result = 0
	--		SET @Result = 1
	--	ELSE
	--		SET @Result = 0
	--	END
	---- Return the result of the function
	--RETURN @Result

END
go

