CREATE   PROC [dbo].[Work_GetListFileAttach_Ver1] 
   @workFlowId as bigint =102 
   ,@UserWorkflowId as nvarchar(1000) 
   as 
   DECLARE @tableDynamic as nvarchar(250),@code as nvarchar(250),@sql as nvarchar(max) 
   set @code=(select Code from Workflow where Id=@workFlowId) 
   set @tableDynamic = ('Dynamic.CheckList_' +trim(@code)) 
   set @sql=' 
   select 
   a.[Id] 
   ,a.[UserWorkflowId] 
   ,a.[CheckListId] 
   ,a.[Name] 
   ,a.[Note] 
   ,a.[Path] 
   ,a.[Type] 
   ,a.[CreatedBy] 
   ,a.[CreatedTime] 
   ,a.[LastModified] 
   ,a.[ModifiedBy] 
   ,a.[IsDeleted] 
   ,f.Tieude as WorkName 
   ,f.UserWorkflowId as WorkId
   ,b.FullName as modifiedByName 
   ,c.Title as documentTypeTitle 
   from '+@tableDynamic+' a 
   inner join PersonalProfile b on a.CreatedBy = b.Email 
   inner join CheckList c on a.CheckListId=c.Id 
   inner join Dynamic.Data_WORK f on f.UserWorkflowId = a.[UserWorkflowId] 
   where a.UserWorkflowId in (select value from string_split('''+@UserWorkflowId+''','','')) and a.IsDeleted=0 
   ' 
   exec(@sql) 
   print(@sql) 
go

