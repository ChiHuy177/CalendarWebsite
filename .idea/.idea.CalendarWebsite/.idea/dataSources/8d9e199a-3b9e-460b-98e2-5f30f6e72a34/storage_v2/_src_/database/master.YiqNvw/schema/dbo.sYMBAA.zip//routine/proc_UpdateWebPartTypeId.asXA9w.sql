CREATE PROCEDURE [dbo].[proc_UpdateWebPartTypeId](
    @SiteId uniqueidentifier,
    @WebPartId uniqueidentifier,
    @WebPartTypeId uniqueidentifier,
    @Assembly nvarchar(255),
    @Class nvarchar(255),
    @SolutionId uniqueidentifier,
    @SolutionWebId uniqueidentifier,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE
        WP
    SET
        WP.tp_WebPartTypeId = @WebPartTypeId,
        WP.tp_Assembly = @Assembly,
        WP.tp_Class = @Class,
        WP.tp_SolutionId = @SolutionId,
        WP.tp_SolutionWebId = @SolutionWebId,
        WP.tp_Version = (CASE WHEN WP.tp_Version IS NULL THEN 2 WHEN WP.tp_Version >= 2147483647 THEN 1 ELSE WP.tp_Version + 1 END)
    FROM
        TVF_WebParts_SitePartId(@SiteId, @WebPartId) AS WP
    IF (0 <> @@ERROR)
        RETURN -2147467259
    RETURN 0

go

