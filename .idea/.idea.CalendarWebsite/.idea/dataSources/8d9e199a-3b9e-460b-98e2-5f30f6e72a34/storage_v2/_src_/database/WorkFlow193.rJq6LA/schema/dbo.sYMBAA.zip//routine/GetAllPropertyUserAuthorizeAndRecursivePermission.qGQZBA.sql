CREATE       FUNCTION [dbo].[GetAllPropertyUserAuthorizeAndRecursivePermission] (
	@UserId BIGINT
	)
RETURNS TABLE
AS
RETURN (
			WITH [Temp]([Id]) AS (
				SELECT DISTINCT [f].[UserWorkflowId]
				FROM [PropertyUserAuthorize] [f]				
				WHERE [f].[UserId] = @UserId
			
				
				UNION ALL
				
				SELECT CAST([f].[ChildUserWorkflowId] AS BIGINT)
				FROM [Temp] AS [t]
					,[dbo].[RecursivePermission] AS [f]
				WHERE [t].[Id] = [f].[ParentUserWorkflowId]
				)
		SELECT DISTINCT [Id]
		FROM [Temp]
)
go

