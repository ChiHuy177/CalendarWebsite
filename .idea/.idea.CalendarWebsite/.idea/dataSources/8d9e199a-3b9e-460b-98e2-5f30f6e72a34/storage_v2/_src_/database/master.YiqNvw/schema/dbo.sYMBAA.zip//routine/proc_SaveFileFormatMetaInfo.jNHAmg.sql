CREATE PROCEDURE [dbo].[proc_SaveFileFormatMetaInfo]
(
    @SiteId uniqueidentifier,
    @DocId uniqueidentifier,
    @Level tinyint,
    @DocVersion int,
    @ContentVersion int,
    @FFM varbinary(max),
    @FFMSize int,
    @FailIfExists bit
)
AS
    SET NOCOUNT ON
    DECLARE @FFMOldSize int, @ERR int, @ROWC int
    DECLARE @ParentId uniqueidentifier
    DECLARE @FFMExists bit
    DECLARE @RET int SET @RET = 0 BEGIN TRAN
    SELECT TOP 1
        @FFMOldSize = D.FileFormatMetaInfoSize,
        @ParentId = D.ParentId,
        @FFMExists = CASE WHEN D.FileFormatMetaInfo IS NOT NULL THEN 1 ELSE 0 END
    FROM
        TVF_Docs_UpdLock_Id_Level(@SiteId, @DocId, @Level) AS D
    SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
    IF (@ERR <> 0)
    BEGIN
        SET @RET = 30
        GOTO cleanup
    END
    ELSE IF (@ROWC <> 1)
    BEGIN
        SET @RET = 2
        GOTO cleanup
    END
    ELSE IF (@FailIfExists = 1 AND @FFMExists = 1)
    BEGIN
        SET @RET = 183
        GOTO cleanup
    END
    UPDATE
        D
    SET
        D.FileFormatMetaInfo = @FFM,
        D.FileFormatMetaInfoSize = @FFMSize,
        D.FFMConsistent = CAST(1 AS bit)
    FROM
        TVF_Docs_CI(@SiteId, @ParentId, @DocId, @Level) AS D
    WHERE
        (@DocVersion IS NULL OR D.ETagVersion IS NULL OR D.ETagVersion = @DocVersion) AND
        (@ContentVersion IS NULL OR D.ContentVersion = @ContentVersion)
    SELECT @ERR=@@ERROR, @ROWC=@@ROWCOUNT
    IF @ERR <> 0
    BEGIN
        SET @RET = 30
        GOTO cleanup
    END
    ELSE IF @ROWC <> 1
    BEGIN
        SET @RET = 21
        GOTO cleanup
    END    
    DECLARE @QuotaChange int
    SET @QuotaChange = (@FFMSize-@FFMOldSize)
    EXEC dbo.proc_QMChangeSiteDiskUsedAndContentTimestamp @SiteId, @QuotaChange, 0, @DocId
cleanup:
    IF (@RET <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
    RETURN @RET

go

