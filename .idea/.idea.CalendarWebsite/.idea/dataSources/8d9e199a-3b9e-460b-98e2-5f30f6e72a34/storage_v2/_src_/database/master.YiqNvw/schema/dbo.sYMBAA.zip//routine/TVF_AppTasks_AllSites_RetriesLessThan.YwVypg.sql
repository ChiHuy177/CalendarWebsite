CREATE FUNCTION [dbo].[TVF_AppTasks_AllSites_RetriesLessThan]
(
    @LEQRetries int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppTasks] WITH (INDEX=AppTasks_Retries, FORCESEEK)
    WHERE
        Retries <= @LEQRetries

go

