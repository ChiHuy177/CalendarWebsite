CREATE PROC [dbo].[proc_GetListCheckedOutFiles](
    @SiteId uniqueidentifier,
    @ListUrl nvarchar(260),
    @RequestGuid uniqueidentifier = NULL OUTPUT     
    )
AS
    SET NOCOUNT ON
    DECLARE @UrlLike nvarchar(260)
    EXEC proc_EscapeForLike @ListUrl, @UrlLike OUTPUT, 1
    SELECT 
        CheckedOutDoc.DirName,
        CheckedOutDoc.LeafName,
        CheckedOutDoc.DoclibRowId,
        CheckedOutDoc.CheckoutUserId,
        ISNULL(UA.tp_Title,''),
        ISNULL(UA.tp_Email,''),
        CheckedOutDoc.TimeLastModified,
        CheckedOutDoc.Size
    FROM 
        TVF_Docs_DirNameEqLike_Value(@SiteId, @ListUrl, @UrlLike) AS CheckedOutDoc
    OUTER APPLY
        TVF_Docs_NoLock_Id_Level(CheckedOutDoc.SiteId, CheckedOutDoc.Id, 2) AS DraftDoc
    OUTER APPLY
        TVF_AllDocs_NoLock_Id_Level(CheckedOutDoc.SiteId, CheckedOutDoc.Id, 1) AS PublishedDoc
    OUTER APPLY
        TVF_UserInfo_PK(CheckedOutDoc.SiteId, CheckedOutDoc.CheckoutUserId) AS UA
    WHERE
        CheckedOutDoc.Level = 255 AND
        CheckedOutDoc.DocFlags & 32 <> 0 AND
        CheckedOutDoc.Type = 0 AND
        DraftDoc.Id IS NULL AND
        PublishedDoc.Id IS NULL AND
        CheckedOutDoc.DoclibRowId IS NOT NULL AND
        CheckedOutDoc.ListId IS NOT NULL
    OPTION (FORCE ORDER)
    RETURN 0

go

