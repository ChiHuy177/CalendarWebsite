-- Work_GetChangUserExec 343320
   CREATE   PROC Work_GetChangUserExec
   @workId as nvarchar(50)
   as
   select top 1 a.*
   ,  ChangForm = STUFF(
   (SELECT ', ' + FullName 
   FROM PersonalProfile d
   WHERE d.id in (select REPLACE(Item,'P:','') as item from Split(a.UserChangeFrom,';'))
   FOR XML PATH (''))
   , 1, 1, '') 
   ,  ChangTo = STUFF(
   (SELECT ', ' + FullName 
   FROM PersonalProfile d
   WHERE d.id in (select REPLACE(Item,'P:','') as item from Split(a.UserChangeTo,';'))
   FOR XML PATH (''))
   , 1, 1, '') 
   , b.FullName as ChangeBy
   ,a.DateRequest
   from Dynamic.Data_ChangeUserExec a
   inner join PersonalProfile b on b.Id=REPLACE(a.UserChange,'P:','')
   where a.WorkId=@workId and ISNULL(IsDelete,0)=0
go

