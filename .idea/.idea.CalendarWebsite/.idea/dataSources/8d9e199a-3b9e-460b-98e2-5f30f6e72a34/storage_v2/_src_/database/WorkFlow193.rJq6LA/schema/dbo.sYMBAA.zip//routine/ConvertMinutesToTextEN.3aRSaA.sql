-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE     FUNCTION [dbo].[ConvertMinutesToTextEN]
(
	@theMinutes int
)
RETURNS nvarchar(500)
AS
BEGIN
	DECLARE @days nvarchar(MAX) = '';
	DECLARE @hours nvarchar(MAX) = '';
	DECLARE @mins nvarchar(MAX) = '';
	DECLARE @Res nvarchar(MAX) = '0 m';

	IF @theMinutes = 0
	BEGIN
		RETURN '0 s'
	END

	IF (@theMinutes / 1440) > 0
	BEGIN
		SET @days = convert(VARCHAR(15), @theMinutes / 1440) + N' d '
	END

	IF ((@theMinutes % 1440) / 60) > 0
	BEGIN
		SET @hours = convert(VARCHAR(2),(@theMinutes % 1440) / 60) + N' h '
	END

	IF (@theMinutes % 60) > 0
	BEGIN
		SET @mins = convert(VARCHAR(2),(@theMinutes % 60)) + N' m '
	END

	IF LTRIM(RTRIM(@days + @hours + @mins)) <> ''
		SET @Res = LTRIM(RTRIM(@days + @hours + @mins))
	
	RETURN (CASE WHEN (@Res = '' OR @Res = ' ') THEN '0 s' ELSE @Res END);
END
go

