CREATE FUNCTION [dbo].[TVF_Resources_SiteId]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[Resources] WITH (INDEX=Resources_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

