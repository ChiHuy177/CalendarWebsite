CREATE FUNCTION [dbo].[TVF_BuildDependencies_DirNameEqLike_NotForDelete]
(
    @SiteId uniqueidentifier,
    @DirName nvarchar(256),
    @DirNameLike nvarchar(1024)
)
RETURNS TABLE AS RETURN
    SELECT
        T1.*
    FROM
    (SELECT
        *
    FROM
        BuildDependencies WITH (INDEX=BuildDependencies_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DirName = @DirName
    UNION ALL
    SELECT
        *
    FROM
        BuildDependencies WITH (INDEX=BuildDependencies_Forward, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        DirName LIKE @DirNameLike) AS T2
    INNER LOOP JOIN
        BuildDependencies AS T1 WITH (INDEX=BuildDependencies_Forward, FORCESEEK)
    ON
                    T1.SiteId = T2.SiteId AND
                    T1.DirName = T2.DirName AND
                    T1.LeafName = T2.LeafName

go

