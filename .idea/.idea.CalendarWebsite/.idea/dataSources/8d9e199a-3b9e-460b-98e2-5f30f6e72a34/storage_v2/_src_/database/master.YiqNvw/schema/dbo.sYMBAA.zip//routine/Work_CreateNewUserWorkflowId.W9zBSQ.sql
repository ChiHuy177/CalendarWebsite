CREATE PROC [dbo].[Work_CreateNewUserWorkflowId]
@UserWorkflowIdOld as bigint,      
@CongViecCha as char(20)= null,
@WorkflowId as char(20)=null,
@WorkflowStepId as char(20)=null
as      
      
-- thêm mới bảng [UserWorkflow] lấy Id       
declare @UserWorkflowIdNew as bigint 
      
INSERT INTO [dbo].[UserWorkflow]      
           ([UserId]      
           ,[WorkflowId]      
           ,[WorkflowStepId]      
           ,[WorkflowCode]      
           ,[ShortContent]      
           ,[Status]      
           ,[CreatedBy]      
           ,[CreatedTime]      
           ,[LastModified]      
           ,[ModifiedBy]      
           ,[IsDeleted]      
           ,[IsDraft]      
           ,[UserWorkflowStatus]      
           ,[Content]      
           ,[Note]      
           ,[Approver]      
           ,[IsWaitingForAppoved]      
           ,[MeetingRoom]      
           ,[IsConverted]      
           ,[MainUserWorkflowId]      
           ,[WorkId])      
select [UserId]      
           ,@WorkflowId as [WorkflowId]      
           ,[WorkflowStepId]      
           ,[WorkflowCode]      
           ,[ShortContent]      
           ,[Status]      
           ,CreatedBy      
           ,GETDATE() as [CreatedTime]      
           ,GETDATE() as  [LastModified]      
           ,[ModifiedBy]      
           ,[IsDeleted]      
           ,[IsDraft]      
           ,[UserWorkflowStatus]      
           ,[Content]      
           ,[Note]      
           ,[Approver]      
           ,[IsWaitingForAppoved]      
           ,[MeetingRoom]      
           ,[IsConverted]      
           ,[MainUserWorkflowId]      
           ,[WorkId]      
from UserWorkflow where Id=@UserWorkflowIdOld      
      
set @UserWorkflowIdNew =@@IDENTITY      
  
;  
  
INSERT INTO [dbo].[UserWorkflowStep]  
           ( [UserWorkflowId]  
           ,[UserId]  
           ,[FromUserWorkflowId]  
           ,[WorkflowStepId]  
           ,[CreatedBy]  
           ,[CreatedTime]  
           ,[LastModified]  
           ,[ModifiedBy]  
           ,[IsDeleted]  
           ,[IsActived]  
           ,[Index]  
           ,[StartTime]  
           ,[FinishTime]  
           ,[Action]  
           ,[Note]  
           ,[IsRecall]  
           ,[IsAddInfo]  
           ,[IsReplace]  
           ,[DueDate]  
           ,[IsDefault]  
           ,[IsIdea]  
           ,[IsReturned]  
           ,[SkippedByUserWorkflowStepId]  
           ,[IsAuthorizeApproval]  
           ,[AuthorizeApprovalCode])  
       
  select @UserWorkflowIdNew as [UserWorkflowId]  
           ,[UserId]  
           ,[FromUserWorkflowId]  
           ,@WorkflowStepId as [WorkflowStepId]  
           ,[CreatedBy]  
           ,[CreatedTime]  
           ,[LastModified]  
           ,[ModifiedBy]  
           ,[IsDeleted]  
           ,[IsActived]  
           ,[Index]  
           ,[StartTime]  
           ,[FinishTime]  
           ,[Action]  
           ,[Note]  
           ,[IsRecall]  
           ,[IsAddInfo]  
           ,[IsReplace]  
           ,[DueDate]  
           ,[IsDefault]  
           ,[IsIdea]  
           ,[IsReturned]  
           ,[SkippedByUserWorkflowStepId]  
           ,[IsAuthorizeApproval]  
           ,[AuthorizeApprovalCode]  
from [dbo].[UserWorkflowStep]   
where UserWorkflowId=@UserWorkflowIdOld  
  
; 

select @UserWorkflowIdNew
go

