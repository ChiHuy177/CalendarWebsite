-- Work_ReportChartByUserLogin 'vuongnq@vntt.com.vn'                                                  
   CREATE   PROC  [dbo].[Work_ReportChartByUserLogin]                                           
   @email AS NVARCHAR(50) = '',                                  
   @projectId as nvarchar(50)='' ,                            
   @projectType as nvarchar(150)=''                            
   AS                                              
   DECLARE @userId AS NVARCHAR(20)                                                
   CREATE TABLE #duan (UserWorkflowId char(50)  NOT NULL PRIMARY KEY, Ten nvarchar(500), Loai nvarchar(500), RemindReviewsWork char(10))                  
   DECLARE @tab TABLE(Name  nvarchar(150), Quantity INT,UserID nVARCHAR(50), type int)                                     
   SET @userId = (                                                
   SELECT 'P:' + TRIM(str(Id))                                                
   FROM PersonalProfile                                                
   WHERE Email = @email  and ISNULL(IsDeleted,0)=0 and UserStatus <>-1                                   
   )                                                
   if(@projectId='')                                
   begin                                 
   insert into #duan select UserWorkflowId,Ten,Loai,RemindReviewsWork from Dynamic.Data_RESOURCEDA where ISNULL(IsDeleted,'False')='False'  and ISNULL(Loai,'') like  N'%'+ @projectType+'%'    and TrangThai <>N'Hủy'                                    
   insert into #duan select '','','',''                 
   end                                
   else                                
   begin                                 
   insert into #duan select UserWorkflowId,Ten,Loai,RemindReviewsWork from Dynamic.Data_RESOURCEDA  where UserWorkflowId= @projectId                         
   end                                          
   insert into @tab                                            
   select N'Xử lý' AS Name , 0 as Quantity, @userId as UserID , 1 as type                                            
   insert into @tab                                            
   select N'Theo dõi' AS Name , 0 as Quantity, @userId as UserID, 2 as type                                            
   insert into @tab                                            
   select N'Việc giao' AS Name , 0 as Quantity, @userId as UserID, 3 as type                                            
   insert into @tab                                            
   select N'Phối hợp' AS Name , 0 as Quantity, @userId as UserID, 4 as type                      
   insert into @tab                                            
   select N'Việc đã xử lý' AS Name , 0 as Quantity, @userId as UserID, 5 as type                      
   insert into @tab                                            
   select N'Việc cần đánh giá' AS Name , 0 as Quantity, @userId as UserID, 6 as type        
   SELECT a.UserWorkflowId    
   ,case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoigiao,''), ';') where value=@userId )>0 then 1 else 0 end as Nguoigiao  
   ,case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoixuly,''), ';') where value=@userId )>0 then 1 else 0 end as Nguoixuly  
   ,case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoitheodoi,''), ';') where value=@userId )>0 then 1 else 0 end as Nguoitheodoi  
   ,case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoiphoihop,''), ';') where value=@userId )>0 then 1 else 0 end as Nguoiphoihop  
   ,case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.NguoiXuLyDauTien,''), ';') where value=@userId )>0 then 1 else 0 end as NguoiXuLyDauTien  
   ,d.TrangThaiCongViec  
   ,b.RemindReviewsWork   
   into #work                                        
   from  [Dynamic].Data_WORK a           
   inner join  DYNAMIC.Data_RESOURCETTFC d  on a.TrangThaiCongViec=d.UserWorkflowId and a.Duan=d.Duan       
   inner join  #duan b on  isnull(a.Duan, '') = b.UserWorkflowId                                              
   WHERE ISNULL(a.WorkRepeat,'False')='False'      
   and @userId = (select top 1 value                
   from STRING_SPLIT(ISNULL(a.Nguoixuly,'')+';'+ISNULL(a.NguoiXuLyDauTien,'')  
   +';'+ISNULL(a.Nguoiphoihop,'')+';'+ISNULL(a.Nguoigiao,'')+';'+ISNULL(a.Nguoitheodoi,''), ';')   
   where value=@userId  
   group by value )  
   and ISNULL(a.IsActive,'True')='True'    
   update @tab set Quantity= (                                            
   SELECT COUNT(*) AS Quantity                                                
   from  #work a                    
   WHERE  a.Nguoixuly=1  
   and  isnull(a.TrangThaiCongViec,'') not in ( N'Hoàn thành',N'Hủy')   
   ) where type=1       
   update @tab set Quantity=(                                            
   SELECT COUNT(*) AS Quantity                                                
   from  #work a                            
   WHERE  a.Nguoitheodoi=1                                     
   and  isnull(a.TrangThaiCongViec,'') not in ( N'Hoàn thành',N'Hủy')   
   ) where type=2                                            
   update @tab set Quantity=(                                            
   SELECT COUNT(*) AS Quantity                                                
   from  #work a                            
   WHERE  a.Nguoigiao=1                                
   and  isnull(a.TrangThaiCongViec,'') not in ( N'Hoàn thành',N'Hủy')                    
   ) where type=3                                            
   update @tab set Quantity=(                                            
   SELECT COUNT(*) AS Quantity                                                
   from  #work a                            
   WHERE      a.Nguoiphoihop=1                                  
   and  isnull(a.TrangThaiCongViec,'') not in ( N'Hoàn thành',N'Hủy')                     
   ) where type=4                               
   update @tab set Quantity=(                                            
   SELECT COUNT(*) AS Quantity                                                
   from  #work a                               
   WHERE ( Nguoigiao=1 or Nguoiphoihop=1 or Nguoitheodoi=1 or NguoiXuLyDauTien=1)  
   and  isnull(a.TrangThaiCongViec,'') in ( N'Hoàn thành',N'Hủy')    
   ) where type=5                          
   update @tab set Quantity=(                                            
   SELECT COUNT(*) AS Quantity                                                
   from  #work a                     
   left join Dynamic.Data_ReviewsWork e on e.WorkId=a.UserWorkflowId      
   WHERE  a.Nguoigiao=1   
   and  isnull(a.TrangThaiCongViec,'') =N'Hoàn thành' and a.RemindReviewsWork='1' and e.WorkId is null                                                       
   ) where type=6                         
   select Name,ISNULL(Quantity,0) as Quantity,UserID from @tab       
   drop table #duan  
   drop table #work
go

