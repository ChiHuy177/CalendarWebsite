CREATE procedure [dbo].[GetListAllMember] @key varchar(50) =''
as
begin
	
	select * from (
	select us.AccountName,cus.CustomerName, cus.CustomerCode,cus.AccountantCode, cus.PhoneBilling,cus.Address,case when us.ID is null then 0 else us.ID end ID,cus.ID CustomerID,
	ROW_NUMBER() OVER (ORDER BY cus.ID DESC) AS RowNum
	 from CustomerDB.dbo.Customers cus  left join UserDetails us on us.CustomerID = cus.ID
	 where cus.CustomerCode  like '%' + @key + '%' or cus.AccountantCode like '%' + @key+ '%' or 
	 cus.PhoneBilling like + '%' + @key + '%' or cus.CustomerName like '%' +  @key + '%') temp
	 where RowNum >= 1 and RowNum <=50
end
go

