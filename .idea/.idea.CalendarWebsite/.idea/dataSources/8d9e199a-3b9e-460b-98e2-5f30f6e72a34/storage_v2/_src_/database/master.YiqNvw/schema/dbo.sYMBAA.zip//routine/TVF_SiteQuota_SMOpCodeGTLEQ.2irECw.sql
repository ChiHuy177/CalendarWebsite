CREATE FUNCTION [dbo].[TVF_SiteQuota_SMOpCodeGTLEQ]
(
    @SiteId uniqueidentifier,
    @SessionId smallint,
    @GTSMOpCode tinyint,
    @LEQSMOpCode tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SiteQuota] WITH (INDEX=SiteQuota_SiteId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        SessionId = @SessionId AND
        SMOpCode > @GTSMOpCode AND
        SMOpCode <= @LEQSMOpCode

go

