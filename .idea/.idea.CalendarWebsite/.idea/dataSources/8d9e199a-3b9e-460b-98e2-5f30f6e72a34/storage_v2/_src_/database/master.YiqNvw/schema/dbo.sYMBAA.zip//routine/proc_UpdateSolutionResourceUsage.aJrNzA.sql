CREATE PROC [dbo].[proc_UpdateSolutionResourceUsage](
    @SiteId uniqueidentifier,
    @SolutionId uniqueidentifier,
    @ResourceQuota float,
    @RecentInvocations int)
AS
    SET NOCOUNT ON
    UPDATE
        Solutions
    SET
        ResourceQuota = @ResourceQuota,
        RecentInvocations = @RecentInvocations
    FROM
        TVF_Solutions_PTCSolution(@SiteId, @SolutionId) AS Solutions
    RETURN 0

go

