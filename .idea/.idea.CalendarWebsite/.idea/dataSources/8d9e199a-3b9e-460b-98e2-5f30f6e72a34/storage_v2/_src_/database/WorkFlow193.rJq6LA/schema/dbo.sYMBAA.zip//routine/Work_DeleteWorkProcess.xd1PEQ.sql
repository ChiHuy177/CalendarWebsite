CREATE   PROC [dbo].[Work_DeleteWorkProcess]
   as
   delete Dynamic.Data_TMDSQTCV where IsUseForWork <0
   delete Dynamic.Data_LSQTCV where IsUseForWork <0
   delete Dynamic.Data_FOLLOWCHART where IsUseForWork <0
go

