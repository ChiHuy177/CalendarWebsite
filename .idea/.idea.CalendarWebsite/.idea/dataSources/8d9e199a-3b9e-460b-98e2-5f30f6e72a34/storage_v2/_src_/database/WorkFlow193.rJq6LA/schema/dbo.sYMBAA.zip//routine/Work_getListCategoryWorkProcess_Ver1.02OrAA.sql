/****** Script for SelectTopNRows command from SSMS ******/   
   -- [Work_getListCategoryWorkProcess_Ver1] 'P:287'  
   CREATE   PROC [dbo].[Work_getListCategoryWorkProcess_Ver1]   
   @UserId as nvarchar(50)   
   as  
   declare @tbUser table ( UserId nvarchar(50), UserWorkflowId bigint)   
   insert into @tbUser   
   select * from   
   (   
   SELECT    
   'P:'+ trim(str(c.PersonalProfilesId)) AS userId   
   ,a.UserWorkflowId   
   -- into #da   
   FROM Dynamic.Data_TMDSQTCV AS a   
   CROSS APPLY STRING_SPLIT(a.PermissionUser, ';') as b   
   inner join GroupPersonalProfile c on 'G:'+ trim(str(GroupsId))=b.value   
   where left(trim(b.value),2)='G:'   
   and ISNULL(a.IsUseForWork,'')='' and ISNULL(IsDelete,'False')='False'   
   union   
   SELECT    
   b.value AS userId   
   ,a.UserWorkflowId   
   -- into #da   
   FROM Dynamic.Data_TMDSQTCV AS a   
   CROSS APPLY STRING_SPLIT(a.PermissionUser, ';') as b   
   where left(trim(b.value),2)='P:'   
   and ISNULL(a.IsUseForWork,'')='' and ISNULL(IsDelete,'False')='False'   
   union   
   SELECT    
   'P:'+ trim(str(b.Id)) AS userId    
   ,a.UserWorkflowId   
   -- into #da   
   FROM Dynamic.Workflow_TMDSQTCV AS a   
   inner join PersonalProfile b on a.CreatedBy=b.Email   
   inner join Dynamic.Data_TMDSQTCV c on a.UserWorkflowId=c.UserWorkflowId  
   where ISNULL(c.IsUseForWork,'')='' and ISNULL(IsDelete,'False')='False'   
   ) a group by userId,UserWorkflowId   
   select * from (   
   SELECT   
   Title as label   
   ,trim(str(a.UserWorkflowId)) as value   
   FROM Dynamic.Data_TMDSQTCV a    
   --inner join   
   --(   
   -- select WorkflowId,max(ISNULL(Version,1)) as Version from Dynamic.Data_TMDSQTCV group by WorkflowId   
   --) b on ISNULL(a.WorkflowId,'') = ISNULL(b.WorkflowId,'') and ISNULL(a.Version,1)=b.Version   
   inner join Dynamic.Data_FOLLOWCHART c on TRIM( str(a.UserWorkflowId))= trim(c.CategoryWorkProcessId)   
   inner join @tbUser d on a.UserWorkflowId=d.UserWorkflowId   
   where ISNULL(a.IsUseForWork,'')='' and d.UserId=@UserId and ISNULL(a.IsDelete,'False')='False'   
   union   
   SELECT   
   Title as label   
   ,trim(str(a.UserWorkflowId)) as value   
   FROM Dynamic.Data_TMDSQTCV a    
   --inner join   
   --(   
   -- select WorkflowId,max(ISNULL(Version,1)) as Version from Dynamic.Data_TMDSQTCV group by WorkflowId   
   --) b on ISNULL(a.WorkflowId,'') = ISNULL(b.WorkflowId,'') and ISNULL(a.Version,1)=b.Version   
   inner join Dynamic.Data_FOLLOWCHART c on TRIM( str(a.UserWorkflowId))= trim(c.CategoryWorkProcessId)   
   --inner join @tbUser d on a.UserWorkflowId=d.UserWorkflowId   
   where ISNULL(a.IsUseForWork,'')='' and ISNULL( a.PermissionUser,'')='' and ISNULL(a.IsDelete,'False')='False'   
   ) a   
   group by a.label,a.value   
go

