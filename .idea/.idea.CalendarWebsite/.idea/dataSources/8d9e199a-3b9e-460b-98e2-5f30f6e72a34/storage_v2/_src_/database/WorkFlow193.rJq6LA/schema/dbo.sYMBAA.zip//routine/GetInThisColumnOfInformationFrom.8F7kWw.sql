-- =============================================
-- Author:		Duy Dam
-- Create date: 09/11/2021
-- Description:	Get list value from column which is defined in property
-- =============================================
CREATE     PROCEDURE [dbo].[GetInThisColumnOfInformationFrom]
	-- Add the parameters for the stored procedure here
	@FromWeb INT
	,@InformationFrom NVARCHAR(max)
	,@InThisColumn NVARCHAR(max)
	,@Email NVARCHAR(max) = NULL
	,@IsAll bit = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@SqlScript NVARCHAR(4000)
		,@TableName AS NVARCHAR(MAX)
		,@UserId AS BIGINT
		,@IsNewVersionOfSQL AS BIT = 0;

	IF EXISTS (
			SELECT TOP 1 Id
			FROM WorkflowPara
			WHERE ParaName = 'IsNewVersionOfSQL'
				AND IsSystemPara = 1
			)
	BEGIN
		SET @IsNewVersionOfSQL = CAST(1 AS BIT);
	END

	/* Root: 0 , Workflow: 1 */
	IF @FromWeb = 0
	BEGIN
		IF (
				@InformationFrom = N'PersonalProfile'
				OR @InformationFrom = N'Nhân viên'
				)
			SET @SqlScript = 'SELECT distinct TOP 1000 [' + @InThisColumn + '] FROM (SELECT TOP 1000 p.* 
						,m.FullName AS Manager 
						,d.Title as Department 
						,po.Title as Position 
						FROM PersonalProfile p 
						LEFT JOIN PersonalProfile m ON m.Id = p.ManagerId 
						LEFT JOIN Department d on d.Id = p.DepartmentId 
						LEFT JOIN Position po on po.Id = p.PositionId ) AS u
						WHERE IsDeleted = 0 AND [' + @InThisColumn + '] IS NOT NULL AND [' + @InThisColumn + '] <> '''' '
		ELSE IF (
				@InformationFrom = N'Department'
				OR @InformationFrom = N'Đơn vị'
				)
			SET @SqlScript = 'SELECT distinct TOP 1000 [' + @InThisColumn + '] FROM (SELECT TOP 1000 d.* 
						,m.FullName AS Manager
						,pa.Title AS Parent
						FROM Department d 
						LEFT JOIN Department pa ON pa.ID = d.ParentId
						LEFT JOIN PersonalProfile m ON m.Id = d.ManagerId) AS u
						WHERE IsDeleted = 0 AND [' + @InThisColumn + '] IS NOT NULL AND [' + @InThisColumn + '] <> '''' '
		ELSE IF (
				@InformationFrom = N'Position'
				OR @InformationFrom = N'Chức vụ'
				)
			SET @SqlScript = 'SELECT distinct TOP 1000 [' + @InThisColumn + '] FROM [dbo].[Position] WHERE IsDeleted = 0 AND [' + @InThisColumn + '] IS NOT NULL 
				AND [' + @InThisColumn + '] <> '''' '
		ELSE
			SET @SqlScript = 'SELECT distinct TOP 1000 [' + @InThisColumn + '] FROM [dbo].[' + @InformationFrom + '] WHERE IsDeleted = 0 AND [' + @InThisColumn + '] IS NOT NULL 
				AND [' + @InThisColumn + '] <> '''' '

		SET @SqlScript = @SqlScript + ' OPTION (RECOMPILE)'
		EXEC sp_executesql @SqlScript;
	END
	ELSE
	BEGIN
		SET @WorkflowCode = (
				SELECT Code
				FROM [dbo].[Workflow]
				WHERE Id = @InformationFrom
				);
		SET @TableName = CONCAT (
				'Dynamic.Workflow_'
				,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
				);
		SET @UserId = (
				SELECT TOP 1 Id
				FROM [dbo].[PersonalProfile]
				WHERE Email = @Email
					AND IsDeleted = 0
				ORDER BY Id DESC
				);

		IF (
				@WorkflowCode IS NOT NULL
				AND @WorkflowCode != ''
				)
		BEGIN
			IF @InThisColumn = N'Mã Phiếu'
			BEGIN
				SELECT TOP 1000 u.WorkflowCode
				FROM [dbo].[UserWorkflow] u WITH (NOLOCK)
				INNER JOIN [dbo].[Workflow] w WITH (NOLOCK) ON w.Id = u.WorkflowId
				WHERE u.WorkflowId = @InformationFrom
					AND u.IsDeleted = 0
					AND u.WorkflowCode IS NOT NULL
					AND u.UserWorkflowStatus = 1
					AND (
						EXISTS (
							SELECT TOP 1 Id
							FROM UserWorkflowStep WITH (NOLOCK)
							WHERE UserWorkflowId = u.Id
								AND UserId = @UserId
								AND IsDeleted = 0
							)
						OR EXISTS (
							SELECT TOP 1 Id
							FROM UserWorkflowShare WITH (NOLOCK)
							WHERE UserWorkflowId = u.Id
								AND UserId = @UserId
								AND IsDeleted = 0
							)
						OR (
							w.SeenPermission IS NOT NULL
							AND w.SeenPermission <> ''
							AND (
								w.SeenPermission LIKE '%P:' + CAST(@UserId AS VARCHAR) + '%'
								OR EXISTS (
									SELECT TOP 1 [gp].*
									FROM [dbo].[GroupPersonalProfile] [gp] WITH (NOLOCK)
									JOIN dbo.splitPermissionGroup(CONCAT (
												w.SeenPermission
												,','
												)) [sl] ON [sl].[Name] = [gp].[GroupsId]
									WHERE [gp].[PersonalProfilesId] = @UserId
									)
								)
							)
						OR @IsAll = 1
						)
				ORDER BY u.Id desc
				OPTION (RECOMPILE)
			END
			ELSE
			BEGIN
				IF @IsNewVersionOfSQL = CAST(1 AS BIT)
				BEGIN
					DECLARE @columnForJson AS NVARCHAR(Max) = CONCAT (
							'$'
							,'.'
							,@InThisColumn
							);

					SET @SqlScript = 'SELECT TOP 1000 
										dbo.fnRemoveHtml(JSON_VALUE(d.[Data],''' + @columnForJson + '''))
										FROM ' + @TableName + ' d WITH (NOLOCK)
										INNER JOIN [dbo].[UserWorkflow] u WITH (NOLOCK) ON (
												u.Id = d.UserWorkflowId
												AND u.IsDeleted = 0
												)
										INNER JOIN [dbo].[Workflow] w WITH (NOLOCK) ON w.Id = u.WorkflowId
										WHERE d.IsDeleted = 0
											AND u.UserWorkflowStatus = 1
											AND 
												JSON_VALUE(d.[Data],''' + @columnForJson + ''')
													 IS NOT NULL
		
											AND (
												EXISTS (
													SELECT TOP 1 Id
													FROM UserWorkflowStep WITH (NOLOCK)
													WHERE UserWorkflowId = u.Id
														AND UserId = ' + CAST(@UserId AS VARCHAR) + '
														AND IsDeleted = 0
													)
												OR ' + CAST(@IsAll AS varchar(1)) + ' = 1
												OR EXISTS (
													SELECT TOP 1 Id
													FROM UserWorkflowShare WITH (NOLOCK)
													WHERE UserWorkflowId = u.Id
														AND UserId = ' + CAST(@UserId AS VARCHAR) + 
						'
														AND IsDeleted = 0
													)
												OR (
													w.SeenPermission IS NOT NULL
													AND w.SeenPermission <> ''''
													AND (
														w.SeenPermission LIKE ''%P:' + CAST(@UserId AS VARCHAR) + '%'' ' + 'OR EXISTS (
															SELECT TOP 1 [gp].*
															FROM [dbo].[GroupPersonalProfile] [gp] WITH (NOLOCK)
															JOIN dbo.splitPermissionGroup(CONCAT ( w.SeenPermission ,'',''))  [sl] ON [sl].[Name] = [gp].[GroupsId]
															WHERE [gp].[PersonalProfilesId] = ' + CAST(@UserId AS VARCHAR) + '
															)
														)
													)
												)
										ORDER BY d.Id DESC';
				END
				ELSE
					SET @SqlScript = 'SELECT TOP 1000 dbo.fnRemoveHtml((SELECT ( CASE WHEN ( [StringValue] = ' + '''null''' + ' OR [StringValue] = '''' ) THEN NULL ELSE [StringValue] END ) FROM parseJSON(d.[Data]) WHERE [Name] = ''' + @InThisColumn + ''')) FROM ' + @TableName + ' d ' + 'INNER JOIN [dbo].[UserWorkflow] u ON (u.Id = d.UserWorkflowId AND u.IsDeleted = 0) INNER JOIN [dbo].[Workflow] w ON w.Id = u.WorkflowId ' + ' WHERE d.IsDeleted = 0 AND u.UserWorkflowStatus = 1 AND ((SELECT ( CASE WHEN ( [StringValue] = ' + '''null''' + ' OR [StringValue] = '''' ) THEN NULL ELSE [StringValue] END ) FROM parseJSON(d.[Data]) WHERE [Name] = ''' + @InThisColumn + ''') IS NOT NULL) ' + 'AND (EXISTS(SELECT TOP 1 Id FROM UserWorkflowStep where UserWorkflowId = u.Id and UserId = ' + CAST(@UserId AS VARCHAR) + ' and IsDeleted = 0) OR ' + CAST(@IsAll AS varchar(1)) + ' = 1 OR EXISTS(SELECT TOP 1 Id FROM UserWorkflowShare where UserWorkflowId = u.Id and UserId = ' + CAST(@UserId AS VARCHAR) + ' and IsDeleted = 0)' + 
						' OR( w.SeenPermission IS NOT NULL AND w.SeenPermission <> '''' AND (w.SeenPermission LIKE ''%P:' + CAST(@UserId AS VARCHAR) + '%'' ' + ' OR EXISTS (SELECT TOP 1 [gp].* FROM [dbo].[GroupPersonalProfile] [gp] JOIN dbo.splitPermissionGroup(CONCAT ( w.SeenPermission ,'','')) [sl] ON [sl].[Name] = [gp].[GroupsId] WHERE [gp].[PersonalProfilesId] = ' + CAST(@UserId AS VARCHAR) + ') ) ) )' + ' ORDER BY d.Id DESC'

				--SET @SqlScript = 'SELECT TOP 1000 dbo.fnRemoveHtml(JSON_VALUE(d.[Data], ''$.' + @InThisColumn + ''')) FROM ' + @TableName + ' d INNER JOIN [dbo].[UserWorkflow] u ON (u.Id = d.UserWorkflowId AND u.IsDeleted = 0) WHERE d.IsDeleted = 0 ' + 'AND JSON_VALUE(d.[Data], ''$.' + @InThisColumn + ''') IS NOT NULL ' + ' ORDER BY d.Id DESC';
				--PRINT @SqlScript

				SET @SqlScript = @SqlScript + ' OPTION (RECOMPILE)'
				EXEC sp_executesql @SqlScript;
			END
		END
	END
END
go

