-- =============================================
-- Author:		DuyDam
-- Create date: 15/04/2022
-- Description:	Set done for job and update IsWaitingForAppoved for UserWorkflowS
-- =============================================
CREATE   PROCEDURE [dbo].[SetDoneForUserWorkflowJobOfUserCheckList] @UserWorkflowId BIGINT
	,@UserCheckListId BIGINT
	,@IsFail BIT
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
	BEGIN TRAN

	UPDATE [dbo].[UserWorkflowJob]
	SET IsDone = 1
		,IsExecuting = 0
		,IsFail = (
			CASE @IsFail
				WHEN CAST(1 AS BIT)
					THEN CAST(1 AS BIT)
				ELSE CAST(0 AS BIT)
				END
			)
		,IsSucess = (
			CASE @IsFail
				WHEN CAST(1 AS BIT)
					THEN CAST(0 AS BIT)
				ELSE CAST(1 AS BIT)
				END
			)
	WHERE UserWorkflowId = @UserWorkflowId
		AND UserCheckListId = @UserCheckListId;

	-- UPDATE [dbo].[UserWorkflow]
	-- SET IsWaitingForAppoved = (
	-- 		CASE 
	-- 			WHEN NOT EXISTS (
	-- 					SELECT TOP 1 Id
	-- 					FROM [dbo].[UserWorkflowJob] WITH (NOLOCK)
	-- 					WHERE IsDeleted = CAST(0 AS BIT)
	-- 						AND IsDone = CAST(0 AS BIT)
	-- 						AND UserWorkflowId = @UserWorkflowId
	-- 					)
	-- 				THEN 0
	-- 			ELSE 1
	-- 			END
	-- 		)
	-- WHERE Id = @UserWorkflowId;
	COMMIT TRAN
END
go

