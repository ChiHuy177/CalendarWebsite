-- Work_CheckIsDepartmentManager 'P:285','5'
   CREATE   PROC Work_CheckIsDepartmentManager  
   @defaulUser AS NVARCHAR(50) = ''                 
   ,@department AS NVARCHAR(50) = ''    
   as  
   select a.Id from Department a     
   where id in (       
   select b.value from Dynamic.Data_RuleViewProject a      
   cross apply string_split(Department,';') b      
   where [User]=@defaulUser      
   ) and Id=@department  and a.IsDeleted=0    
   union   
   select b.Id from PersonalProfile a       
   inner join Department b on a.DepartmentId=b.Id      
   where 'P:'+ trim(str(b.ManagerId)) =@defaulUser  and b.IsDeleted=0
go

