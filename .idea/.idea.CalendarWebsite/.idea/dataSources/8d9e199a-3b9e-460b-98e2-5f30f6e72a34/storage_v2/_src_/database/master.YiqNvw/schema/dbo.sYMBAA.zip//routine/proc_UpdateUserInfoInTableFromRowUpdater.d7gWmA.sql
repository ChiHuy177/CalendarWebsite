CREATE PROCEDURE [dbo].[proc_UpdateUserInfoInTableFromRowUpdater](
    @SiteId uniqueidentifier,
    @UserId int,
    @Title nvarchar(255) = NULL,
    @Email nvarchar(255) = NULL,
    @IsActive bit = NULL,
    @Locale int = NULL,
    @CalendarType smallint = NULL,
    @AdjustHijriDays smallint = NULL,
    @TimeZone smallint = NULL,
    @Collation smallint = NULL,
    @Time24 bit = NULL,
    @AltCalendarType tinyint = NULL,
    @CalendarViewOptions tinyint = NULL,
    @WorkDays smallint = NULL,
    @WorkDayStartHour smallint = NULL,
    @WorkDayEndHour smallint = NULL,
    @MobileNumber nvarchar(127) = NULL,
    @MUILanguages varchar(64) = NULL,
    @ContentLanguages varchar(64) = NULL,
    @RequestGuid uniqueidentifier = NULL OUTPUT     
)
AS
    SET NOCOUNT ON
    DECLARE @OldIsActive bit
    SELECT TOP 1
        @OldIsActive = UI.tp_IsActive
    FROM
        TVF_UserInfo_PK(@SiteId, @UserId) AS UI
    WHERE
        UI.tp_Deleted = 0
    UPDATE
        UI
    SET
        UI.tp_Title = ISNULL(@Title, N''),
        UI.tp_Email = ISNULL(@Email, N''),
        UI.tp_IsActive = ISNULL(@IsActive, tp_IsActive),
        UI.tp_Locale = @Locale,
        UI.tp_CalendarType = @CalendarType,
        UI.tp_AdjustHijriDays = @AdjustHijriDays,
        UI.tp_TimeZone = @TimeZone,
        UI.tp_Time24 = @Time24,
        UI.tp_AltCalendarType = @AltCalendarType,
        UI.tp_CalendarViewOptions = @CalendarViewOptions,
        UI.tp_WorkDays = @WorkDays,
        UI.tp_WorkDayStartHour = @WorkDayStartHour,
        UI.tp_WorkDayEndHour = @WorkDayEndHour,
        UI.tp_Mobile = @MobileNumber,
        UI.tp_MUILanguages = @MUILanguages,
        UI.tp_ContentLanguages = @ContentLanguages
    FROM
        TVF_UserInfo_PK(@SiteId, @UserId) AS UI
    UPDATE 
        I
    SET 
        I.UserEmail = ISNULL(@Email, N'')
    FROM
        TVF_ImmedSubscriptions_SiteIdUserId(@SiteId, @UserId) AS I
    UPDATE 
        S
    SET 
        S.UserEmail = ISNULL(@Email, N'')
    FROM
        TVF_SchedSubscriptions_SiteIdUserId(@SiteId, @UserId) AS S

go

