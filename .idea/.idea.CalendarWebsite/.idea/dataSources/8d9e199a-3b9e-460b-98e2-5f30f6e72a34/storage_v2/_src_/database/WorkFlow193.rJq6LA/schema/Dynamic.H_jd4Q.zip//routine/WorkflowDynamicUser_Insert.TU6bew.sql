-- =============================================
-- Author:		DuyDam
-- Create date: 05/11/2021
-- Description:	Insert value into dynamic table
-- Changelog: 12/04/2022 duydam Replace ' with '' for insert into dynamic tables
--          : 06/01/2024 duydam ADd check for codeTempalte 
-- =============================================
CREATE   PROCEDURE [Dynamic].[WorkflowDynamicUser_Insert] @WorkflowId BIGINT
	,@WorkflowStepId BIGINT
	,@PersonalProfileId BIGINT
	,@Status NVARCHAR(MAX) = NULL
	,@ShortContent NVARCHAR(MAX) = NULL
	,@Content NVARCHAR(MAX) = NULL
	,@IsDraft BIT = NULL
	,@Note NVARCHAR(MAX) = NULL
	,@Email NVARCHAR(MAX) = NULL
	,@Data_Json NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @WorkflowCode AS NVARCHAR(MAX)
		,@TableName AS NVARCHAR(MAX)
		,@LineBreak NCHAR(2) = NCHAR(13) + NCHAR(10)
		,@Sql NVARCHAR(MAX)
		,@UserWorkflowId BIGINT
		,@CurrentYear NVARCHAR(MAX)
		,@CurrentMonth NVARCHAR(MAX)
		,@NeedToUpdateCodeCount BIT = 0
		,@Count BIGINT = 1
		,@AutoGenerateCodeWhenDraft bit = 0
		,@CodeTemplate NVARCHAR(MAX);

	IF (@IsDraft IS NULL)
	BEGIN
		SET @IsDraft = 1;
	END
	

	SET @CurrentYear = [dbo].[fn_GetThe2digitYear]();
	SET @CurrentMonth = [dbo].[fn_GetThe2digitMonth]();
	SET @CodeTemplate = (
			SELECT CodeTemplate
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @WorkflowCode = (
			SELECT Code
			FROM [dbo].[Workflow]
			WHERE Id = @WorkflowId
			);
	SET @TableName = CONCAT (
			'Dynamic.Workflow_'
			,dbo.fn_StripCharacters(@WorkflowCode, '^a-z0-9')
			);
	IF EXISTS (SELECT Id
           FROM  WorkflowPara
           WHERE ParaName = 'AutoGenerateCodeWhenDraft' and Value = '1')
	 BEGIN
	   SET @AutoGenerateCodeWhenDraft = 1;
	 END

	 IF (@CodeTemplate IS NOT NULL AND @CodeTemplate <> '')
	 BEGIN
		SET @AutoGenerateCodeWhenDraft = 0;
	 END

	/* Generate basic para for workflow*/
	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE [WorkflowId] = @WorkflowId
					AND ParaName = 'Year'
				)
			)
	BEGIN
		INSERT INTO [dbo].[WorkflowPara] (
			ParaName
			,WorkflowId
			,Value
			,[Order]
			)
		VALUES (
			'Year'
			,@WorkflowId
			,[dbo].[fn_GetThe2digitYear]()
			,0
			);
	END

	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE [WorkflowId] = @WorkflowId
					AND ParaName = 'Month'
				)
			)
	BEGIN
		INSERT INTO [dbo].[WorkflowPara] (
			ParaName
			,WorkflowId
			,Value
			,[Order]
			)
		VALUES (
			'Month'
			,@WorkflowId
			,[dbo].[fn_GetThe2digitMonth]()
			,0
			);
	END

	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE [WorkflowId] = @WorkflowId
					AND ParaName = 'CodeCount'
				)
			)
	BEGIN
		INSERT INTO [dbo].[WorkflowPara] (
			ParaName
			,WorkflowId
			,Value
			,[Order]
			)
		VALUES (
			'CodeCount'
			,@WorkflowId
			,'1'
			,0
			);
	END

	/*----------------------------------------*/
	/* Update Wofklow Para*/
	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE WorkflowId = @WorkflowId
					AND ParaName = 'Year'
					AND Value = @CurrentYear
				)
			)
	BEGIN
		UPDATE [dbo].[WorkflowPara]
		SET Value = @CurrentYear
		WHERE WorkflowId = @WorkflowId
			AND ParaName = 'Year';

		SET @NeedToUpdateCodeCount = 1;
	END

	IF (
			NOT EXISTS (
				SELECT *
				FROM [dbo].[WorkflowPara]
				WHERE WorkflowId = @WorkflowId
					AND ParaName = 'Month'
					AND Value = @CurrentMonth
				)
			)
	BEGIN
		UPDATE [dbo].[WorkflowPara]
		SET Value = @CurrentMonth
		WHERE WorkflowId = @WorkflowId
			AND ParaName = 'Month';

		SET @NeedToUpdateCodeCount = 1;
	END

	IF (@NeedToUpdateCodeCount = 1)
	BEGIN
		UPDATE [dbo].[WorkflowPara]
		SET Value = 1
		WHERE WorkflowId = @WorkflowId
			AND ParaName = 'CodeCount';
	END

	/* Set WorkflowCode depend on Year and Month*/
	SET @Count = (
			SELECT MAX(CAST(Value AS BIGINT))
			FROM [dbo].[WorkflowPara]
			WHERE WorkflowId = @WorkflowId
				AND ParaName = 'CodeCount'
			);
	SET @WorkflowCode = CONCAT (
			@WorkflowCode
			,@CurrentYear
			,@CurrentMonth
			,FORMAT(@Count, '0000')
			);
	
	IF @AutoGenerateCodeWhenDraft = 1
	BEGIN
			UPDATE [dbo].[WorkflowPara]
			SET Value = (@Count + 1)
			WHERE WorkflowId = @WorkflowId
				AND ParaName = 'CodeCount';
	END

	/* Insert [UserWorkflow]*/
	INSERT INTO [dbo].[UserWorkflow] (
		UserId
		,WorkflowId
		,WorkflowStepId
		,WorkflowCode
		,ShortContent
		,STATUS
		,CreatedBy
		,CreatedTime
		,IsDeleted
		,UserWorkflowStatus
		,IsDraft
		,Content
		,Note
		)
	VALUES (
		@PersonalProfileId
		,@WorkflowId
		,@WorkflowStepId
		,(CASE @AutoGenerateCodeWhenDraft WHEN 1 THEN @WorkflowCode ELSE '' END)
		,@ShortContent
		,@Status
		,@Email
		,GETDATE()
		,0
		,0
		,@IsDraft
		,@Content
		,@Note
		);

	SET @UserWorkflowId = SCOPE_IDENTITY();
	/* Insert into dynamic table*/
	SET @Sql = 'BEGIN TRANSACTION' + @LineBreak + 'BEGIN TRY' + @LineBreak + 'INSERT INTO ' + @TableName + '([Data], UserWorkflowId, IsDeleted, CreatedBy,CreatedTime)' + @LineBreak + 'SELECT ' + CONCAT (
			'N'
			,''''
			,REPLACE(@Data_Json, '''', '''''')
			,''''
			) + ', ' + CAST(@UserWorkflowId AS VARCHAR) + ' as UserWorkflowId, 0 as IsDeleted, ' + CONCAT (
			''''
			,@Email
			,''''
			) + ' as CreatedBy, ' + CONCAT (
			''''
			,GETDATE()
			,''''
			) + ' as CreatedTime' + @LineBreak + 'COMMIT TRANSACTION' + @LineBreak + 'END TRY' + @LineBreak + 'BEGIN CATCH' + @LineBreak + 'IF @@TRANCOUNT > 0' + @LineBreak + '    ROLLBACK TRANSACTION' + @LineBreak + 'END CATCH' + @LineBreak;

	EXEC sp_ExecuteSql @SQL;

	/* IReturn [UserWorkflow]*/
	SELECT *
	FROM [dbo].[UserWorkflow]
	WHERE Id = @UserWorkflowId;
END
go

