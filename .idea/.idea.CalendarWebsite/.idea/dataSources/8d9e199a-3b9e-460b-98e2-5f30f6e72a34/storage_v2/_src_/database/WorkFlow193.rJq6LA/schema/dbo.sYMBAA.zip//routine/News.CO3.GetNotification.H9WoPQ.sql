-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.GetNotification] @userId Nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @sql AS NVARCHAR(max)

	SELECT dw.*
	FROM [Dynamic].[Workflow_Notification] dw
	INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
	WHERE u.IsDeleted = 0
	and u.UserWorkflowStatus=1
	 AND (dbo.JSON_VALUE([dw].Data, '$.Assignee') LIKE ('%' + CAST(@userId AS VARCHAR) + '%'))
	 

END
go

