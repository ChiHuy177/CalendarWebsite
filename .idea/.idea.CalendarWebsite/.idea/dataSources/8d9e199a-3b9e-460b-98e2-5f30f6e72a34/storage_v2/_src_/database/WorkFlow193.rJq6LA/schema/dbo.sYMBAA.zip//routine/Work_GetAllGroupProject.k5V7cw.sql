-- Work_GetAllGroupProject 258921 
   CREATE   PROC [dbo].[Work_GetAllGroupProject] 
   @projectId as char(50) 
   as 
   select a.Id,a.UserWorkflowId,a.Ten,a.ProjectId,a.Status,a.StartDate,a.DueDate,a.IsDelete,a.IsDefault,a.[Index],a.GroupParent,a.IsParent 
   ,b.Ten as GroupParentName 
   from Dynamic.Data_ProjectGroup a 
   left join Dynamic.Data_ProjectGroup b on a.GroupParent=b.UserWorkflowId and ISNULL(b.IsDelete,'False')='False' 
   where a.ProjectId=@projectId and ISNULL(a.IsDelete,'False')='False' --and ISNULL(a.IsParent,'')='' 
   order by a.[Index] 
      -- select * from Dynamic.Data_ProjectGroup where UserWorkflowId=308538 
      -- update Dynamic.Data_ProjectGroup set GroupParent=308535 where UserWorkflowId=308043 
      -- update Dynamic.Data_ProjectGroup set GroupParent=null where UserWorkflowId=308535
go

