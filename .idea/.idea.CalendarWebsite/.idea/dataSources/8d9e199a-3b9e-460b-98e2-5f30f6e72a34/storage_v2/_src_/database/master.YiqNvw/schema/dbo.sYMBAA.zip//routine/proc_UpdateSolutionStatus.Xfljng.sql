CREATE PROC [dbo].[proc_UpdateSolutionStatus](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @SolutionId uniqueidentifier,
    @SolutionLevel int,
    @Hash nvarchar(50),
    @Status smallint)
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    UPDATE
        Solutions
    SET
        Status = @Status
    FROM
        TVF_Solutions_UniqueSolution(@SiteId, @WebId, @SolutionId, @SolutionLevel) AS Solutions
    WHERE
        Hash = @Hash
    IF @@ROWCOUNT = 1
    BEGIN
        SET @Ret = 0
    END
    ELSE
    BEGIN
        SET @Ret = 1
    END
    RETURN @Ret

go

