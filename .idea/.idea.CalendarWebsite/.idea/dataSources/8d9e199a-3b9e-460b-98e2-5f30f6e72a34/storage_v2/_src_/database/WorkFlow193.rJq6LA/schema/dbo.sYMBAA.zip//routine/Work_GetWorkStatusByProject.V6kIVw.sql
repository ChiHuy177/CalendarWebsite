-- Work_GetWorkStatusByProject '333572',''         
   CREATE   PROC [dbo].[Work_GetWorkStatusByProject]          
   @userWorkFlowId AS nvarchar(max)='332666'          
   ,@userId as nvarchar(50)=''      
   as      
   declare @congviec table ( trangthaiId bigint, trangthai nvarchar(500), id bigint, Tiendo nvarchar(50),ProjectId bigint ,CongViecCha nvarchar(50))         
   declare @tbProject table (ProjectId bigint )         
   insert into @tbProject         
   select * from string_split(@userWorkFlowId,',')         
   select b.Ten as Name, 0 as Quantity, 0 as Value, '' ProjectName,0 as ProjectProgress, c.Step as [index] ,b.id as trangthaiId          
   ,b.UserWorkflowId         
   ,d.ProjectId         
   into #trangthai          
   from [Dynamic].Data_RESOURCEDA a          
   inner join [Dynamic].Data_RESOURCETTFC b on a.UserWorkflowId=b.Duan          
   inner join Dynamic.Data_LSQTCV c on a.UserWorkflowId = c.ProjectId and b.nodeid=c.Nodeid         
   inner join @tbProject d on d.ProjectId=a.UserWorkflowId    
   where ISNULL(b.IsSetting,0)=0  
   group by b.Ten,b.Id,c.Step,b.UserWorkflowId,d.ProjectId ;     
   insert into @congviec       
   select         
   b.Id as trangthaiId         
   , b.Ten as trangthai         
   ,a.id         
   ,a.Tiendo         
   ,d.ProjectId         
   ,a.CongViecCha         
   from [Dynamic].Data_WORK a          
   inner join [Dynamic].Data_RESOURCETTFC b on a.TrangThaiCongViec=b.UserWorkflowId         
   inner join @tbProject d on d.ProjectId=a.Duan         
   where ISNULL(a.IsActive,'True')='True' and ISNULL(a.WorkRepeat,'False')='False'       
   and @userId = (case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoixuly,''), ';') where value=@userId )>0 then @userId       
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoigiao,''), ';') where value=@userId )>0 then @userId       
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoiphoihop,''), ';') where value=@userId )>0 then @userId       
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoitheodoi,''), ';') where value=@userId )>0 then @userId       
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.NguoiXuLyDauTien,''), ';') where value=@userId )>0 then @userId       
   else '' end       
   )       
   SELECT         
   a.trangthaiId,          
   a.trangthai,          
   count(a.Id) AS Quantity          
   ,cast((COUNT(*) /((SELECT case when COUNT(*) =0 then 1 else COUNT(*) end AS Total          
   FROM @congviec) + 0.0) * 100) AS INT ) AS Value          
   , ProjectId          
   --,AVG(CONVERT(int, dbo.fn_GetNumeric(a.Tiendo))) AS ProjectProgress         
   into #sumCongviec          
   FROM @congviec a group by a.trangthai,a.trangthaiId,ProjectId          
   update a set a.Quantity=b.Quantity,a.Value=b.Value         
   from #trangthai a          
   inner join #sumCongviec b on a.trangthaiId=b.trangthaiId          
   -- update #trangthai set ProjectProgress= isnull((select AVG(CONVERT(int, dbo.fn_GetNumeric(Tiendo))) from @congviec),0)         
   update a set a.ProjectProgress=b.ProjectProgress from #trangthai a         
   inner join         
   (         
   select AVG(CONVERT(int, dbo.fn_GetNumeric(Tiendo))) as ProjectProgress,ProjectId from @congviec where ISNULL(CongViecCha,'')='' group by ProjectId         
   ) b on a.ProjectId=b.ProjectId         
   select name,Quantity,Value,ProjectName,ProjectProgress,[index],TrangthaiId,UserWorkflowId,         
   ProjectId    
   from #trangthai order by ProjectId, [index]          
   DROP TABLE #trangthai          
   drop table #sumCongviec
go

