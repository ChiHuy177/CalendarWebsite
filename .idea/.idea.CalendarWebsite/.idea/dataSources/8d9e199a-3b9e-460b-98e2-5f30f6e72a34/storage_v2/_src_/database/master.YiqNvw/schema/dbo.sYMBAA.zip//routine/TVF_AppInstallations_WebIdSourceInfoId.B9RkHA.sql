CREATE FUNCTION [dbo].[TVF_AppInstallations_WebIdSourceInfoId]
(
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @SourceInfoId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AppInstallations] WITH (INDEX=AppInstallations_WebIdSourceInfoId, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        WebId = @WebId AND
        SourceInfoId = @SourceInfoId

go

