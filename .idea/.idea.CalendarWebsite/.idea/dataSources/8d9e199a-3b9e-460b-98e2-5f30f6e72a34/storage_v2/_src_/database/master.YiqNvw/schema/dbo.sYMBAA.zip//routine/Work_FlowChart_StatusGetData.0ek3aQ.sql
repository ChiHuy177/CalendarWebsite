              
-- [FlowChart_StatusGetData] 'node-d92e0efc-b58e-4c19-b7bb-f7f7a044fec8',210281      
CREATE PROC [dbo].[Work_FlowChart_StatusGetData]  
@nodeid AS NVARCHAR(500)              
,@projectId as nvarchar(500)          
AS              
----------------------------------------    
-- kiểm tra xem có phải là node đầu tiên sau node bắt đầu không nếu là node đầu thì show chức năng cho phép chọn chỉ dùng cho cv con    
declare @step as char(10)     
set @step=( select Step from Dynamic.Data_LSQTCV a    
WHERE ISNULL(a.nodeid, '') = @nodeid  and a.ProjectId=@projectId)    
    
select * into #a from Dynamic.Data_LSQTCV a    
WHERE  a.ProjectId=@projectId   and  Step=0 and @step in (select * from string_split(a.NextStep,','))    
    
SELECT  a.[Id]    
      ,a.[UserWorkflowId]    
      ,a.[Ten]    
      ,a.[Duan]    
      ,a.[TrangThaiCongViec]    
      ,a.[NguoiChinhSua]    
      ,a.[nodeid]    
      ,a.[QuyenXacNhanHoanThanhCV]    
      ,ISNULL(a.[UseForChild],'0') as   [UseForChild]  
      ,case when (select COUNT(*) from #a)>0 then 'true' else 'false' end as [Show]          
FROM DYNAMIC.Data_RESOURCETTFC AS a      
WHERE ISNULL(a.nodeid, '') = @nodeid  and a.Duan=@projectId 
go

