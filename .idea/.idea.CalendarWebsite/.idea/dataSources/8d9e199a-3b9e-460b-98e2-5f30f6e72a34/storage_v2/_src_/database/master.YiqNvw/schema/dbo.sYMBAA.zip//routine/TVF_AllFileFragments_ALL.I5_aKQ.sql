CREATE FUNCTION [dbo].[TVF_AllFileFragments_ALL]
(
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllFileFragments] WITH (INDEX=AllFileFragments_PartId_UCI)
    WHERE
        1 = 1

go

