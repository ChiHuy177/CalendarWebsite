-- Work_GetWorkLayoutParentChild '228050,228051,228052,228053,228054,228066,228040,228044,228045' 
   CREATE   PROC [dbo].[Work_GetWorkLayoutParentChild] 
   @workId as nvarchar(max) 
   as 
   -- tạo bảng lưu workid 
   declare @tbId table(UserWorkflowId bigint, RowIndex int,IsMyWork int) 
   insert into @tbId select Item,0,0 from Split(@workId,',') 
   ; 
   -- ***************** đệ quy trong sql lấy ra tất cả cha con ************************** 
   -- rowIndex thứ tự node tính từ cha xuống băt đầu là 0 (0->1->2....) 
   WITH Managers AS 
   ( 
   --initialization 
   SELECT a.UserWorkflowId,a.Tieude,a.CongViecCha, a.Duan, 0 as RowIndex,1 as IsMyWork 
   FROM [Dynamic].[Data_WORK] AS a 
   inner join @tbId b on a.UserWorkflowId=b.UserWorkflowId 
   --where a.UserWorkflowId in (218184,218207,218930,217302,217404,218720,218722) 
   UNION ALL 
   --recursive execution 
   SELECT 
   a.UserWorkflowId,a.Tieude,a.CongViecCha,b.Duan, b.RowIndex +1 as RowIndex,0 as IsMyWork 
   FROM Dynamic.Data_WORK a 
   inner join Managers b on ISNULL(b.UserWorkflowId,'') = ISNULL(a.CongViecCha,'') 
   where ISNULL( a.IsActive,'True')='True' 
   ) 
   -- ***************** đệ quy trong sql lấy ra tất cả cha con ************************** 
   --bảng #a thêm vào bang tạm #a workId 
   SELECT a.UserWorkflowId,RowIndex,IsMyWork,Tieude into #a 
   FROM Managers a 
   --bảng #b lấy ra distinct workId để xuống dưới join không bị trùng 
   select UserWorkflowId into #b from #a group by UserWorkflowId 
   -- bảng #c lấy ra gốc cha (gốc cha là 0) having dùng để lấy ra node bằng 0 và là duy nhất 
   select UserWorkflowId ,min(RowIndex) as RowIndex,Tieude into #c from #a 
   group by UserWorkflowId,Tieude having COUNT(UserWorkflowId)=1 
   SELECT a.Duan  
   ,a.Id  
   ,a.tieude AS title  
   ,ISNULL(a.noidung, '') AS description  
   ,a.TrangThaiCongViec AS STATUS  
   ,a.tieude  
   ,a.noidung 
   ,ISNULL(a.Nguoiphoihop, '') AS Nguoiphoihop  
   ,isnull(a.Nguoixuly, '') AS Nguoixuly  
   ,ISNULL(a.Nguoigiao, '') AS Nguoigiao  
   ,ISNULL(a.Nguoitheodoi, '') AS Nguoitheodoi  
   ,a.UserWorkflowId 
   ,trim(CONVERT(CHAR, ISNULL(a.Ngaybatdau, null), 120)) AS [start] 
   ,trim(CONVERT(CHAR, ISNULL(a.Ngayketthuc, null), 120)) AS [end]  
   ,trim(CONVERT(CHAR, ISNULL(e.CreatedTime, getdate()), 120)) AS CreatedTime  
   ,ISNULL(a.Loaicv, '') AS Loaicv  
   ,ISNULL(a.CongViecCha,'') as CongViecCha 
   ,a.Tiendo as Progress 
   ,b.Ten as projectName 
   ,d.Ten as statusName 
   ,a.Douutien Priority 
   ,c.TenCV as CategoryName  
   ,d.TrangThaiCongViec as StatusType  
   ,e.Id as Id1 
   ,e.CreatedBy  
   ,case when ISNULL( g.UserWorkflowId,0)>0 then 1 else 0 end as IsMyWork 
   ,case when ISNULL( h.RowIndex,9999)=0 then 0 else 9999 end as RowIndex 
   ,d.TrangThaiCongViec as StatusType  
   ,case when ISNULL(g.UserWorkflowId,0)>0 then 1 else 0 end as IsMyWork 
   ,case when d.TrangThaiCongViec=N'Hoàn thành' then trim(CONVERT(CHAR, ISNULL(e.LastModified, null), 120)) else null end as DateComplete 
   ,CONVERT(CHAR, ISNULL(e.LastModified, e.CreatedTime), 120) as LastModified 
   --,case when exists ( select UserWorkflowId as abc from [Dynamic].[Data_WORK] where CongViecCha=a.UserWorkflowId) then 'True' else 'False' end as Haschildren 
   ,ISNULL(a.CongViecCha,'') as Parent 
   FROM [Dynamic].[Data_WORK] AS a  
   inner join DYNAMIC.Data_RESOURCEDA b on a.Duan=b.UserWorkflowId 
   left join DYNAMIC.Data_NHOMCV c on a.Loaicv=c.UserWorkflowId 
   left join DYNAMIC.Data_RESOURCETTFC d on a.TrangThaiCongViec=d.UserWorkflowId  
   inner join Dynamic.Workflow_WORK e on a.UserWorkflowId=e.UserWorkflowId 
   inner join #b f on a.UserWorkflowId=f.UserWorkflowId 
   left join @tbId g on a.UserWorkflowId=g.UserWorkflowId 
   left join #c h on a.UserWorkflowId=h.UserWorkflowId 
   order by d.TrangThaiCongViec,a.UserWorkflowId desc 
   --select * from #a 
   --select * from #c 
   drop table #a 
   drop table #b 
   drop table #c
go

