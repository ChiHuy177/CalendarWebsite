CREATE PROCEDURE [dbo].[proc_ReturnWebFeatures](
    @DocSiteId   uniqueidentifier,
    @Webs_Id     uniqueidentifier,
    @SolutionLevel int,
    @IsUserSolutionActivated bit = NULL)
AS
    SET NOCOUNT ON
    DECLARE @ret int
    EXEC @ret = proc_GetWebFeatureList
        @DocSiteId, '00000000-0000-0000-0000-000000000000', @SolutionLevel, @IsUserSolutionActivated
    IF (@ret <> 0)
    BEGIN
        RETURN @ret
    END
    EXEC @ret = proc_GetWebFeatureList
        @DocSiteId, @Webs_Id, @SolutionLevel, @IsUserSolutionActivated
    IF (@ret <> 0)
    BEGIN
        RETURN @ret
    END
    RETURN @ret

go

