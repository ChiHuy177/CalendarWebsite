CREATE PROC [dbo].[proc_UpdateSolutionWebPartData](
    @SiteId uniqueidentifier,
    @WebId uniqueidentifier,
    @SolutionId uniqueidentifier,
    @SolutionLevel int,
    @Hash nvarchar(50),
    @WebPartData varbinary(max))
AS
    SET NOCOUNT ON
    DECLARE @Ret int
    UPDATE
        Solutions
    SET
        WebPartData = @WebPartData 
    FROM
        TVF_Solutions_UniqueSolution(@SiteId, @WebId, @SolutionId, @SolutionLevel) AS Solutions
    WHERE
        Hash = @Hash
    IF @@ROWCOUNT = 1
    BEGIN
        SET @Ret = 0
    END
    ELSE
    BEGIN
        SET @Ret = 1
    END
    RETURN @Ret

go

