
-- =============================================
-- Author:		Duy Dam
-- Create date: 12/09/2022
-- Description:	Get the lsit of userWorkflowStep from the root userWorkflowId
-- =============================================
CREATE   PROCEDURE [dbo].[GetAllUserWorkflowStepFromRootUserWorkflowId] @UserWorkflowId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Insert statements for procedure here		
	WITH TEMP (
		[Id]
		,[UserWorkflowId]
		,[UserId]
		,[FromUserWorkflowId]
		,[WorkflowStepId]
		,[CreatedBy]
		,[CreatedTime]
		,[LastModified]
		,[ModifiedBy]
		,[IsDeleted]
		,[IsActived]
		,[Index]
		,[StartTime]
		,[FinishTime]
		,[Action]
		,[Note]
		,[IsRecall]
		,[IsAddInfo]
		,[IsReplace]
		,[DueDate]
		,[IsDefault]
		,[IsIdea]
		,[IsReturned]
		,[SkippedByUserWorkflowStepId]
		,[ShortContent]
		,[WorkflowTitle]
		,[WorkflowStepTitle]
		,[FullName]
		)
	AS (
		SELECT DISTINCT us.[Id]
			,us.[UserWorkflowId]
			,us.[UserId]
			,us.[FromUserWorkflowId]
			,us.[WorkflowStepId]
			,us.[CreatedBy]
			,us.[CreatedTime]
			,us.[LastModified]
			,us.[ModifiedBy]
			,us.[IsDeleted]
			,us.[IsActived]
			,us.[Index]
			,us.[StartTime]
			,us.[FinishTime]
			,us.[Action]
			,us.[Note]
			,us.[IsRecall]
			,us.[IsAddInfo]
			,us.[IsReplace]
			,us.[DueDate]
			,us.[IsDefault]
			,us.[IsIdea]
			,us.[IsReturned]
			,us.[SkippedByUserWorkflowStepId]
			,u.[ShortContent]
			,w.[Title]
			,ws.[Title]
			,p.FullName
		FROM UserWorkflowStep us
		INNER JOIN PersonalProfile p ON p.Id = us.UserId
		INNER JOIN UserWorkflow u ON us.UserWorkflowId = u.Id
		INNER JOIN Workflow w ON w.Id = u.WorkflowId
		INNER JOIN WorkflowStep ws ON ws.Id = us.WorkflowStepId
		WHERE us.IsDeleted <> 1
			AND us.UserWorkflowId = @UserWorkflowId
		
		UNION ALL
		
		SELECT b.[Id]
			,b.[UserWorkflowId]
			,b.[UserId]
			,b.[FromUserWorkflowId]
			,b.[WorkflowStepId]
			,b.[CreatedBy]
			,b.[CreatedTime]
			,b.[LastModified]
			,b.[ModifiedBy]
			,b.[IsDeleted]
			,b.[IsActived]
			,b.[Index]
			,b.[StartTime]
			,b.[FinishTime]
			,b.[Action]
			,b.[Note]
			,b.[IsRecall]
			,b.[IsAddInfo]
			,b.[IsReplace]
			,b.[DueDate]
			,b.[IsDefault]
			,b.[IsIdea]
			,b.[IsReturned]
			,b.[SkippedByUserWorkflowStepId]
			,ub.[ShortContent]
			,wb.[Title]
			,wsb.[Title]
			,pb.[FullName]
		FROM TEMP AS a
			,UserWorkflowStep AS b
		INNER JOIN PersonalProfile pb ON pb.Id = b.UserId
		INNER JOIN UserWorkflow ub ON b.UserWorkflowId = ub.Id
		INNER JOIN Workflow wb ON wb.Id = ub.WorkflowId
		INNER JOIN WorkflowStep wsb ON wsb.Id = b.WorkflowStepId
		WHERE b.UserWorkflowId IN (
				SELECT ur.UserWorkflowId
				FROM UserWorkflowStepRelation ur
				WHERE ur.UserWorkflowStepId = a.Id
				)
			AND b.Id <> a.Id
			AND b.IsDeleted <> 1
		)
	SELECT us.[Id]
		,us.[UserWorkflowId]
		,us.[UserId]
		,us.[FromUserWorkflowId]
		,us.[WorkflowStepId]
		,us.[CreatedBy]
		,us.[CreatedTime]
		,us.[LastModified]
		,us.[ModifiedBy]
		,us.[IsDeleted]
		,us.[IsActived]
		,us.[Index]
		,us.[StartTime]
		,us.[FinishTime]
		,us.[Action]
		,us.[Note]
		,us.[IsRecall]
		,us.[IsAddInfo]
		,us.[IsReplace]
		,us.[DueDate]
		,us.[IsDefault]
		,us.[IsIdea]
		,us.[IsReturned]
		,us.[SkippedByUserWorkflowStepId]
		,us.[ShortContent]
		,us.[WorkflowTitle]
		,us.[WorkflowStepTitle]
		,us.[FullName]
	FROM TEMP us
	WHERE us.IsDefault = 1
	ORDER BY CASE 
			WHEN UserWorkflowId = @UserWorkflowId
				THEN 0
			ELSE 1
			END
		,[UserWorkflowId]
		,[Index]
END
go

