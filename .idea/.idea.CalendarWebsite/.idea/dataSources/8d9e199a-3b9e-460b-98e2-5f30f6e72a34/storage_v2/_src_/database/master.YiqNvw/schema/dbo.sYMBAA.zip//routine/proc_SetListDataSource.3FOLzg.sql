CREATE PROC [dbo].[proc_SetListDataSource](
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @DataSource nvarchar(max),
    @EntityId int,
    @RequestGuid uniqueidentifier = NULL OUTPUT)    
AS
    SET NOCOUNT ON
    UPDATE 
        ALP 
    SET 
        DataSource = @DataSource,
        EntityId = @EntityId
    FROM 
        TVF_AllListsPlus_ListId(@SiteId, @ListId) AS ALP

go

