CREATE FUNCTION [dbo].[TVF_UserInfo_NoLock_SID]
(
    @tp_SiteID uniqueidentifier,
    @tp_SystemID tSystemID
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[UserInfo] WITH (NOLOCK, INDEX=UserInfo_SID, FORCESEEK)
    WHERE
        tp_SiteID = @tp_SiteID AND
        tp_SystemID = @tp_SystemID

go

