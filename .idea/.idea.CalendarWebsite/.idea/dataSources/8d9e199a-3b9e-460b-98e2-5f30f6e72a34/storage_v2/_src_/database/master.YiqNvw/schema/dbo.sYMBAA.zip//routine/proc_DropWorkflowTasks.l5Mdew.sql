CREATE PROCEDURE [dbo].[proc_DropWorkflowTasks] (
        @WorkflowInstanceId    uniqueidentifier,
        @SiteId                uniqueidentifier,
        @WebId                 uniqueidentifier,
        @TaskListId            uniqueidentifier
        )
AS
    SET NOCOUNT ON
    DECLARE @ItemId int
    DECLARE @ItemIdList TABLE (ItemId INT)
    INSERT INTO
	    @ItemIdList
	SELECT 
            NVP.ItemId
        FROM 
            NameValuePair AS NVP WITH (INDEX=NameValuePair_CI)
        WHERE
            NVP.SiteId = @SiteId AND
            NVP.ListId = @TaskListId AND
            NVP.FieldId = 'DE8BEACF-5505-47CD-80A6-AA44E7FFE2F4' AND 
            NVP.Value = @WorkflowInstanceId
    DECLARE @WorkflowTask CURSOR
    SET @WorkflowTask = CURSOR LOCAL FAST_FORWARD FOR
    (
        SELECT 
            ItemId
        FROM 
            @ItemIdList
    )
    OPEN @WorkflowTask
    IF @@CURSOR_ROWS <> 0
    BEGIN
        FETCH NEXT FROM @WorkflowTask INTO @ItemId
        WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE @Ret int SET @Ret = 0 BEGIN TRAN
            EXEC @Ret = proc_DropListRecord
                @SiteId,
                @WebId, 
                @TaskListId, 
                0, 
                @ItemId,
                1, 
                0, 
                NULL,
                NULL,
                0, 
                0, 
                0, 
                NULL, 
                3 
            IF (@Ret <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN
            FETCH NEXT FROM @WorkflowTask INTO @ItemId
        END
    END
    CLOSE @WorkflowTask
    DEALLOCATE @WorkflowTask
    IF (@Ret = 0)
    BEGIN
        EXEC proc_UpdateListItemCount @SiteId, @TaskListId
        EXEC proc_UpdateDiskUsed @SiteId
    END

go

