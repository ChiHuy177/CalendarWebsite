
-- =============================================
-- Author:		Duy Dam
-- Create date: 27/09/2021
-- Description:	Get the list of PersonalProfile in groups with @GroupId
-- =============================================
CREATE   PROCEDURE [dbo].[PersonalProfile_GetAllFromGroup] @GroupId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT p.*
	FROM PersonalProfile p
	LEFT JOIN GroupPersonalProfile g ON g.PersonalProfilesId = p.Id
	WHERE p.IsDeleted != 1
		AND g.GroupsId = @GroupId
END
go

