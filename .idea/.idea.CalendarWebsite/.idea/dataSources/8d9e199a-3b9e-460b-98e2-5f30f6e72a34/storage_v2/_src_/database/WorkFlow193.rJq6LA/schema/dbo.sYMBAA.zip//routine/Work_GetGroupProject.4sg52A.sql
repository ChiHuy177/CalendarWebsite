-- Work_GetGroupProject 333572             
   CREATE   PROC [dbo].Work_GetGroupProject             
   @projectId as char(50)             
   ,@userId as nvarchar(50)=''            
   as             
   select a.Id      
   ,a.UserWorkflowId       
   ,a.UserWorkflowId   as [Key]
   ,a.Ten      
   ,a.ProjectId      
   ,a.Status      
   , a.StartDate      
   ,a.DueDate      
   ,a.IsDelete
   ,a.IsDefault
   ,a.[Index]
   ,ISNULL(a.GroupParent,'') as GroupParent
   ,a.IsParent             
   ,b.Ten as GroupParentName , 0 as Qty         
   ,a.AlowAddWork    
   ,a.UserExecDefault  
   into #Group          
   from Dynamic.Data_ProjectGroup a             
   left join Dynamic.Data_ProjectGroup b on a.GroupParent=b.UserWorkflowId and ISNULL(b.IsDelete,'False')='False'             
   where a.ProjectId=@projectId and ISNULL(a.IsDelete,'False')='False' --and ISNULL(a.IsParent,'')=''             
   if(select COUNT(*) from #Group )>0        
   begin         
   insert into #Group (id, UserWorkflowId,Ten,Qty, [Index],GroupParent) values (-999,'-999',N'Trống (Chưa chọn) ',0,9999999,'')        
   end        
   select b.UserWorkflowId,COUNT(a.UserWorkflowId) as Qty           
   into #b          
   from Dynamic.Data_WORK a          
   inner join  #Group b on b.UserWorkflowId=ISNULL(a.GroupProject,'-999')         
   where ISNULL(a.IsActive,'True')='True' and ISNULL(a.WorkRepeat,'False')='False'             
   and @userId = (    
   case when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoixuly,''), ';') where value=@userId )>0 then @userId             
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoigiao,''), ';') where value=@userId )>0 then @userId             
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoiphoihop,''), ';') where value=@userId )>0 then @userId             
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.Nguoitheodoi,''), ';') where value=@userId )>0 then @userId             
   when (SELECT COUNT(*) FROM STRING_SPLIT(isnull(a.NguoiXuLyDauTien,''), ';') where value=@userId )>0 then @userId             
   else '' end             
   )             
   and a.Duan=@projectId        
   group by b.UserWorkflowId          
   update a set a.Qty=b.Qty          
   from #Group a inner join #b b on a.UserWorkflowId=b.UserWorkflowId          
   select * from #Group  order by [Index]        
   drop table #Group          
   drop table #b
go

