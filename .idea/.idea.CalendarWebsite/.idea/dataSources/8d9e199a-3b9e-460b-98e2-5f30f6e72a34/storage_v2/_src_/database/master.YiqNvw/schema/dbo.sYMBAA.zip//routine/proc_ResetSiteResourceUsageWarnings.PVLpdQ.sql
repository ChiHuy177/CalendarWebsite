CREATE PROC [dbo].[proc_ResetSiteResourceUsageWarnings]
AS
    SET NOCOUNT ON
    UPDATE
        S
    SET
        S.CurrentResourceUsage = 0,
        S.BitFlags = CASE
            WHEN 0 >= S.ResourceUsageMaximum 
            THEN S.BitFlags | 8388608 | 4194304
            ELSE S.BitFlags & (~(2097152 |
            4194304 |
            8388608))
            END
    FROM
        TVF_Sites_ALL() AS S
    RETURN 0

go

