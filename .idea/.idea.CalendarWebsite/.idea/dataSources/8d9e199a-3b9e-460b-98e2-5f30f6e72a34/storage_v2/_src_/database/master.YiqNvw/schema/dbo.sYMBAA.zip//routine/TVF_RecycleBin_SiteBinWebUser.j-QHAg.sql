CREATE FUNCTION [dbo].[TVF_RecycleBin_SiteBinWebUser]
(
    @SiteId uniqueidentifier,
    @BinId tinyint,
    @WebId uniqueidentifier,
    @DeleteUserId int
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[RecycleBin] WITH (INDEX=RecycleBin_SiteBinWebUser, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        BinId = @BinId AND
        WebId = @WebId AND
        DeleteUserId = @DeleteUserId

go

