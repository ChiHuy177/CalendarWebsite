
-- =============================================
-- Author:		Duy Dam
-- Create date: 15/06/2022
-- Description:	Get the maximum index of userworkflow
-- =============================================
CREATE   PROCEDURE [dbo].[UserWorkflowStep_GetMaximumStepNumber] @UserWorkflowId BIGINT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT MAX([ws].[Step])
	FROM dbo.UserWorkflowStep us
	JOIN dbo.WorkflowStep ws ON ws.Id = us.WorkflowStepId
	WHERE us.UserWorkflowId = @UserWorkflowId
		AND us.IsDeleted = 0
		AND us.IsDefault = 1;
END
go

