CREATE FUNCTION [dbo].[TVF_AllListsPlus_ListId]
(
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllListsPlus] WITH (INDEX=AllListsPlus_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ListId = @ListId

go

