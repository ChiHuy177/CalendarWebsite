-- Work_ShareFileByWorkId 213536,'LibraryBecawork290323'    
   CREATE   PROC  [dbo].[Work_ShareFileByWorkId]        
   @workId as nvarchar(50)      
   ,@db as nvarchar(250)    
   as        
   declare @sql as nvarchar(max)    
   set @sql='    
   declare @a as nvarchar(500)  
   set @a=( select  ISNULL( Nguoixuly,'''')+'';''+ ISNULL(Nguoigiao,'''') +'';''+ ISNULL(Nguoiphoihop,'''') +'';''+ISNULL(Nguoitheodoi,'''')      
   from Dynamic.Data_WORK where UserWorkflowId='+@workId+')      
   select REPLACE(value,''P:'','''') as Id      
   ,'+@workId+' as WorkId      
   into #a      
   from string_split(@a,'';'')      
   where value<>''''      
   select       
   c.Path as  [FileId]
   ,a.Id [UserId]
   ,null [DepartmentId]
   ,null [GroupId]
   ,0 [AllowEdit]
   ,1 [IsSharedByWorkflow]
   , ''duydd1'' as [CreatedBy]
   ,GETDATE() as [CreatedTime]
   ,''duydd1'' as [LastModified]
   ,GETDATE() as [ModifiedBy]
   ,0 as [IsDeleted]
   ,null as [Note]   
   into #b      
   from PersonalProfile a            
   inner join #a b on a.Id=b.Id      
   inner join Dynamic.CheckList_WORK c on c.UserWorkflowId=b.WorkId      
   group by a.Id,c.Path      
   delete a from '+@db+'.dbo.SharedFile a      
   inner join #b b on TRIM(str(a.FileId))=b.FileId      
   INSERT INTO '+@db+'.[dbo].[SharedFile]
   ([FileId]
   ,[UserId]
   ,[DepartmentId]
   ,[GroupId]
   ,[AllowEdit]
   ,[IsSharedByWorkflow]
   ,[CreatedBy]
   ,[CreatedTime]
   ,[LastModified]
   ,[ModifiedBy]
   ,[IsDeleted]
   ,[Note])
   select * from #b where ISNUMERIC(FileId)=1  
   drop table #a      
   drop table #b   
   '    
   exec(@sql)    
   print(@sql)  
go

