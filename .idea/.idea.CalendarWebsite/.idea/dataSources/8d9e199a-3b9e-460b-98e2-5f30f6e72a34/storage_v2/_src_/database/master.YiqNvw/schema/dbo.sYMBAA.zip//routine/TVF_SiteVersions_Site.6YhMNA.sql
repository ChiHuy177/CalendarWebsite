CREATE FUNCTION [dbo].[TVF_SiteVersions_Site]
(
    @SiteId uniqueidentifier
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[SiteVersions] WITH (INDEX=SiteVersionsId_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId

go

