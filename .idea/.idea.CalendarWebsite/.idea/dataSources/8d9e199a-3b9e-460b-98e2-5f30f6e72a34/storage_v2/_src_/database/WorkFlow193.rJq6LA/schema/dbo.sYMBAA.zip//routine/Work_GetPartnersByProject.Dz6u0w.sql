CREATE   PROC [dbo].[Work_GetPartnersByProject] 
   @projectId as NVARCHAR(max) 
   as 
   declare @tb table (Id nvarchar(50) , AccountId nvarchar(50), AccountName nvarchar(150) 
   , FullName nvarchar(250), DepartmentId bigint) 
   SELECT  
   b.value AS userId 
   , 1 as [Index] 
   into #UserManager 
   FROM DYNAMIC.Data_RESOURCEDA AS a  
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   WHERE a.UserWorkflowId = @projectId 
   select * into #a from ( 
   SELECT  
   b.value AS userId 
   FROM DYNAMIC.Data_RESOURCEDA AS a  
   CROSS APPLY STRING_SPLIT(a.QuanLy, ';') as b 
   WHERE a.UserWorkflowId = @projectId 
   union 
   SELECT  
   b.value AS userId 
   FROM DYNAMIC.Data_RESOURCEDA AS a  
   CROSS APPLY STRING_SPLIT(a.ThanhPhanThamGia, ';') as b 
   WHERE a.UserWorkflowId = @projectId 
   ) a 
   insert into @tb 
   SELECT 'P:'+ trim(str(c.Id)) AS Id 
   ,[AccountId] 
   ,[AccountName]  
   ,[FullName]  
   ,c.DepartmentId 
   FROM #a a 
   INNER JOIN PersonalProfile c ON REPLACE(a.userId,'P:','') =trim(str(c.Id)) 
   where left(trim(a.userId),1)='P' and c.UserStatus = 1 
   union  
   SELECT 'P:'+trim(str(b.Id)) AS Id 
   ,[AccountId] 
   ,[AccountName]  
   ,[FullName]  
   ,b.DepartmentId  
   FROM #a a  
   inner join GroupPersonalProfile c on REPLACE(a.userId,'G:','')=c.GroupsId 
   INNER JOIN PersonalProfile b ON b.Id =c.PersonalProfilesId 
   where left(trim(a.userId),1)='G' and b.UserStatus = 1 
   select p.Id,AccountName,CONCAT(p.FullName,' - ',AccountName,' - ', d.Title) as FullName from @tb p 
   inner join [dbo].Department d on 
   p.DepartmentId = d.Id 
   group by p.Id,AccountName,p.FullName , d.Title 
   drop table #a 
   drop table #UserManager 
go

