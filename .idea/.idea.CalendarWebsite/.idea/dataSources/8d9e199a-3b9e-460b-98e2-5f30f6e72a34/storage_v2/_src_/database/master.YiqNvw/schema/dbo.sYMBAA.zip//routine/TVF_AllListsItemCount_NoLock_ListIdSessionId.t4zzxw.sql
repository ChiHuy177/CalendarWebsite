CREATE FUNCTION [dbo].[TVF_AllListsItemCount_NoLock_ListIdSessionId]
(
    @SiteId uniqueidentifier,
    @ListId uniqueidentifier,
    @SessionId smallint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllListsItemCount] WITH (NOLOCK, INDEX=AllListsItemCount_PK, FORCESEEK)
    WHERE
        SiteId = @SiteId AND
        ListID = @ListId AND
        SessionId = @SessionId

go

