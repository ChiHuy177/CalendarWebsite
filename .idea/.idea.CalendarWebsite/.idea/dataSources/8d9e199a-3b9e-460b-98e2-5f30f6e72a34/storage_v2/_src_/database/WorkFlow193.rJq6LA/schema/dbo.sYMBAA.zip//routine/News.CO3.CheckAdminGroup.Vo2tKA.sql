-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[News.CO3.CheckAdminGroup] @userId BIGINT,
@userWorkflowId Bigint
AS
BEGIN
	SET NOCOUNT ON;

SELECT dw.*

FROM [Dynamic].[Workflow_GroupNews] [dw]
INNER JOIN UserWorkflow u ON u.Id = dw.UserWorkflowId
WHERE u.IsDeleted = 0

  AND (
  dw.UserWorkflowId=@userWorkflowId
  and
     (
      ISNULL(dbo.JSON_VALUE([dw].Data, '$.Admin'), '') <> ''
      AND (dbo.JSON_VALUE([dw].Data, '$.Admin') LIKE ('%' + CAST(@userId AS VARCHAR) + '%'))
      )
	     
    )
END
go

