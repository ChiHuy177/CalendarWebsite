CREATE   PROC Work_123
 as
 select * from Workflow
go

