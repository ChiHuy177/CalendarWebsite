CREATE FUNCTION [dbo].[TVF_AllUserDataJunctions_SiteDel]
(
    @tp_SiteId uniqueidentifier,
    @tp_DeleteTransactionId varbinary(16)
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllUserDataJunctions] WITH (INDEX=AllUserDataJunctions_PK, FORCESEEK)
    WHERE
        tp_SiteId = @tp_SiteId AND
        tp_DeleteTransactionId = @tp_DeleteTransactionId

go

