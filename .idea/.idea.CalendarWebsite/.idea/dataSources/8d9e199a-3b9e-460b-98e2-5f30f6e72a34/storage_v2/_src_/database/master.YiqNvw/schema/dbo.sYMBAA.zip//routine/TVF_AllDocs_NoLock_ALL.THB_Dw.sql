CREATE FUNCTION [dbo].[TVF_AllDocs_NoLock_ALL]
(
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[AllDocs] WITH (NOLOCK, INDEX=AllDocs_ParentId)
    WHERE
        1 = 1

go

