-- Work_GetValueByWorkFlowIdAndId 600,24594   
   CREATE   PROC [dbo].[Work_GetValueByWorkFlowIdAndId]   
   @workFlowId as bigint =102   
   ,@UserWorkflowId as bigint = 213301   
   as   
   DECLARE @colsUnpivot AS NVARCHAR(MAX),@colsUnpivotValues as nvarchar(max), @query AS NVARCHAR(MAX), @table as nvarchar(250),@tableDynamic as nvarchar(250),@code as nvarchar(250)   
   set @code=( select [dbo].[Work_ReplaceInvalidChars]( Code) from Workflow where Id=@workFlowId)  
   if(@code='work')   
   begin   
   update Dynamic.Data_WORK set NguoiXuLyDauTien=REPLACE(NguoiXuLyDauTien,',',';'),Nguoixuly=REPLACE(Nguoixuly,',',';'),Nguoiphoihop=REPLACE(Nguoiphoihop,',',';') where UserWorkflowId=@UserWorkflowId   
   end   
   set @table= ('Data_' +trim(@code))   
   set @tableDynamic = ('Dynamic.Data_' +trim(@code))   
   select @colsUnpivot   
   = stuff((select ','+quotename(C.column_name)   
   from information_schema.columns as C   
   where C.table_name = @table --and   
   --C.column_name like 'Indicator%'   
   for xml path('')), 1, 1, '')   
   select @colsUnpivotValues   
   = stuff((select ', isnull( CAST (' + quotename(C.column_name)+' as nvarchar(max)),''-999'') as '+ quotename(C.column_name)   
   from information_schema.columns as C   
   where C.table_name = @table --and   
   --C.column_name like 'Indicator%'   
   for xml path('')), 1, 1, '')   
   set @query   
   = '   
   select ''Code'' as name,case when ISNULL(WorkflowCode,'''') ='''' then N'''+N'[Chưa nhập mã]'+''' else WorkflowCode end  as value from UserWorkflow where id='+str(@UserWorkflowId)+'   
   union   
   select name12345, case when name12345=N''IsActive'' and value ='''' then ''True''   
   when value =''-999'' then null   
   else value end as value   
   from (select '+@colsUnpivotValues+' from '+@tableDynamic+' where UserWorkflowId = '+str(@UserWorkflowId)+') p   
   unpivot   
   (   
   value   
   for name12345 in ('+ @colsunpivot +')   
   ) u '   
   print(cast( @query as text))  
   exec sp_executesql @query;
go

