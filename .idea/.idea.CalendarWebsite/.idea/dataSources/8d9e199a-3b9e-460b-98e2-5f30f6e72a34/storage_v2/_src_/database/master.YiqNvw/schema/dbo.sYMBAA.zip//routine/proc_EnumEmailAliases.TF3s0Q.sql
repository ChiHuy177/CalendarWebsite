CREATE PROC [dbo].[proc_EnumEmailAliases]
AS
    SET NOCOUNT ON
    SELECT
        L.tp_EmailAlias,
        W.SiteId,
        L.tp_WebId,
        L.tp_ID
    FROM
        Lists AS L
    CROSS APPLY
        TVF_Webs_Id(L.tp_SiteId, L.tp_WebId) AS W
    WHERE
        L.tp_EmailAlias IS NOT NULL

go

