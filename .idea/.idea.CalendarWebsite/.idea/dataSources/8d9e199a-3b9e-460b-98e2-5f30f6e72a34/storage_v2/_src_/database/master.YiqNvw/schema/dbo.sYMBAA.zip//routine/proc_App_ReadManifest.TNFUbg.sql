CREATE Procedure [dbo].[proc_App_ReadManifest] (
    @PackageFingerprint binary(64),
    @SiteId uniqueidentifier
)
AS
SET NOCOUNT ON
SELECT Manifest FROM TVF_AppPackages_PackageFingerprint(@SiteId, @PackageFingerprint)

go

