-- [Work_GetExistedCoupon] 'work','','P:287',264522
   CREATE   PROC [dbo].[Work_GetExistedCoupon]     
   @type as nvarchar(50)     
   ,@code as nvarchar(500)     
   ,@userId as nvarchar(50)     
   ,@projectOrWorkId as nvarchar(50)-- id la projectId hay workId     
   as     
   if(@type='Project')     
   begin     
   --select Id into #a from Workflow where Code not in (select * from string_split(@code,',')) and WorkflowType = 0    
   select a.Id as [Value], trim(WorkflowCode) +' - ' + ShortContent as Label     
   from UserWorkflow a     
   left join Dynamic.Data_ProjectLinkCoupon b on a.Id=b.CouponId and b.ProjectId= @projectOrWorkId     
   inner join     
   (     
   select distinct a.Id from UserWorkflow a     
   inner join UserWorkflowStep b on a.Id=b.UserWorkflowId     
   left join UserWorkflowShare c on c.UserWorkflowId=a.Id    
   where 'P:'+ trim(STR(a.UserId)) = @userId or 'P:'+ trim(STR(b.UserId))=@userId or 'P:'+ trim(STR(c.UserId))=@userId    
   )c on a.Id=c.Id    
   inner join Workflow d on a.WorkflowId=d.Id    
   where a.IsDeleted=0  and WorkflowType in(0,3)	   
   and b.CouponId is null     
   end     
   else if(@type='work')     
   begin     
   --select Id into #b from Workflow where Code not in (select * from string_split(@code,',')) and WorkflowType = 0     
   select a.Id as [Value], trim(WorkflowCode) +' - ' + ShortContent as Label from UserWorkflow a     
   left join Dynamic.Data_ProjectLinkCoupon b on a.Id=b.CouponId and b.WorkId= @projectOrWorkId     
   inner join     
   (     
   select distinct a.Id from UserWorkflow a     
   inner join UserWorkflowStep b on a.Id=b.UserWorkflowId     
   left join UserWorkflowShare c on c.UserWorkflowId=a.Id    
   where 'P:'+ trim(STR(a.UserId)) = @userId or 'P:'+ trim(STR(b.UserId))=@userId or 'P:'+ trim(STR(c.UserId))=@userId    
   )c on a.Id=c.Id    
   inner join Workflow d on a.WorkflowId=d.Id    
   where a.IsDeleted=0  and WorkflowType in(0,3)
   and b.CouponId is null     
   end
go

