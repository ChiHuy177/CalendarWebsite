CREATE PROCEDURE [dbo].[proc_DeleteCustomActionsForFeature](
                                    @SiteId uniqueidentifier,
                                    @WebId uniqueidentifier,
                                    @FeatureId uniqueidentifier,
                                    @SolutionLevel int,
                                    @ResourceWebId uniqueidentifier)
AS
BEGIN
    SET NOCOUNT ON  
    DECLARE @rowCount int
    DECLARE @updateListFlags bit
    DECLARE @updateSiteWebFlags bit
    SET @rowCount = 0
    SET @updateListFlags = 0
    SET @updateSiteWebFlags = 0
    DECLARE @returnCode int SET @returnCode = 0 BEGIN TRAN
    IF ((NOT ((@SiteId IS NULL) OR (@SiteId = '00000000-0000-0000-0000-000000000000'))) AND
        (NOT ((@WebId IS NULL) OR (@WebId = '00000000-0000-0000-0000-000000000000'))))
    BEGIN
        SELECT TOP 1
            ScopeId
        FROM
            TVF_CustomActions_CFeat(@SiteId, @WebId, @FeatureId, @SolutionLevel)
        Where
            ScopeType = 4
        SELECT @returnCode=@@ERROR, @rowCount=@@ROWCOUNT
        IF (0 <> @returnCode)
        BEGIN
            GOTO cleanup
        END
        IF (0 <> @rowCount)
        BEGIN
            SET @updateListFlags = 1
            DECLARE @listIdsTmpTable TABLE(Id uniqueidentifier NOT NULL)
            INSERT INTO
                @listIdsTmpTable
            SELECT DISTINCT
                ScopeId
            FROM
                TVF_CustomActions_CFeat(@SiteId, @WebId, @FeatureId, @SolutionLevel)
            Where
                ScopeType = 4
        END   
    END
    DELETE 
        R
    FROM
        TVF_CustomActions_CFeat(@SiteId, @WebId, @FeatureId, @SolutionLevel) AS CA
    CROSS APPLY
        TVF_Resources_Web(CA.SiteId, @ResourceWebId) AS R
    WHERE
        R.ResourceName LIKE  (N'{' + CAST(CA.Id AS nvarchar(1024)) + N'}' + '_%')
    SELECT @returnCode=@@ERROR, @rowCount=@@ROWCOUNT
    IF (0 <> @returnCode)
    BEGIN
        GOTO cleanup
    END
    DELETE 
        CA
    FROM
        TVF_CustomActions_CFeat(@SiteId, @WebId, @FeatureId, @SolutionLevel) AS CA
    SELECT @returnCode=@@ERROR, @rowCount=@@ROWCOUNT
    IF (0 <> @returnCode)
    BEGIN
        GOTO cleanup
    END
    IF (0 <> @rowCount)
    BEGIN
        IF ((@WebId IS NULL) OR (@WebId = '00000000-0000-0000-0000-000000000000'))
        BEGIN
            EXEC @returnCode = proc_UpdateSiteCustomActionFlag @SiteId
        END
        ELSE
        BEGIN
            EXEC @returnCode = proc_UpdateWebCustomActionFlag @SiteId, @WebId
        END
        IF (0 <> @returnCode)
        BEGIN
            GOTO cleanup
        END        
        IF (1 = @updateListFlags)
        BEGIN
            DECLARE @listId uniqueidentifier
            DECLARE listIdsCursor CURSOR LOCAL READ_ONLY FAST_FORWARD FOR
            SELECT
                Id
            FROM
                @listIdsTmpTable
            OPEN listIdsCursor
            FETCH NEXT FROM listIdsCursor INTO @listId
            WHILE (@@FETCH_STATUS = 0)
            BEGIN
                EXEC @returnCode = proc_UpdateListCustomActionFlag @SiteId, @WebId, @listId, 0
                IF (0 <> @returnCode)
                BEGIN
                    GOTO cleanup
                END
                FETCH NEXT FROM listIdsCursor INTO @listId
            END
        END
    END
Cleanup:
    IF (@returnCode <> 0 AND @@TRANCOUNT = 1) ROLLBACK TRAN ELSE COMMIT TRAN   
    RETURN @returnCode
END

go

