CREATE Procedure [dbo].[proc_App_SetUpdateAvailableOnInternalAppsList] (
    @SPApps tvpArrayOfInternalSPApps READONLY)
AS
BEGIN TRANSACTION
SET NOCOUNT ON
-- If the version number for a particular product Id of the tenant specified by the 
-- subscrption in the TVP is less than the version number of the product Id in the 
-- database then set the UpdateAvailable bit. As each component of the version number 
-- is stored separately we need to compare each version component separately and doing 
-- so using TVF would not be practical. 
UPDATE SourceInfo 
SET UpdateAvailable = CASE
    WHEN Apps.VersionMajor > Packages.VersionMajor OR
        (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor > Packages.VersionMinor) OR
        (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor = Packages.VersionMinor AND Apps.VersionBuild > Packages.VersionBuild) OR
        (Apps.VersionMajor = Packages.VersionMajor AND Apps.VersionMinor = Packages.VersionMinor AND Apps.VersionBuild = Packages.VersionBuild AND Apps.VersionRevision > Packages.VersionRevision)
        THEN 1
    ELSE 0
    END
FROM 
    @SPApps AS Apps
    CROSS APPLY TVF_Sites_SubscriptionId(Apps.SubscriptionId) AS Sites
    CROSS APPLY TVF_AppPackages_ProductId(Sites.Id, Apps.ProductId) AS Packages
    CROSS APPLY TVF_AppSourceInfo_PackageFingerprint_AppSource(Sites.Id, Packages.PackageFingerprint, 2) AS SourceInfo
OPTION (FORCE ORDER)
COMMIT TRANSACTION

go

