
        CREATE VIEW [dbo].[Sites]
        AS
            SELECT
                *
            FROM
                AllSites
            WHERE
                Deleted = CONVERT(bit, 0)
    
go

