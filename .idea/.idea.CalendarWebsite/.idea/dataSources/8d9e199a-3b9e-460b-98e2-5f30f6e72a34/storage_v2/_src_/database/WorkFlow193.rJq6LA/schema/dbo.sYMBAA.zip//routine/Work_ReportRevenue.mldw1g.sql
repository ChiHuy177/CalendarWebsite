CREATE   PROC  [dbo].[Work_ReportRevenue]
   @projectId as nvarchar(50)='313131'
   ,@year as nvarchar(50)='2023'
   as
   select 
   (c.doanhthuth) as RevenueQuarter
   , (c.kehoachdt) as PlanRevenue
   , c.thoigian as time
   from Dynamic.Data_WORK a
   inner join Dynamic.Data_ProjectLinkCoupon b on a.UserWorkflowId=b.WorkId
   inner join Dynamic.data_DVVTGTCV c on b.CouponId=c.UserWorkflowId
   where a.Duan = @projectId and ISNULL(a.IsDelete,'False')='False' and ISNULL(b.IsDelete,'False')='False' 
   and year(c.thoigian) = @year
go

