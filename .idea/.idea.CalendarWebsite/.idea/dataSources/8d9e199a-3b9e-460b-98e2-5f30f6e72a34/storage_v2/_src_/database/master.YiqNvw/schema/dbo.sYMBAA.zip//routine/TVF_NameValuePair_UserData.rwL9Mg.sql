CREATE FUNCTION [dbo].[TVF_NameValuePair_UserData]
(
    @ListId uniqueidentifier,
    @ItemId int,
    @Level tinyint
)
RETURNS TABLE AS RETURN
    SELECT
        *
    FROM
        [dbo].[NameValuePair] WITH (INDEX=NameValuePair_MatchUserData, FORCESEEK)
    WHERE
        ListId = @ListId AND
        ItemId = @ItemId AND
        Level = @Level

go

