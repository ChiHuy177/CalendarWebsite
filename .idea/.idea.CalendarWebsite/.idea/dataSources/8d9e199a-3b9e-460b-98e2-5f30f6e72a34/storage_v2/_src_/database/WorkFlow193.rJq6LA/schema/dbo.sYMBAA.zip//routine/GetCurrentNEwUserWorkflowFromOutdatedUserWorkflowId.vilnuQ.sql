CREATE   PROCEDURE [dbo].[GetCurrentNEwUserWorkflowFromOutdatedUserWorkflowId]
	-- Add the parameters for the stored procedure here
	@OutdatedUserWorkflowId bigint
AS
BEGIN
	SET NOCOUNT ON;

    WITH [Temp]([Id]) AS (
				SELECT DISTINCT [f].[MainUserWorkflowId]
				FROM [UserWorkflowOutdated] [f]
				WHERE [f].[IsDeleted] = 0
					AND [f].[OutdatedUserWorkflowId] = @OutdatedUserWorkflowId
					
				
				UNION ALL
				
				SELECT [f].[MainUserWorkflowId]
				FROM [Temp] AS [t]
					,[UserWorkflowOutdated] AS [f]
				WHERE [t].[Id] = [f].[OutdatedUserWorkflowId]
					AND [f].[IsDeleted] = 0
				)
		SELECT top 1 u.*
		FROM [Temp] f
		inner join UserWorkflow u on u.ID = f.[Id] and u.IsOutdated = 0 and u.UserWorkflowStatus = 1
END
go

